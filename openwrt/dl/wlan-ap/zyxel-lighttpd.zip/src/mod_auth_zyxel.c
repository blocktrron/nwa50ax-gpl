#include "base.h"
#include "log.h"
#include "buffer.h"
#include "response.h"
#include "plugin.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <uam.h>
#include <user_profile.h>

#define HEADER(con, key)	((data_string *)array_get_element((con)->request.headers, (key)))

typedef struct {
	buffer *redirect;
	array *global_pattern_list; /* skip_pattern */
	array *user_pattern_list;
} plugin_config;

typedef struct {
	PLUGIN_DATA;

	plugin_config **config_storage;

	plugin_config conf;
} plugin_data;

int search_pattern(array *patterns, request_uri *uri)
{
	int found = 0, k = 0;
	int s_len = uri->path->used - 1;
	char *path = NULL, *pattstr = NULL;
	for (k = 0; k < patterns->used; k++) {
		data_string *ds = (data_string *)patterns->data[k];
		int ct_len = ds->value->used - 1;

		if (ct_len > s_len) continue;
		if (ds->value->used == 0) continue;
		/* deal with 127.0.0.1:10443 */
		if (ds->value->ptr[0] != '/') {
			if (0 == strncmp((char *)uri->authority->ptr, (char *)ds->value->ptr, ct_len)) {
				found = 1;
				break;
			}
		}
		else {
			if (NULL != strstr((char *)uri->path->ptr, (char *)ds->value->ptr)) {
				found = 1;
				break;
			}
		}
	}
	return found;
}

INIT_FUNC(mod_auth_zyxel_init) {
	plugin_data *p;

	p = calloc(1, sizeof(*p));

	return p;
}

FREE_FUNC(mod_auth_zyxel_free) {
	plugin_data *p = p_d;

	UNUSED(srv);

	if (!p) return HANDLER_GO_ON;

	if (p->config_storage) {
		size_t i;
		for (i = 0; i < srv->config_context->used; i++) {
			plugin_config *s = p->config_storage[i];
			if (!s) continue;
			if (s->redirect) buffer_free(s->redirect);
			if (s->global_pattern_list) array_free(s->global_pattern_list);
			if (s->user_pattern_list) array_free(s->user_pattern_list);

			free(s);
		}
		free(p->config_storage);
	}

	free(p);

	return HANDLER_GO_ON;
}

SETDEFAULTS_FUNC(mod_auth_zyxel_set_defaults) {
	plugin_data *p = p_d;
	size_t i = 0;

	config_values_t cv[] = {
		{ "auth_zyxel.AuthZyxelRedirect",           NULL, T_CONFIG_STRING, T_CONFIG_SCOPE_CONNECTION },
		{ "auth_zyxel.AuthZyxelSkipPattern",        NULL, T_CONFIG_ARRAY, T_CONFIG_SCOPE_CONNECTION },
		{ "auth_zyxel.AuthZyxelSkipUserPattern",	NULL, T_CONFIG_ARRAY, T_CONFIG_SCOPE_CONNECTION },
		{ NULL,                          			NULL, T_CONFIG_UNSET, T_CONFIG_SCOPE_UNSET }
	};
	
	if (!p) return HANDLER_ERROR;

	p->config_storage = calloc(1, srv->config_context->used * sizeof(plugin_config *));

	for (i = 0; i < srv->config_context->used; i++) {
		plugin_config *s;

		s = calloc(1, sizeof(plugin_config));
		s->redirect    			= buffer_init();
		s->global_pattern_list  = array_init();
		s->user_pattern_list    = array_init();

		cv[0].destination = s->redirect;
		cv[1].destination = s->global_pattern_list;
		cv[2].destination = s->user_pattern_list;

		p->config_storage[i] = s;

		if (0 != config_insert_values_global(srv, ((data_config *)srv->config_context->data[i])->value, cv, i == 0 ? T_CONFIG_SCOPE_SERVER : T_CONFIG_SCOPE_CONNECTION)) {
			return HANDLER_ERROR;
		}
	}

	return HANDLER_GO_ON;
}

#define PATCH(x) \
	p->conf.x = s->x;
static int mod_auth_zyxel_patch_connection(server *srv, connection *con, plugin_data *p) {
	size_t i, j;
	plugin_config *s = p->config_storage[0];

	PATCH(redirect);
	PATCH(global_pattern_list);
	PATCH(user_pattern_list);

	/* skip the first, the global context */
	for (i = 1; i < srv->config_context->used; i++) {
		data_config *dc = (data_config *)srv->config_context->data[i];
		s = p->config_storage[i];

		/* condition didn't match */
		if (!config_check_cond(srv, con, dc)) continue;

		/* merge config */
		for (j = 0; j < dc->value->used; j++) {
			data_unset *du = dc->value->data[j];
			if (buffer_is_equal_string(du->key, CONST_STR_LEN("auth_zyxel.AuthZyxelRedirect"))) {
				PATCH(redirect);
			}
			if (buffer_is_equal_string(du->key, CONST_STR_LEN("auth_zyxel.AuthZyxelSkipPattern"))) {
				PATCH(global_pattern_list);
			}
			if (buffer_is_equal_string(du->key, CONST_STR_LEN("auth_zyxel.AuthZyxelSkipUserPattern"))) {
				PATCH(user_pattern_list);
			}
		}
	}

	return 0;
}
#undef PATCH

/**
 * URI handler
 *
 * we will get called twice:
 * - after the clean up of the URL and 
 * - after the pathinfo checks are done
 *
 * this handles the issue of trailing slashes
 */
URIHANDLER_FUNC(mod_auth_zyxel_uri_handler) {
	plugin_data *p = p_d;
	size_t authtoklen;
	u_int32_t client_ip;
	data_string *ds;
	int globalallowed = 0, userallowed, uamret = 0;
	char *authtok = NULL, *idx = NULL;
	struct user_info uinfo;
	buffer *location = NULL;

	if (con->uri.path->used == 0 || con->uri.path->used == 1) return HANDLER_GO_ON;
	if ( con->uri.path->used == 2 && con->uri.path->ptr[0] == '/') {
		return HANDLER_GO_ON;
	}

	mod_auth_zyxel_patch_connection(srv, con, p);

	if (con->conf.log_request_handling) {
 		log_error_write(srv, __FILE__, __LINE__, "s", 
				"-- mod_auth_zyxel_uri_handler called");
	}
	client_ip = con->dst_addr.ipv4.sin_addr.s_addr;

	globalallowed = search_pattern(p->conf.global_pattern_list, &con->uri);
	if (globalallowed) {
		return HANDLER_GO_ON;
	}
	
#define AUTHTOK_ID	"authtok="
	do {
		ds = HEADER(con, "Cookie");
		if (ds == NULL) {
			break;
		}
		if ((idx = strstr(ds->value->ptr, AUTHTOK_ID)) == NULL) {
			break;
		}
		/* strlen(AUTHTOK_ID) == 8 */
		authtoklen = ds->value->used - 8 - (idx - ds->value->ptr);
		authtok = malloc(sizeof(char) * authtoklen);
		if (authtok == NULL) {
			return HANDLER_ERROR;
		}
		/* strlen(AUTHTOK_ID) == 8 */
		memcpy(authtok, idx + 8, authtoklen);
		if ((idx = strchr(authtok, ';')) == NULL) {
			break;
		}
		*idx = '\0';
	} while (0);

	if (authtok) {
		uamret = uam_find_first_match(&uinfo, SERVICE_NAME_HTTP_HTTPS, NULL, 0, authtok);
	}
	if (authtok) {
		free(authtok);
		authtok = NULL;
	}
	location = buffer_init();
	buffer_append_string_len(location, CONST_BUF_LEN(con->uri.scheme));
	buffer_append_string(location, "://");
	buffer_append_string_len(location, CONST_BUF_LEN(con->uri.authority));
	buffer_append_string_len(location, CONST_BUF_LEN(p->conf.redirect));
	if (uamret <= 0) {
		/* redirect */
		/*response_header_insert(srv, con, CONST_STR_LEN("Location"), CONST_BUF_LEN(p->conf.redirect));*/
		response_header_insert(srv, con, CONST_STR_LEN("Location"), CONST_BUF_LEN(location));
		con->http_status = 302;
		con->mode = DIRECT;
		con->file_finished = 1;
		if (location) {
			buffer_free(location);
			location = NULL;
		}
		return HANDLER_FINISHED;
	}
	userallowed = search_pattern(p->conf.user_pattern_list, &con->uri);
	if ((uinfo.type == USER_TYPE || uinfo.type == GUEST_TYPE) && (userallowed == 0)) {
		/* redirect */
		/*response_header_insert(srv, con, CONST_STR_LEN("Location"), CONST_BUF_LEN(p->conf.redirect));*/
		response_header_insert(srv, con, CONST_STR_LEN("Location"), CONST_BUF_LEN(location));
		con->http_status = 302;
		con->mode = DIRECT;
		con->file_finished = 1;
		if (location) {
			buffer_free(location);
			location = NULL;
		}
		return HANDLER_FINISHED;
	}
	
	if (location) {
		buffer_free(location);
		location = NULL;
	}
	return HANDLER_GO_ON;
}


int mod_auth_zyxel_plugin_init(plugin *p);
int mod_auth_zyxel_plugin_init(plugin *p) {
	p->version     = LIGHTTPD_VERSION_ID;
	p->name        = buffer_init_string("access");

	p->init        = mod_auth_zyxel_init;
	p->set_defaults = mod_auth_zyxel_set_defaults;
	p->handle_docroot = mod_auth_zyxel_uri_handler;
	p->cleanup     = mod_auth_zyxel_free;

	p->data        = NULL;

	return 0;
}

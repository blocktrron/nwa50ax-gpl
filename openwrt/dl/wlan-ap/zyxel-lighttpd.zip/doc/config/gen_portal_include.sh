rm -rf /var/zyxel/service_conf/portal_used.conf
ls /var/zyxel/service_conf/captive_portal_* >> /var/zyxel/service_conf/portal_used.conf
ls /var/zyxel/service_conf/findme_* >> /var/zyxel/service_conf/portal_used.conf
ls /var/zyxel/service_conf/cdr_* >> /var/zyxel/service_conf/portal_used.conf
sed -i 's/^/include \"/g' /var/zyxel/service_conf/portal_used.conf
sed -i 's/$/\"/g' /var/zyxel/service_conf/portal_used.conf

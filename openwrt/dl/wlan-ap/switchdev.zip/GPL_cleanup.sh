#!/usr/bin/env bash

# cleanup directory
rm -f *.mod.c *.mod.o *.o *.ko .*.cmd Module.symvers modules.order
rm -fr .tmp_versions/

# keep dev_cfg.c
if [ -L "./dev_cfg.c" ]; then
	dev_cfg="$(realpath ./dev_cfg.c)"
	rm -f ./dev_cfg.c && mv ${dev_cfg} ./dev_cfg.c
fi

#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <linux/module.h>
#include <linux/types.h>
#include <linux/seq_file.h>
#else
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/ptrace.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/timer.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <linux/ioctl.h>
#include <linux/init.h>
#include <linux/mtd/compatmac.h>
#include <linux/mtd/mtd.h>
#endif

#ifdef CONFIG_PROC_FS
#include <linux/proc_fs.h>
#endif
#include <zld-spec.h>
#include "switchdev.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
DEFINE_SEMAPHORE(switch_table_mutex);
#else
DECLARE_MUTEX(switch_table_mutex);
#endif
struct switch_info *switch_table[MAX_SWITCH_DEVICES];//is a pointer array,not a real table array

EXPORT_SYMBOL(switch_table_mutex);
EXPORT_SYMBOL(switch_table);

/**
 *	add_switch_device - register an SWITCH device
 *	@switch_dev: pointer to new SWITCH device info structure
 *
 *	Add a device to the list of SWITCH devices present in the system, and
 *	notify each currently active SWITCH 'user' of its arrival. Returns
 *	zero on success or 1 on failure, which currently will only happen
 *	if the number of present devices exceeds MAX_SWITCH_DEVICES (i.e. 16)
 */

int
add_switch_device(struct switch_info *switch_dev)
{
	int i;

	down(&switch_table_mutex);

	for (i=0; i < MAX_SWITCH_DEVICES; i++){
		if (!switch_table[i]) {
			switch_table[i] = switch_dev;
			switch_dev->index = i;
			switch_dev->usecount = 0;

//			DEBUG(0, "switch_dev: Giving out device %d to %s\n",i, switch_dev->name);
			/* No need to get a refcount on the module containing
			   the notifier, since we hold the switch_table_mutex */

			up(&switch_table_mutex);
			/* We _know_ we aren't being removed, because
			   our caller is still holding us here. So none
			   of this try_ nonsense, and no bitching about it
			   either. :) */
			__module_get(THIS_MODULE);
			return 0;
		}
	}

	up(&switch_table_mutex);
	return 1;
}

/**
 *	del_switch_device - unregister an SWITCH device
 *	@switch_dev: pointer to SWITCH device info structure
 *
 *	Remove a device from the list of SWITCH devices present in the system,
 *	and notify each currently active SWITCH 'user' of its departure.
 *	Returns zero on success or 1 on failure, which currently will happen
 *	if the requested device does not appear to be present in the list.
 */

int
del_switch_device (struct switch_info *switch_dev)
{
	int ret;

	down(&switch_table_mutex);

	if (switch_table[switch_dev->index] != switch_dev) {
		ret = -ENODEV;
	} else if (switch_dev->usecount) {
		printk(KERN_NOTICE "Removing SWITCH device #%d (%s) with use count %d\n",
			   switch_dev->index, switch_dev->name, switch_dev->usecount);
		ret = -EBUSY;
	} else {

		/* No need to get a refcount on the module containing
		   the notifier, since we hold the switch_table_mutex */

		switch_table[switch_dev->index] = NULL;

		module_put(THIS_MODULE);
		ret = 0;
	}

	up(&switch_table_mutex);
	return ret;
}


/**
 *  get_switch_cnt
 *		return the numner of register switch
 */
int
get_switch_num( void )
{
	int i;
	int count = 0;

	down(&switch_table_mutex);

	for (i=0; i < MAX_SWITCH_DEVICES; i++){
		if (switch_table[i]) {
			count ++;
		}
	}
	up(&switch_table_mutex);
	return count;
} /* get_switch_num */


/**
 *	get_switch_device - obtain a validated handle for an SWITCH device
 *	@switch_dev: last known address of the required SWITCH device
 *	@num: internal device number of the required SWITCH device
 *
 *	Given a number and NULL address, return the num'th entry in the device
 *	table, if any.	Given an address and num == -1, search the device table
 *	for a device with that address and return if it's still present. Given
 *	both, return the num'th driver only if its address matches. Return NULL
 *	if not.
 */

struct switch_info *
get_switch_device(struct switch_info *switch_dev, int num)
{
	struct switch_info *ret = NULL;
	int i;

	down(&switch_table_mutex);

	if (num == -1) {
		for (i=0; i< MAX_SWITCH_DEVICES; i++){
			if (switch_table[i] == switch_dev){
				ret = switch_table[i];
			}
		}
	}
	else if (num < MAX_SWITCH_DEVICES) {
		ret = switch_table[num];
		if (switch_dev && switch_dev != ret){
			ret = NULL;
		}
	}

	if (ret && !try_module_get(ret->owner)){
		ret = NULL;
	}

	if (ret){
		ret->usecount++;
	}

	up(&switch_table_mutex);
	return ret;
}

void
put_switch_device(struct switch_info *switch_dev)
{
	int c;

	down(&switch_table_mutex);
	c = --switch_dev->usecount;
	up(&switch_table_mutex);
	BUG_ON(c < 0);

	module_put(switch_dev->owner);
}

EXPORT_SYMBOL(add_switch_device);
EXPORT_SYMBOL(del_switch_device);
EXPORT_SYMBOL(get_switch_device);
EXPORT_SYMBOL(put_switch_device);
EXPORT_SYMBOL(get_switch_num);
/*====================================================================*/
/* Support for /proc/switch_dev */

#ifdef CONFIG_PROC_FS
static struct proc_dir_entry *proc_switch;

char *
str_ctrlif(uint8_t ctrlif)
{
	switch(ctrlif)
	{
		case SI_INTERFACE:
			return "SI";
		case PI_INTERFACE:
			return "PI";
		case PCI_INTERFACE:
			return "PCI";
		case SMI_INTERFACE:
			return "SMI";
	}
	return "";
}

static int switch_proc_show(struct seq_file *m, void *v)
{
	int i;
	struct switch_info *this = NULL;

	seq_printf(m,"%-10s:%16s %6s %9s\n","dev","name","ctrlif","totalport");
	for (i=0; i< MAX_SWITCH_DEVICES; i++) {
		this = switch_table[i];
		if (!this){
			return 0;
		}
		seq_printf(m,"switch%-2d  :%16s %6s %9d\n",i,this->name,str_ctrlif(this->ctrlif),this->totalport);
		this = NULL;
	}
	return 0;
}

static int switch_proc_open(struct inode *inode, struct file *file)
{
	return single_open(file, switch_proc_show, NULL);
}

static const struct file_operations proc_file_fops = {
	.open  		= switch_proc_open,
	.read  		= seq_read,
	.llseek		= seq_lseek,
	.release	= single_release,
};
#endif /* CONFIG_PROC_FS */

/*====================================================================*/
/* Init code */

static int __init
switch_init(void)
{
	int i;
#ifdef CONFIG_PROC_FS
	proc_switch = proc_create("switch", 0, NULL, &proc_file_fops);
#endif

	for(i=0;i<=MAX_SWITCH_DEVICES-1;i++){
		switch_table[i] = NULL;
	}
	init_zld_port_tbl ( get_zld_port_cfg_table(), ZLD_MAX_ETHER_PORT_NUM );
	init_zld_port_tbl ( get_zld_port_ext_cfg_table(), ZLD_MAX_ETHER_PORT_NUM );
	return 0;
}

static void __exit
switch_cleanup(void)
{
#ifdef CONFIG_PROC_FS
		if (proc_switch){
			remove_proc_entry( "switch", NULL);
		}
#endif
}

module_init(switch_init);
module_exit(switch_cleanup);

MODULE_LICENSE("Proprietary");
MODULE_AUTHOR("Heren Lin <heren.lin@zyxel.com.tw>");
MODULE_DESCRIPTION("Core SWITCH registration and access routines");

/*
[root@localhost /]# mknod /dev/switch0 c 92 0
[root@localhost /]# ll /dev/switch*
crw-r--r--    1 root     root      92,   0 Jun 19 16:15 /dev/switch0
crw-r--r--    1 root     root      92,   1 Jun 19 16:15 /dev/switch1
crw-r--r--    1 root     root      92,  10 Jun 19 16:16 /dev/switch10
crw-r--r--    1 root     root      92,  11 Jun 19 16:16 /dev/switch11
crw-r--r--    1 root     root      92,  12 Jun 19 16:16 /dev/switch12
crw-r--r--    1 root     root      92,  13 Jun 19 16:16 /dev/switch13
crw-r--r--    1 root     root      92,  14 Jun 19 16:16 /dev/switch14
crw-r--r--    1 root     root      92,  15 Jun 19 16:16 /dev/switch15
crw-r--r--    1 root     root      92,   2 Jun 19 16:15 /dev/switch2
crw-r--r--    1 root     root      92,   3 Jun 19 16:15 /dev/switch3
crw-r--r--    1 root     root      92,   4 Jun 19 16:15 /dev/switch4
crw-r--r--    1 root     root      92,   5 Jun 19 16:16 /dev/switch5
crw-r--r--    1 root     root      92,   6 Jun 19 16:16 /dev/switch6
crw-r--r--    1 root     root      92,   7 Jun 19 16:16 /dev/switch7
crw-r--r--    1 root     root      92,   8 Jun 19 16:16 /dev/switch8
crw-r--r--    1 root     root      92,   9 Jun 19 16:16 /dev/switch9
[root@localhost /]#
*/

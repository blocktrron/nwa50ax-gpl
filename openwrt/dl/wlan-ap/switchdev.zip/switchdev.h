#ifndef __SWITCHDEV_H__
#define __SWITCHDEV_H__

#include "switchdev-abi.h"

#define DEVNAME "switch"
#define SWITCH_CHAR_MAJOR 92
#define MAX_SWITCH_DEVICES 8

#define SI_INTERFACE  0
#define PI_INTERFACE  1
#define PCI_INTERFACE 2
#define SMI_INTERFACE 3

struct switch_info {
	uint16_t type;
	u_int32_t flags;
	u_int32_t size;

	// Kernel-only stuff starts here.
	char name[16];
	int index;
	int int_idx;
	void *priv;
	struct module *owner;
	int usecount;
	uint8_t ctrlif;//control interface:SI,PI,PCI,SMI
	uint16_t totalport;
	/* Sync */
	void (*sync) (struct switch_info *switch_dev);
	void (*switch_enable) (struct switch_info *switch_dev, unsigned char force_enable);
	void (*switch_port_enable) (struct switch_info *switch_dev, int port_num);
	void (*switch_disable) (struct switch_info *switch_dev);
	void (*switch_port_disable) (struct switch_info *switch_dev, int port_num);
	int (*switch_get_port_counter) (struct switch_info *switch_dev,switch_port_counter *sw_pc);
	void (*switch_clear_port_counter) (struct switch_info *switch_dev,switch_port_counter *sw_pc);
	int (*switch_set_port_status) (struct switch_info *switch_dev,switch_port_status *sw_ps);
	int (*switch_get_port_status) (struct switch_info *switch_dev,switch_port_status *sw_ps);
	int (*switch_vlan_port_mode_set) (struct switch_info *switch_dev,switch_vlan_port_mode *sw_vpm);
	int (*switch_vlan_port_mode_get) (struct switch_info *switch_dev,switch_vlan_port_mode *sw_vpm);
	int (*switch_vlan_table_read) (struct switch_info *switch_dev,switch_vlan_table_entry *sw_vte);
	int (*switch_vlan_table_write) (struct switch_info *switch_dev,switch_vlan_table_entry *sw_vte);
	void (*switch_loopback_enable) (struct switch_info *switch_dev,int port_no);
	void (*switch_loopback_disable) (struct switch_info *switch_dev,int port_no);
	void (*switch_port_loopguard_status_func_set) (struct switch_info *switch_dev, switch_port_loopguard_status *set_value);
	void (*switch_port_loopguard_status_func_get) (struct switch_info *switch_dev, switch_port_loopguard_status *set_value);
	void (*switch_loopguard_status_func_set) (struct switch_info *switch_dev, int set_value);
	void (*switch_loopguard_status_func_get) (struct switch_info *switch_dev, int *set_value);
	/* debug */
	void (*switch_dbg_switch_reg_read) (struct switch_info *switch_dev,switch_reg *sw_reg);
	void (*switch_dbg_switch_reg_write) (struct switch_info *switch_dev,switch_reg *sw_reg);
	void (*switch_dbg_switch_mii_read) (struct switch_info *switch_dev,switch_mii *sw_mii);
	void (*switch_dbg_switch_mii_write) (struct switch_info *switch_dev,switch_mii *sw_mii);
#ifdef ZLDCONFIG_DEBUG_RGMII_TUNING
	void (*switch_dbg_switch_rgmii_delay_set)(struct switch_info *switch_dev, switch_rgmii_delay *sw_rd);
	void (*switch_dbg_switch_rgmii_delay_get)(struct switch_info *switch_dev, switch_rgmii_delay *sw_rd);
#endif
#ifdef ZLDCONFIG_ETH_STORM_CONTROL
	void (*switch_storm_control_set)(struct switch_info *switch_dev, storm_control_property_t *);
	void (*switch_storm_control_get)(struct switch_info *switch_dev, storm_control_property_t *);
#endif
	int (*switch_led_control) (struct switch_info *switch_dev, int operation);
};

	/* Kernel-side ioctl definitions */

extern int add_switch_device(struct switch_info *switch_dev);
extern int del_switch_device(struct switch_info *switch_dev);

extern int get_switch_num( void );
extern int get_total_port_num( void );
extern int get_sw_port_table(zld_port_cfg_t *port_p, zld_port_cfg_t *tbl_p, int size  );
extern zld_port_cfg_t *get_zld_port_cfg_table( void );
extern zld_port_cfg_t *get_zld_port_ext_cfg_table( void );
extern int get_zld_port_table_cnt( zld_port_cfg_t *port_p );
extern int get_sw_summary ( zld_sw_summary_t *zld_sw_summary_p );
extern int cfg_to_ext_cfg_table ( zld_port_cfg_t *cfg_port_p );
extern int find_ext_cfg_table_idx_by_name ( char *name );
extern int zld_port_table_add( int index, int switch_type, int switch_idx );
extern int init_zld_port_tbl ( zld_port_cfg_t *port_p, int cnt );
extern int zld_port_table_adjust( void );
extern zld_port_cfg_t *find_port_entry_by_sw_port( int sw_type, int reg_idx, int port );
extern int zyinit_mass_port_disable( int port );
extern zld_port_cfg_t *find_port_by_switch( int sw_type, int reg_idx );
extern int zyinit_get_enable_eth_port( int *enable_port );

/* switch_port_vlan_hook.c --> switch_vlan_hook.ko */
extern int cfg_vlan_table_by_vid(struct switch_info *switch_dev, switch_vlan_table_entry *sw_vte);
extern int find_vlan_table_by_vid(struct switch_info *switch_dev, switch_vlan_table_entry *sw_vte);
extern int cfg_pvid_by_port_no(struct switch_info *switch_dev,switch_vlan_port_mode *sw_vpm);
extern int find_pvid_by_port_no(struct switch_info *switch_dev,switch_vlan_port_mode *sw_vpm);

extern struct switch_info *get_switch_device(struct switch_info *switch_dev, int num);
extern void put_switch_device(struct switch_info *switch_dev);

#endif /* __SWITCHDEV_H__ */

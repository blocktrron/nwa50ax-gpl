#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/compat.h>
#else
#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#endif
#include <linux/netdevice.h>
#include <linux/if_vlan.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include "switchdev.h"

#if defined(ZLDCONFIG_LLDP)
#define ETH_P_LLDP                 0x88CC
#endif

#if defined(ZLDCONFIG_ZDP)
#define ETH_P_ZDP                  0xC1C1
#endif

#define HASHSIZE 4096
//#define DEBGU_SWITCHDEV 1

#ifdef DEBGU_SWITCHDEV
#define DEBUG_MSG(format,args...) \
        do{ \
				printk(KERN_EMERG format,##args); \
        } while(0)
#else
#define DEBUG_MSG(format,args...) \
        do {} while(0)
#endif

extern int (*switch_port_rx_vlan_hook)(struct sk_buff *skb);
extern int (*switch_port_tx_vlan_hook)(struct sk_buff *skb);

extern struct net_device *zld_find_vlan_dev(struct net_device *real_dev,unsigned short VID); /* vlan.c */
extern struct vlan_dev_info *zld_get_realdev_from_vlandev(struct net_device *dev); /* vlan.c */
extern uint16_t zld_get_vlanId_from_vlandev(struct net_device *dev); /* vlan.c */

/*
 * zld_port_tbl[ZLD_MAX_ETHER_PORT_NUM] entry <--> net_device
 */
static int zld_port_dev_init_flag = 0;
struct net_device *zld_port_dev_tbl[ZLD_MAX_ETHER_PORT_NUM];

static void reset_zld_port_dev_tbl(void)
{
	memset(zld_port_dev_tbl, 0, ZLD_MAX_ETHER_PORT_NUM * sizeof(struct net_device*));
	zld_port_dev_init_flag = 0;
}

static void init_zld_port_dev_tbl(void)
{
	struct net_device *dev;
	zld_port_cfg_t *tbl_p;

	tbl_p = get_zld_port_cfg_table();
	while ( tbl_p->ext_idx != ZLD_CFG_TBL_END ) {
		if ((dev = dev_get_by_name(&init_net, tbl_p->name)) != NULL) {
			zld_port_dev_tbl[tbl_p->ext_idx] = dev;
			dev_put(dev);
		}
		tbl_p++;
	}
}

static int find_cfg_table_idx_by_dev(struct net_device *dev)
{
	int i;

	if (zld_port_dev_init_flag == 0) {
		init_zld_port_dev_tbl();
		zld_port_dev_init_flag = 1;
	}
	for (i = 0; i < ZLD_MAX_ETHER_PORT_NUM; i++) {
		if (zld_port_dev_tbl[i] == dev) {
			return i;
		}
	}
	return ZLD_CFG_TBL_END; /* not found */
}

/*
 * VLAN TABLE
 */
/* support up to 2 switchdev now */
unsigned int vlanTable[2][4096];

typedef struct zld_untag_vlan_cfg_s {
	uint32_t   ext_idx;
	uint32_t   vlanID;
	struct list_head list;
} zld_untag_vlan_cfg_t;

struct list_head vlanUntagMemberTable[HASHSIZE];
DEFINE_SPINLOCK(UntagVlanlock);


static int findVlanNode(int ext_idx,int vlanID)
{
	zld_untag_vlan_cfg_t *vlanPtr;
	struct list_head *head;

	head= &vlanUntagMemberTable[(ext_idx+vlanID)%HASHSIZE];
	list_for_each_entry(vlanPtr, head,list) {
		if(vlanPtr->vlanID == vlanID && vlanPtr->ext_idx == ext_idx) {
			return 0;
		}
	}
	return -1;
}

static void dumpUntagVlanNode(void)
{
	zld_untag_vlan_cfg_t *vlanPtr;
	struct list_head *head= NULL;
	int i=0;
	printk(KERN_EMERG "=======================================================================\n\n");
	spin_lock(&UntagVlanlock);
	for(i=0; i<HASHSIZE; i++)
	{
		head= &vlanUntagMemberTable[i];
		if(head->next==head)	continue;

		list_for_each_entry(vlanPtr, head,list) {
			printk(KERN_EMERG "Device index=%d VLAN ID=%d\n",vlanPtr->ext_idx,vlanPtr->vlanID);
		}
		//printk(KERN_EMERG "\n\n");
	}
	spin_unlock(&UntagVlanlock);
	printk(KERN_EMERG "=======================================================================\n\n");
}

static void addUntagVlanNode(int ext_idx,int vlanID)
{

	zld_untag_vlan_cfg_t *vlanPtr;
	DEBUG_MSG("addUntagVlanNode ext_idx=%d vlanID=%d\n",ext_idx, vlanID);

	if(!findVlanNode(ext_idx,vlanID))	return;
	vlanPtr = (zld_untag_vlan_cfg_t *)kzalloc(sizeof(zld_untag_vlan_cfg_t),GFP_KERNEL);
	if (vlanPtr == NULL)  return;

	vlanPtr->ext_idx = ext_idx;
	vlanPtr->vlanID = vlanID;
	spin_lock(&UntagVlanlock);
	list_add(&vlanPtr->list, &vlanUntagMemberTable[(ext_idx+vlanID)%HASHSIZE]);
	spin_unlock(&UntagVlanlock);
	//dumpUntagVlanNode();
}

static int delUntagVlanNode(int ext_idx,int vlanID)
{
	zld_untag_vlan_cfg_t *vlanPtr,*n;
	struct list_head *head= NULL;

	spin_lock(&UntagVlanlock);
	head= &vlanUntagMemberTable[(ext_idx+vlanID)%HASHSIZE];
	if(head->next==head) {
		spin_unlock(&UntagVlanlock);
		return -1;
	}
	list_for_each_entry_safe(vlanPtr,n,head,list) {
		if(vlanPtr!=NULL && vlanPtr->vlanID == vlanID && vlanPtr->ext_idx == ext_idx) {
			list_del(&vlanPtr->list);
			kfree(vlanPtr);
			spin_unlock(&UntagVlanlock);
			//dumpUntagVlanNode();
			return 0;
		}
	}
	spin_unlock(&UntagVlanlock);
	return -1;
}

int cfg_vlan_table_by_vid(struct switch_info *switch_dev, switch_vlan_table_entry *sw_vte)
{
	zld_port_cfg_t *tbl_p = get_zld_port_cfg_table();

	//printk(KERN_EMERG "%s VLANID=%d mem_ports=%x, tagged_port=%x, untagged_ports=%x\n", __func__,
	//	   sw_vte->vid, sw_vte->port_no_bitfield, sw_vte->port_no_bitfield & (~sw_vte->untagmsk), sw_vte->untagmsk);
	vlanTable[switch_dev->index][sw_vte->vid] = sw_vte->port_no_bitfield;
	while ( tbl_p ->ext_idx != ZLD_CFG_TBL_END ) {
		if (tbl_p->sw_idx == switch_dev->index) {
			delUntagVlanNode(tbl_p->ext_idx,sw_vte->vid);
			if(sw_vte->untagmsk &(1 << tbl_p->front_idx)) {
				addUntagVlanNode(tbl_p->ext_idx,sw_vte->vid);
			}
		}
		tbl_p++;
	}
	return 0;
}

int find_vlan_table_by_vid(struct switch_info *switch_dev, switch_vlan_table_entry *sw_vte)
{
	zld_port_cfg_t *tbl_p = get_zld_port_cfg_table();

	sw_vte->port_no_bitfield = vlanTable[switch_dev->index][sw_vte->vid];
	sw_vte->untagmsk = 0;
	while ( tbl_p ->ext_idx != ZLD_CFG_TBL_END ) {
		if (tbl_p->sw_idx == switch_dev->index && (sw_vte->port_no_bitfield &(1 << tbl_p->front_idx))) {
			if(!findVlanNode(tbl_p->ext_idx,sw_vte->vid)) {
				sw_vte->untagmsk |= (1 << tbl_p->front_idx);
			}
		}
		tbl_p++;
	}
	//printk(KERN_EMERG "%s mem_ports=%x, untagged_ports=%x\n", __func__, sw_vte->port_no_bitfield, sw_vte->untagmsk);
	return 0;
}

/*
 * Switch Port PVID <-- 1-1 mapping --> net_device (Must)
 */
typedef struct zld_vlan_pvid_cfg_s {
	unsigned int      valid;
	unsigned int      pvid;
	unsigned int      is_uplinkport;
	struct net_device *dev;
	struct list_head  list;
} zld_vlan_pvid_cfg_t;

/* support up to 2 switchdev now */
zld_vlan_pvid_cfg_t vlanPvid[2][ZLD_MAX_ETHER_PORT_NUM+1];
struct list_head vlanPvid_list;
DEFINE_SPINLOCK(vlanPvid_lock);

static void reset_table_vlanPvid(void)
{
	int i, j;

	spin_lock(&vlanPvid_lock);
	for (i = 0; i < 2; i++) {
		for (j = 0; j < ZLD_MAX_ETHER_PORT_NUM+1; j++) {
			vlanPvid[i][j].valid = 0;
			vlanPvid[i][j].pvid  = 0;
			vlanPvid[i][j].is_uplinkport = 0;
			vlanPvid[i][j].dev   = NULL;
		}
	}
	vlanPvid_list.next = &vlanPvid_list;
	vlanPvid_list.prev = &vlanPvid_list;
	spin_unlock(&vlanPvid_lock);
}

int cfg_pvid_by_port_no(struct switch_info *switch_dev,switch_vlan_port_mode *sw_vpm)
{
	struct net_device *dev;
	zld_port_cfg_t *tbl_p = get_zld_port_cfg_table();

	//printk(KERN_EMERG "%s port %d, pvid %d\n", __func__, sw_vpm->port_no, sw_vpm->pvid);
	spin_lock(&vlanPvid_lock);
	/* tbl_p->front_idx == sw_vpm->port_no */
	if (sw_vpm->port_no <= ZLD_MAX_ETHER_PORT_NUM) {
		while ( tbl_p->ext_idx != ZLD_CFG_TBL_END ) {
			if ( tbl_p->sw_type == switch_dev->type &&  tbl_p->front_idx == sw_vpm->port_no) {
				if ((dev = dev_get_by_name(&init_net, tbl_p->name)) != NULL) {
					vlanPvid[switch_dev->index][sw_vpm->port_no].valid = 1;
					vlanPvid[switch_dev->index][sw_vpm->port_no].pvid  = sw_vpm->pvid;
					vlanPvid[switch_dev->index][sw_vpm->port_no].is_uplinkport = tbl_p->flags & ZLD_PORT_FLG_UPLINK_PORT;
					vlanPvid[switch_dev->index][sw_vpm->port_no].dev   = dev;
					dev_put(dev);
					{
						zld_vlan_pvid_cfg_t *vlan_pvid_entry, *n;
						struct list_head *head;
						head = &vlanPvid_list;
						list_for_each_entry_safe(vlan_pvid_entry, n, head, list) {
							if (&vlan_pvid_entry->list == &vlanPvid[switch_dev->index][sw_vpm->port_no].list) {
								list_del(&vlan_pvid_entry->list);
								vlan_pvid_entry->list.prev = &vlan_pvid_entry->list;
								vlan_pvid_entry->list.next = &vlan_pvid_entry->list;
								break;
							}
						}
						if (sw_vpm->pvid > 0) {
							list_add(&vlanPvid[switch_dev->index][sw_vpm->port_no].list, &vlanPvid_list);
						}
					}
					spin_unlock(&vlanPvid_lock);
					return 0;
				}
			}
			tbl_p++;
		}
	}
	spin_unlock(&vlanPvid_lock);
	return -1;
}

int find_pvid_by_port_no(struct switch_info *switch_dev,switch_vlan_port_mode *sw_vpm)
{
	/* tbl_p->front_idx == sw_vpm->port_no */
	if (vlanPvid[switch_dev->index][sw_vpm->port_no].valid == 1) {
		sw_vpm->pvid = vlanPvid[switch_dev->index][sw_vpm->port_no].pvid;
		//printk(KERN_EMERG "%s port %d, pvid %d\n", __func__, sw_vpm->port_no, sw_vpm->pvid);
		return 0;
	}
	return -1;
}

static int find_pvid_by_dev(struct net_device *dev)
{
	zld_vlan_pvid_cfg_t *vlan_pvid_entry;
	struct list_head *head;

	head = &vlanPvid_list;
	list_for_each_entry(vlan_pvid_entry, head, list) {
		if ((vlan_pvid_entry->valid == 1) && (vlan_pvid_entry->dev == dev)) {
			return vlan_pvid_entry->pvid;
		}
	}
	/* not found in list, default PVID set to 0 */
	return 0;
}

static int check_uplinkport_by_dev(struct net_device *dev)
{
	zld_vlan_pvid_cfg_t *vlan_pvid_entry;
	struct list_head *head;

	head = &vlanPvid_list;
	list_for_each_entry(vlan_pvid_entry, head, list) {
		if ((vlan_pvid_entry->valid == 1) && (vlan_pvid_entry->dev == dev)) {
			return vlan_pvid_entry->is_uplinkport;
		}
	}
	/* not found in list, default is_uplinkport set to 0 */
	return 0;
}

/*
 * SWITCH PORT VLAN HOOK
 */
int switch_port_tx_vlan(struct sk_buff *skb)
{
	struct net_device *vlanDev = skb->dev;
	struct net_device *realDev;
	uint16_t vlanID=0,extID=0;
	uint32_t pvid=0;

	if (vlanDev != NULL && (vlanDev->priv_flags & IFF_802_1Q_VLAN)) {
		realDev = zld_get_realdev_from_vlandev(vlanDev);
		vlanID  = zld_get_vlanId_from_vlandev(vlanDev);
		if (realDev !=NULL) {
			if (check_uplinkport_by_dev(realDev)) {
				pvid = find_pvid_by_dev(realDev);
				if ((pvid > 0) && (pvid == vlanID)) {
					return false; /* tx untag packet */
				}
			} else {
				extID = find_cfg_table_idx_by_dev(realDev);
				if ((extID != ZLD_CFG_TBL_END) && (!findVlanNode(extID,vlanID))) {
					return false; /* tx untag packet */
				}
			}
		}
	}
	return true; /* tx tag packet */
}

int switch_port_rx_vlan(struct sk_buff *skb)
{
	struct net_device *vlan_dev;
	uint32_t pvid=0;
 	struct vlan_hdr *vhdr;
	u16 vlan_id;
	u16 vlan_tci;

	//if(skb->dev && !skb->dev->priv_flags)
	if(skb->dev)
	{
		pvid = find_pvid_by_dev(skb->dev);
		if (pvid > 0) {
			// handle untag packet (send untag packet to vlandev with management-vlanid)
			if ((skb->protocol != cpu_to_be16(ETH_P_8021Q))
#if defined(ZLDCONFIG_LLDP)
					&& (skb->protocol != cpu_to_be16(ETH_P_LLDP))
#endif
			   ) {
				vlan_dev = zld_find_vlan_dev(skb->dev, pvid);
				if (!vlan_dev) {
					return false;
				}
				skb->vlan_tci = pvid;
				skb->dev = vlan_dev;
			}
			// handle tag packet (drop packets with management-vlanid tag from uplink port)
			if (skb->protocol == cpu_to_be16(ETH_P_8021Q)) {
				if (check_uplinkport_by_dev(skb->dev)) {
					vhdr = (struct vlan_hdr *)skb->data;
					vlan_tci = ntohs(vhdr->h_vlan_TCI);
					vlan_id = vlan_tci & VLAN_VID_MASK;
					if (pvid == vlan_id) {
						return false;
					}
				}
			}
		}
	}
	return true;
}

static int __init switch_port_vlan_hook_register(void)
{
	uint32_t i=0;

	reset_table_vlanPvid();
	reset_zld_port_dev_tbl();

	spin_lock(&UntagVlanlock);
	for(i=0; i<HASHSIZE; i++)
	{
		vlanUntagMemberTable[i].next= &vlanUntagMemberTable[i];
		vlanUntagMemberTable[i].prev= &vlanUntagMemberTable[i];
	}
	switch_port_rx_vlan_hook = switch_port_rx_vlan;
	switch_port_tx_vlan_hook = switch_port_tx_vlan;

	spin_unlock(&UntagVlanlock);

	return 0;
}

static void __exit switch_port_vlan_hook_Unregister(void)
{
	uint32_t i=0;
	zld_untag_vlan_cfg_t *vlanPtr,*n;
	struct list_head *head= NULL;

	spin_lock(&UntagVlanlock);
	for(i=0; i<HASHSIZE; i++)
	{
		if((head= &vlanUntagMemberTable[i])==NULL)	continue;

		list_for_each_entry_safe(vlanPtr,n,head,list) {
			list_del(&vlanPtr->list);
			kfree(vlanPtr);
		}

		vlanUntagMemberTable[i].next= &vlanUntagMemberTable[i];
		vlanUntagMemberTable[i].prev= &vlanUntagMemberTable[i];
	}
	switch_port_rx_vlan_hook = NULL;
	switch_port_tx_vlan_hook = NULL;

	spin_unlock(&UntagVlanlock);

	reset_zld_port_dev_tbl();
	reset_table_vlanPvid();
}

module_init(switch_port_vlan_hook_register);
module_exit(switch_port_vlan_hook_Unregister);

MODULE_LICENSE("Proprietary");
MODULE_AUTHOR("Heren Lin <staven.peng@zyxel.com.tw>");
MODULE_DESCRIPTION("Hook for VLAN functionality");

EXPORT_SYMBOL(cfg_vlan_table_by_vid);
EXPORT_SYMBOL(find_vlan_table_by_vid);
EXPORT_SYMBOL(cfg_pvid_by_port_no);
EXPORT_SYMBOL(find_pvid_by_port_no);

#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <linux/module.h>
#include <linux/types.h>
#else
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/ptrace.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/timer.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <linux/ioctl.h>
#include <linux/init.h>
#include <linux/mtd/compatmac.h>
#include <linux/mtd/mtd.h>
#endif

#ifdef CONFIG_PROC_FS
#include <linux/proc_fs.h>
#endif
#include "switchdev.h"

/* 
Cavium platform notes: 
 Please check 
 cvmx_helper_board_get_mii_address(int ipd_port)
 cvmx_helper_interface_get_mode()
 
*/

#if 0
#define SW_DBG_CHK(port,cfg_p) \
{\
	if ( ( port >=  ZLD_MAX_ETHER_PORT_NUM ) || ( port >=  ZLD_MAX_ETHER_PORT_NUM ) || \
		((cfg_p+port )->ext_idx == ZLD_CFG_TBL_END)) { \
			printk("%s: port=%d\n",__FUNCTION__,port); \
		} \
} \

#else
#define SW_DBG_CHK(port,cfg_p)
#endif


static zld_port_cfg_t zld_port_tbl[ZLD_MAX_ETHER_PORT_NUM] = {
{ZLD_CFG_TBL_END,0,"","",0,0,0,0,0,0,0,0,0}
};

static zld_port_cfg_t zld_port_ext_tbl[ZLD_MAX_ETHER_PORT_NUM] = {
{ZLD_CFG_TBL_END,0,"","",0,0,0,0,0,0,0,0,0}
};


int
init_zld_port_tbl ( zld_port_cfg_t *port_p, int cnt )
{
	int i;
	for ( i = 0; i < cnt; i++, port_p++ ) {
		port_p->ext_idx = ZLD_CFG_TBL_END;
		port_p->name[0]='\0';
		port_p->base_name[0]='\0';
	}
	return 0;
}


zld_port_cfg_t *
get_zld_port_cfg_table( void )
{
	return &(zld_port_tbl[0]);
} /* get_zld_port_cfg_table */


zld_port_cfg_t *
get_zld_port_ext_cfg_table( void )
{
	return &(zld_port_ext_tbl[0]);
} /* get_zld_port_cfg_table */


int
cfg_to_ext_cfg_table ( zld_port_cfg_t *cfg_port_p )
{
	int idx = 0;
	zld_port_cfg_t *tbl_p = get_zld_port_ext_cfg_table();

	while ( tbl_p->ext_idx != ZLD_CFG_TBL_END ) {
		tbl_p ++;
		idx ++;
	}
	memcpy( tbl_p, cfg_port_p, sizeof(zld_port_cfg_t) );
	tbl_p->ext_idx = idx;
	tbl_p->cpu_port = idx;
	
	tbl_p++;
	tbl_p->ext_idx = ZLD_CFG_TBL_END;
	return idx;
} /* cfg_to_ext_cfg_table */


int
find_ext_cfg_table_idx_by_name ( char *name )
{
	zld_port_cfg_t *tbl_p = get_zld_port_ext_cfg_table();

	while ( tbl_p->ext_idx != ZLD_CFG_TBL_END ) {
		if ( strcmp( tbl_p->name, name ) == 0 ) {
			break;
		}
		tbl_p++;
	}
	return tbl_p->ext_idx;
} /* find_ext_cfg_table_idx_by_name */
	
zld_port_cfg_t *
find_port_entry_by_sw_port( int sw_type, int reg_idx, int port )
{
	zld_port_cfg_t *port_p = get_zld_port_cfg_table();
	while ( port_p ->ext_idx != ZLD_CFG_TBL_END ) {
		if ( ( port_p->sw_type == sw_type ) &&
			 ( port_p->reg_idx == reg_idx ) &&
			 ( port_p->front_idx == port ) ) {
			 return port_p;
		}
		port_p ++;
	}	
	
	
	port_p = get_zld_port_ext_cfg_table();
	while ( port_p ->ext_idx != ZLD_CFG_TBL_END ) {
		if ( ( port_p->sw_type == sw_type ) &&
			 ( port_p->reg_idx == reg_idx ) &&
			 ( port_p->front_idx == port ) ) {
			 return port_p;
		}
		port_p ++;
	}
	return NULL;
}


/* Use to find any port in this switch. Basically, we want to get eth_base or cpu port */
zld_port_cfg_t *
find_port_by_switch( int sw_type, int reg_idx )
{
	zld_port_cfg_t *port_p ;
	
	port_p = get_zld_port_cfg_table();
	while ( port_p ->ext_idx != ZLD_CFG_TBL_END ) {
		if ( ( port_p->sw_type == sw_type ) &&
			 ( port_p->reg_idx == reg_idx ) ) {
			 return port_p;
		}
		port_p ++;
	}	
	
	port_p = get_zld_port_ext_cfg_table();
	while ( port_p ->ext_idx != ZLD_CFG_TBL_END ) {
		if ( ( port_p->sw_type == sw_type ) &&
			 ( port_p->reg_idx == reg_idx ) ){
			 return port_p;
		}
		port_p ++;
	}
	return NULL;
}



int
get_zld_port_table_cnt( zld_port_cfg_t *port_p )
{
	int cnt = 1; // start from 1 to include the TABLE_END

	while ( port_p->ext_idx != ZLD_CFG_TBL_END ) {
		cnt ++;
		port_p++;
	}
	
	return cnt;;
} /* get_zld_port_table_cnt */


int 
get_sw_port_table(zld_port_cfg_t *port_p, zld_port_cfg_t *tbl_p, int size  )
{
	memcpy(port_p, tbl_p, size);
	return 0;
}


int
get_sw_summary ( zld_sw_summary_t *zld_sw_summary_p )
{
	zld_sw_summary_p->sw_num       = get_switch_num();
	zld_sw_summary_p->port_num     = get_zld_port_table_cnt( get_zld_port_cfg_table ());
	zld_sw_summary_p->ext_port_num = get_zld_port_table_cnt( get_zld_port_ext_cfg_table ());
	return 0;
} /* get_sw_summary */


int
zyinit_mass_port_disable( int port )
{
	zld_port_cfg_t *port_p =get_zld_port_cfg_table();
	struct switch_info *switch_dev;

	if ( port & DISABLE_MULTI_BOOT_PORT ) {
		port &= ~DISABLE_MULTI_BOOT_PORT;
		
		while ( port_p ->ext_idx != ZLD_CFG_TBL_END ) {
//			printk("%s0: port=%d, idx=%d, sw=%d\n",__FUNCTION__,port,port_p->ext_idx, port_p->reg_idx);
			if ( port_p->ext_idx == port ) {
				switch_dev = get_switch_device(NULL, port_p->reg_idx);
				switch_dev->switch_port_disable( switch_dev, port_p->front_idx );
			}
			port_p ++;
		}
	}
	else {
		while ( port_p ->ext_idx != ZLD_CFG_TBL_END ) {
//			printk("%s1: port=%d, idx=%d, sw=%d\n",__FUNCTION__,port,port_p->ext_idx, port_p->reg_idx);
			if ( port_p->ext_idx != port ) {
				switch_dev = get_switch_device(NULL, port_p->reg_idx);
				switch_dev->switch_port_disable( switch_dev, port_p->front_idx );
			}
			port_p ++;
		}
	}
	return 0;		
} /* zyinit_mass_port_disable */

int
zyinit_get_enable_eth_port( int *enable_port)
{
	zld_port_cfg_t *port_p =get_zld_port_cfg_table();
	while ( port_p->ext_idx != ZLD_CFG_TBL_END ) {
		if ( port_p->flags & ZLD_PORT_FLG_ENABLE_PORT  ) {
			*enable_port = port_p->ext_idx;
			break;
		}
		port_p ++;
	}
	return 0;

} /* zyinit_get_enable_eth_port */

EXPORT_SYMBOL(get_zld_port_table_cnt);
EXPORT_SYMBOL(get_sw_port_table);
EXPORT_SYMBOL(get_zld_port_cfg_table);
EXPORT_SYMBOL(get_zld_port_ext_cfg_table);
EXPORT_SYMBOL(find_ext_cfg_table_idx_by_name);
EXPORT_SYMBOL(find_port_by_switch);
EXPORT_SYMBOL(cfg_to_ext_cfg_table);
EXPORT_SYMBOL(get_sw_summary);
EXPORT_SYMBOL(find_port_entry_by_sw_port);
EXPORT_SYMBOL(zyinit_mass_port_disable);
EXPORT_SYMBOL(zyinit_get_enable_eth_port);

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/version.h>
#include <linux/slab.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/compat.h>
#include <zld-spec.h>
#include "switchdev.h"

/*
 * We use file->private_data to store a pointer to the SWITCH device.
 * Since alighment is at least 32 bits, we have 2 bits free for OTP
 * modes as well.
 */

#define TO_SWITCH(file) 	(struct switch_info *)((long)((file)->private_data) & ~3L)
#define SWITCH_MODE(file)	((long)((file)->private_data) & 3)

#define SET_SWITCH_MODE(file, mode) \
	do { long __p = (long)((file)->private_data); \
	     (file)->private_data = (void *)((__p & ~3L) | mode); } while (0)

static int 
switch_open(struct inode *inode, struct file *file)
{
	int minor = iminor(inode);
	int devnum = minor ;
	struct switch_info *switch_dev;

	if (devnum >= MAX_SWITCH_DEVICES){
		return -ENODEV;
	}
	
	switch_dev = get_switch_device(NULL, devnum);
	
	if (!switch_dev){
		return -ENODEV;
	}

	file->private_data = switch_dev;
		
	return 0;
} /* switch_open */

/*====================================================================*/

static int 
switch_close(struct inode *inode, struct file *file)
{
	struct switch_info *switch_dev;

	switch_dev = TO_SWITCH(file);
		
	put_switch_device(switch_dev);

	return 0;
} /* switch_close */



static long switch_ioctl(struct file *file, u_int cmd, u_long arg)
{
	struct switch_info *switch_dev = TO_SWITCH(file);
	void __user *argp = (void __user *)arg;
	void *kargp = NULL;
	int ret = 0;
	int sw_idx;
	u_long size = (cmd & IOCSIZE_MASK) >> IOCSIZE_SHIFT;

	/* allocate required buffer */
	if ( cmd & IOC_INOUT ) {
		if ( (kargp = (switch_config*)kmalloc(size, GFP_KERNEL)) == NULL ) {
			ret = -ENOMEM;
			goto fail;
		}
	}

	sw_idx = switch_dev->index;
	/* verify and copy data from user-space */
	if (cmd & IOC_IN) {
		if ( !access_ok(VERIFY_READ, argp, size) ) {
			ret = -EFAULT;
			goto fail;
		}
		if (copy_from_user(kargp, argp, size)){
			ret = -EFAULT;
			goto fail;
		}
	}

	/* execute the cmd */
	ret = 0;

	switch (cmd) {
	case SWITCHDEV_ENABLE:
		if(switch_dev->switch_enable !=NULL)
		switch_dev->switch_enable(switch_dev, 1);					
		break;

	case SWITCHDEV_DISABLE:
		if(switch_dev->switch_disable !=NULL)
		switch_dev->switch_disable(switch_dev);					
		break;

	case SWITCHDEV_GET_PORT_COUNTER:
		if(switch_dev->switch_get_port_counter != NULL)
		switch_dev->switch_get_port_counter(switch_dev, (switch_port_counter*)(kargp));
		break;

	case SWITCHDEV_CLEAR_PORT_COUNTER:
		if(switch_dev->switch_clear_port_counter != NULL)
		switch_dev->switch_clear_port_counter(switch_dev, (switch_port_counter*)(kargp));
		break;

	case SWITCHDEV_GET_PORT_STATUS:
		if(switch_dev->switch_get_port_status != NULL)
		switch_dev->switch_get_port_status(switch_dev, (switch_port_status*)(kargp));
		break;

	case SWITCHDEV_SET_PORT_STATUS:
		if(switch_dev->switch_set_port_status != NULL)
		switch_dev->switch_set_port_status(switch_dev, (switch_port_status*)(kargp));
		break;
	
	case SWITCHDEV_VLAN_PORT_MODE_GET:
		if(switch_dev->switch_vlan_port_mode_get != NULL)
		switch_dev->switch_vlan_port_mode_get(switch_dev, (switch_vlan_port_mode*)(kargp));
		break;

	case SWITCHDEV_VLAN_PORT_MODE_SET:
		if(switch_dev->switch_vlan_port_mode_set != NULL)
		switch_dev->switch_vlan_port_mode_set(switch_dev, (switch_vlan_port_mode*)(kargp));
		break;

	case SWITCHDEV_VLAN_TABLE_READ:
		if(switch_dev->switch_vlan_table_read != NULL)
		switch_dev->switch_vlan_table_read(switch_dev, (switch_vlan_table_entry*)(kargp));
		break;

	case SWITCHDEV_VLAN_TABLE_WRITE:
		if(switch_dev->switch_vlan_table_write != NULL)
		switch_dev->switch_vlan_table_write(switch_dev, (switch_vlan_table_entry*)(kargp));
		break;

	case SWITCHDEV_PORT_ENABLE:
		if(switch_dev->switch_port_enable != NULL)
		switch_dev->switch_port_enable(switch_dev, *(int*)(kargp));
		break;

	case SWITCHDEV_PORT_DISABLE:
		if(switch_dev->switch_port_disable != NULL)
		switch_dev->switch_port_disable(switch_dev, *(int*)(kargp));

		break;

	case SWITCHDEV_LOOPBACK_ENABLE:
		if(switch_dev->switch_loopback_enable != NULL)
		switch_dev->switch_loopback_enable(switch_dev, *(int*)(kargp));
		break;

	case SWITCHDEV_LOOPBACK_DISABLE:
		if(switch_dev->switch_loopback_disable != NULL)
		switch_dev->switch_loopback_disable(switch_dev, *(int*)(kargp));
		break;
	
	case SWITCHDEV_SET_LOOPGUARD_STATUS:	
		if(switch_dev->switch_loopguard_status_func_set != NULL)
		switch_dev->switch_loopguard_status_func_set(switch_dev, *(int*)(kargp));
		break;
	
	case SWITCHDEV_GET_LOOPGUARD_STATUS:	
		if(switch_dev->switch_loopguard_status_func_get != NULL)
		switch_dev->switch_loopguard_status_func_get(switch_dev, (int*)(kargp));
		break;

	case SWITCHDEV_PORT_SET_LOOPGUARD_STATUS:	
		if(switch_dev->switch_port_loopguard_status_func_set != NULL)
		switch_dev->switch_port_loopguard_status_func_set(switch_dev, (switch_port_loopguard_status*)(kargp));
		break;
	
	case SWITCHDEV_PORT_GET_LOOPGUARD_STATUS:	
		if(switch_dev->switch_port_loopguard_status_func_get != NULL)
		switch_dev->switch_port_loopguard_status_func_get(switch_dev, (switch_port_loopguard_status*)(kargp));
		break;
		
	case SWITCHDEV_DBG_SWITCH_REG_READ:
		if(switch_dev->switch_dbg_switch_reg_read != NULL)
		switch_dev->switch_dbg_switch_reg_read(switch_dev, (switch_reg*)(kargp));
		break;

	case SWITCHDEV_DBG_SWITCH_REG_WRITE:
		if(switch_dev->switch_dbg_switch_reg_write != NULL)
		switch_dev->switch_dbg_switch_reg_write(switch_dev, (switch_reg*)(kargp));
		break;

	case SWITCHDEV_DBG_SWITCH_MII_READ:
		if(switch_dev->switch_dbg_switch_mii_read != NULL)
		switch_dev->switch_dbg_switch_mii_read(switch_dev, (switch_mii*)(kargp));
		break;

	case SWITCHDEV_DBG_SWITCH_MII_WRITE:
			if(switch_dev->switch_dbg_switch_mii_write != NULL)
		switch_dev->switch_dbg_switch_mii_write(switch_dev, (switch_mii*)(kargp));
		break;

	case SWITCHDEV_GET_SWITCT_SUMMARY:
		get_sw_summary((zld_sw_summary_t *)kargp);
		break;

	case SWITCHDEV_GET_PORT_TABLE:
			/* free first and re-allocate again for this special command */
			kfree(kargp);
			size = get_zld_port_table_cnt( get_zld_port_cfg_table ()) * sizeof ( zld_port_cfg_t );

			if ( (kargp = (switch_config*)kmalloc(size, GFP_KERNEL)) == NULL ) {
				ret = -ENOMEM;
				goto fail;
			}
			get_sw_port_table(kargp, get_zld_port_cfg_table (), size);
		break;
	case SWITCHDEV_GET_PORT_EXT_TABLE:
			/* free first and re-allocate again for this special command */
			kfree(kargp);
			size = get_zld_port_table_cnt( get_zld_port_ext_cfg_table ()) * sizeof ( zld_port_cfg_t );

			if ( (kargp = (switch_config*)kmalloc(size, GFP_KERNEL)) == NULL ) {
				ret = -ENOMEM;
				goto fail;
			}
			get_sw_port_table(kargp, get_zld_port_ext_cfg_table (), size);
		break;
	case SWITCHDEV_PORT_TABLE_ADJUST:	
		zld_port_table_adjust();
		break;
	case SWITCHDEV_MASS_PORT_DISABLE:	
		zyinit_mass_port_disable( *(int*)(kargp) );
		break;
	case SWITCHDEV_GET_ENABLE_ETH_PORT:	
		zyinit_get_enable_eth_port( (int*)(kargp) );
		break;
#ifdef ZLDCONFIG_DEBUG_RGMII_TUNING
	case SWITCHDEV_DBG_SWITCH_RGMII_DELAY_SET:
		switch_dev->switch_dbg_switch_rgmii_delay_set(switch_dev, (switch_rgmii_delay*)(kargp));
	       break;
	case SWITCHDEV_DBG_SWITCH_RGMII_DELAY_GET:
		switch_dev->switch_dbg_switch_rgmii_delay_get(switch_dev, (switch_rgmii_delay*)(kargp));
	       break;
#endif
#ifdef ZLDCONFIG_ETH_STORM_CONTROL
	case SWITCHDEV_SET_STORM_CONTROL:
		switch_dev->switch_storm_control_set(switch_dev, (storm_control_property_t*)(kargp));
	    break;
	case SWITCHDEV_GET_STORM_CONTROL:
		switch_dev->switch_storm_control_get(switch_dev, (storm_control_property_t*)(kargp));
	    break;
#endif
	default:
		ret = -EINVAL;
		break;
	}

	if ( ret ) {
		goto fail;
	}

	/* copy data to user-space */
	if (cmd & IOC_OUT) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
		if ( !access_ok(VERIFY_WRITE, argp, size) ) {
#else
		if ( verify_area(VERIFY_WRITE, argp, size) ) {
#endif
			ret = -EFAULT;
			goto fail;
		}
		if (copy_to_user(argp, kargp, size)){
			ret = -EFAULT;
			goto fail;
		}
	}

fail:
	/* free the buffer */
	if ( kargp ) {
		kfree(kargp);
	}

	return ret;
} /* switch_ioctl */

#ifdef CONFIG_COMPAT
static long
switch_compat_ioctl(struct file *file,u_int cmd, u_long arg)
{
	return switch_ioctl(file, cmd, (u_long)(compat_ptr(arg)));
}
#endif

static struct file_operations switch_fops = {
	.owner		= THIS_MODULE,
	.unlocked_ioctl		= switch_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = switch_compat_ioctl,
#endif
	.open		= switch_open,
	.release	= switch_close,
};

static struct class *switch_class;

static int __init switch_char_init(void)
{
	struct device *switch_device;
	int ret;

	ret = register_chrdev(SWITCH_CHAR_MAJOR, DEVNAME, &switch_fops);
	if (ret < 0) {
		pr_err("register_chrdev failed\n");
		goto err;
	}

	switch_class = class_create(THIS_MODULE, DEVNAME);
	if (IS_ERR(switch_class)) {
		pr_err("failed to create class\n");
		ret = PTR_ERR(switch_class);
		goto err_class;
	}

	switch_device = device_create(switch_class, NULL,
				      MKDEV(SWITCH_CHAR_MAJOR, 0), NULL,
				      "%s%d", DEVNAME, 0);
	if (IS_ERR(switch_device)) {
		pr_err("failed to create device\n");
		ret = PTR_ERR(switch_device);
		goto err_device;
	}
	return 0;

err_device:
	class_destroy(switch_class);
err_class:
	unregister_chrdev(SWITCH_CHAR_MAJOR, DEVNAME);
err:
	return ret;
}

static void __exit switch_char_cleanup(void)
{
	device_destroy(switch_class, MKDEV(SWITCH_CHAR_MAJOR, 0));
	class_destroy(switch_class);
	unregister_chrdev(SWITCH_CHAR_MAJOR, DEVNAME);
}

module_init(switch_char_init);
module_exit(switch_char_cleanup);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Heren Lin <heren.lin@zyxel.com.tw>");
MODULE_DESCRIPTION("Direct character-device access to SWITCH devices");

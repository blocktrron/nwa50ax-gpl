#ifndef __SWITCHDEV_ABI_H__
#define __SWITCHDEV_ABI_H__
#include <zld-spec.h>

#if !defined(__KERNEL__) && !defined(_STDINT_H) && !defined(_LINUX_TYPES_H)
typedef unsigned char		uint8_t;
typedef unsigned short int	uint16_t;
typedef unsigned int		uint32_t;
#endif /* __KERNEL__ */

#ifndef BOOL
#define	BOOL   int	/* false: 0, true: anything	but	0 */
#endif
typedef	unsigned int switch_vid_t;	   /* VLAN Identifier */

typedef	struct _switch_config	{
	uint32_t chip_id;
	uint32_t revision_number;
	uint32_t part_number;
	uint32_t manufacturer_id;
}switch_config;


#define ZLD_SWITCH_TYPE_AR934X		0x1000
#define ZLD_SWITCH_TYPE_AR8227		0x1001
#define ZLD_SWITCH_TYPE_AR8334		0x1002
#define ZLD_SWITCH_TYPE_BCM53125	0x1100
#define ZLD_SWITCH_TYPE_RTL8363NB	0x1200
#define ZLD_SWITCH_TYPE_IPQ807X		0x1300
#define ZLD_SWITCH_TYPE_IPQ40XX		0x1301
#define ZLD_SWITCH_TYPE_MT76XX		0x1400


#define ZLD_PORT_FLG_CPU_PORT 		0x0001
#define ZLD_PORT_FLG_VLAN_PORT 		0x0002
#define ZLD_PORT_FLG_ETHBASE 		0x0004
#define ZLD_PORT_FLG_PASSIVE_PHY 	0x0008  /* phy is managed by others */
#define ZLD_PORT_FLG_ENABLE_PORT 	0x0010
#define ZLD_PORT_FLG_UPLINK_PORT	0x0020
#define ZLD_PORT_FLG_ACL_ETH_PORT	0x0040
#define ZLD_PORT_FLG_ACL_AR_SWITCH	0x0080
#define ZLD_PORT_FLG_MANAGED_SWITCH	0x0100
#define ZLD_PORT_FLG_ACL_RTK_SWITCH	0x0200
#define ZLD_PORT_FLG_MULTIGI_PHY	0x0400
#define ZLD_PORT_FLG_AR_PHY	0x0800


#define ZLD_CFG_TBL_END 9999


typedef struct zld_port_cfg_s {
	int 		ext_idx; /* ethx */
	int 		base_idx; /* ether_base idx */
	char 		name[16];
	char 		base_name[16]; /* Etherbase name */
	uint16_t	sw_type;
	uint16_t	sw_idx;

	int 		reg_idx; /* index in register switch table */

	int		front_idx;  /* switch front port index */
	int 		mac_idx; /* mac index */

	int		phy_addr; /* phy address */
	uint16_t	phy_cfg_sw;  // This field useless now. FIXME: modify it some other time.
	uint16_t	phy_sw_idx; // This field useless now. FIXME: modify it some other time.
	uint32_t	flags;
	int		cpu_port;
} zld_port_cfg_t;


typedef struct zld_sw_summary_s {
	uint32_t sw_num;
	uint32_t port_num;
	uint32_t ext_port_num;
	uint32_t reserved;
} zld_sw_summary_t;


#define ZLD_MAX_ETHER_PORT_NUM 12
#define DISABLE_MULTI_BOOT_PORT 0x8000


typedef	struct _switch_port_counter {
	int	port_no;
	//rx
	unsigned long long rx_bytes;
	uint32_t rx_packets;
	uint32_t rx_bcast;
	uint32_t rx_errs;
	uint32_t rx_drop;
	uint32_t rx_fifo;
	uint32_t rx_frame;
	uint32_t rx_compressed;
	uint32_t rx_multicast;
	//tx
	unsigned long long tx_bytes;
	uint32_t tx_packets;
	uint32_t tx_bcast;
	uint32_t tx_errs;
	uint32_t tx_drop;
	uint32_t tx_fifo;
	uint32_t tx_colls;
	uint32_t tx_carrier;
	uint32_t tx_compressed;
}switch_port_counter;

/*
	Adjustable set PHY status
					link_status_set	link_speed_set	negotiation_set	duplex_mode_set
	10Mbps	half	1				10				0				0
	10Mbps	full	1				10				0				1
	100Mbps	half	1				100				0				0
	100Mbps	full	1				100				0				1
	auto			1				1000			1				1
*/

typedef	struct _switch_port_status {
	int	port_no;
	//link,	only for ethernet
	int	port_enable;

	int	link_status_set;//i	is up, 0 is	down
	int	link_speed_set;//10,	100, 1000
	int	negotiation_set;//auto is 1, forced	is 0
	int	duplex_mode_set;//half is 0,	full is	1
	int media_preference_set; //fiber 1, copper 0

	int	link_status_now;//i	is up, 0 is	down
	int	link_speed_now;//10,	100, 1000
	int	duplex_mode_now;//half is 0,	full is	1
#ifdef ZLDCONFIG_IEEE_8023AZ
	int 	eee_mode_set;//0 is off, 1 is on
	int 	eee_mode_now;//0 is off, 1 is on
#endif
	int	up_time;//the instant when cable connect to	this port; unit	: same as jiffies
	int media_type;

}switch_port_status;

#ifdef ZLDCONFIG_ETH_STORM_CONTROL

/* a port (port0~portX) uses 1 (support bit) + 4 (storm type) bit */
#define SC_MAX_SUPPORT_PORT_INDEX 6 // port0~port5
#define SC_PORT_SUPPORT_BIT_NUM 1
#define SC_PORT_SUPPORT_BMAP_INDEX(PORT_NO) ((SC_PORT_SUPPORT_BIT_NUM + STORM_TYPE_MAX) * PORT_NO)
#define SC_STORMING_BMAP_INDEX(PORT_NO, STORM_TYPE) (((SC_PORT_SUPPORT_BIT_NUM + STORM_TYPE_MAX) * PORT_NO) + SC_PORT_SUPPORT_BIT_NUM + STORM_TYPE)

/* For storm control setting capability
 *  bit0~15:
 *   The minimum settable storm rate (for PPS)
 *  bit16~19:
 *   Setting by "port" or "frame type"
 *  bit20~23:
 *   Show storming by "port" or "frame type"
 *  bit24~30:
 *   Reserved
 */
#define SC_CAPS_MIN_PPS_BMAP_SHIFT 0
#define SC_CAPS_MIN_PPS_BMAP_MASK 0xFFFF
#define SC_CAPS_RATE_SETTING_BMAP_SHIFT 16
#define SC_CAPS_RATE_SETTING_BMAP_MASK 0XF0000
#define SC_CAPS_STORMING_GET_BMAP_SHIFT 20
#define SC_CAPS_STORMING_GET_BMAP_MASK 0XF00000

enum {
	STORM_TYPE_UNKNOWN = 0,
	STORM_TYPE_UNICAST,
	STORM_TYPE_MULTICAST,
	STORM_TYPE_BROADCAST,
	STORM_TYPE_MAX
};

enum {
	STORM_RATE_TYPE_UNKNOWN = 0,
	STORM_RATE_TYPE_KBPS,
	STORM_RATE_TYPE_PPS,
	STORM_RATE_TYPE_MAX
};

typedef struct {
	int command;
	int len;
	int port_no;
	int storm_type;
	int storming;
} storm_control_nl_msg_t;

typedef struct {
	int port_no;
	int port_id;
	int storm_enable;
	int storm_type;		// suppressed packet type: ucast/mcast/bcast
	int storm_rate_type;	// kbps/pps
	int storm_rate;
	int storming;
	unsigned long last_suppression_time;
	unsigned long last_recovery_time;
	int setting_changed;
} storm_control_property_t;

typedef struct {
	storm_control_property_t storm_type[STORM_TYPE_MAX];
} eth_storm_control_t;

typedef struct {
	int storming_bmap;
	int caps_bmap;
	eth_storm_control_t eth[ZLDSYSPARM_PHY_PORT_MAX_NUM];
} storm_control_t;
#endif

/* VLAN	acceptable frame type */
typedef	enum _vlan_frame_t {
	VLAN_FRAME_ALL,	   /* Accept all frames	*/
	VLAN_FRAME_TAGGED  /* Accept tagged	frames only	*/
} vlan_frame_t;


/* VLAN	port parameters	*/
typedef	struct _switch_vlan_port_mode_t {
	unsigned int port_no;
	BOOL		aware;			/*VLAN awareness*/
	switch_vid_t	pvid;			/*Port VLAN ID*/
	vlan_frame_t	frame_type;		/*Acceptable frame type*/
	BOOL			ingress_filter;	/*Ingress filtering*/
} switch_vlan_port_mode;

typedef enum _vlan_tbl_usage_t {
	NONE_VLAN,
	PORT_BASED_VLAN,
	USER_CUSTIMIZED_VLAN
} vlan_tbl_usage_t;

typedef	struct _switch_vlan_table_entry_t {
	switch_vid_t vid;
	uint32_t		port_no_bitfield;
	BOOL			check_source;
	BOOL			mirror;
	uint32_t		untagmsk;
	vlan_tbl_usage_t usage;
} switch_vlan_table_entry;

typedef struct _switch_reg_t {
	unsigned char block;
	unsigned char subblock;
	uint32_t addr;
	uint32_t value;
} switch_reg;

typedef struct _switch_mii_t {
	unsigned char port_no;
	uint32_t addr;
	uint32_t value;
} switch_mii;

typedef	struct _switch_port_loopguard_status_t {
	int port;
	int islooping;
	int loopguard;
	unsigned long lastloop_time;
	int lastloop_port;
	unsigned long lastrecovery_time;
} switch_port_loopguard_status;

#ifdef ZLDCONFIG_DEBUG_RGMII_TUNING
typedef struct _switch_rgmii_delay_t {
	BOOL tx_delay_enable;
	BOOL rx_delay_enable;
	uint32_t tx_delay;
	uint32_t rx_delay;
} switch_rgmii_delay;
#endif

#define SWITCHDEV_ENABLE							_IO		('S',  1)
#define SWITCHDEV_DISABLE							_IO		('S',  2)
#define SWITCHDEV_GET_PORT_COUNTER					_IOWR	('S',  3, switch_port_counter)
#define SWITCHDEV_CLEAR_PORT_COUNTER				_IOW	('S',  4, switch_port_counter)
#define SWITCHDEV_GET_PORT_STATUS					_IOWR	('S', 5, switch_port_status)
#define SWITCHDEV_SET_PORT_STATUS					_IOW	('S', 6, switch_port_status)
#define SWITCHDEV_VLAN_PORT_MODE_GET				_IOWR	('S', 7, switch_vlan_port_mode)
#define SWITCHDEV_VLAN_PORT_MODE_SET				_IOW	('S', 8, switch_vlan_port_mode)
#define SWITCHDEV_VLAN_TABLE_READ					_IOWR	('S', 9, switch_vlan_table_entry)
#define SWITCHDEV_VLAN_TABLE_WRITE					_IOW	('S', 10, switch_vlan_table_entry)
#define SWITCHDEV_PORT_ENABLE						_IOW	('S', 11, int)
#define SWITCHDEV_PORT_DISABLE						_IOW	('S', 12, int)
#define SWITCHDEV_LOOPBACK_ENABLE					_IOW	('S', 13, int)
#define SWITCHDEV_LOOPBACK_DISABLE					_IOW	('S', 14, int)

#define SWITCHDEV_GET_SWITCT_SUMMARY				_IOR	('S', 15, zld_sw_summary_t)
#define SWITCHDEV_GET_PORT_TABLE					_IOWR	('S', 16, zld_port_cfg_t)  //This size will recount
#define SWITCHDEV_GET_PORT_EXT_TABLE				_IOWR	('S', 17, zld_port_cfg_t)  //This size will recount
#define SWITCHDEV_PORT_TABLE_ADJUST					_IOW	('S', 18, int)
#define SWITCHDEV_MASS_PORT_DISABLE					_IOW	('S', 19, int)  //Special for ZyInit
#define SWITCHDEV_GET_ENABLE_ETH_PORT				_IOR	('S', 20, int)
#define SWITCHDEV_PORT_SET_LOOPGUARD_STATUS			_IOW	('S', 21, switch_port_loopguard_status)
#define SWITCHDEV_PORT_GET_LOOPGUARD_STATUS			_IOWR	('S', 22, switch_port_loopguard_status)
#define SWITCHDEV_SET_LOOPGUARD_STATUS				_IOW	('S', 23, int)
#define SWITCHDEV_GET_LOOPGUARD_STATUS				_IOWR	('S', 24, int)


/* for debug */
#define SWITCHDEV_DBG(x) (x+50)
#define SWITCHDEV_DBG_SWITCH_REG_READ				_IOWR	('S', SWITCHDEV_DBG(1), switch_reg)
#define SWITCHDEV_DBG_SWITCH_REG_WRITE				_IOW	('S', SWITCHDEV_DBG(2), switch_reg)
#define SWITCHDEV_DBG_SWITCH_MII_READ				_IOWR	('S', SWITCHDEV_DBG(3), switch_mii)
#define SWITCHDEV_DBG_SWITCH_MII_WRITE				_IOW	('S', SWITCHDEV_DBG(4), switch_mii)

#ifdef ZLDCONFIG_DEBUG_RGMII_TUNING
#define SWITCHDEV_DBG_SWITCH_RGMII_DELAY_SET			_IOW	('S', SWITCHDEV_DBG(5), switch_rgmii_delay)
#define SWITCHDEV_DBG_SWITCH_RGMII_DELAY_GET			_IOR	('S', SWITCHDEV_DBG(6), switch_rgmii_delay)
#endif

#ifdef ZLDCONFIG_ETH_STORM_CONTROL
#define SWITCHDEV_SET_STORM_CONTROL			_IOW	('S', SWITCHDEV_DBG(7), storm_control_property_t)
#define SWITCHDEV_GET_STORM_CONTROL			_IOWR	('S', SWITCHDEV_DBG(8), storm_control_property_t)
#endif

#endif /* __SWITCHDEV_ABI_H__ */

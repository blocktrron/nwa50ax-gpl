#!/bin/sh

/sbin/modprobe ip_set

#if defined(ZLDSYSPARAM_IPSET_VERSION) && (ZLDSYSPARAM_IPSET_VERSION == 45)
# old ipset-4
/sbin/modprobe ip_set_iphash
/sbin/modprobe ipt_set
#else
# new ipset (5.0 and later)
/sbin/modprobe ip_set_hash_ip
/sbin/modprobe xt_set
#endif

/usr/sbin/ipset -N external_portal_url iphash
/bin/mkdir -p /tmp/external_portal_url/

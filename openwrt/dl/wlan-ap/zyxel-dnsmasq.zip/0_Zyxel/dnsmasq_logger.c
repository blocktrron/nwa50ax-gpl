#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <json-c/json.h>

#include "zylog.h"

int main(int argc, char *argv[]) {
	if (argc < 4) {
		exit(EXIT_FAILURE);
	}
	if ((strcmp(argv[1], "add") == 0) || (strcmp(argv[1], "old") == 0)) {
		char *mac;
		char *ip;
		char *hostname;
		char json_msg[ZYLOG_MAX_MESSAGE_LEN];

		mac = argv[2];
		ip = argv[3];
		hostname = (argc == 5 ? argv[4] : NULL);

		/* create the root json object */
		json_object *root = json_object_new_object();
		/* put all the objects to root node */
		json_object_object_add(root, "action", json_object_new_string("ack"));
		json_object_object_add(root, "ip", json_object_new_string(ip));
		json_object_object_add(root, "hostname", (hostname ? json_object_new_string(hostname) : NULL));
		json_object_object_add(root, "mac", json_object_new_string(mac));
		/* print to json message */
		snprintf(json_msg, ZYLOG_MAX_MESSAGE_LEN, "%s", json_object_to_json_string(root));
		/* free the json object */
		json_object_put(root);

		zylog_json(ZYLOG_SRC_DHCP, ZYLOG_PRI_INFO, ZYLOG_FAC_DHCP, 0, 0, 0, 0, "NAT", json_msg,
			   "DHCP server assigned %s to %s(%s)", ip, (hostname ? hostname : "(null)"), mac);
	}
	exit(EXIT_SUCCESS);
}

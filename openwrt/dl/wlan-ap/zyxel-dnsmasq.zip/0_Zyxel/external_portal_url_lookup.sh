#!/bin/bash
if [ "${BASH_VERSINFO[0]}" -ge 4 ] && [ "${BASH_VERSINFO[1]}" -gt 2 ]; then
    exec {lock_fd}>/tmp/external_portal_url_lookup.lock || exit 1
    flock -x "$lock_fd"
else
    exec 9>/tmp/external_portal_url_lookup.lock
    flock -x 9
fi

url_lists=`cat /tmp/external_portal_url/*.conf | grep 'ipset=' | awk -F '/' '{ print $2 }'`

for url in $url_lists; do
    is_ip=`echo $url | grep -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'`
    if [ -z "${is_ip}" ]; then
        /usr/local/bin/nslookup $url 127.0.0.1 -sil
    else
        /usr/sbin/ipset -A external_portal_url $url
    fi
done

if [ "${BASH_VERSINFO[0]}" -ge 4 ] && [ "${BASH_VERSINFO[1]}" -gt 2 ]; then
    flock -u "$lock_fd"
else
    flock -u 9
fi

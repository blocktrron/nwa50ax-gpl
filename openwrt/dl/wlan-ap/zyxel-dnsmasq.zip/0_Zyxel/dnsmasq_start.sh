#!/bin/bash

DNSMASQ_PID=`pidof -s dnsmasq`

if [ -n "$DNSMASQ_PID" ]; then
    kill -15 `cat /var/run/dnsmasq.pid`
fi

shopt -s nullglob dotglob
CONF=(/var/zyxel/dnsmasq.d/*.conf)

if [ ${#CONF[@]} -gt 0 ]; then
    /usr/local/bin/dnsmasq -C /etc/dnsmasq.conf
fi

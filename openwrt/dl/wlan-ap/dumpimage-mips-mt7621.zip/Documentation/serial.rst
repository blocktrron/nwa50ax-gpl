.. SPDX-License-Identifier: GPL-2.0+

Serial system
=============

.. kernel-doc:: drivers/serial/serial.c
   :internal:

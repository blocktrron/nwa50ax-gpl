.. SPDX-License-Identifier: GPL-2.0+

#######################
U-Boot Developer Manual
#######################

.. toctree::

   efi
   linker_lists
   serial

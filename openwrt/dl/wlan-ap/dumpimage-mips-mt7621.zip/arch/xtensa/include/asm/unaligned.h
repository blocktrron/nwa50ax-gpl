#ifndef _ASM_XTENSA_UNALIGNED_H
#define _ASM_XTENSA_UNALIGNED_H

#include <asm-generic/unaligned.h>

#endif /* _ASM_XTENSA_UNALIGNED_H */

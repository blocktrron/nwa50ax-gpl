/* SPDX-License-Identifier: GPL-2.0+ */
/*
 *  Copyright (C) 1997 Tensilica Inc.
 */

#ifndef _XTENSA_PROCESSOR_H
#define _XTENSA_PROCESSOR_H


#endif /* _XTENSA_PROCESSOR_H */

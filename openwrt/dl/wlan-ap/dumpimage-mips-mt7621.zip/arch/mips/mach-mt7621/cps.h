/* SPDX-License-Identifier:	GPL-2.0+ */
/*
 * Copyright (C) 2018 MediaTek Incorporation. All Rights Reserved.
 *
 * Author: Weijie Gao <weijie.gao@mediatek.com>
 */

#ifndef _MACH_MT7621_CPS_H_
#define _MACH_MT7621_CPS_H_

extern void mt7621_cps_init(void);

#endif /* _MACH_MT7621_CPS_H_ */

// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright (C) 2016 Marek Vasut <marex@denx.de>
 */

#include <common.h>

/* The lowlevel_init() is not needed on AR934x */
void lowlevel_init(void) {}

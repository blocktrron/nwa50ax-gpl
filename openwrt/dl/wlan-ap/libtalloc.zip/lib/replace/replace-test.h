#ifndef __LIB_REPLACE_REPLACE_TEST_H__
#define __LIB_REPLACE_REPLACE_TEST_H__

int libreplace_test_strptime(void);
int test_readdir_os2_delete(void);
int getifaddrs_test(void);

#endif /* __LIB_REPLACE_REPLACE_TEST_H__ */


#!/bin/sh
if [ "${BASH_VERSINFO[0]}" -gt 3 ] && [ "${BASH_VERSINFO[1]}" -gt 1 ]; then
    exec {lock_fd}>/tmp/radiusd_start.lock || exit 1
    flock -x "${lock_fd}"
else
    exec 9>/tmp/radiusd_start.lock
    flock -x 9
fi

if [ -f /tmp/radiusd_start_running ]; then
    rm -f /tmp/radiusd_start_running
fi
touch /tmp/radiusd_start_running

function kill_freeradius_server {
    while [ -n "$(pidof -s radiusd)" ]; do
        RADIUSPID=$(pidof -s radiusd)
        if [ -f "/var/run/radiusd.pid" ] && [ "${RADIUSPID}" -eq "$(cat /var/run/radiusd.pid)" ]; then
            # FIXME: SIGTERM sometimes causes SIGSEGV when radiusd enables threads.
            /bin/kill -SIGKILL ${RADIUSPID}
        else
            rm -f /var/run/radiusd.pid
            /usr/bin/killall -SIGKILL radiusd
        fi
        # sleep 3 seconds to make sure that daemon is killed. magic...
        sleep 3
    done
}

BOOTING=6
#if defined(ZLDCONFIG_LEGACY_RW_FILE_PATH)
RADIUS_RST_COUNT='/etc/zyxel/ftp/tmp/radiusd_restart_cnt'
#else
RADIUS_RST_COUNT='/etc/zyxel/ftp/diaglog/radiusd_restart_cnt'
#endif
i=0
until [ -f "/var/run/boot-status" ] && [ "$(cat /var/run/boot-status)" -ne ${BOOTING} ]; do
    ((i++))
    sleep 5
done
if [ $i -gt 0 ]; then
    echo "[$(date +%F_%H-%M-%S)] radiusd start delayed $(($i*5)) second(s) due to device is in boot progress" >> ${RADIUS_RST_COUNT}
fi

ZYKITMODE=`sed -n p /etc/zyxel/ftp/conf/startup-config.conf | grep 'hybrid-mode' | awk '{print $2}'`
RADIUSD_ARG=
#if defined(ZLDCONFIG_PLATFORM_ARM_QUALCOMM_IPQ40XX) || defined(ZLDCONFIG_PLATFORM_MIPSEL_MEDIATEK_MT7621)
# disable threads
RADIUSD_ARG="-t"
#endif
if [ "${ZYKITMODE}" = "cloud" ]; then
    EXT="Nebula"
else
    EXT="ZyXEL"
fi
RADDB="/var/zyxel/raddb/"
SWAPCONF='proxy.conf radiusd.conf'
SWAPSITE='default'

kill_freeradius_server
if [ -e "${RADDB}/mac_role" ]; then
    rm -f "${RADDB}/mac_role"
    touch "${RADDB}/mac_role"
fi
for f in ${SWAPCONF}; do
    cd "${RADDB}"
    rm -f "${f}"
    ln -sf "${f}.${EXT}" "${f}"
done
for f in ${SWAPSITE}; do
    cd "${RADDB}/sites-enabled/"
    rm -f "${f}"
    ln -sf "../sites-available/${f}.${EXT}" "${f}"
done
/usr/sbin/radiusd ${RADIUSD_ARG} -d ${RADDB}

rm -f /tmp/radiusd_start_running
if [ "${BASH_VERSINFO[0]}" -gt 3 ] && [ "${BASH_VERSINFO[1]}" -gt 1 ]; then
    flock -u "${lock_fd}"
else
    flock -u 9
fi

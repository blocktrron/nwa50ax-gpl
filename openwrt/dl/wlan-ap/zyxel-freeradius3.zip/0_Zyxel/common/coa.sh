#!/bin/sh

/bin/zysh -p 110 -e "configure terminal users force-logout $1" 1>/dev/null 2>&1

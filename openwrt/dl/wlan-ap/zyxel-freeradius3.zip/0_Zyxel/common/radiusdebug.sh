#!/bin/sh

#ulimit -c unlimited
#if defined(ZLDCONFIG_LEGACY_RW_FILE_PATH)
COUNT_FILE="/etc/zyxel/ftp/tmp/radiusd_restart_cnt"
#else
COUNT_FILE="/etc/zyxel/ftp/diaglog/radiusd_restart_cnt"
#endif

# max log file size = 512 (bytes)
LOGFILESIZE=512

#if defined(ZLDCONFIG_PLATFORM_AARCH64_QUALCOMM_IPQ807X) || defined(ZLDCONFIG_PLATFORM_ARM_QUALCOMM_IPQ40XX) || defined(ZLDCONFIG_PLATFORM_MIPSEL_MEDIATEK_MT7621)
#ifdef ZLDCONFIG_PLATFORM_AARCH64_QUALCOMM_IPQ807X
# max memory usage (90M in IPQ807X. VmRSS is displayed in KB)
MEMMAXIMUM=$((90*1024))
#endif
#if defined(ZLDCONFIG_PLATFORM_ARM_QUALCOMM_IPQ40XX) || defined(ZLDCONFIG_PLATFORM_MIPSEL_MEDIATEK_MT7621)
# max memory usage (10M with thread disabled. VmRSS is displayed in KB)
MEMMAXIMUM=$((10*1024))
#endif
#else
# max memory usage (15M. VmRSS is displayed in KB, bash does not support float calc)
MEMMAXIMUM=$((15*1024))
#endif

# max radius log file size (500K)
RADIUSLOGSIZE=$((500*1024))

# max radiusd process number
RADIUS_MAX_PROCESS_NUM=5

# status check times & timeout
RADIUS_STATUS_CHECK_TIMES=5
RADIUS_STATUS_CHECK_TIMEOUT=5

while :
do
        sleep 30

        CurrentTime=$(date +%F_%H-%M-%S)
        opt=0

        filesize=$(wc -c "$COUNT_FILE" 2>/dev/null | cut -f 1 -d ' ')
        if [ ${filesize:=0} -gt $LOGFILESIZE ]; then
                rm -f $COUNT_FILE
                echo "[${CurrentTime}] radiusd_restart_cnt has reached max log size" >> ${COUNT_FILE}
        fi

        if [ ! -f $COUNT_FILE ]; then
                touch $COUNT_FILE
        fi

        if [ ! -f "/tmp/radiusd_start_running" ]; then
                RADIUS_PROCESS_NUM=`ps | grep -w 'radiusd' | grep -v 'grep' | wc -l`

                if [ ${RADIUS_PROCESS_NUM} -gt ${RADIUS_MAX_PROCESS_NUM} ]; then
                        # too much radiusd process!!
                        echo "[$CurrentTime] Reason: radiusd process number ($RADIUS_PROCESS_NUM) > max. process number ($RADIUS_MAX_PROCESS_NUM)" >> $COUNT_FILE
                        opt=1
                elif [ ${RADIUS_PROCESS_NUM} -gt 0 ]; then
                        # radiusd exist, get PID
                        RADIUSPID=`cat /var/run/radiusd.pid 2>/dev/null`
                        # radiusd exist, check memory usage
                        MEMUSAGE=`cat /proc/$RADIUSPID/status 2>/dev/null | grep "VmRSS" | awk '{print $2}'`
                        # radiusd exist, check radius.log size
                        RADIUSLOGUSAGE=$(wc -c /var/log/radius/radius.log 2>/dev/null | cut -f 1 -d ' ')

                        if [ -z ${RADIUSPID} ]; then
                                # radiusd.pid may not exist before it daemonized.
                                # echo "[$CurrentTime] Reason: radiusd.pid does not exist" >> $COUNT_FILE
                                # opt=1
                                true
                        # check priority: 1.radius.log size 2.memory usage 3.status check
                        elif [ ${RADIUSLOGUSAGE:=0} -gt ${RADIUSLOGSIZE} ]; then
                                rm -f /var/log/radius/radius.log
                                echo "[$CurrentTime] Reason: reach max radius log size" >> $COUNT_FILE
                                opt=1
                        elif [ ${MEMUSAGE:=0} -gt ${MEMMAXIMUM} ]; then
                                echo "[$CurrentTime] Reason: radiusd VmRSS ($MEMUSAGE) > max memory threshold ($MEMMAXIMUM)" >> $COUNT_FILE
                                opt=1
                        elif [ 0 -eq "$(echo 'Message-Authenticator = 0x00' | /usr/bin/radclient -t "${RADIUS_STATUS_CHECK_TIMEOUT}" -r "${RADIUS_STATUS_CHECK_TIMES}" 127.0.0.1:18121 status adminsecret | grep 'Received Access-Accept' | wc -l)" ]; then
                                # radiusd is not respond to status check
                                echo "[$CurrentTime] Reason: status check failed" >> $COUNT_FILE
                                opt=1
                        fi
                else
                        # radiusd is not running?
                        # echo "[$CurrentTime] Reason: daemon is not running?" >> $COUNT_FILE
                        opt=1
                fi
        fi
        if [ $opt -eq 1 ]; then
                /usr/local/bin/radiusd_start.sh &
        fi
done

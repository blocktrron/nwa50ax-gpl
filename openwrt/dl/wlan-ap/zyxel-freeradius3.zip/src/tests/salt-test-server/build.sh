salt-ssh --config-dir=salt_config -l quiet "test-server" state.highstate

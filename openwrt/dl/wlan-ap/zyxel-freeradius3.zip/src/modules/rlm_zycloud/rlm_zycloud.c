/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/

/**
 * $Id: 96032d09509a04dfc35b07861d2c03cb27a02d77 $
 * @file rlm_always.c
 * @brief Return preconfigured fixed rcodes.
 *
 * @copyright 2000,2006  The FreeRADIUS server project
 */
//RCSID("$Id: 96032d09509a04dfc35b07861d2c03cb27a02d77 $")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>
#include <freeradius-devel/modcall.h>
#include <freeradius-devel/zyRadius.h>
#include "zld-spec.h"
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>

/*
 *	The instance data for rlm_always is the list of fake values we are
 *	going to return.
 */

#define RADIUSTOCLOUD	"/usr/sbin/radiustocloud"
#define BIN_CAT	"/bin/cat"
#define RADDB_DIR 		"/var/zyxel/raddb"

#define GET_USERNAME						1
#define GET_PASSWORD						2
#define GET_EXPIRED							3
#define GET_HTTPCODE						4

#define	NO							0
#define	YES							1

#define MAX_SLOT						2
#define MAX_VAP							8

//#define MAX_CLOUD_USERNAME_LEN					(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define MAX_CLOUD_PASSWORD_LEN						(ZLDSYSPARM_UAM_PASSWORD_LEN)

#define USERNAME							"username:"
#define PASSWORD							"password:"
#define CLOUD_EXPIRED						"valid_until:"
#define HTTPCODE							"httpcode:"
#define VLAN_ID								"vlan_id:"

#define MAC_FORMAT "%c%c-%c%c-%c%c-%c%c-%c%c-%c%c"
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5],(a)[6], (a)[7], (a)[8], (a)[9], (a)[10], (a)[11]

typedef struct rlm_zycloud_t {
} rlm_zycloud_t;

/*
 *	A mapping of configuration file names to internal variables.
 */
static const CONF_PARSER module_config[] = {
		CONF_PARSER_TERMINATOR
};

struct case_type_t {
	char *name;
	int type;
};

struct delimiter_type_t {
	char *name;
	char type;
};

#define UPPER	0
#define LOWER	1

struct case_type_t case_map[] = {
	{"upper",	UPPER},
	{"lower",	LOWER}
};

struct delimiter_type_t delimiter_map[] = {
	{"none",	'\0'},
	{"colon",	':'},
	{"dash",	'-'}
};

int change_mac_format(char *mac, size_t len, char *mac_case, char *mac_delimiter)
{
	int ret = 0, target_case = UPPER;
	size_t i, idx = 0;;
	char target_delimiter = '\0', tmp_mac[20] = {0};

	if ((mac_case==NULL) || (mac_delimiter==NULL)) {
		ERROR("mac_case or mac_delimiter is NULL\n");
		ret = -1;
		goto end;
	}

	for (i = 0; i < (sizeof(case_map)/sizeof(struct case_type_t)); i++) {
		struct case_type_t *map = &case_map[i];
		if (!strcmp(map->name, mac_case)) {
			target_case = map->type;
			break;
		}
	}

	for (i = 0; i < (sizeof(delimiter_map)/sizeof(struct delimiter_type_t)); i++) {
		struct delimiter_type_t *map = &delimiter_map[i];
		if (!strcmp(map->name, mac_delimiter)) {
			target_delimiter = map->type;
			break;
		}
	}

	if (len == 12) { /* mac format is aabbccddeeff */
		for (i=0; i<len; i++) {
			if (target_case == UPPER){
				tmp_mac[idx] = (char) toupper(mac[i]);
				idx++;
			}
			else {
				tmp_mac[idx] = (char) tolower(mac[i]);
				idx++;
			}

			if (i == (len-1)) {
				continue;
			}
			else if (((i+1)%2) == 0) {
				if(target_delimiter != '\0')
				{
					tmp_mac[idx] = target_delimiter;
					idx++;
				}
			}
		}
		tmp_mac[idx] = '\0';
	}
	else if (len == 17)
	{ /* mac format is aa:bb:cc:dd:ee:ff or aa-bb-cc-dd-ee-ff */
		for (i=0; i<len; i++) {
			if (((i+1)%3) == 0) {
				if(target_delimiter != '\0')
				{
					tmp_mac[idx] = target_delimiter;
					idx++;
				}
				continue;
			}

			if (target_case == UPPER){
				tmp_mac[idx] = (char) toupper(mac[i]);
				idx++;
			}
			else {
				tmp_mac[idx] = (char) tolower(mac[i]);
				idx++;
			}
		}
		tmp_mac[idx] = '\0';
	}
	else {
		ERROR("mac len is not 12 or 17\n");
		ret = -1;
		goto end;
	}

	sprintf(mac, "%s", tmp_mac);
	DEBUG2("after change_mac_format, mac is %s\n", mac);

end:
	return ret;
}

char *get_param(char *strbuf, int target){
	char line[512], buf[512];
	char *pch = NULL,*saveptr = NULL;

	if(strbuf == NULL){
		return NULL;
	}

	strcpy(line, strbuf);
	switch (target){
		case GET_USERNAME:
			pch = strstr(line, USERNAME);
			if(pch != NULL){
				pch = strtok_r(line, ":", &saveptr);
				pch = strtok_r(NULL, ",", &saveptr);
				strcpy(buf, pch);
				if(strstr(buf, PASSWORD)){
					pch = NULL;
				}
			}
		break;
		case GET_PASSWORD:
			pch = strstr(line, PASSWORD);
			if(pch != NULL){
				strcpy(line, pch);
				pch = strtok_r(line, ":", &saveptr);
				pch = strtok_r(NULL, ",", &saveptr);
				strcpy(buf, pch);
				if(strstr(buf, CLOUD_EXPIRED)){
					pch = NULL;
				}
			}
		break;
		case GET_EXPIRED:
			pch = strstr(line, CLOUD_EXPIRED);
			if(pch != NULL){
				strcpy(line, pch);
				pch = strtok_r(line, ":", &saveptr);
				pch = strtok_r(NULL, ",", &saveptr);
				strcpy(buf, pch);
				if(strstr(buf, VLAN_ID)){
					return NULL;
				}
			}
		break;
		case GET_HTTPCODE:
			pch = strstr(line, HTTPCODE);
			if(pch != NULL){
				strcpy(line, pch);
				pch = strtok_r(line, ":", &saveptr);
				pch = strtok_r(NULL, "\n", &saveptr); /* end of line */
			}
		break;
		default:
			break;
	}
	return pch;
}

int gen_raddb_mac_role(char const *ptr, char *expired, char *httpcode){
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;
	char filename1[128];
	char filename2[128];
	char user_expired[128];
	char http_code[8];
	char str_mac[128];
	int ret=RLM_MODULE_OK;

	sprintf(filename1,"%s/mac_role", RADDB_DIR);
	if ( ( fp1 = fopen(filename1,"w") ) == NULL ) {
		ret = RLM_MODULE_NOOP;
		goto error;
	}

	sprintf(filename2,"%s/authorized_macs", RADDB_DIR);
	if ( ( fp2 = fopen(filename2,"w") ) == NULL ) {
		ret = RLM_MODULE_NOOP;
		goto error;
	}

	if(ptr != NULL){
		snprintf(str_mac, sizeof(str_mac), "%s", ptr);
		if(expired[0] != '\0'){
			strcpy(user_expired, expired);
		}

		if(httpcode[0] != '\0'){
			strcpy(http_code, httpcode);
		}
		if(str_mac[0] != '\0') {
			change_mac_format(str_mac, strlen(str_mac), "upper", "dash");
		}
		/*internal DB : modify "mac_role"*/
		fprintf(fp1,"%s\n  Ext-Group-Name := mac-users,\n  Expired-Timeout := %s,\n  HTTP-Code := %s,\n  Fall-Through = No\n", str_mac, user_expired, http_code);
		/*internal DB : modify "authorized_macs"*/
		fprintf(fp2,"%s\n", str_mac);
	}else{
		fputs("", fp1);
		fputs("", fp2);
	}

	error:
	if (fp1)
		fclose(fp1);
	if (fp2)
		fclose(fp2);

	return ret;
}



static int mod_instantiate(CONF_SECTION *conf, void *instance)
{
	return 0;
}

int isNumber(char *param){
	size_t i, str_len = 0;
	int ret = YES;
	str_len = strlen(param);
	for(i = 0; i < str_len; i++){
		if(!isdigit(*param)){
			ret = NO;
			break;
		}
		param++;
	}
	return ret;
}

static void zyclound_handle(void *instance, REQUEST *request)
{
	VALUE_PAIR *usernamepair = NULL;
	VALUE_PAIR *stationmacpair = NULL;
	VALUE_PAIR *authoptpair = NULL;
	VALUE_PAIR *vapinterfacepair = NULL;
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;
	int slot = 0, index = 0, is_smartMesh = 0;
	char username[18];
	char password[MAX_CLOUD_PASSWORD_LEN];
	char *param = NULL;
	char strbuf[512],cmdBuf[512],ssid_profile_name[64];
	char macbuf[18];
	char expired[128];
	char httpcode[8];
	strbuf[0]  = cmdBuf[0] = ssid_profile_name[0] = macbuf[0]='\0';

	RDEBUG2("cloud mac-auth");

	usernamepair = fr_pair_find_by_num(request->packet->vps, PW_USER_NAME, 0, TAG_ANY);
	stationmacpair = fr_pair_find_by_num(request->packet->vps, PW_CALLING_STATION_ID,0,TAG_ANY);
	authoptpair = fr_pair_find_by_num(request->packet->vps, PW_AUTH_OPT,ZYXEL_VENDOR,TAG_ANY);
	if (authoptpair != NULL) {
		RDEBUG2("cloud_test mac-auth");
		if (!memcmp(authoptpair->vp_strvalue,"macAuth",7)) {
			if (usernamepair) {
				RDEBUG2("attribute: User-Name - (%s)", usernamepair->vp_strvalue);
			}

			if (stationmacpair) {
				RDEBUG2("attribute: Calling-Station-Id - (%s)", stationmacpair->vp_strvalue);
			}

			if (authoptpair) {
				RDEBUG2("attribute: AUTH-Opt - (%s)", authoptpair->vp_strvalue);
			}

			/*get eth mac*/
			snprintf(cmdBuf, sizeof(cmdBuf), "%s /tmp/capwap_mac", BIN_CAT);
			RDEBUG2("cmdBuf=%s", cmdBuf);
			fp1 = popen (cmdBuf, "r");

			if(fp1==NULL){
				RDEBUG2("get eth mac fail. %s, with errno %d.\n",strerror(errno), errno);
				return;
			}

			fgets(macbuf, sizeof(macbuf), fp1);
			RDEBUG2("macbuf=%s", macbuf);
			pclose(fp1);
			vapinterfacepair = fr_pair_find_by_num(request->packet->vps, PW_VAP_INTERFACE , ZYXEL_VENDOR, TAG_ANY);
			if(vapinterfacepair != NULL){
				if (strstr(vapinterfacepair->vp_strvalue, "wlan-") == NULL) {
					RDEBUG2("It's repeater auth., iface=%s\n", vapinterfacepair->vp_strvalue);
					is_smartMesh = 1;
				}
				else if (sscanf(vapinterfacepair->vp_strvalue, "wlan-%d-%d", &slot, &index) != 2) {
					RDEBUG2("ERROR!!!! not sent VAP attribute\n");
				}
				else {
					snprintf(ssid_profile_name, sizeof(ssid_profile_name), "SSID%d", index);
					RDEBUG2("ssid_profile_name=%s\n", ssid_profile_name);
				}
			}
			/* In order to match CC standard format (saved in cloudauthd cache) */
			if(is_smartMesh == 0) {
				strcpy(username, usernamepair->vp_strvalue);
				change_mac_format(username, strlen(username), "upper", "colon");
				// in order to let auth success & auth fail has the same username, we copy Calling-Station-Id to Username pair.
				fr_pair_value_strcpy(usernamepair, stationmacpair->vp_strvalue);
			}
			/*get cloud info */
			if (is_smartMesh == 1) {
				snprintf(cmdBuf, sizeof(cmdBuf), "%s %s radius \"\" %s Smart-Mesh",RADIUSTOCLOUD,usernamepair->vp_strvalue,macbuf);
			}
			else {
				snprintf(cmdBuf, sizeof(cmdBuf), "%s %s radius \"%s\" %s MAC-auth",RADIUSTOCLOUD,username,ssid_profile_name,macbuf);
			}
			fp2 = popen (cmdBuf, "r");
			RDEBUG2("cmdBuf=%s", cmdBuf);
			if(fp2==NULL){
				RDEBUG2("cloud_info is failed. %s, with errno %d.\n",strerror(errno), errno);
			}
			fgets(strbuf, sizeof(strbuf) , fp2);
			RDEBUG2("strbuf2=%s", strbuf);
			/*if the user is exist,we need to gen_raddb_mac_role */
			pclose(fp2);

			password[0] = '\0';
			param=get_param(strbuf, GET_PASSWORD);
			if(param == NULL){
				RDEBUG2("no password \n");
				gen_raddb_mac_role(NULL, NULL, NULL);
				return;
			}else{
				strcpy(password, param);
				RDEBUG2("passowrd: %s\n", password);
			}

			expired[0] = '\0';
			param=get_param(strbuf, GET_EXPIRED);
			if(param == NULL){
				RDEBUG2("no user expired time\n");
				strcpy(expired, "0");	/* if expired is null then set 0 */
			}else{
				if(isNumber(param) == YES){ /* preventing CC send non-number characters */
					strcpy(expired, param);
				}else{
					RDEBUG2("expired time isn't a number\n");
					strcpy(expired, "0");	/* if expired isn't number then set 0 */
				}
			}
			RDEBUG2("expired: %s\n", expired);

			httpcode[0] = '\0';
			param=get_param(strbuf, GET_HTTPCODE);
			if(param == NULL){
				RDEBUG2("no http code\n");
				httpcode[0] = '\0';
			}else{
				strcpy(httpcode, param);
				RDEBUG2("http code: %s\n", httpcode);
			}

			if (password[0] != '\0') {
				gen_raddb_mac_role(stationmacpair->vp_strvalue, expired, httpcode);
				RDEBUG2("get mac-auth info");
			}else {
				/*we can not get password from CC*/
				return;

			}
		}
	}else {
		/*password auth*/
		RDEBUG2("password auth");
		return;
	}
}

static rlm_rcode_t CC_HINT(nonnull) mod_zycloud_return(void *instance, UNUSED REQUEST *request)
{
	return RLM_MODULE_NOOP;
}


static rlm_rcode_t CC_HINT(nonnull) mod_zycloud(void *instance, REQUEST *request)
{
	zyclound_handle(instance, request);
	return RLM_MODULE_NOOP;

}


extern module_t rlm_zycloud;
module_t rlm_zycloud = {
	.magic		= RLM_MODULE_INIT,
	.name		= "zycloud",
	.type		= RLM_TYPE_HUP_SAFE,
	.inst_size	= sizeof(rlm_zycloud_t),
	.config		= module_config,
	.instantiate	= mod_instantiate,
	.methods = {
		[MOD_AUTHENTICATE]	= mod_zycloud,
		[MOD_AUTHORIZE]		= mod_zycloud,
		[MOD_PREACCT]		= mod_zycloud_return,
		[MOD_ACCOUNTING]	= mod_zycloud_return,
#ifdef WITH_SESSION_MGMT
		[MOD_SESSION]		= mod_zycloud,
#endif
		[MOD_PRE_PROXY]		= mod_zycloud,
		[MOD_POST_PROXY]	= mod_zycloud,
		[MOD_POST_AUTH]		= mod_zycloud,
#ifdef WITH_COA
		[MOD_RECV_COA]		= mod_zycloud_return,
		[MOD_SEND_COA]		= mod_zycloud_return
#endif
	},
};

var searchData=
[
  ['name',['name',['../d0/df8/structtransapi__rpc__callbacks.html#a5ac083a645d964373f022d03df4849c8',1,'transapi_rpc_callbacks']]],
  ['ns_5fmapping',['ns_mapping',['../d9/dc0/structtransapi.html#a517eb18d6321490a3439ae595edbf9a4',1,'transapi']]]
];

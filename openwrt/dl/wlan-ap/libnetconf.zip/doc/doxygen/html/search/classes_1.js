var searchData=
[
  ['ncds_5fcustom_5ffuncs',['ncds_custom_funcs',['../d0/d28/structncds__custom__funcs.html',1,'']]],
  ['ns_5fpair',['ns_pair',['../d0/d77/structns__pair.html',1,'']]]
];

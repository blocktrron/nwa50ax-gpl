var searchData=
[
  ['clbcks_5fapplied',['CLBCKS_APPLIED',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1',1,'transapi.h']]]
];

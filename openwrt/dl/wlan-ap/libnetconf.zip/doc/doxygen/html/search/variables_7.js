var searchData=
[
  ['lock',['lock',['../d0/d28/structncds__custom__funcs.html#ad4ec2f4e544216398bf5b56a383a4dfa',1,'ncds_custom_funcs']]]
];

var searchData=
[
  ['rollback',['rollback',['../d0/d28/structncds__custom__funcs.html#a1f69235dfc5cd8714c45690fff0abdc5',1,'ncds_custom_funcs']]],
  ['rpc_5fclbks',['rpc_clbks',['../d9/dc0/structtransapi.html#ae40968626e78bf37871565d98292b1b7',1,'transapi']]]
];

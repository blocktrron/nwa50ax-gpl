var searchData=
[
  ['todo_20list',['Todo List',['../dd/da0/todo.html',1,'']]],
  ['transaction_20api_20_28transapi_29',['Transaction API (transAPI)',['../d9/d25/transapi.html',1,'']]],
  ['transport_20protocol',['Transport Protocol',['../d4/d76/transport.html',1,'usage']]],
  ['troubleshooting',['Troubleshooting',['../d7/dc8/troubles.html',1,'usage']]]
];

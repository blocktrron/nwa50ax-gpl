var searchData=
[
  ['transapi',['transapi',['../d9/dc0/structtransapi.html',1,'']]],
  ['transapi_5fdata_5fcallbacks',['transapi_data_callbacks',['../d6/dcb/structtransapi__data__callbacks.html',1,'']]],
  ['transapi_5ffile_5fcallbacks',['transapi_file_callbacks',['../de/df8/structtransapi__file__callbacks.html',1,'']]],
  ['transapi_5frpc_5fcallbacks',['transapi_rpc_callbacks',['../d0/df8/structtransapi__rpc__callbacks.html',1,'']]]
];

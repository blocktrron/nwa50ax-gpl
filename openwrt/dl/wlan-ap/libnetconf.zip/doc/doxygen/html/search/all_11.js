var searchData=
[
  ['was_5fchanged',['was_changed',['../d0/d28/structncds__custom__funcs.html#a793b5d1b168db7d9529cbc6d02e614b1',1,'ncds_custom_funcs']]],
  ['with_5fdefaults_2eh',['with_defaults.h',['../da/dbe/with__defaults_8h.html',1,'']]],
  ['with_2ddefaults_20capability',['With-defaults capability',['../d1/df7/group__withdefaults.html',1,'']]]
];

var searchData=
[
  ['xmldiff_5fadd',['XMLDIFF_ADD',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488adc0f4fc8354a1e293db5efd4f8e6f0b1',1,'transapi.h']]],
  ['xmldiff_5fchain',['XMLDIFF_CHAIN',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488a4038204cbce3cfa24153b304b95e99a6',1,'transapi.h']]],
  ['xmldiff_5ferr',['XMLDIFF_ERR',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488af2c3cac34cb7553ac93e8f3ad8acee3c',1,'transapi.h']]],
  ['xmldiff_5fmod',['XMLDIFF_MOD',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488a27c20d1fff6c4a35673bea8c6bbe23c4',1,'transapi.h']]],
  ['xmldiff_5fnone',['XMLDIFF_NONE',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488a45a3557c464a0d85a333b68634df5561',1,'transapi.h']]],
  ['xmldiff_5frem',['XMLDIFF_REM',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488a149cdeec9d87bdbb700861f773759129',1,'transapi.h']]],
  ['xmldiff_5freorder',['XMLDIFF_REORDER',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488a732f013a15b9125ea90d20f16d2f2d8e',1,'transapi.h']]],
  ['xmldiff_5fsibling',['XMLDIFF_SIBLING',['../d8/d55/group__transapi.html#gga10d59d84527f735d2781dbbb629a4488afed6f3e2b762ffe2cad87676c48c488f',1,'transapi.h']]]
];

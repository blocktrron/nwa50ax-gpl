var searchData=
[
  ['clbcks_5fapplied_5fchildren_5ferror',['CLBCKS_APPLIED_CHILDREN_ERROR',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1afaf72f8ab2b660b41cd12c9b6221dcaf',1,'transapi.h']]],
  ['clbcks_5fapplied_5fchildren_5fno_5ferror',['CLBCKS_APPLIED_CHILDREN_NO_ERROR',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1af0e0aab72e30c282ea342d41f9f199be',1,'transapi.h']]],
  ['clbcks_5fapplied_5ferror',['CLBCKS_APPLIED_ERROR',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1ade6e4c0852716f8abb3a8c6bf6c01b2d',1,'transapi.h']]],
  ['clbcks_5fapplied_5ffully',['CLBCKS_APPLIED_FULLY',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1a1f22ada2f979a364421c615aab111a55',1,'transapi.h']]],
  ['clbcks_5fapplied_5fno_5ferror',['CLBCKS_APPLIED_NO_ERROR',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1a62f4abe20a7abaaaa40a1f0da8f729d2',1,'transapi.h']]],
  ['clbcks_5fapplied_5fnone',['CLBCKS_APPLIED_NONE',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1a3d548192228314ac8c57d98290d4d871',1,'transapi.h']]],
  ['clbcks_5fapplied_5fnot_5ffully',['CLBCKS_APPLIED_NOT_FULLY',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1ad8fad907385a1343c08b53fbe1923c8a',1,'transapi.h']]],
  ['clbcks_5fapplying_5fchildren',['CLBCKS_APPLYING_CHILDREN',['../d0/db0/transapi_8h.html#a2af5216eb9ecb26064be099ccb8464b1ae3ef919c748a9aab76b44447ab3bb192',1,'transapi.h']]]
];

var searchData=
[
  ['file_5fclbks',['file_clbks',['../d9/dc0/structtransapi.html#a829682c0ae04089a665f2de8f1378446',1,'transapi']]],
  ['free',['free',['../d0/d28/structncds__custom__funcs.html#af147a5b35325a0d302af2d813e60df06',1,'ncds_custom_funcs']]],
  ['func',['func',['../d0/dd1/structclbk.html#aecdb0401379b34c8aa71dd594b79d45d',1,'clbk::func()'],['../d0/df8/structtransapi__rpc__callbacks.html#a4e198e0f385cc9d713aa918597858fbb',1,'transapi_rpc_callbacks::func()'],['../de/df8/structtransapi__file__callbacks.html#a9c1038ab827316debf4109f49818519f',1,'transapi_file_callbacks::func()']]]
];

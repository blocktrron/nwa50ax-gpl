var searchData=
[
  ['nc_5fntf',['nc_ntf',['../da/d54/group__notifications.html#ga3c2f8ca237327fcf3c871544f414bdfe',1,'netconf.h']]],
  ['nc_5freply',['nc_reply',['../d0/de2/group__reply.html#ga40338a1274759a932a7c2c7b8ed0121d',1,'netconf.h']]],
  ['nc_5frpc',['nc_rpc',['../db/de9/group__rpc.html#gab21d1d39737065c552f2ccc5b4819262',1,'netconf.h']]],
  ['ncds_5fid',['ncds_id',['../db/d67/group__store.html#ga8e6ae05c400975ba4d3f038c6d174c19',1,'datastore.h']]]
];

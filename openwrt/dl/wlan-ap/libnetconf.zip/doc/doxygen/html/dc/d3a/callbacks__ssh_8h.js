var callbacks__ssh_8h =
[
    [ "nc_callback_ssh_host_authenticity_check", "db/d52/group__session.html#ga78a69a69dea0369455218c5aeedce9f8", null ],
    [ "nc_callback_sshauth_interactive", "db/d52/group__session.html#ga41c10d3af57cccebc7c67b11e4024c21", null ],
    [ "nc_callback_sshauth_passphrase", "db/d52/group__session.html#ga81ef9b1c1949bbffd86cbfd9aa159726", null ],
    [ "nc_callback_sshauth_password", "db/d52/group__session.html#ga28299d575ef4e234ed96bad5c4f086fb", null ],
    [ "nc_del_keypair_path", "db/d52/group__session.html#ga93972e2d0602d0f3fd2728af279e61c1", null ],
    [ "nc_set_keypair_path", "db/d52/group__session.html#gad067c538c9c44117a99cb0620e135108", null ]
];
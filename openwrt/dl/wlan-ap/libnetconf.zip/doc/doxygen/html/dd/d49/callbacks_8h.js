var callbacks_8h =
[
    [ "nc_callback_error_reply", "d0/de2/group__reply.html#ga771a110143440bcd3b7d4c0e98388e80", null ],
    [ "nc_callback_print", "d3/d35/group__gen_a_p_i.html#ga806dfa9c27d2b8076bae21bcd549cce7", null ]
];
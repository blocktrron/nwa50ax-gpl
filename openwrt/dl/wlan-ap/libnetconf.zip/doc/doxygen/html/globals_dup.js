var globals_dup =
[
    [ "c", "globals.html", null ],
    [ "e", "globals_e.html", null ],
    [ "m", "globals_m.html", null ],
    [ "n", "globals_n.html", null ],
    [ "t", "globals_t.html", null ],
    [ "x", "globals_x.html", null ]
];
var structclbk =
[
    [ "func", "d0/dd1/structclbk.html#aecdb0401379b34c8aa71dd594b79d45d", null ],
    [ "path", "d0/dd1/structclbk.html#a44196e6a5696d10442c29e639437196e", null ]
];
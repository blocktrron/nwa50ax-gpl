#include <stdio.h>
#include <stdarg.h>
#include <time.h>

#define MSG_BUF_SIZE	512

#define LOG_FILE_SIZE	1024000			//1MB
//#define LOG_FILE_PATH   "/etc/zyxel/ftp/tmp/dbg_netconf_session.log"
#define LOG_FILE_PATH   "/tmp/dbg_netconf_session.log"

void LogMsgToFile (const char *fmt, ...)
{
	FILE    *pFile;
	va_list argptr;
	char    szBuf[MSG_BUF_SIZE];

	pFile = fopen (LOG_FILE_PATH,"a+");
	if (pFile != NULL)
	{
		time_t now;
		struct tm *sTime;

		time(&now);
		sTime = localtime(&now);

		va_start (argptr, fmt);
		vsprintf (szBuf, fmt, argptr);
		va_end (argptr);

		fprintf(pFile, "%04d/%02d/%02d %02d:%02d:%02d: %s\n",
				sTime->tm_year + 1900,
				sTime->tm_mon + 1,
				sTime->tm_mday,
				sTime->tm_hour,
				sTime->tm_min,
				sTime->tm_sec,
				szBuf);

		fclose (pFile);
	}
}

void LogTextToFile (char *pszText)
{
	FILE    *pFile;

	pFile = fopen (LOG_FILE_PATH,"a+");
	if (pFile != NULL)
	{
		fseek(pFile, 0, SEEK_END);
		if(ftell(pFile) >= LOG_FILE_SIZE)
		{
			fclose(pFile);
			unlink(LOG_FILE_PATH);
			pFile = fopen(LOG_FILE_PATH, "a+");
			if(pFile != NULL)
				fputs("####### Debug file too large, overwrite it #######\n", pFile);
		}

		fprintf (pFile, "%s\n==========\n", pszText);
		fclose (pFile);
	}
}

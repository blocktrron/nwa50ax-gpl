/******************************************************************************
*
*  Module:     hy_fwd
*  File Name:  hy_fwd.h
*  Description: header file of hybrid forwarding module
*  Date:       08/10/2020
*  Version:    1.0
*  Autor:      Albert Liu
*
******************************************************************************/
#ifndef HY_FWD_H
#define HY_FWD_H

/*
 *  The wax650 use generic netlink. The other
 *  model use old netlink. So we must use compile
 *  flag to separete them.
 *  The wax650 is ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER
 *  and ZLDSYSPARM_ATHEROS_DRIVER_VERSION = 110.
 *  MTK platform use wax650 netlink_extern.h,
 *  we need to define NETLINK_EXT here.
 */
#if !defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) || (ZLDSYSPARM_ATHEROS_DRIVER_VERSION != 110)
#if defined(ZLDCONFIG_WLAN_BUILD_MTK_DRIVER)
#define NETLINK_EXT 31
#else
#define NETLINK_EXT NETLINK_HY_FWD
#endif /* ZLDCONFIG_WLAN_BUILD_MTK_DRIVER */
#endif /* !ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER || (ZLDSYSPARM_ATHEROS_DRIVER_VERSION != 110) */

enum nl_msg_id {
	HY_FWD_CMD_ADD_LINK = 1,
	HY_FWD_CMD_DEL_LINK,
	FWD_CMD_MAX
};

#define SEND_EVENT_LEN 256

/*Data structure definition.*/
struct device_link{
	char name[IFNAMSIZ];
	char blk_mc;		/* mc pkt 0: not block, 1: block */
};

/* netlink attributes */
enum {
	HY_FWD_A_UNSPEC,
	HY_FWD_A_MSG,
	__HY_FWD_A_MAX,
};
#define HY_FWD_A_MAX (__HY_FWD_A_MAX - 1)

/* command */
enum {
	HY_FWD_E_UNSPEC,
	HY_FWD_E_ECHO,
	__HY_FWD_E_MAX,
};
#define HY_FWD_E_MAX (__HY_FWD_E_MAX - 1)
/* max GENL_NAMSIZ (16) bytes: */
#define ZYXEL_HY_FWD_GENL_FAM_NAME "hy_fwd"

struct debug_lvl {
	int level;
};

struct enable {
	int on;
};

struct log_supress {
	int interval;
};

typedef struct hy_event_msg_s{
	pid_t pid;
	int code;
	//char msg[SEND_EVENT_LEN];
	union{
		struct debug_lvl dbg;
		struct enable active;
		struct log_supress log;
	}data;
} hy_event_msg_t;

#define EVT_HY_FWD_DEBUG_LEVEL 0
#define EVT_HY_FWD_SUSPEND 1
#define EVT_HY_FWD_LOG_SUPRESS 2

#endif

 /******************************************************************************
 *
 *	Module:    hy_fwd
 *	File Name: hy_fwd.c
 *	Description: implementation of hybrid forwarding module
 *	Date:      08/10/2020
 *	Version:   1.0
 *	Autor:     Albert Liu
 *
 ******************************************************************************/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/netfilter.h>
#include <linux/netfilter_bridge.h>
#include <linux/list.h>
#include <linux/if_ether.h>
#include <linux/etherdevice.h>
#include <net/netlink.h>
#include <linux/string.h>
#include <linux/timer.h>
#include <linux/smp.h>
#include <linux/spinlock.h>
#include <linux/kobject.h>
#include <linux/version.h>
#include <linux/jhash.h>
#include <linux/if_bridge.h>
#include <zld/netlink_extern.h>
#include <zld-spec.h>
#if defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
#include <linux/rtnetlink.h>
#include <net/genetlink.h>
#endif /* ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110) */
#include <linux/kthread.h>
#include <linux/delay.h>
#include "hy_fwd.h"

#define MAX_ENTRY_CNT 256

/* Macro definition */
#define HASH_TABLE_SIZE 256
#define MAC_ADDR_HASH(addr) (addr[0]^addr[1]^addr[2]^addr[3]^addr[4]^addr[5])
#define MAC_ADDR_HASH_INDEX(addr) (MAC_ADDR_HASH(addr) & (HASH_TABLE_SIZE - 1))
#define MAX(a, b) ((a > b) ? (a) : (b))
#define MIN(a, b) ((a < b) ? (a) : (b))

#define DBG_LVL_OFF	0
#define DBG_LVL_ERROR	1
#define DBG_LVL_WARN	2
#define DBG_LVL_TRACE	3
#define DBG_LVL_INFO	4
#define DBG_LVL_LOUD	5

#define AGEOUT_TIME     30000 /* 0.5 mins */

unsigned long dbg_level = DBG_LVL_LOUD;

#define HY_DBGPRINT_RAW(Level, Fmt)    \
do{                                    \
	unsigned long __gLevel = (Level) & 0xff;\
	if (__gLevel <= dbg_level)      \
	{                               \
		printk Fmt;                 \
	}                               \
}while(0)

#define HY_DBGPRINT(Level, Fmt)    HY_DBGPRINT_RAW(Level, Fmt)

struct link_entry {
	struct list_head list;
	struct rcu_head rcu;
	struct net_device *dev;
	char blk_mc;		/* mc pkt 0:not block, 1: block */
	char addr[ETH_ALEN];
};

extern struct net_device *br_port_dev_get(struct net_device *dev, unsigned char *addr,
				   struct sk_buff *skb,
				   unsigned int cookie);

/* Global variable */
int link_tbl_cnt = 0;
spinlock_t link_tbl_lock;
struct list_head link_tbl[HASH_TABLE_SIZE];
struct sock *nl_sk = NULL;
struct task_struct *ageout_thread = NULL;

#if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 9, 0))
static inline bool is_vlan_dev(const struct net_device *dev)
{
	return dev->priv_flags & IFF_802_1Q_VLAN;
}
#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(3, 9, 0) */

static inline int hy_fwd_is_ieee1905_pkt(struct sk_buff *skb)
{
	struct ethhdr *ethhdr = eth_hdr(skb);

	if (unlikely(ethhdr == NULL || ethhdr->h_proto == htons(0x893A))) {
		return 1;
	}

	return 0;
}

static inline struct net_device *hy_fwd_get_master(struct net_device *dev)
{
	struct net_device *master = NULL;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 9, 0))
	rcu_read_lock();
	master = netdev_master_upper_dev_get_rcu(dev);
	if (master)
		dev_hold(master);

	rcu_read_unlock();
#else
	master = dev->master;
	if (master)
		dev_hold(master);
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(3, 9, 0) */
	return master;
}

static inline struct net_device *hy_fwd_get_by_name(const char *name)
{
	return dev_get_by_name(&init_net, name);
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0))
unsigned int hy_fwd_hook_local_out(void *priv,
		struct sk_buff *skb,
		const struct nf_hook_state *state)
#else
unsigned int hy_fwd_hook_local_out(unsigned int hooknum,
		struct sk_buff *skb,
		const struct net_device *in,
		const struct net_device *out,
		int (*okfn)(struct sk_buff *))
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0) */
{
	const struct net_device *outdev = NULL;
	int hash_idx = 0;
	struct link_entry *lk_pos = NULL;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0))
	outdev = state->out;
#else
	outdev = out;
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0) */

	if (link_tbl_cnt < 2) {
		return NF_ACCEPT;
	}

	if (unlikely(!skb)) {
		return NF_ACCEPT;
	}

	if (hy_fwd_is_ieee1905_pkt(skb)) {
		return NF_ACCEPT;
	}

	if (likely(!is_multicast_ether_addr(eth_hdr(skb)->h_dest))) {
		return NF_ACCEPT;
	}

	if (unlikely(!outdev)) {
		return NF_ACCEPT;
	}
	/* hold the interface reference to avoid the reace condition */
	dev_hold(outdev);
	
	{
		if (is_vlan_dev(outdev)) {
			const struct net_device *real_dev = NULL;
			real_dev = vlan_dev_real_dev(outdev);
			dev_hold(real_dev);
			dev_put(outdev);
			outdev = real_dev;
		}

		hash_idx = MAC_ADDR_HASH_INDEX(outdev->dev_addr);
		rcu_read_lock();
		list_for_each_entry_rcu(lk_pos, &link_tbl[hash_idx], list) {
			if (lk_pos->dev == outdev && lk_pos->blk_mc) {
				rcu_read_unlock();
				dev_put(outdev);
				return NF_DROP;
			}
		}
		rcu_read_unlock();
	}
	
	dev_put(outdev);
	return NF_ACCEPT;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0))
unsigned int hy_fwd_hook_pre_routing(void *priv,
		struct sk_buff *skb,
		const struct nf_hook_state *state)
#else
unsigned int hy_fwd_hook_pre_routing(unsigned int hooknum,
		struct sk_buff *skb,
		const struct net_device *in,
		const struct net_device *out,
		int (*okfn)(struct sk_buff *))
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0) */
{
	const struct net_device *indev = NULL;
	int hash_idx = 0;
	struct link_entry *lk_pos = NULL;
	int is_loop_pkt = 0;
	int is_from_bh = 0;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0))
	indev = state->in;
#else
	indev = in;
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0) */

	if (link_tbl_cnt < 2) {
		return NF_ACCEPT;
	}

	if (unlikely(!skb)) {
		return NF_ACCEPT;
	}

	if (hy_fwd_is_ieee1905_pkt(skb)) {
		return NF_ACCEPT;
	}

	if (likely(!is_multicast_ether_addr(eth_hdr(skb)->h_dest))) {
		return NF_ACCEPT;
	}

	if (unlikely(!indev)) {
		return NF_ACCEPT;
	}
	/* hold the interface reference to avoid the reace condition */
	dev_hold(indev);

	/* first check if this is generated by backhaul interface */
	hash_idx = MAC_ADDR_HASH_INDEX(eth_hdr(skb)->h_source);
	rcu_read_lock();
	list_for_each_entry_rcu(lk_pos, &link_tbl[hash_idx], list) {
		if (!memcmp(lk_pos->addr, eth_hdr(skb)->h_source, ETH_ALEN)) {
			is_loop_pkt = 1;
			break;
		}
	}
	rcu_read_unlock();

	if (unlikely(is_loop_pkt)) {
		const struct net_device *real_dev = NULL;
		/* find out the physical interfaces */
		if (is_vlan_dev(indev)) {
			real_dev = vlan_dev_real_dev(indev);
			dev_hold(real_dev);
			dev_put(indev);
			indev = real_dev;
		}
		hash_idx = MAC_ADDR_HASH_INDEX(indev->dev_addr);
		rcu_read_lock();
		list_for_each_entry_rcu(lk_pos, &link_tbl[hash_idx], list) {
			if (lk_pos->dev == indev) {
				if (lk_pos->blk_mc) {
					rcu_read_unlock();
					dev_put(indev);
					return NF_DROP;
				}
				is_from_bh = 1;
				break;
			}
		}
		rcu_read_unlock();

		/* drop the packet if loop detected but not receive by backhaul interface */
		if (!is_from_bh){
			dev_put(indev);
			return NF_DROP;
		}
	}

	dev_put(indev);
	return NF_ACCEPT;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0))
unsigned int hy_fwd_hook_forwarding(void *priv,
		struct sk_buff *skb,
		const struct nf_hook_state *state)
#else
unsigned int hy_fwd_hook_forwarding(unsigned int hooknum,
		struct sk_buff *skb,
		const struct net_device *in,
		const struct net_device *out,
		int (*okfn)(struct sk_buff *))
#endif
{
	const struct net_device *outdev = NULL;
	const struct net_device *indev = NULL;
	int hash_idx = 0;
	int hash_idx_in = 0;
	struct link_entry *lk_pos = NULL;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0))
	indev = state->in;
	outdev = state->out;
#else
	indev = in;
	outdev = out;
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0) */

	if (link_tbl_cnt < 2) {
		return NF_ACCEPT;
	}

	if (unlikely(!skb)) {
		return NF_ACCEPT;
	}

	if (hy_fwd_is_ieee1905_pkt(skb)) {
		return NF_ACCEPT;
	}

	if (unlikely(!indev || !outdev)) {
		return NF_ACCEPT;
	}

	/* hold the interface reference to avoid the reace condition */
	dev_hold(indev);
	dev_hold(outdev);
	{
		const struct net_device *real_dev = NULL;
		/* find out the physical interfaces */
		if (is_vlan_dev(indev)) {
			real_dev = vlan_dev_real_dev(indev);
			dev_hold(real_dev);
			dev_put(indev);
			indev = real_dev;
		}
		if (is_vlan_dev(outdev)) {
			real_dev = vlan_dev_real_dev(outdev);
			dev_hold(real_dev);
			dev_put(outdev);
			outdev = real_dev;
		}

		hash_idx = MAC_ADDR_HASH_INDEX(outdev->dev_addr);
		rcu_read_lock();
		list_for_each_entry_rcu(lk_pos, &link_tbl[hash_idx], list) {
			if (lk_pos->dev == outdev && lk_pos->blk_mc) {
				rcu_read_unlock();
				dev_put(indev);
				dev_put(outdev);
				return NF_DROP;
			}
		}
		rcu_read_unlock();

		hash_idx_in = MAC_ADDR_HASH_INDEX(indev->dev_addr);
		rcu_read_lock();
		list_for_each_entry_rcu(lk_pos, &link_tbl[hash_idx_in], list) {
			if (lk_pos->dev == indev && lk_pos->blk_mc) {
				rcu_read_unlock();
				dev_put(indev);
				dev_put(outdev);
				return NF_DROP;
			}
		}
		rcu_read_unlock();

	}
	dev_put(indev);
	dev_put(outdev);

	return NF_ACCEPT;
}

void free_lk_entry(struct rcu_head *head)
{
	struct link_entry *blk =
		container_of(head, struct link_entry, rcu);
	kfree(blk);
	return;
}

void ageout_link_entry(void)
{
	struct link_entry *pos = NULL, *n = NULL;
	int hash_idx = 0;

	do {
		spin_lock(&link_tbl_lock);
		for (hash_idx = 0; hash_idx < HASH_TABLE_SIZE; hash_idx++) {
			list_for_each_entry_safe(pos, n, &link_tbl[hash_idx], list) {
				if (pos->dev->dev_addr == NULL) {
					list_del_rcu(&pos->list);
					link_tbl_cnt--;
					call_rcu(&pos->rcu, free_lk_entry);
					HY_DBGPRINT(DBG_LVL_ERROR, ("ageout: del link \n"));
				}
			}
		}
		spin_unlock(&link_tbl_lock);
		msleep(AGEOUT_TIME);
	}while(!kthread_should_stop());

	return;
}

int add_link_entry(struct device_link *lk)
{
	struct net_device *dev = NULL;
	struct link_entry *pos = NULL;
	int hash_idx = 0;

	dev = hy_fwd_get_by_name(lk->name);
	if (dev == NULL) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("no net device found for %s\n", lk->name));
		return -1;
	}

	hash_idx = MAC_ADDR_HASH_INDEX(dev->dev_addr);
	HY_DBGPRINT(DBG_LVL_LOUD, ("hash_idx: %d\n", hash_idx));
	spin_lock(&link_tbl_lock);
	list_for_each_entry(pos, &link_tbl[hash_idx], list) {
		if (pos->dev == dev) {
			if (dev->dev_addr) {
				memcpy(pos->addr, dev->dev_addr, ETH_ALEN);
			}
			else {
				HY_DBGPRINT(DBG_LVL_ERROR, ("update link %s fail, device address null\n", lk->name));
				return -1;
			}
			pos->blk_mc = lk->blk_mc;
			HY_DBGPRINT(DBG_LVL_ERROR, ("update link %s, blk_mc:%d\n", lk->name, lk->blk_mc));
			break;
		}
	}

	if (&pos->list == &link_tbl[hash_idx] && link_tbl_cnt <= MAX_ENTRY_CNT) {
		/*add a new entry to table.*/
		if (dev->dev_addr) {
			pos = kmalloc(sizeof(struct link_entry), GFP_ATOMIC);
			if (pos == NULL) {
				spin_unlock(&link_tbl_lock);
				goto exit1;
			}
			
			memset(pos, 0, sizeof(struct link_entry));
			pos->dev = dev;
			pos->blk_mc = lk->blk_mc;
			memcpy(pos->addr, dev->dev_addr, ETH_ALEN);

			list_add_tail_rcu(&pos->list, &link_tbl[hash_idx]);
			link_tbl_cnt++;
			
			HY_DBGPRINT(DBG_LVL_ERROR, ("add link %s, blk_mc:%d, link_tbl_cnt=%d\n", lk->name, lk->blk_mc, link_tbl_cnt));
		}
		else {
			HY_DBGPRINT(DBG_LVL_ERROR, ("add link %s fail, device address null\n", lk->name));
			return -1;
		}
	}
	spin_unlock(&link_tbl_lock);

exit1:
	dev_put(dev);

	return 0;
}

int del_link_entry(struct device_link *lk)
{
	struct link_entry *pos = NULL, *n = NULL;
	struct net_device *dev = NULL;
	int hash_idx = 0;

	dev = hy_fwd_get_by_name(lk->name);
	if (dev == NULL) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("no net device found for %s\n", lk->name));
		return -1;
	}

	hash_idx = MAC_ADDR_HASH_INDEX(dev->dev_addr);

	spin_lock(&link_tbl_lock);
	list_for_each_entry_safe(pos, n, &link_tbl[hash_idx], list) {
		if (dev == pos->dev) {
			list_del_rcu(&pos->list);
			link_tbl_cnt--;
			call_rcu(&pos->rcu, free_lk_entry);
			HY_DBGPRINT(DBG_LVL_ERROR, ("del link %s\n", lk->name));
		}
	}
	spin_unlock(&link_tbl_lock);

	dev_put(dev);

	return 0;
}

void parse_nlmsg(char *msg)
{
	HY_DBGPRINT(DBG_LVL_TRACE, ("receive msg: %02x\n", msg[0]));

	switch (msg[0]) {
	case HY_FWD_CMD_ADD_LINK:
		add_link_entry((struct device_link *)&msg[1]);
		break;
	case HY_FWD_CMD_DEL_LINK:
		del_link_entry((struct device_link *)&msg[1]);
		break;
	default:
		break;
	}
	return;
}

void recv_nlmsg(struct sk_buff *skb)
{
	int pid = 0;
	struct nlmsghdr *nlh = nlmsg_hdr(skb);
	char *msg = NULL;

	if (nlh->nlmsg_len < NLMSG_HDRLEN || skb->len < nlh->nlmsg_len) {
		return;
	}

	msg = (char *)NLMSG_DATA(nlh);
	pid = nlh->nlmsg_pid;

	parse_nlmsg(msg);

	return;
}

#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0)
struct netlink_kernel_cfg nl_kernel_cfg = {
	.groups = 0,
	.flags = 0,
	.input = recv_nlmsg,
	.cb_mutex = NULL,
	.bind = NULL,
	.unbind = NULL,
	.compare = NULL,
};
#endif /* LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0) */

static struct nf_hook_ops hk_ops[] = {
	{
		.hook		= hy_fwd_hook_pre_routing,
		.pf		= NFPROTO_BRIDGE,
		.hooknum	= NF_BR_PRE_ROUTING,
		.priority	= NF_BR_PRI_FIRST,
	},
	{
		.hook		= hy_fwd_hook_forwarding,
		.pf		= NFPROTO_BRIDGE,
		.hooknum	= NF_BR_FORWARD,
		.priority	= NF_BR_PRI_FIRST,
	},
	{
		.hook		= hy_fwd_hook_local_out,
		.pf		= NFPROTO_BRIDGE,
		.hooknum	= NF_BR_LOCAL_OUT,
		.priority	= NF_BR_PRI_FIRST,
	}
};

static ssize_t fwd_show_setting(struct kobject *kobj,
		struct kobj_attribute *attr, char *buf)
{
	unsigned int i = 0, n = 0;
	struct link_entry *lk_pos = NULL;

	n = 0;
	sprintf(buf, "[hy_fwd] client link table:\n");
	rcu_read_lock();
	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		list_for_each_entry_rcu(lk_pos, &link_tbl[i], list) {
			sprintf(buf+strlen(buf), "\t%d: %s, block_mc=%d\n", n++,
				lk_pos->dev->name, lk_pos->blk_mc);
		}
	}
	rcu_read_unlock();

	return strlen(buf);
}

static ssize_t fwd_set_dbg_level(struct kobject *kobj,
		struct kobj_attribute *attr, const char *buf, size_t count)
{
	int dbglvl = simple_strtol(buf, 0, 10);

	if (DBG_LVL_OFF <= dbglvl && dbglvl <= DBG_LVL_LOUD) {
		dbg_level = dbglvl;
		HY_DBGPRINT(DBG_LVL_OFF, ("set hy_fwd dbg level set to %d\n", dbglvl));
	} else
		HY_DBGPRINT(DBG_LVL_OFF, ("value is invalid, it should be 0~5\n"));

	return count;
}

static struct kobj_attribute hy_fwd_sysfs_show_setting =
		__ATTR(show_setting, S_IRUGO, fwd_show_setting, NULL);

static struct kobj_attribute hy_fwd_sysfs_set_dbg_level =
		__ATTR(debug_level, S_IWUSR, NULL, fwd_set_dbg_level);

static struct attribute *hy_fwd_sysfs[] = {
	&hy_fwd_sysfs_show_setting.attr,
	&hy_fwd_sysfs_set_dbg_level.attr,
	NULL,
};

static struct attribute_group hy_fwd_attr_group = {
	.attrs = hy_fwd_sysfs,
};
struct kobject *hy_fwd_kobj;

#if defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
static int _is_hy_fwd_genl_init = 0;
/* message handler */
static int hy_fwd_genl_echo_doit(struct sk_buff *skb, struct genl_info *info);

/* attribute policy */
struct nla_policy hy_fwd_genl_policy[HY_FWD_A_MAX + 1] = {
	[HY_FWD_A_MSG] = {.type = NLA_NUL_STRING},
};

/* family definition */
struct genl_family hy_fwd_genl_family = {
	.id = GENL_ID_GENERATE,
	.hdrsize = 0,
	.name = ZYXEL_HY_FWD_GENL_FAM_NAME,
	.version = 1,
	.maxattr = HY_FWD_A_MAX,
};

/* operation definition */
struct genl_ops hy_fwd_genl_ops[] = {
	{
	 .cmd = HY_FWD_E_ECHO,
	 .flags = 0,
	 .policy = hy_fwd_genl_policy,
	 .doit = hy_fwd_genl_echo_doit,
	 .dumpit = NULL,
	 },
};

enum hy_fwd_multicast_groups {
	HY_FWD_MCGRP_CTRL,
};

static struct genl_multicast_group hy_fwd_genl_mc_groups[] = {
	[HY_FWD_MCGRP_CTRL] = {.name = "hy_fwd_ctrl",},
};

static int hy_fwd_genl_echo_doit(struct sk_buff *skb, struct genl_info *info)
{
	struct nlmsghdr *nlhdr = NULL;
	struct genlmsghdr *genlhdr = NULL;
	struct nlattr *nlh = NULL;
	char *msg = NULL;

	nlhdr = nlmsg_hdr(skb);
	if (!nlhdr) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("nlhdr is NULL\n"));
		return -1;
	}
	genlhdr = nlmsg_data(nlhdr);
	if (!genlhdr) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("genlhdr is NULL\n"));
		return -1;
	}
	nlh = genlmsg_data(genlhdr);
	if (!nlh) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("nlh is NULL\n"));
		return -1;
	}
	msg = nla_data(nlh);
	if (!msg) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("msg is NULL\n"));
		return -1;
	}

	parse_nlmsg(msg);

	return 0;
}

int hy_fwd_genl_init(void)
{
	int res;

	if (_is_hy_fwd_genl_init) {
		return 0;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 13, 0)
	res = genl_register_family_with_ops_groups(&hy_fwd_genl_family,
						 hy_fwd_genl_ops,
						 hy_fwd_genl_mc_groups);
	if (res) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("genl_register_family hy_fwd family error!!!\n"));
		return -1;
	}
#else
	res = genl_register_family(&hy_fwd_genl_family);
	if (res != 0) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("genl_register_family hy_fwd family error!!!\n"));
		return -1;
	}

	res = genl_register_ops(&hy_fwd_genl_family, hy_fwd_genl_ops);
	if (res != 0) {
		HY_DBGPRINT(DBG_LVL_ERROR,
			("genl_register_ops hy_fwd family error!!!\n"));
		genl_unregister_family(&hy_fwd_genl_family);
		return -1;
	}

	res = genl_register_mc_group(&hy_fwd_genl_family, hy_fwd_genl_mc_groups);
	if (res != 0) {
		HY_DBGPRINT(DBG_LVL_ERROR,
			("genl_register_mc_group zyUMAC family error!!!\n"));
		genl_unregister_ops(&hy_fwd_genl_family, hy_fwd_genl_ops);
		genl_unregister_family(&hy_fwd_genl_family);
		return -1;
	}
#endif
	_is_hy_fwd_genl_init = 1;
	return 0;
}

void hy_fwd_genl_exit(void)
{
	if (_is_hy_fwd_genl_init) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 13, 0)
		genl_unregister_ops(&hy_fwd_genl_family, hy_fwd_genl_ops);
		genl_unregister_mc_group(&hy_fwd_genl_family,
					 hy_fwd_genl_mc_groups);
#endif
		genl_unregister_family(&hy_fwd_genl_family);
		_is_hy_fwd_genl_init = 0;
	}
	return;
}
#endif /* ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110) */

#define GERERIC_NETLINK 1
static int __init hy_fwd_init(void)
{
	int ret = 0, i = 0;
	ret = 0; i = 0;
	HY_DBGPRINT(DBG_LVL_OFF, ("-->hy_fwd_init()"));

	link_tbl_cnt = 0;

	/* init hash table. */
	spin_lock_init(&link_tbl_lock);
	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		INIT_LIST_HEAD(&link_tbl[i]);
	}

	/* register hook function to bridge. */
	ret = nf_register_hooks(&hk_ops[0], ARRAY_SIZE(hk_ops));
	if (ret < 0) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("register nf hook fail, ret = %d\n", ret));
		goto error1;
	}

	/* register netlink interface. */
#if defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
	if (hy_fwd_genl_init() < 0) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("create netlink socket error.\n"));
		goto error2;
	}
#else
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0)
	nl_sk = netlink_kernel_create(&init_net, NETLINK_EXT, &nl_kernel_cfg);
#else
	nl_sk = netlink_kernel_create(&init_net, NETLINK_EXT, 0, recv_nlmsg, NULL, THIS_MODULE);
#endif /* LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0) */
	if (!nl_sk) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("create netlink socket error.\n"));
		ret = -EFAULT;
		goto error2;
	}
#endif /* ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110) */

	hy_fwd_kobj = kobject_create_and_add("hy_fwd", NULL);
	if (!hy_fwd_kobj) {
		ret = -EFAULT;
		goto error3;
	}

	ret = sysfs_create_group(hy_fwd_kobj, &hy_fwd_attr_group);
	if (ret)
		goto error4;

	ageout_thread = kthread_run(ageout_link_entry, NULL, "ageout link entry thread");
	if (IS_ERR(ageout_thread)) {
		HY_DBGPRINT(DBG_LVL_ERROR, ("create link entry ageout thread error.\n"));
		goto error4;
	}
	HY_DBGPRINT(DBG_LVL_OFF, ("<--"));

	return ret;
error4:
	kobject_put(hy_fwd_kobj);
error3:
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0)
	sock_release(nl_sk->sk_socket);
#else
	netlink_kernel_release(nl_sk);
#endif /* LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0) */
error2:
	nf_unregister_hooks(&hk_ops[0], ARRAY_SIZE(hk_ops));
error1:
	return ret;
}

static void __exit hy_fwd_exit(void)
{
	int i = 0;
	struct link_entry *pos_link = NULL, *link = NULL;

	HY_DBGPRINT(DBG_LVL_OFF, ("-->hy_fwd_exit()"));

	kthread_stop(ageout_thread);

	sysfs_remove_group(hy_fwd_kobj, &hy_fwd_attr_group);
	kobject_put(hy_fwd_kobj);

#if defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
	hy_fwd_genl_exit();
#else
	if (nl_sk != NULL)
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0)
		sock_release(nl_sk->sk_socket);
#else
		netlink_kernel_release(nl_sk);
#endif /* LINUX_VERSION_CODE > KERNEL_VERSION(3, 8, 0) */
#endif /* ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) && (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110) */

	nf_unregister_hooks(&hk_ops[0], ARRAY_SIZE(hk_ops));

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		list_for_each_entry_safe(pos_link, link, &link_tbl[i], list) {
			list_del_rcu(&pos_link->list);
			link_tbl_cnt--;
			kfree(pos_link);
		}
	}

	HY_DBGPRINT(DBG_LVL_OFF, ("<--hy_fwd_exit()"));

	return;
}

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Albert Liu");
MODULE_DESCRIPTION("Hybrid Fowarding Module");

module_init(hy_fwd_init);
module_exit(hy_fwd_exit);

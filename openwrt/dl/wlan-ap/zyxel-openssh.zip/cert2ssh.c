

#include "includes.h"
#include <unistd.h>
#include <sys/types.h>
//RCSID("$OpenBSD: ssh-keygen.c,v 1.117 2004/07/11 17:48:47 deraadt Exp $");

#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include "xmalloc.h"
#include "sshkey.h"
#include "ssh-sk.h"
#include "authfile.h"
#include "pathnames.h"
#include "log.h"
#include "misc.h"
#ifdef HAVE_SYS_TIME_H
# include <sys/time.h>
#endif

#include <stdarg.h>
#include <stdio.h>

#include <ctype.h>
#include <string.h>
#include <dlfcn.h>

#include "openbsd-compat/sys-queue.h"
#include "openbsd-compat/openssl-compat.h"

#include <openssl/ecdsa.h>
#include <openssl/x509.h>
#include <openssl/err.h>

#define CRYPTOKI_COMPAT
#include "pkcs11.h"

#include "ssh-pkcs11.h"
#include "digest.h"
#include "xmalloc.h"

#define _MYDEBUG
#undef 	_MYDEBUG

#ifdef _MYDEBUG
#define MSG(string, args...)	printf(string, ##args)
#else
#define MSG(string, args...)	
#endif

#define CERT_PATH		"/etc/zyxel/ftp/cert/"

#define SSH_PRIVATE_KEY_NAME_V1	"ssh_host_key"
#define SSH_PUBLIC_KEY_NAME_V1	"ssh_host_key.pub"

#define SSH_PRIVATE_KEY_NAME_V2	"ssh_host_rsa_key"
#define SSH_PUBLIC_KEY_NAME_V2	"ssh_host_rsa_key.pub"

#define SSH_PRIVATE_KEY_NAME_DSA	"ssh_host_dsa_key"
#define SSH_PUBLIC_KEY_NAME_DSA		"ssh_host_dsa_key.pub"

#define SSH_PRIVATE_KEY_NAME_ECDSA	"ssh_host_ecdsa_key"
#define SSH_PUBLIC_KEY_NAME_ECDSA	"ssh_host_ecdsa_key.pub"

#define STR_LEN	1024


int check_zyxel_ssh_ecdsa_nid (int ecdsa_nid) {
	/*
		ZYXEL System SSH ECDSA support:
		1. Becaues system ssh config used default HostKeyAlgorithms(see zysh: gen_sshd_conf_file()), the following ecdsa key NID must be supported
		2. KEY_ED25519 is not be supported yet
		3. The following ecdsa key NID must be updated by sshkey_ecdsa_key_to_nid() and HostKeyAlgorithms during openssh upgrading
	*/
	int ret = -1;
	
	switch (ecdsa_nid) {
		case NID_X9_62_prime256v1:
		case NID_secp384r1:
		case NID_secp521r1:
			ret = 0;
		default:
			/*not support.*/
			break;
	}
	return ret;
}

int
main(int argc, char *argv[])
{
	int ret = 1;
	FILE *f = NULL;
	struct passwd *pw;
	char str_buf[STR_LEN];
	char str_buf2[STR_LEN];
	char hostname[STR_LEN], comment[STR_LEN], certfile[STR_LEN];
 	struct sshkey pk, rk;
	BIO  *bio  = NULL;
	X509 *x509 = NULL;
	EVP_PKEY *env_pkey = NULL;
	EVP_PKEY *privKey = NULL;

	OpenSSL_add_all_algorithms();
	
	//init_rng();
	seed_rng();
	
	if (argc != 3) {
		//MSG("Usage: cert2ssh cert_name target_path.\n");
		goto out;
	}
	
	sprintf(certfile, "%s%s", CERT_PATH, argv[1]);
	
	/* we need this for the home * directory.  */
	pw = getpwuid(getuid());
	if (!pw) {
		MSG("You don't exist. go away.\n");
		goto out;
	}
	if (gethostname(hostname, sizeof(hostname)) < 0) {
		MSG("gethostname has failed.\n");		
		goto out;
	}
	
	/* private key */
	sprintf(str_buf, "%s.prv", certfile);
	f = fopen(str_buf, "r");
	if (f == NULL) {
		MSG("Open private key has failed.\n");		
		goto out;
	}
	privKey = PEM_read_PrivateKey(f, NULL, NULL, NULL);
	if (privKey == NULL) {
		MSG("PEM_read_PrivateKey has failed.\n");		
		goto out;
	}
	
	switch ( EVP_PKEY_base_id(privKey) ) {
		case EVP_PKEY_EC:
			rk.ecdsa = EVP_PKEY_get1_EC_KEY(privKey);
			if (rk.ecdsa == NULL) {
				MSG("EVP_PKEY_get1_EC_KEY has failed.\n");		
				goto out;
			}
			rk.type = KEY_ECDSA;
			rk.ecdsa_nid = sshkey_ecdsa_key_to_nid(rk.ecdsa);
			if (check_zyxel_ssh_ecdsa_nid(rk.ecdsa_nid)){
				MSG("check_zyxel_ssh_ecdsa_nid has failed.\n");		
				goto out;
			}
			sprintf(str_buf2, "%s%s", argv[2], SSH_PRIVATE_KEY_NAME_ECDSA);
			break;
			
		case EVP_PKEY_RSA:
			rk.rsa = EVP_PKEY_get1_RSA(privKey);
			if (rk.rsa == NULL) {
				MSG("EVP_PKEY_get1_RSA has failed.\n");		
				goto out;
			}
			rk.type = KEY_RSA;
			sprintf(str_buf2, "%s%s", argv[2], SSH_PRIVATE_KEY_NAME_V2);
			break;
			
		case EVP_PKEY_DSA:
#if 0
			rk.dsa = EVP_PKEY_get0_DSA(privKey);
			if (rk.dsa == NULL) {
				MSG("EVP_PKEY_get0_DSA has failed.\n");		
				goto out;
			}
			rk.type = KEY_DSA;
			
			sprintf(str_buf2, "%s%s", argv[2], SSH_PRIVATE_KEY_NAME_DSA);
			break;
#else
			MSG("EVP_PKEY_DSA is not support.\n");		
			goto out;
#endif
			
		default:
			MSG("unsupport private Key type.\n");		
			goto out;
	}
	snprintf(comment, sizeof comment, "%s@%s", pw->pw_name, hostname);
	sprintf(str_buf, "%s%s", argv[2], SSH_PRIVATE_KEY_NAME_V1);
	ret = sshkey_save_private(&rk, str_buf, "", comment, 0, NULL, -1);
	ret = sshkey_save_private(&rk, str_buf2, "", comment, 0, NULL, -1);
	
	bio = BIO_new(BIO_s_file()); 
	if (!bio) {
		MSG("BIO_new has failed.\n");		
		goto out;
	}
	if (f) {
		fclose(f);
		f = NULL;
	}
	
	/* x509 public key */
	BIO_read_filename(bio, certfile); 
	x509 = d2i_X509_bio(bio, NULL);
	if (!x509) {
		MSG("d2i_X509_bio has failed.\n");		
		goto out;
	}
	
	env_pkey = X509_get_pubkey(x509);
	if (env_pkey == NULL) {
		MSG("X509_get_pubkey has failed.\n");		
		goto out;
	}
	
	switch ( EVP_PKEY_base_id(env_pkey) ) {
		case EVP_PKEY_EC:
			pk.ecdsa = EVP_PKEY_get1_EC_KEY(env_pkey);
			if (!pk.ecdsa) {
				MSG("EVP_PKEY_get1_EC_KEY has failed.\n");		
				goto out;
			}
			pk.type = KEY_ECDSA;
			pk.ecdsa_nid = sshkey_ecdsa_key_to_nid(pk.ecdsa);
			/*if (check_zyxel_ssh_ecdsa_nid(pk.ecdsa_nid)){
				MSG("check_zyxel_ssh_ecdsa_nid has failed.\n");		
				goto out;
			}*/
			sprintf(str_buf2, "%s%s", argv[2], SSH_PUBLIC_KEY_NAME_ECDSA);
			break;
			
		case EVP_PKEY_RSA:
			pk.rsa = EVP_PKEY_get1_RSA(env_pkey);
			if (!pk.rsa) {
				MSG("EVP_PKEY_get1_RSA has failed.\n");		
				goto out;
			}
			pk.type = KEY_RSA;
			sprintf(str_buf2, "%s%s", argv[2], SSH_PUBLIC_KEY_NAME_V2);
			break;
			
		case EVP_PKEY_DSA:
#if 0
			pk.dsa = EVP_PKEY_get0_DSA(env_pkey);
			if (!pk.dsa) {
				MSG("EVP_PKEY_get0_DSA has failed.\n");		
				goto out;
			}
			pk.type = KEY_DSA;
			sprintf(str_buf2, "%s%s", argv[2], SSH_PUBLIC_KEY_NAME_DSA);
			break;
#else
			MSG("EVP_PKEY_DSA is not support.\n");		
			goto out;
#endif
			
		default:
			MSG("unsupport public Key type.\n");		
			goto out;
	}
	
	sprintf(str_buf, "%s%s", argv[2], SSH_PUBLIC_KEY_NAME_V1);
	f = fopen(str_buf, "w");
	if (f == NULL) {
		MSG("Open pk1 has failed.\n");		
		goto out;
	}
	if (sshkey_write(&pk, f)) {
		MSG("key_write pk1 has failed.\n");		
		goto out;
	}
	fprintf(f, " %s\n", comment);
	if (f) {
		fclose(f);
		f = NULL;
	}
	
	f = fopen(str_buf2, "w");
	if (f == NULL) {
		MSG("Open pk has failed.\n");		
		goto out;
	}
	
	if (sshkey_write(&pk, f)) {
		MSG("key_write pk has failed.\n");		
		goto out;
	}
	fprintf(f, " %s\n", comment);
	ret = 0;
out:
	if (bio)
		BIO_free(bio);
	if (x509)
		X509_free(x509);	
	if (privKey) {
		EVP_PKEY_free(privKey);
	}
	if (env_pkey) {
		EVP_PKEY_free(env_pkey);
	}
	if (f)
		fclose(f);	
		
	return ret;
}

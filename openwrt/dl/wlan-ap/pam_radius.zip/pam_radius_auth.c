/*
 * $Id: pam_radius_auth.c,v 1.21 2007/05/21 01:28:05 hwtseng Exp $
 * pam_radius_auth
 *      Authenticate a user via a RADIUS session
 *
 * 0.9.0 - Didn't compile quite right.
 * 0.9.1 - Hands off passwords properly.  Solaris still isn't completely happy
 * 0.9.2 - Solaris now does challenge-response.  Added configuration file
 *         handling, and skip_passwd field
 * 1.0.0 - Added handling of port name/number, and continue on select
 * 1.1.0 - more options, password change requests work now, too.
 * 1.1.1 - Added client_id=foo (NAS-Identifier), defaulting to PAM_SERVICE
 * 1.1.2 - multi-server capability.
 * 1.2.0 - ugly merger of pam_radius.c to get full RADIUS capability
 * 1.3.0 - added my own accounting code.  Simple, clean, and neat.
 * 1.3.1 - Supports accounting port (oops!), and do accounting authentication
 * 1.3.2 - added support again for 'skip_passwd' control flag.
 * 1.3.10 - ALWAYS add Password attribute, to make packets RFC compliant.
 * 1.3.11 - Bug fixes by Jon Nelson <jnelson@securepipe.com>
 * 1.3.12 - miscellanous bug fixes.  Don't add password to accounting
 *          requests; log more errors; add NAS-Port and NAS-Port-Type
 *          attributes to ALL packets.  Some patches based on input from
 *          Grzegorz Paszka <Grzegorz.Paszka@pik-net.pl>
 * 1.3.13 - Always update the configuration file, even if we're given
 *          no options.  Patch from Jon Nelson <jnelson@securepipe.com>
 * 1.3.14 - Don't use PATH_MAX, so it builds on GNU Hurd.
 * 1.3.15 - Implement retry option, miscellanous bug fixes.
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The original pam_radius.c code is copyright (c) Cristian Gafton, 1996,
 *                                             <gafton@redhat.com>
 *
 * Some challenge-response code is copyright (c) CRYPTOCard Inc, 1998.
 *                                              All rights reserved.
 */

#define PAM_SM_AUTH
#define PAM_SM_PASSWORD
#define PAM_SM_SESSION

#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>

#ifdef sun
#include <security/pam_appl.h>
#endif
#include <security/pam_modules.h>

#include "pam_radius_auth.h"

#include "zld-spec.h"

#include "zykit.h"

#include <user_profile.h>
#include <security/pam_uam_utils.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define DPRINT if (ctrl & PAM_DEBUG_ARG) _pam_log

#if 0
FILE *fp = NULL;
#define pam_debug(fmt, arg...) \
do {\
  fprintf(stderr, "%s %s %d:"fmt"\n", __FILE__, __FUNCTION__, __LINE__, ##arg);	 \
  if ( fp || (fp == NULL && (fp = fopen("/tmp/pam_radius_log", "w")) != NULL)) { \
    fprintf(fp, "%s %s %d:"fmt"\n", __FILE__, __FUNCTION__, __LINE__, ##arg);	 \
    fflush(fp); \
  } else {\
    fprintf(stderr, "console>> %s %s %d:"fmt"\n", __FILE__, __FUNCTION__, __LINE__, ##arg);	 \
  } \
}while(0)
#else
#define pam_debug(fmt, arg...)
#endif

static int is_cloud = 0;

/* internal data */
static CONST char *pam_module_name = "pam_radius_auth";
static char conf_file[BUFFER_SIZE]; /* configuration file */

/* we need to save these from open_session to close_session, since
 * when close_session will be called we won't be root anymore and
 * won't be able to access again the radius server configuration file
 * -- cristiang */
static radius_server_t *live_server = NULL;
static time_t session_time;

/*FIXME: These global variables are critical regions and maybe need lock.*/
static int auth_module_idx;
static int group_attribute;

/* logging */
static void _pam_log(int err, CONST char *format, ...)
{
    va_list args;
    char buffer[BUFFER_SIZE];

    va_start(args, format);
    vsprintf(buffer, format, args);
    /* don't do openlog or closelog, but put our name in to be friendly */
    syslog(err, "%s: %s", pam_module_name, buffer);
    va_end(args);
}

/* argument parsing */
static int _pam_parse(int argc, CONST char **argv, radius_conf_t *conf, struct zyuser_auth_info *auth_info)
{
  int ctrl=0;

  memset(conf, 0, sizeof(radius_conf_t)); /* ensure it's initialized */

  strcpy(conf_file, CONF_FILE);

  /*
   *  If either is not there, then we can't parse anything.
   */
  if ((argc == 0) || (argv == NULL)) {
    return ctrl;
  }

  /* step through arguments */
  for (ctrl=0; argc-- > 0; ++argv) {

    /* generic options */
    if (!strncmp(*argv,"conf=",5)) {
      strcpy(conf_file,*argv+5);

    } else if (!strcmp(*argv, "use_first_pass")) {
      ctrl |= PAM_USE_FIRST_PASS;

    } else if (!strcmp(*argv, "try_first_pass")) {
      ctrl |= PAM_TRY_FIRST_PASS;

    } else if (!strcmp(*argv, "skip_passwd")) {
      ctrl |= PAM_SKIP_PASSWD;

    } else if (!strncmp(*argv,"retry=",6)) {
      int i = atoi(*argv+6);
      i &= 0x03;		/* keep the low 3 bits only */
      ctrl |= (i << 4);

    } else if (!strncmp(*argv, "client_id=", 10)) {
      if (conf->client_id) {
  _pam_log(LOG_WARNING, "ignoring duplicate '%s'", *argv);
      } else {
  conf->client_id = (char *) *argv+10; /* point to the client-id */
      }
    } else if (!strcmp(*argv, "accounting_bug")) {
      conf->accounting_bug = TRUE;

    } else if (!strcmp(*argv, "debug")) {
      ctrl |= PAM_DEBUG_ARG;
      conf->debug = 1;

    } else if (!strncmp(*argv, "idx=", 4)) {
      int i = atoi(*argv+4);
      auth_module_idx = i;
    if (auth_info)	auth_info->module_idx = (unsigned char)i;
    } else {
      _pam_log(LOG_WARNING, "unrecognized option '%s'", *argv);
    }
  }

  return ctrl;
}

/* Callback function used to free the saved return value for pam_setcred. */
void _int_free( pam_handle_t * pamh, void *x, int error_status )
{
    free(x);
}

/*************************************************************************
 * SMALL HELPER FUNCTIONS
 *************************************************************************/

/*
 * Return an IP address in host long notation from
 * one supplied in standard dot notation.
 */
static UINT4 ipstr2long(char *ip_str) {
  char	buf[6];
  char	*ptr;
  int	i;
  int	count;
  UINT4	ipaddr;
  int	cur_byte;

  ipaddr = (UINT4)0;

  for(i = 0;i < 4;i++) {
    ptr = buf;
    count = 0;
    *ptr = '\0';

    while(*ip_str != '.' && *ip_str != '\0' && count < 4) {
      if(!isdigit(*ip_str)) {
  return((UINT4)0);
      }
      *ptr++ = *ip_str++;
      count++;
    }

    if(count >= 4 || count == 0) {
      return((UINT4)0);
    }

    *ptr = '\0';
    cur_byte = atoi(buf);
    if(cur_byte < 0 || cur_byte > 255) {
      return ((UINT4)0);
    }

    ip_str++;
    ipaddr = ipaddr << 8 | (UINT4)cur_byte;
  }
  return(ipaddr);
}

/*
 * Check for valid IP address in standard dot notation.
 */
static int good_ipaddr(char *addr) {
  int	dot_count;
  int	digit_count;

  dot_count = 0;
  digit_count = 0;
  while(*addr != '\0' && *addr != ' ') {
    if(*addr == '.') {
      dot_count++;
      digit_count = 0;
    } else if(!isdigit(*addr)) {
      dot_count = 5;
    } else {
      digit_count++;
      if(digit_count > 3) {
        dot_count = 5;
      }
    }
    addr++;
  }
  if(dot_count != 3) {
    return(-1);
  } else {
    return(0);
  }
}

/*
 * Return an IP address in host long notation from a host
 * name or address in dot notation.
 */
static UINT4 get_ipaddr(char *host) {
  struct hostent *hp;

  if(good_ipaddr(host) == 0) {
    return(ipstr2long(host));

  } else if((hp = gethostbyname(host)) == (struct hostent *)NULL) {
    return((UINT4)0);
  }

  return(ntohl(*(UINT4 *)hp->h_addr));
}

/*
 * take server->hostname, and convert it to server->ip and server->port
 */
static int
host2server(radius_server_t *server)
{
  char *p;
  int ctrl = 1; /* for DPRINT */

  if ((p = strchr(server->hostname, ':')) != NULL) {
    *(p++) = '\0';		/* split the port off from the host name */
  }

  if ((server->ip.s_addr = get_ipaddr(server->hostname)) == ((UINT4)0)) {
    DPRINT(LOG_DEBUG, "DEBUG: get_ipaddr(%s) returned 0.\n", server->hostname);
    return PAM_AUTHINFO_UNAVAIL;
  }

  /*
   *  If the server port hasn't already been defined, go get it.
   */
  if (!server->port) {
    if (p && isdigit(*p)) {	/* the port looks like it's a number */
      unsigned int i = atoi(p) & 0xffff;

      if (!server->accounting) {
        server->port = htons((u_short) i);
      } else {
        server->port = htons((u_short) (i + 1));
      }
    } else {			/* the port looks like it's a name */
      struct servent *svp;

      if (p) {			/* maybe it's not "radius" */
        svp = getservbyname (p, "udp");
        /* quotes allow distinction from above, lest p be radius or radacct */
        DPRINT(LOG_DEBUG, "DEBUG: getservbyname('%s', udp) returned %d.\n", p, svp);
        *(--p) = ':';		/* be sure to put the delimiter back */
      } else {
        if (!server->accounting) {
          svp = getservbyname ("radius", "udp");
          DPRINT(LOG_DEBUG, "DEBUG: getservbyname(radius, udp) returned %d.\n", svp);
        } else {
          svp = getservbyname ("radacct", "udp");
          DPRINT(LOG_DEBUG, "DEBUG: getservbyname(radacct, udp) returned %d.\n", svp);
        }
      }

      if (svp == (struct servent *) 0) {
        /* debugging above... */
        return PAM_AUTHINFO_UNAVAIL;
      }

      server->port = svp->s_port;
    }
  }

  return PAM_SUCCESS;
}

/*
 * Do XOR of two buffers.
 */
static unsigned char *
xor(unsigned char *p, unsigned char *q, int length)
{
  int i;
  unsigned char *retval = p;

  for (i = 0; i < length; i++) {
    *(p++) ^= *(q++);
  }
  return retval;
}

/**************************************************************************
 * MID-LEVEL RADIUS CODE
 **************************************************************************/

/*
 * get a pseudo-random vector.
 */
static void
get_random_vector(unsigned char *vector)
{
#ifdef linux
  int fd = open("/dev/urandom",O_RDONLY); /* Linux: get *real* random numbers */
  int total = 0;
  if (fd >= 0) {
    while (total < AUTH_VECTOR_LEN) {
      int bytes = read(fd, vector + total, AUTH_VECTOR_LEN - total);
      if (bytes <= 0)
        break;			/* oops! Error */
      total += bytes;
    }
    close(fd);
  }

  if (total != AUTH_VECTOR_LEN)
#endif
    {				/* do this *always* on other platforms */
      MD5_CTX my_md5;
      struct timeval tv;
      struct timezone tz;
      static unsigned int session = 0; /* make the number harder to guess */

      /* Use the time of day with the best resolution the system can
      give us -- often close to microsecond accuracy. */
      gettimeofday(&tv,&tz);

      if (session == 0) {
        session = getppid();	/* (possibly) hard to guess information */
      }

      tv.tv_sec ^= getpid() * session++;

      /* Hash things to get maybe cryptographically strong pseudo-random numbers */
      MD5Init(&my_md5);
      MD5Update(&my_md5, (unsigned char *) &tv, sizeof(tv));
      MD5Update(&my_md5, (unsigned char *) &tz, sizeof(tz));
      MD5Final(vector, &my_md5);	      /* set the final vector */
    }
}

/*
 * RFC 2139 says to do generate the accounting request vector this way.
 * However, the Livingston 1.16 server doesn't check it.  The Cistron
 * server (http://home.cistron.nl/~miquels/radius/) does, and this code
 * seems to work with it.  It also works with Funk's Steel-Belted RADIUS.
 */
static void
get_accounting_vector(AUTH_HDR *request, radius_server_t *server)
{
  MD5_CTX my_md5;
  int secretlen = strlen(server->secret);
  int len = ntohs(request->length);

  memset(request->vector, 0, AUTH_VECTOR_LEN);
  MD5Init(&my_md5);
  memcpy(((char *)request) + len, server->secret, secretlen);

  MD5Update(&my_md5, (unsigned char *)request, len + secretlen);
  MD5Final(request->vector, &my_md5);      /* set the final vector */
}

/*
 * Verify the response from the server
 */
static int
verify_packet(char *secret, AUTH_HDR *response, AUTH_HDR *request)
{
  MD5_CTX my_md5;
  unsigned char	calculated[AUTH_VECTOR_LEN];
  unsigned char	reply[AUTH_VECTOR_LEN];

  /*
   * We could dispense with the memcpy, and do MD5's of the packet
   * + vector piece by piece.  This is easier understand, and maybe faster.
   */
  memcpy(reply, response->vector, AUTH_VECTOR_LEN); /* save the reply */
  memcpy(response->vector, request->vector, AUTH_VECTOR_LEN); /* sent vector */

  /* MD5(response packet header + vector + response packet data + secret) */
  MD5Init(&my_md5);
  MD5Update(&my_md5, (unsigned char *) response, ntohs(response->length));

  /*
   * This next bit is necessary because of a bug in the original Livingston
   * RADIUS server.  The authentication vector is *supposed* to be MD5'd
   * with the old password (as the secret) for password changes.
   * However, the old password isn't used.  The "authentication" vector
   * for the server reply packet is simply the MD5 of the reply packet.
   * Odd, the code is 99% there, but the old password is never copied
   * to the secret!
   */
  if (*secret) {
    MD5Update(&my_md5, (unsigned char *) secret, strlen(secret));
  }

  MD5Final(calculated, &my_md5);      /* set the final vector */

  /* Did he use the same random vector + shared secret? */
  if (memcmp(calculated, reply, AUTH_VECTOR_LEN) != 0) {
    return FALSE;
  }
  return TRUE;
}


/*
 * Find an attribute in a RADIUS packet.  Note that the packet length
 * is *always* kept in network byte order.
 */
static attribute_t *
find_attribute(AUTH_HDR *response, unsigned char type)
{


  attribute_t *attr = (attribute_t *) &response->data;
    int len = ntohs(response->length) - AUTH_HDR_LEN;

  while (attr->attribute != type) {
    if ((len -= attr->length) <= 0) {
      return NULL;		/* not found */
    }
    attr = (attribute_t *) ((char *) attr + attr->length);

  }

  return attr;
}


/*
 * add by fanny,
 * find an zyxel attribute in a RADIUS packet.  Note that the packet length
 * is *always* kept in network byte order.
 */
void
find_vendor_specific_zyxel(AUTH_HDR *response, char *attr_buf, unsigned char type)
{

  attribute_t *attr = (attribute_t *) &response->data;
  int pointer_len=0;
  char vendor_id[4],tmp[1],vendor_type;
  int vendor_len, tmp_len;

  int len = ntohs(response->length) - AUTH_HDR_LEN;

  attr_buf[0] = '\0';

  while ( len > 0) {
    tmp_len = pointer_len;
    //_pam_log(LOG_WARNING,"----------type=%x",attr->attribute);
    //_pam_log(LOG_WARNING,"----------length=%d",attr->length);

    if(attr->attribute == PW_VENDOR_SPECIFIC){ //vendor-specific=26

      //get length of vendor specific
      sprintf(tmp,"%d", response->data[++tmp_len]);
      vendor_len = atoi(tmp);

      //get vendor id
      memcpy(vendor_id, &response->data[++tmp_len], 4);
      //_pam_log(LOG_WARNING,"---- vendor id =%x %x %x %x",vendor_id[0],vendor_id[1],vendor_id[2],vendor_id[3]);
      //compare the vendor id whether zyxel 890 D = 37A H
      if( (vendor_id[0] == 0x00) && (vendor_id[1] == 0x00) && (vendor_id[2] == 0x03) && (vendor_id[3] == 0x7A) ){
        tmp_len+=4;

        vendor_type = response->data[tmp_len] ;
        if(vendor_type == type) {
          tmp_len+=2;
          /* Skip AVP header 6 bytes - Type[1],Length[1],Vendor ID[4] */
          /* Then VSA header 2 bytes - Type[1],Length[1] */
          /* So sub 8 */
          /* Tested with free-radius */
          snprintf(attr_buf, (vendor_len - 8 + 1), "%s", &response->data[tmp_len]);
          break;
        }
      }
    }
    len -= attr->length;
    pointer_len+=attr->length;
    attr = (attribute_t *) ((char *) attr + attr->length);
  }

  }

/*
 * Add an attribute to a RADIUS packet.
 */
static void
add_attribute(AUTH_HDR *request, unsigned char type, CONST unsigned char *data, int length)
{
  attribute_t *p;

  p = (attribute_t *) ((unsigned char *)request + ntohs(request->length));
  p->attribute = type;
  p->length = length + 2;		/* the total size of the attribute */
  request->length = htons(ntohs(request->length) + p->length);
  memcpy(p->data, data, length);
}

/*
 * Add an integer attribute to a RADIUS packet.
 */
static void
add_int_attribute(AUTH_HDR *request, unsigned char type, int data)
{
  int value = htonl(data);

  add_attribute(request, type, (unsigned char *) &value, sizeof(int));
}

/*
 * Add a RADIUS password attribute to the packet.  Some magic is done here.
 *
 * If it's an PW_OLD_PASSWORD attribute, it's encrypted using the encrypted
 * PW_PASSWORD attribute as the initialization vector.
 *
 * If the password attribute already exists, it's over-written.  This allows
 * us to simply call add_password to update the password for different
 * servers.
 */
static void
add_password(AUTH_HDR *request, unsigned char type, CONST char *password, char *secret)
{
  MD5_CTX md5_secret, my_md5;
  unsigned char misc[AUTH_VECTOR_LEN];
  int i;
  int length = strlen(password);
  unsigned char hashed[256 + AUTH_PASS_LEN]; /* can't be longer than this */
  unsigned char *vector;
  attribute_t *attr;

  if (length > MAXPASS) {	/* shorten the password for now */
    length = MAXPASS;
  }

  if (length == 0) {
    length = AUTH_PASS_LEN;	/* 0 maps to 16 */
  } if ((length & (AUTH_PASS_LEN - 1)) != 0) {
    length += (AUTH_PASS_LEN - 1); /* round it up */
    length &= ~(AUTH_PASS_LEN - 1); /* chop it off */
  }                             /* 16*N maps to itself */

  memset(hashed, 0, length);
  memcpy(hashed, password, strlen(password));

  attr = find_attribute(request, PW_PASSWORD);

  if (type == PW_PASSWORD) {
    vector = request->vector;
  } else {
    vector = attr->data;	/* attr CANNOT be NULL here. */
  }

  /* ************************************************************ */
  /* encrypt the password */
  /* password : e[0] = p[0] ^ MD5(secret + vector) */
  MD5Init(&md5_secret);
  MD5Update(&md5_secret, (unsigned char *) secret, strlen(secret));
  my_md5 = md5_secret;		/* so we won't re-do the hash later */
  MD5Update(&my_md5, vector, AUTH_VECTOR_LEN);
  MD5Final(misc, &my_md5);      /* set the final vector */
  xor(hashed, misc, AUTH_PASS_LEN);

  /* For each step through, e[i] = p[i] ^ MD5(secret + e[i-1]) */
  for (i = 1; i < (length >> 4); i++) {
    my_md5 = md5_secret;	/* grab old value of the hash */
    MD5Update(&my_md5, &hashed[(i-1) * AUTH_PASS_LEN], AUTH_PASS_LEN);
    MD5Final(misc, &my_md5);      /* set the final vector */
    xor(&hashed[i * AUTH_PASS_LEN], misc, AUTH_PASS_LEN);
  }

  if (type == PW_OLD_PASSWORD) {
    attr = find_attribute(request, PW_OLD_PASSWORD);
  }

  if (!attr) {
    add_attribute(request, type, hashed, length);
  } else {
    memcpy(attr->data, hashed, length); /* overwrite the packet */
  }
}

static void
cleanup(radius_server_t *server)
{
  radius_server_t *next;

  while (server) {
    next = server->next;
    _pam_drop(server->hostname);
    _pam_forget(server->secret);
    _pam_drop(server->nas_ip);
    _pam_drop(server->nas_id);
#if 0 //def ZLDCONFIG_AAA_RADIUS_ACCT
    _pam_drop(server->profile_name);
#endif
    _pam_drop(server);
    server = next;
  }
}


static int pam_config_read(radius_server_conf_t *radius)
{
  char buf[256], *pos;
  int line = 0;
  int errors = 0;
/*
 *	for fopen issue in PPC platform
 */
  FILE *fserver;
  radius_host_t *ptr=NULL, *ptr2=NULL;

  memset(radius, 0, sizeof(*radius));

  /* the first time around, read the configuration file */
  if ((fserver = fopen (conf_file, "r")) == (FILE*)NULL) {
    _pam_log(LOG_ERR, "Could not open configuration file %s: %s\n", conf_file, strerror(errno));
    return PAM_ABORT;
  }
  while (fgets(buf, sizeof(buf), fserver)) {
    line++;

  if (buf[0] == '#')
      continue;
    pos = buf;
    while (*pos != '\0') {
      if (*pos == '\n') {
        *pos = '\0';
      break;
    }
      pos++;
    }
    if (buf[0] == '\0')
      continue;

    pos = strchr(buf, '=');
    if (pos == NULL) {
      USER_ZYLOG("Line %d: invalid line '%s'\n", line, buf);
      errors++;
      continue;
    }
    *pos = '\0';
    pos++;

    if (strcmp(buf, "server") == 0) {
      ptr = malloc(sizeof(radius_host_t));
      if (ptr == NULL) {
        USER_ZYLOG("[%s]Insufficient memory.",__FUNCTION__);
        fclose(fserver);
        return PAM_AUTHINFO_UNAVAIL;
      }
      if (ptr2) {
        ptr2->next = ptr;
        ptr2 = ptr;
      }
      else {
        radius->host = ptr;
        ptr2 = ptr;
      }

      ptr2->hostname = strdup(pos);
      ptr2->next = NULL;
    }
    else if (strcmp(buf, "secret") == 0) {
      radius->secret = strdup(pos);
    }
    else if (strcmp(buf, "timeout") == 0) {
      radius->timeout = atoi(pos);
    }
    else if (strcmp(buf, "group_attribute") == 0) {
      group_attribute = atoi(pos);
    }
    else if (strcmp(buf, "nas_ip") == 0) {
      radius->nas_ip = strdup(pos);
    }
    else if (strcmp(buf, "nas_id") == 0) {
      radius->nas_id = strdup(pos);
    }
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
    else if (strcmp(buf, "profile_name") == 0) {
      radius->profile_name = strdup(pos);
    }
#endif
    else if (strcmp(buf, "ignore_case") == 0) {
      if (!strcmp(pos,"yes"))
        radius->ignore_case = 1;
      else
        radius->ignore_case = 0;
    }
  }

  if ((radius->timeout < 1) || (radius->timeout > 60)) {
    radius->timeout = 3;
  }

  fclose(fserver);

  return 0;
}

static void free_radius_server_conf(radius_server_conf_t *radius_conf)
{
  radius_host_t *ptr, *temp;

  ptr = radius_conf->host;
  while(ptr) {
    temp = ptr->next;
    free(ptr->hostname);
    free(ptr);
    ptr = temp;
  }

  free(radius_conf->secret);
  if (radius_conf->nas_id)
    free(radius_conf->nas_id);
  free(radius_conf->nas_ip);
#if 0 //def ZLDCONFIG_AAA_RADIUS_ACCT //sherry, mark for daemon dead
  free(radius_conf->profile_name);
#endif
  free(radius_conf);
}

/*
 * allocate and open a local port for communication with the RADIUS
 * server
 */
static int
initialize(radius_conf_t *conf, int accounting)
{
  struct sockaddr salocal;
  u_short local_port;
  radius_server_t *server = NULL, *temp = NULL;
  struct sockaddr_in * s_in;
  radius_server_conf_t *radius_conf;
  radius_host_t *ptr;

  radius_conf = malloc(sizeof(radius_server_conf_t));
  if (radius_conf == NULL) {
    USER_ZYLOG("[%s]Insufficient memory.",__FUNCTION__);
    return PAM_AUTHINFO_UNAVAIL;
  }

  pam_config_read(radius_conf);

  conf->ignore_case = radius_conf->ignore_case;

  ptr = radius_conf->host;
  if (!ptr){
    _pam_log(LOG_ERR, "No RADIUS server found in configuration file %s\n",conf_file);
    free_radius_server_conf(radius_conf);
    return PAM_AUTHINFO_UNAVAIL;
  }

  USER_ZYLOG("pam_read_config: hostname:%s, nas_ip:%s", radius_conf->host->hostname, radius_conf->nas_ip);
  while(ptr) {
    temp = malloc(sizeof(radius_server_t));
    if (temp == NULL) {
      USER_ZYLOG("[%s]Insufficient memory.",__FUNCTION__);
      free_radius_server_conf(radius_conf);
      return PAM_AUTHINFO_UNAVAIL;
    }

    memset(temp, 0, sizeof(radius_server_t));
    if (server) {
      server->next = temp;
      server = server->next;
    } else {
      conf->server = temp;
      server= temp;		/* first time */
    }

    server->hostname = strdup(ptr->hostname);
    server->secret = strdup(radius_conf->secret);
    server->accounting = accounting;
    server->port = 0;
    server->nas_ip = strdup(radius_conf->nas_ip);
    server->timeout = radius_conf->timeout;

    if(radius_conf->nas_id)
      server->nas_id = strdup(radius_conf->nas_id);
    else
      server->nas_id = NULL;
#if 0//def ZLDCONFIG_AAA_RADIUS_ACCT //sherry, mark for daemon dead
    server->profile_name = strdup(radius_conf->profile_name);
#endif
    server->next = NULL;

    ptr = ptr->next;
  }

  free_radius_server_conf(radius_conf);

  /* open a socket.  Dies if it fails */
  conf->sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (conf->sockfd < 0) {
    _pam_log(LOG_ERR, "Failed to open RADIUS socket: %s\n", strerror(errno));
    return PAM_AUTHINFO_UNAVAIL;
  }

  /* set up the local end of the socket communications */
  s_in = (struct sockaddr_in *) &salocal;
  memset ((char *) s_in, '\0', sizeof(struct sockaddr));
  s_in->sin_family = AF_INET;
  s_in->sin_addr.s_addr = INADDR_ANY;

  /*
   *  Use our process ID as a local port for RADIUS.
   */
  local_port = (getpid() & 0x7fff) + 1024;
  do {
    local_port++;
    s_in->sin_port = htons(local_port);
  } while ((bind(conf->sockfd, &salocal, sizeof (struct sockaddr_in)) < 0) && (local_port < 64000));

  if (local_port >= 64000) {
    close(conf->sockfd);
    _pam_log(LOG_ERR, "No open port we could bind to.");
    return PAM_AUTHINFO_UNAVAIL;
  }

  return PAM_SUCCESS;
}

/*
 * Helper function for building a radius packet.
 * It initializes *some* of the header, and adds common attributes.
 */
static void
build_radius_packet(AUTH_HDR *request, CONST char *user, CONST char *password, radius_conf_t *conf)
{
  char hostname[256];
  UINT4 ipaddr;

  hostname[0] = '\0';
  gethostname(hostname, sizeof(hostname) - 1);

  request->length = htons(AUTH_HDR_LEN);

  if (password) {		/* make a random authentication req vector */
    get_random_vector(request->vector);
  }

  add_attribute(request, PW_USER_NAME, (unsigned char *) user, strlen(user));

  /*
   *  Add a password, if given.
   */
  if (password) {
    add_password(request, PW_PASSWORD, password, conf->server->secret);

    /*
     *  Add a NULL password to non-accounting requests.
     */
  } else if (request->code != PW_ACCOUNTING_REQUEST) {
    add_password(request, PW_PASSWORD, "", conf->server->secret);
  }

  /* the packet is from localhost if on localhost, to make configs easier */
  if ((conf->server->ip.s_addr == ntohl(0x7f000001)) || (!hostname[0])) {
    ipaddr = 0x7f000001;
  } else {
    struct hostent *hp;

    if ((hp = gethostbyname(hostname)) == (struct hostent *) NULL) {
      ipaddr = 0x00000000;	/* no client IP address */
    } else {

  if (conf->server->nas_ip != NULL) {
    ipaddr = inet_network(conf->server->nas_ip);
  } else {
      ipaddr = ntohl(*(UINT4 *) hp->h_addr); /* use the first one available */
    }

    }
  }

  /* If we can't find an IP address, then don't add one */
  if (ipaddr) {
    add_int_attribute(request, PW_NAS_IP_ADDRESS, ipaddr);
  }

  /* There's always a NAS identifier */

  if(conf->server->nas_id != NULL) {
    add_attribute(request, PW_NAS_IDENTIFIER, (unsigned char *) conf->server->nas_id, strlen(conf->server->nas_id));
  }

  /*
   *  Add in the port (pid) and port type (virtual).
   *
   *  We might want to give the TTY name here, too.
   */
  add_int_attribute(request, PW_NAS_PORT_ID, getpid());
  add_int_attribute(request, PW_NAS_PORT_TYPE, PW_NAS_PORT_TYPE_VIRTUAL);
}

/*
 * Talk RADIUS to a server.
 * Send a packet and get the response
 */
static int
talk_radius(radius_conf_t *conf, AUTH_HDR *request, AUTH_HDR *response,
      char *password, char *old_password, int tries)
{
  int total_length;
  fd_set set;
  struct timeval tv;
  time_t now, end;
  int rcode;
  struct sockaddr saremote;
  struct sockaddr_in *s_in = (struct sockaddr_in *) &saremote;
  radius_server_t *server = conf->server;
  int ok;
  int server_tries;
  int retval = PAM_AUTHINFO_UNAVAIL;
  socklen_t salen;


  /* ************************************************************ */
  /* Now that we're done building the request, we can send it */

  /*
    Hmm... on password change requests, all of the found server information
    could be saved with a pam_set_data(), which means even the radius_conf_t
    information will have to be malloc'd at some point

    On the other hand, we could just try all of the servers again in
    sequence, on the off chance that one may have ended up fixing itself.

    */

  /* loop over all available servers */
  while (server != NULL) {

    /* only look up IP information as necessary */
    if ((retval = host2server(server)) != PAM_SUCCESS) {
      _pam_log(LOG_ERR,
         "Failed looking up IP address for RADIUS server %s (errcode=%d)",
         server->hostname, retval);
      ok = FALSE;
      goto next;		/* skip to the next server */
    }

    /* set up per-server IP && port configuration */
    memset ((char *) s_in, '\0', sizeof(struct sockaddr));
    s_in->sin_family = AF_INET;
    s_in->sin_addr.s_addr = htonl(server->ip.s_addr);
    s_in->sin_port = server->port;
    total_length = ntohs(request->length);

    if (!password) { 		/* make an RFC 2139 p6 request authenticator */
      get_accounting_vector(request, server);
    }

    server_tries = tries;
send:
    /* send the packet */
    if (sendto(conf->sockfd, (char *) request, total_length, 0,
         &saremote, sizeof(struct sockaddr_in)) < 0) {
      _pam_log(LOG_ERR, "Error sending RADIUS packet to server %s: %s",
         server->hostname, strerror(errno));
      ok = FALSE;
      goto next;		/* skip to the next server */
    }

    /* ************************************************************ */
    /* Wait for the response, and verify it. */
    salen = sizeof(struct sockaddr);
    tv.tv_sec = server->timeout; /* wait for the specified time */
    tv.tv_usec = 0;
    FD_ZERO(&set);		/* clear out the set */
    FD_SET(conf->sockfd, &set);	/* wait only for the RADIUS UDP socket */

    time(&now);
    end = now + tv.tv_sec;

    /* loop, waiting for the select to return data */
    ok = TRUE;
    while (ok) {

      rcode = select(conf->sockfd + 1, &set, NULL, NULL, &tv);

      /* select timed out */
      if (rcode == 0) {
        _pam_log(LOG_ERR, "RADIUS server %s failed to respond", server->hostname);
        if (--server_tries)
          goto send;
        ok = FALSE;
        retval = PAM_TO_RAD_TIMEOUT;
        break;			/* exit from the select loop */
      } else if (rcode < 0) {

        /* select had an error */
        if (errno == EINTR) {	/* we were interrupted */
          time(&now);

          if (now > end) {
            _pam_log(LOG_ERR, "RADIUS server %s failed to respond",
            server->hostname);
            if (--server_tries)
              goto send;
            ok = FALSE;
            break;			/* exit from the select loop */
          }

          tv.tv_sec = end - now;
          if (tv.tv_sec == 0) {	/* keep waiting */
            tv.tv_sec = 1;
          }

        } else {		/* not an interrupt, it was a real error */
          _pam_log(LOG_ERR, "Error waiting for response from RADIUS server %s: %s", server->hostname, strerror(errno));
          ok = FALSE;
          break;
        }

      /* the select returned OK */
      } else if (FD_ISSET(conf->sockfd, &set)) {

        /* try to receive some data */
        if ((total_length = recvfrom(conf->sockfd, (char *) response, BUFFER_SIZE, 0, &saremote, &salen)) < 0) {
        _pam_log(LOG_ERR, "error reading RADIUS packet from server %s: %s", server->hostname, strerror(errno));
        ok = FALSE;
        break;

        /* there's data, see if it's valid */
        } else {

          char *p = server->secret;

          if ((ntohs(response->length) != total_length) || (ntohs(response->length) > BUFFER_SIZE)) {
            _pam_log(LOG_ERR, "RADIUS packet from server %s is corrupted",
            server->hostname);
            ok = FALSE;
            break;
          }

        /* Check if we have the data OK.  We should also check request->id */

        if (password) {
          if (old_password) {
#ifdef LIVINGSTON_PASSWORD_VERIFY_BUG_FIXED
            p = old_password;	/* what it should be */
#else
            p = "";		/* what it really is */
#endif
          }
        /*
        * RFC 2139 p.6 says not do do this, but the Livingston 1.16
        * server disagrees.  If the user says he wants the bug, give in.
        */
        } else {		/* authentication request */
          if (conf->accounting_bug) {
            p = "";
          }
        }

        if (!verify_packet(p, response, request)) {
          _pam_log(LOG_ERR, "packet from RADIUS server %s fails verification: The shared secret is probably incorrect.", server->hostname);
          ok = FALSE;
          break;
        }

        /*
        * Check that the response ID matches the request ID.
        */
        if (response->id != request->id) {
          _pam_log(LOG_WARNING, "Response packet ID %d does not match the request packet ID %d: verification of packet fails", response->id, request->id);
          ok = FALSE;
          break;
        }

      }

        /*
        * Whew!  The select is done.  It hasn't timed out, or errored out.
        * It's our descriptor.  We've got some data.  It's the right size.
        * The packet is valid.
        * NOW, we can skip out of the select loop, and process the packet
        */
        break;
      } 
      /* otherwise, we've got data on another descriptor, keep select'ing */
    } 

    /* go to the next server if this one didn't respond */
  next:
    if (!ok) {
      radius_server_t *old;	/* forget about this server */

      old = server;
      server = server->next;
      conf->server = server;

      _pam_forget(old->secret);
      free(old->hostname);
      free(old);

      if (server) {		/* if there's more servers to check */
        /* get a new authentication vector, and update the passwords */
        get_random_vector(request->vector);
        request->id = request->vector[0];

        /* update passwords, as appropriate */
        if (password) {
          get_random_vector(request->vector);
          if (old_password) {	/* password change request */
            add_password(request, PW_PASSWORD, password, old_password);
            add_password(request, PW_OLD_PASSWORD, old_password, old_password);
          } else {		/* authentication request */
            add_password(request, PW_PASSWORD, password, server->secret);
          }
        }
      }
      continue;

    } else {
      /* we've found one that does respond, forget about the other servers */
      cleanup(server->next);
      server->next = NULL;
      live_server = server;	/* we've got a live one! */
      break;
    }
  }

  if (!server) {
    _pam_log(LOG_ERR, "All RADIUS servers failed to respond.");
    return retval;
  }

  return PAM_SUCCESS;
}

/**************************************************************************
 * MIDLEVEL PAM CODE
 **************************************************************************/

/* this is our front-end for module-application conversations */

#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) { return retval; }

static int rad_converse(pam_handle_t *pamh, int msg_style, char *message, char **password)
{
  CONST struct pam_conv *conv;
  struct pam_message resp_msg;
  CONST struct pam_message *msg[1];
  struct pam_response *resp = NULL;
  int retval;

  resp_msg.msg_style = msg_style;
  resp_msg.msg = message;
  msg[0] = &resp_msg;

  /* grab the password */
  retval = pam_get_item(pamh, PAM_CONV, (CONST void **) &conv);
  PAM_FAIL_CHECK;

  retval = conv->conv(1, msg, &resp,conv->appdata_ptr);
  PAM_FAIL_CHECK;

  if (password) {		/* assume msg.type needs a response */
    /* I'm not sure if this next bit is necessary on Linux */
#ifdef sun
    /* NULL response, fail authentication */
    if ((resp == NULL) || (resp->resp == NULL)) {
      return PAM_SYSTEM_ERR;
    }
#endif

    *password = resp->resp;
    free(resp);
  }

  return PAM_SUCCESS;
}

/**************************************************************************
 * GENERAL CODE
 **************************************************************************/

#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) {	\
  int *pret = malloc( sizeof(int) );		\
  *pret = retval;					\
  pam_set_data( pamh, "rad_setcred_return"	\
                , (void *) pret, _int_free );	\
  return retval; }

#ifdef ZLDCONFIG_WEBAUTH
static int check_numeric(char *buf)
{
  int i;

  for (i = 0; i < strlen(buf); i++)
  {
    if(!isdigit(buf[i]))
      return 0;
  }
  return 1;
}
#endif

#ifdef AAA_WEB_PORTAL
int get_http_info(AUTH_HDR *response){
  char attr_buf[32];
  int httpstatus;

  memset(attr_buf,'\0', sizeof(attr_buf));

  find_vendor_specific_zyxel( response, attr_buf, PW_VENDOR_HTTP_STATUS_CODE) ;
  if(attr_buf[0] != '\0') {
    httpstatus = atoi(attr_buf);
  } else {
    httpstatus = 0;
  }
  return httpstatus;
}
#endif

void change_mac_format(char *sta_mac,char *calling_station_id)
{
  int i,tmp;
  sta_mac[0]='\0';
  if(strlen(calling_station_id)==17) {
    for(i=0;i<17;i++) {
      if(isdigit(calling_station_id[i]) || isupper(calling_station_id[i]) || calling_station_id[i] == '-' ) {
        sta_mac[i]=calling_station_id[i];
      }
      else if(calling_station_id[i] == ':') {
        sta_mac[i]='-';
      }
      else if(islower(calling_station_id[i])) {
        sta_mac[i]=toupper(calling_station_id[i]);
      }
    }
    sta_mac[17]='\0';
  }
  else if(strlen(calling_station_id)==12) {
    tmp = 0;
    for(i=0;i<12;i++) {
      if((i!=0) && (i%2==0)) {
        sta_mac[tmp]='-';
        tmp++;
        if(islower(calling_station_id[i])) {
          sta_mac[tmp]=toupper(calling_station_id[i]);
        }
        else {
          sta_mac[tmp]=calling_station_id[i];
        }
      }
      else{
        if(islower(calling_station_id[i])) {
          sta_mac[tmp]=toupper(calling_station_id[i]);
        }
        else {
          sta_mac[tmp]=calling_station_id[i];
        }
      }
      tmp++;
    }
    sta_mac[17]='\0';
  }
  else {
    //unknow format !!!
  }
}

static int get_user_info(user_role_t*user, char *username, AUTH_HDR *response)
{
  char attr_buf[32];
#ifdef ZLDCONFIG_WEBAUTH
  char *hour, *min;
  int _hour, _min;
#endif

  memset(attr_buf,'\0', sizeof(attr_buf));

  find_vendor_specific_zyxel( response, attr_buf, PW_VENDOR_TYPE) ;
  if(attr_buf[0] != '\0') {
    user->type = get_user_type_from_radius(attr_buf);
  }
  else {
    user->type=NONE_TYPE;
  }

  find_vendor_specific_zyxel( response, attr_buf, PW_VENDOR_LEASE_TIME) ;
#ifdef ZLDCONFIG_WEBAUTH
  if(attr_buf[0] != '\0') {
    if(!check_numeric(attr_buf) || atoi(attr_buf) < 0 || atoi(attr_buf) > MAX_TIMEOUT) {
      //RADIUS_ZYLOG("RADIUS user %s - Vendor Specific Attribute(Lease Time) is error.", username);
      user->lease_time = -1;
    }
    else {
      user->lease_time = atoi(attr_buf);
    }
  }
  else {
    user->lease_time = -1;
  }
#else
  if(attr_buf[0] != '\0') {
    user->lease_time = atoi(attr_buf);
    user->flag |= FLAG_EXT_LEASE_TIME;
  }
  else {
#ifdef AAA_WEB_PORTAL
/* Workaround for Nebula Sign-on with my radius server will timeout for 2 mins. */
    if(is_cloud) {
      user->lease_time = 0;
    }
    else {
      user->lease_time = -1;
    }
#else
    user->lease_time = -1;
#endif
  }
#endif

  find_vendor_specific_zyxel( response, attr_buf, PW_VENDOR_REAUTH_TIME) ;
#ifdef ZLDCONFIG_WEBAUTH
  if(attr_buf[0] != '\0') {
    if(!check_numeric(attr_buf) || atoi(attr_buf) < 0 || atoi(attr_buf) > MAX_TIMEOUT) {
      //RADIUS_ZYLOG("RADIUS user %s - Vendor Specific Attribute(Re-auth Time) is error.", username);
      user->reauth_time = -1;
    }
    else {
      user->reauth_time = atoi(attr_buf);
    }
  }
  else {
    user->reauth_time = -1;
  }
#else
  if(attr_buf[0] != '\0') {
    user->reauth_time = atoi(attr_buf);
    user->flag |= FLAG_EXT_REAUTH_TIME;
  }
  else {
#ifdef AAA_WEB_PORTAL
/* Workaround for Nebula Sign-on with my radius server will timeout for 2 mins. */
    if(is_cloud) {
      user->reauth_time = 0;
    }
    else{
      user->reauth_time = -1;
    }
#else
    user->reauth_time = -1;
#endif
  }
#endif

#ifdef ZLDCONFIG_WEBAUTH
  find_vendor_specific_zyxel( response, attr_buf, PW_VENDOR_DUE_TIME) ;

  if(attr_buf[0] != '\0' && attr_buf[2] == ':' && strlen(attr_buf) == 5) {
    hour = strtok(attr_buf, ":");
    min = strtok(NULL, "");
    _hour = atoi(hour);
    _min = atoi(min);
    if(!check_numeric(hour) || !check_numeric(min) || _hour < 0 ||_hour > 23 || _min < 0 || _min > 59) {
      //RADIUS_ZYLOG("RADIUS user %s - Vendor Specific Attribute(Due Time) is error.", username);
      user->due_time[0] = '\0';
    }
    else {
      snprintf(user->due_time, DUE_TIME_LEN, "%02d%02d", _hour, _min);
    }
  }
  else {
    user->due_time[0] = '\0';
  }
#endif
#ifdef AAA_WEB_PORTAL
  if(is_cloud) {
  find_vendor_specific_zyxel( response, attr_buf, PW_VENDOR_EXPIRED_TIMEOUT) ;
    if(attr_buf[0] != '\0') {
      user->user_expired= atoi(attr_buf);

      if(user->user_expired == 0){
        user->user_expired = 0;
      }else if((user->user_expired < 60) && (user->user_expired > 0) ){
        user->user_expired = 1;
      }else if((user->user_expired%60) > 0){
        user->user_expired = user->user_expired/60;
        user->user_expired = user->user_expired + 1;
      }else{
        user->user_expired = user->user_expired/60;
      }
    }
    else {
      /* will apply lease timeout */
      user->user_expired = 0;
    }
  }
#endif
  return 0;

}

#if 0
/* this is for service mapping and pam_get_userinfo() */
#define inline
#include "../../../uam-1.0.0/pam_uam_utils.c"

void gen_auth_log(int pam_retval, pam_handle_t * pamh)
{
  char note[32];
  struct pam_info pinfo;

  if (pam_retval != PAM_AUTH_ERR)
    return;

  if (pam_get_userinfo(pamh, &pinfo) != PAM_SUCCESS) {
    PAM_UAM_DEBUG("Can't get user information!\n");
    return;
  }

  if (pinfo.username && valid_username(pinfo.username))
    sprintf(note, "User: %s", pinfo.username);
  else
    strcpy(note, "");

  if (pinfo.ip == INADDR_NONE)
    pinfo.ip = 0;

  zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM,
      pinfo.ip, 0, 0, 0, note,
      "Failed %s login attempt!", pinfo.service);
}
#endif

static inline int
string_toupper(CONST char *str1, char *str2, int str1_len)
{
  int i;
  for (i = 0; i < str1_len; i++, str1++) {
    str2[i] = toupper(*str1);
  }
  str2[i] = '\0';
  return 0;
}

#ifdef AAA_WEB_PORTAL
static void
radius_msg_add_vendor_attr(AUTH_HDR *request, unsigned int vendor, unsigned short subtype, unsigned char *data, int length)
{
  attribute_t *v;
  attribute_t *p;
  unsigned char vendor_data[4] = {0};
  int vendor_len;

  if (length > 0) {
    vendor_data[0] = ((vendor >> 24) & 0xFF);
    vendor_data[1] = ((vendor >> 16) & 0xFF);
    vendor_data[2] = ((vendor >> 8) & 0xFF);
    vendor_data[3] = (vendor & 0xFF);
  }
  vendor_len = sizeof(vendor_data) + 2;

  v = (attribute_t *) ((unsigned char *)request + ntohs(request->length));
  v->attribute = PW_VENDOR_SPECIFIC;
  v->length = length + 4 + sizeof(vendor_data);         /* the total size of the attribute */
  request->length = htons(ntohs(request->length) + vendor_len);

  memcpy(v->data, vendor_data, sizeof(vendor_data));

  p = (attribute_t *) ((unsigned char *)request + ntohs(request->length));
  p->attribute = subtype;
  p->length = length + 2;
  request->length = htons(ntohs(request->length) + p->length);

  memcpy(p->data, data, length);
}
#endif

#ifdef AAA_WEB_PORTAL
void gen_radius_timeout_log(pam_handle_t *pamh, char hostname[])
{
	struct pam_info user_info;

	if (pam_get_userinfo(pamh, &user_info) == PAM_SUCCESS)
		pam_get_destination_IP(pamh, &user_info);
	else
		PAM_UAM_DEBUG("Can't get user information!\n");

#ifdef ZLDCONFIG_IPV6
	if (user_info.flags & PAM_INFO_FLAG_USED_IPV6)
	{
		zylog6(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM,
			&(user_info.ip6), 0, &(user_info.dst_ip6), 0, "",
			"Account: %s from station: %s has failed login attempt to %s from %s due to FreeRADIUS request timeout.",
			user_info.username, user_info.sta_mac, hostname, user_info.service);
	}
	else
	{
		zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM,
			user_info.ip, 0, user_info.dst_ip, 0, "",
			"Account: %s from station: %s has failed login attempt to %s from %s due to FreeRADIUS request timeout.",
			user_info.username, user_info.sta_mac, hostname, user_info.service);
	}
#else
	zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM,
		user_info.ip, 0, user_info.dst_ip, 0, "",
		"Account: %s from station: %s has failed login attempt to %s from %s due to FreeRADIUS request timeout.",
		user_info.username, user_info.sta_mac, hostname, user_info.service);
#endif
}
#endif

PAM_EXTERN int
pam_sm_authenticate(pam_handle_t *pamh,int flags,int argc,CONST char **argv)
{
  CONST char *user;
  char *password = NULL;
  CONST char *rhost;
  char *resp2challenge = NULL;
  int ctrl;
  int retval = PAM_AUTH_ERR;
  int auth_module = AUTH_MODULE_RADIUS;
  UINT4 sta_ipaddr;

  char recv_buffer[4096];
  char send_buffer[4096];
  memset(recv_buffer, '\0', 4096);
  memset(send_buffer, '\0', 4096);
  AUTH_HDR *request = (AUTH_HDR *) send_buffer;
  AUTH_HDR *response = (AUTH_HDR *) recv_buffer;
  radius_conf_t config;
  int tries;
  struct zyuser_auth_info auth_info = {PAM_AUTH_MODULE_RADIUS, 0, 0};
  char new_username[IN_USER_NAME_LEN];
#ifdef AAA_WEB_PORTAL
  int httpstatus = 0;
  const char *portal_profile_name;
  portal_profile_t *user_portal_info = NULL;
#endif
#ifdef ZLDCONFIG_CLOUD_MODE_SUPPORT
/* 1000 series*/
  int zykit_curmode;
  zykit_curmode = zykit_wlan_get_hybridmode();
  switch (zykit_curmode) {
    case WHOPMODE_CLOUD:
      is_cloud = 1;
      break;
    case WHOPMODE_STANDALONE:
    case WHOPMODE_MANAGED:
      is_cloud = 0;
      break;
  }
#else
#ifdef ZLDCONFIG_NEBULA_AAA
/* for nebula product*/
  is_cloud = 1;
#else
  is_cloud = 0;
#endif
#endif

  ctrl = _pam_parse(argc, argv, &config, &auth_info);
  tries = ((ctrl & PAM_RETRY) >> 4) + 1;

  /* grab the user name */
  retval = pam_get_user(pamh, &user, NULL);
  PAM_FAIL_CHECK;

  /* check that they've entered something, and not too long, either */
  if ((user == NULL) ||
      (strlen(user) > MAXPWNAM)) {
    int *pret = malloc( sizeof(int) );
    *pret = PAM_USER_UNKNOWN;
    pam_set_data( pamh, "rad_setcred_return", (void *) pret, _int_free );

    DPRINT(LOG_DEBUG, "User name was NULL, or too long");
    return PAM_USER_UNKNOWN;
  }

  DPRINT(LOG_DEBUG, "Got user name %s", user);

  /*
   * Get the IP address of the authentication server
   * Then, open a socket, and bind it to a port
   */
  retval = initialize(&config, FALSE);
  PAM_FAIL_CHECK;
  if (config.ignore_case) {
    auth_info.flag |= PAM_AUTH_IGNORE_CASE;
  }

  pam_set_item(pamh, PAM_ZYXEL_AUTH_INFO, &auth_info);
  USER_ZYLOG("[%s]set auth info, ignore_case:%s",__FUNCTION__,config.ignore_case?"yes":"no");

  /*
   * If there's no client id specified, use the service type, to help
   * keep track of which service is doing the authentication.
   */
  if (!config.client_id) {
    retval = pam_get_item(pamh, PAM_SERVICE, (CONST void **) &config.client_id);
    PAM_FAIL_CHECK;
  }

  /* now we've got a socket open, so we've got to clean it up on error */
#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) {goto error; }

  /* build and initialize the RADIUS packet */
  request->code = PW_AUTHENTICATION_REQUEST;
  get_random_vector(request->vector);
  request->id = request->vector[0]; /* this should be evenly distributed */

  /* grab the password (if any) from the previous authentication layer */
  retval = pam_get_item(pamh, PAM_AUTHTOK, (CONST void **) &password);
  PAM_FAIL_CHECK;

  if(password) {
    password = strdup(password);
    DPRINT(LOG_DEBUG, "Got password %s", password);
  }

  /* no previous password: maybe get one from the user */
  if (!password) {
    if (ctrl & PAM_USE_FIRST_PASS) {
      retval = PAM_AUTH_ERR;	/* use one pass only, stopping if it fails */
      goto error;
    }

    /* check to see if we send a NULL password the first time around */
    if (!(ctrl & PAM_SKIP_PASSWD)) {
      retval = rad_converse(pamh, PAM_PROMPT_ECHO_OFF, "Password: ", &password);
      PAM_FAIL_CHECK;

    }
  } /* end of password == NULL */

  build_radius_packet(request, user, password, &config);
  /* not all servers understand this service type, but some do */
  add_int_attribute(request, PW_USER_SERVICE_TYPE, PW_AUTHENTICATE_ONLY);

  /*
   *  Tell the server which host the user is coming from.
   *
   *  Note that this is NOT the IP address of the machine running PAM!
   *  It's the IP address of the client.
   */
  retval = pam_get_item(pamh, PAM_RHOST, (CONST void **) &rhost);
  PAM_FAIL_CHECK;

  if (rhost) {
    sta_ipaddr = inet_network(rhost);
    if(sta_ipaddr) {
      add_int_attribute(request, PW_FRAMED_ADDRESS, sta_ipaddr);
    }
#ifndef AAA_WEB_PORTAL
    add_attribute(request, PW_CALLING_STATION_ID, (unsigned char *) rhost,
    strlen(rhost));
  }
#else
  char *client_mac = NULL ;
  char mac_buf[18] = {0};
  retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_STA_MAC, (CONST void **) &client_mac);
  PAM_FAIL_CHECK;
  change_mac_format(mac_buf,client_mac);
  if(mac_buf[0] != '\0')
  {
    add_attribute(request, PW_CALLING_STATION_ID, (unsigned char *) mac_buf, strlen(mac_buf));

    /* Add vendor specific attribute here */
    radius_msg_add_vendor_attr(request, ZYXEL_VENDOR, PW_VENDOR_AUTH_OPT, (unsigned char *)"webAuth", strlen("webAuth"));
  }
  char *vap_interface = NULL;
  retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_VAP_IF, (CONST void **) &vap_interface);
  PAM_FAIL_CHECK;
  radius_msg_add_vendor_attr(request, ZYXEL_VENDOR, PW_VENDOR_VAP_INTERFACE, (unsigned char *)vap_interface,strlen(vap_interface));
  char *ap_mac = NULL;
  char *ssid_name = NULL;
  char buf[128] = {0};
  memset(mac_buf,'\0',sizeof(mac_buf));
  retval = pam_get_item(pamh, PAM_ZYXEL_AP_MAC, (CONST void **) &ap_mac);
  PAM_FAIL_CHECK;
  retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_SSID_NAME, (CONST void **) &ssid_name);
  PAM_FAIL_CHECK;
  radius_msg_add_vendor_attr(request, ZYXEL_VENDOR, PW_VENDOR_SSID_NAME, (unsigned char *)ssid_name, strlen(ssid_name));
  change_mac_format(mac_buf,ap_mac);
  snprintf(buf,sizeof(buf),"%s:%s",mac_buf,ssid_name);
  if(buf[0] != '\0')
  {
    add_attribute(request, PW_CALLED_STATION_ID, (unsigned char *) buf, strlen(buf));
  }
}
#endif /* ifndef AAA_WEB_PORTAL */

  DPRINT(LOG_DEBUG, "Sending RADIUS request code %d", request->code);



  retval = talk_radius(&config, request, response, password, NULL, tries);
  PAM_FAIL_CHECK;
#ifdef AAA_WEB_PORTAL
  if(is_cloud){
    user_portal_info = (portal_profile_t * )malloc( sizeof(portal_profile_t) );
    if (user_portal_info== NULL) {
      USER_ZYLOG("[%s]Insufficient memory.",__FUNCTION__);
                  return PAM_AUTH_ERR;
         }
    pam_get_item(pamh, PAM_ZYXEL_PORTAL_PROFILE_NAME, (CONST void **) &portal_profile_name);
    
    char *portal_profile_buf = strdup(portal_profile_name); //workaround for portal_profile_name is 'const char *'
    get_captive_info_from_local(user_portal_info, portal_profile_buf);
    free(portal_profile_buf);

    httpstatus = get_http_info(response);
    pam_set_item(pamh, PAM_ZYXEL_HTTP_STATUS_CODE, &httpstatus);
	
	if((!strcmp(user_portal_info->auth_type, "cloud"))){
		if (httpstatus == 0)
		{
			char hostname[HOST_NAME_MAX];

			if (gethostname(hostname, sizeof(hostname)) != 0)
				strcpy(hostname, "device");

			gen_radius_timeout_log(pamh, hostname);
		}
	}
  }
#endif
  DPRINT(LOG_DEBUG, "Got RADIUS response code %d", response->code);


  /*
   *  If we get an authentication failure, and we sent a NULL password,
   *  ask the user for one and continue.
   *
   *  If we get an access challenge, then do a response, for as many
   *  challenges as we receive.
   */
  while (response->code == PW_ACCESS_CHALLENGE) {
    attribute_t *a_state, *a_reply;
    char challenge[BUFFER_SIZE];

    /* Now we do a bit more work: challenge the user, and get a response */
    if (((a_state = find_attribute(response, PW_STATE)) == NULL) ||
        ((a_reply = find_attribute(response, PW_REPLY_MESSAGE)) == NULL)) {
      _pam_log(LOG_ERR, "RADIUS access-challenge received with State or Reply-Message missing");
      retval = PAM_AUTHINFO_UNAVAIL;
      goto error;
    }

    memcpy(challenge, a_reply->data, a_reply->length - 2);
    challenge[a_reply->length - 2] = 0;


    /* It's full challenge-response, we might as well have echo on */
    retval = rad_converse(pamh, PAM_PROMPT_ECHO_ON, challenge, &resp2challenge);

    /* now that we've got a response, build a new radius packet */
    build_radius_packet(request, user, resp2challenge, &config);
    /* request->code is already PW_AUTHENTICATION_REQUEST */
    request->id++;		/* one up from the request */

    /* copy the state over from the servers response */
    add_attribute(request, PW_STATE, a_state->data, a_state->length - 2);

    retval = talk_radius(&config, request, response, resp2challenge, NULL, 1);
    PAM_FAIL_CHECK;

    DPRINT(LOG_DEBUG, "Got response to challenge code %d", response->code);
  }

  /* Whew! Done the pasword checks, look for an authentication acknowledge */
  if (response->code == PW_AUTHENTICATION_ACK) {
    retval = PAM_SUCCESS;
  } else {
    retval = PAM_AUTH_ERR;	/* authentication failure */

  error:
    /* If there was a password pass it to the next layer */
    if (password && *password) {
      pam_set_item(pamh, PAM_AUTHTOK, password);
    }
  }

   /* get zyxel attributes, add by fanny */
  if(retval == PAM_SUCCESS){
    user_role_t user_role;
    char data[BUFFER_SIZE];
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
    unsigned int session_timeout = 0;
  attribute_t *a_session_timeout;
#endif
  unsigned int idle_timeout = 0;
  attribute_t *a_idle_timeout;

    pam_set_item(pamh, PAM_ZYXEL_AUTH_INFO, &auth_info);
    if (auth_info.flag & PAM_AUTH_IGNORE_CASE) {
      string_toupper(user, new_username, strlen(user));
      pam_set_item(pamh, PAM_USER, new_username);
      user = new_username;
    }

    user_role.flag = 0x0;
    get_user_info(&user_role, (char *)user, response);

    data[0] = '\0';

    if(group_attribute) {
      attribute_t *a_filter_id;
      if (((a_filter_id = find_attribute(response, group_attribute)) == NULL)) {
        _pam_log(LOG_ERR, "RADIUS cannot get attribute [%d]", group_attribute);
      } else {
        memcpy(data, a_filter_id->data, a_filter_id->length - 2);//minus 2 since it includes type(one byte) and length(one byte)
        data[a_filter_id->length - 2] = '\0';
      }
    }

#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
    /* get session timeout attribute */
    if (((a_session_timeout = find_attribute(response, PW_SESSION_TIMEOUT)) == NULL)) {
        session_timeout = 0;
    _pam_log(LOG_ERR, "RADIUS cannot get PW_SESSION_TIMEOUT attribute [%d]", PW_SESSION_TIMEOUT);
    } else {
      //minus 2 since it includes type(one byte) and length(one byte)
        memcpy(&session_timeout, a_session_timeout->data, a_session_timeout->length - 2);
    session_timeout = ntohl(session_timeout);
    }
#endif

#ifndef AAA_WEB_PORTAL
  /* get idle timeout attribute */
    if (((a_idle_timeout = find_attribute(response, PW_IDLE_TIMEOUT)) == NULL)) {
        idle_timeout = 0;
    _pam_log(LOG_ERR, "RADIUS cannot get PW_IDLE_TIMEOUT attribute [%d]", PW_IDLE_TIMEOUT);
    } else {
      //minus 2 since it includes type(one byte) and length(one byte)
        memcpy(&idle_timeout, a_idle_timeout->data, a_idle_timeout->length - 2);
    idle_timeout = ntohl(idle_timeout);
    }
#endif
    user_role.user_role = (char *)malloc(IN_USER_NAME_LEN*ZLDSYSPARM_UAM_USER_ROLES_PER_EXT_GROUP_USER);
    if (user_role.user_role == NULL) {
      USER_ZYLOG("[%s]Insufficient memory.",__FUNCTION__);
      goto out;
    }
    *user_role.user_role = '\0';

    user_role.username = strdup(user);
#if 1 /* CASE-SENSITIVE */
    user_role.flag |= (auth_info.flag & PAM_AUTH_IGNORE_CASE) ? FLAG_IGNORE_CASE : 0;
#endif

    if (user_role.type < 0)
        user_role.type = USER_TYPE;

    if(get_user_role(&user_role, data, auth_module_idx, RADIUS_AUTH) != 0) {
      retval = PAM_ABORT;
      free(user_role.user_role);
      free(user_role.username);
    goto out;
  }

    retval = pam_set_item(pamh, PAM_ZYXEL_USER_TYPE, &user_role.type);
    if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item PAM_ZYXEL_USER_TYPE fail",__FUNCTION__);
    }

#ifdef AAA_WEB_PORTAL
  if(is_cloud){
    if((!strcmp(user_portal_info->auth_type, "cloud"))){
      if((user_role.user_expired > 0)&&(user_role.user_expired < user_portal_info->lease_time)){
        user_portal_info->lease_time = user_role.user_expired;
      }
    }

    if((!strcmp(user_portal_info->auth_type, "cloud")) || (user_role.lease_time == -1) || (user_role.lease_time == 0)){
      pam_set_item(pamh, PAM_ZYXEL_LEASE_TIME, &user_portal_info->lease_time);
      if (retval != PAM_SUCCESS) {
              USER_ZYLOG("[%s]Set item PAM_ZYXEL_LEASE_TIME fail",__FUNCTION__);
          }
    }else{
            retval = pam_set_item(pamh, PAM_ZYXEL_LEASE_TIME, &user_role.lease_time);
            if (retval != PAM_SUCCESS) {
                USER_ZYLOG("[%s]Set item PAM_ZYXEL_LEASE_TIME fail",__FUNCTION__);
            }
    }
  }
  else{
    retval = pam_set_item(pamh, PAM_ZYXEL_LEASE_TIME, &user_role.lease_time);
                if (retval != PAM_SUCCESS) {
                        USER_ZYLOG("[%s]Set item PAM_ZYXEL_LEASE_TIME fail",__FUNCTION__);
                }
  }
#else
    retval = pam_set_item(pamh, PAM_ZYXEL_LEASE_TIME, &user_role.lease_time);
        if (retval != PAM_SUCCESS) {
            USER_ZYLOG("[%s]Set item PAM_ZYXEL_LEASE_TIME fail",__FUNCTION__);
        }
#endif

    retval = pam_set_item(pamh, PAM_ZYXEL_REAUTH_TIME, &user_role.reauth_time);
    if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item  PAM_ZYXEL_REAUTH_TIME fail",__FUNCTION__);
    }

    retval = pam_set_item(pamh, PAM_ZYXEL_AUTH_MODULE, &auth_module);
    if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item PAM_ZYXEL_AUTH_MODULE fail",__FUNCTION__);
    }

#ifdef 	ZLDCONFIG_WEBAUTH
  int due_time = atoi(user_role.due_time);
  retval = pam_set_item(pamh, PAM_ZYXEL_DUE_TIME, &due_time);
    if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item  PAM_ZYXEL_REAUTH_TIME fail",__FUNCTION__);
    }
#endif

    retval = pam_set_item(pamh, PAM_ZYXEL_USER_ROLE, (void *) user_role.user_role);
    if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item PAM_ZYXEL_USER_ROLE fail",__FUNCTION__);
    }

   retval = pam_set_item(pamh, PAM_ZYXEL_DEFINED_USERNAME, (void *) user_role.define_name);
   if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item PAM_ZYXEL_DEFINED_USERNAME fail",__FUNCTION__);
   }

#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
    if ((config.server)->profile_name) {
        retval = pam_set_item(pamh, PAM_ZYXEL_RADIUS_PROFILE, (void *) (config.server)->profile_name);
        USER_ZYLOG("radius profile name: %s \n", (config.server)->profile_name);

      if (retval != PAM_SUCCESS) {
          USER_ZYLOG("[%s]Set item PAM_ZYXEL_RADIUS_PROFILE fail",__FUNCTION__);
       }
    }

    retval = pam_set_item(pamh, PAM_ZYXEL_SESSION_TIMEOUT, &session_timeout);
    if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item  PAM_ZYXEL_SESSION_TIMEOUT fail",__FUNCTION__);
    }
#endif

   retval = pam_set_item(pamh, PAM_ZYXEL_IDLE_TIMEOUT, &idle_timeout);
   if (retval != PAM_SUCCESS) {
      USER_ZYLOG("[%s]Set item  PAM_ZYXEL_IDLE_TIMEOUT fail",__FUNCTION__);
   }

    free(user_role.user_role);
    free(user_role.username);

  }

 out:
#ifdef AAA_WEB_PORTAL
	if(is_cloud) {
		if(user_portal_info)
			free(user_portal_info);
	}
#endif
  if (ctrl & PAM_DEBUG_ARG) {
    _pam_log(LOG_DEBUG, "authentication %s"
       , retval==PAM_SUCCESS ? "succeeded":"failed" );
  }

  close(config.sockfd);
  cleanup(config.server);
  _pam_forget(password);
  _pam_forget(resp2challenge);
  {
    int *pret = malloc( sizeof(int) );
    *pret = retval;
    pam_set_data( pamh, "rad_setcred_return", (void *) pret, _int_free );
  }
  pam_debug("retval = %d", retval);

  USER_ZYLOG("User:%s has passed pam_radius module.", user);
  return retval;
}

/*
 * Return a value matching the return value of pam_sm_authenticate, for
 * greatest compatibility.
 * (Always returning PAM_SUCCESS breaks other authentication modules;
 * always returning PAM_IGNORE breaks PAM when we're the only module.)
 */
PAM_EXTERN int
pam_sm_setcred(pam_handle_t *pamh,int flags,int argc,CONST char **argv)
{
  int retval, *pret;

  retval = PAM_SUCCESS;
  pret = &retval;
  pam_get_data( pamh, "rad_setcred_return", (CONST void **) &pret );
  return *pret;
}

#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) { return PAM_SESSION_ERR; }

static int
pam_private_session(pam_handle_t *pamh, int flags,
        int argc, CONST char **argv,
        int status)
{
  CONST char *user;
  int ctrl;
  int retval = PAM_AUTH_ERR;

  char recv_buffer[4096];
  char send_buffer[4096];
  AUTH_HDR *request = (AUTH_HDR *) send_buffer;
  AUTH_HDR *response = (AUTH_HDR *) recv_buffer;
  radius_conf_t config;

  ctrl = _pam_parse(argc, argv, &config, NULL);

  /* grab the user name */
  retval = pam_get_user(pamh, &user, NULL);
  PAM_FAIL_CHECK;

  /* check that they've entered something, and not too long, either */
  if ((user == NULL) ||
      (strlen(user) > MAXPWNAM)) {
    return PAM_USER_UNKNOWN;
  }

  /*
   * Get the IP address of the authentication server
   * Then, open a socket, and bind it to a port
   */
  retval = initialize(&config, TRUE);
  PAM_FAIL_CHECK;

  /*
   * If there's no client id specified, use the service type, to help
   * keep track of which service is doing the authentication.
   */
  if (!config.client_id) {
    retval = pam_get_item(pamh, PAM_SERVICE, (CONST void **) &config.client_id);
    PAM_FAIL_CHECK;
  }

  /* now we've got a socket open, so we've got to clean it up on error */
#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) {goto error; }

  /* build and initialize the RADIUS packet */
  request->code = PW_ACCOUNTING_REQUEST;
  get_random_vector(request->vector);
  request->id = request->vector[0]; /* this should be evenly distributed */

  build_radius_packet(request, user, NULL, &config);

  add_int_attribute(request, PW_ACCT_STATUS_TYPE, status);

  sprintf(recv_buffer, "%08d", (int) getpid());
  add_attribute(request, PW_ACCT_SESSION_ID, (unsigned char *) recv_buffer,
    strlen(recv_buffer));

  add_int_attribute(request, PW_ACCT_AUTHENTIC, PW_AUTH_RADIUS);

  if (status == PW_STATUS_START) {
    session_time = time(NULL);
  } else {
    add_int_attribute(request, PW_ACCT_SESSION_TIME, time(NULL) - session_time);
  }

  retval = talk_radius(&config, request, response, NULL, NULL, 1);
  PAM_FAIL_CHECK;

  /* oops! They don't have the right password.  Complain and die. */
  if (response->code != PW_ACCOUNTING_RESPONSE) {
    retval = PAM_PERM_DENIED;
    goto error;
  }

  retval = PAM_SUCCESS;

error:

  close(config.sockfd);
  cleanup(config.server);

  return retval;
}

PAM_EXTERN int
pam_sm_open_session(pam_handle_t *pamh, int flags,
        int argc, CONST char **argv)
{
  return pam_private_session(pamh, flags, argc, argv, PW_STATUS_START);
}

PAM_EXTERN int
pam_sm_close_session(pam_handle_t *pamh, int flags,
         int argc, CONST char **argv)
{
  return pam_private_session(pamh, flags, argc, argv, PW_STATUS_STOP);
}

#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) {return retval; }
#define MAX_PASSWD_TRIES 3

PAM_EXTERN int
pam_sm_chauthtok(pam_handle_t *pamh, int flags, int argc, CONST char **argv)
{
  CONST char *user;
  char *password = NULL;
  char *new_password = NULL;
  char *check_password = NULL;
  int ctrl;
  int retval = PAM_AUTHTOK_ERR;
  int attempts;

  char recv_buffer[4096];
  char send_buffer[4096];
  AUTH_HDR *request = (AUTH_HDR *) send_buffer;
  AUTH_HDR *response = (AUTH_HDR *) recv_buffer;
  radius_conf_t config;

  ctrl = _pam_parse(argc, argv, &config, NULL);

  /* grab the user name */
  retval = pam_get_user(pamh, &user, NULL);
  PAM_FAIL_CHECK;

  /* check that they've entered something, and not too long, either */
  if ((user == NULL) ||
      (strlen(user) > MAXPWNAM)) {
    return PAM_USER_UNKNOWN;
  }

  /*
   * Get the IP address of the authentication server
   * Then, open a socket, and bind it to a port
   */
  retval = initialize(&config, FALSE);
  PAM_FAIL_CHECK;

  /*
   * If there's no client id specified, use the service type, to help
   * keep track of which service is doing the authentication.
   */
  if (!config.client_id) {
    retval = pam_get_item(pamh, PAM_SERVICE, (CONST void **) &config.client_id);
    PAM_FAIL_CHECK;
  }

  /* now we've got a socket open, so we've got to clean it up on error */
#undef PAM_FAIL_CHECK
#define PAM_FAIL_CHECK if (retval != PAM_SUCCESS) {goto error; }

  /* grab the old password (if any) from the previous password layer */
  retval = pam_get_item(pamh, PAM_OLDAUTHTOK, (CONST void **) &password);
  PAM_FAIL_CHECK;
  if(password) password = strdup(password);

  /* grab the new password (if any) from the previous password layer */
  retval = pam_get_item(pamh, PAM_AUTHTOK, (CONST void **) &new_password);
  PAM_FAIL_CHECK;
  if(new_password) new_password = strdup(new_password);

  /* preliminary password change checks. */
  if (flags & PAM_PRELIM_CHECK) {
    if (!password) {		/* no previous password: ask for one */
      retval = rad_converse(pamh, PAM_PROMPT_ECHO_OFF, "Password: ", &password);
      PAM_FAIL_CHECK;
    }

    /*
     * We now check the password to see if it's the right one.
     * If it isn't, we let the user try again.
     * Note that RADIUS doesn't have any concept of 'root'.  The only way
     * that root can change someone's password is to log into the RADIUS
     * server, and and change it there.
     */

    /* build and initialize the access request RADIUS packet */
    request->code = PW_AUTHENTICATION_REQUEST;
    get_random_vector(request->vector);
    request->id = request->vector[0]; /* this should be evenly distributed */

    build_radius_packet(request, user, password, &config);
    add_int_attribute(request, PW_USER_SERVICE_TYPE, PW_AUTHENTICATE_ONLY);

    retval = talk_radius(&config, request, response, password, NULL, 1);
    PAM_FAIL_CHECK;

    /* oops! They don't have the right password.  Complain and die. */
    if (response->code != PW_AUTHENTICATION_ACK) {
      _pam_forget(password);
      retval = PAM_PERM_DENIED;
      goto error;
    }

    /*
     * We're now sure it's the right user.
     * Ask for their new password, if appropriate
     */

    if (!new_password) {	/* not found yet: ask for it */
      int new_attempts;
      attempts = 0;

      /* loop, trying to get matching new passwords */
      while (attempts++ < 3) {

  /* loop, trying to get a new password */
  new_attempts = 0;
  while (new_attempts++ < 3) {
    retval = rad_converse(pamh, PAM_PROMPT_ECHO_OFF,
        "New password: ", &new_password);
    PAM_FAIL_CHECK;

    /* the old password may be short.  Check it, first. */
    if (strcmp(password, new_password) == 0) { /* are they the same? */
      rad_converse(pamh, PAM_ERROR_MSG,
       "You must choose a new password.", NULL);
      _pam_forget(new_password);
      continue;
    } else if (strlen(new_password) < 6) {
      rad_converse(pamh, PAM_ERROR_MSG, "it's WAY too short", NULL);
      _pam_forget(new_password);
      continue;
    }

    /* insert crypt password checking here */

    break;		/* the new password is OK */
  }

  if (new_attempts >= 3) { /* too many new password attempts: die */
    retval = PAM_AUTHTOK_ERR;
    goto error;
  }

  /* make sure of the password by asking for verification */
  retval =  rad_converse(pamh, PAM_PROMPT_ECHO_OFF,
             "New password (again): ", &check_password);
  PAM_FAIL_CHECK;

  retval = strcmp(new_password, check_password);
  _pam_forget(check_password);

  /* if they don't match, don't pass them to the next module */
  if (retval != 0) {
    _pam_forget(new_password);
    rad_converse(pamh, PAM_ERROR_MSG,
           "You must enter the same password twice.", NULL);
    retval = PAM_AUTHTOK_ERR;
    goto error;		/* ??? maybe this should be a 'continue' ??? */
  }

  break;			/* everything's fine */
      }	/* loop, trying to get matching new passwords */

      if (attempts >= 3) { /* too many new password attempts: die */
  retval = PAM_AUTHTOK_ERR;
  goto error;
      }
    } /* now we have a new password which passes all of our tests */

    /*
     * Solaris 2.6 calls pam_sm_chauthtok only ONCE, with PAM_PRELIM_CHECK
     * set.
     */
#ifndef sun
    /* If told to update the authentication token, do so. */
  } else if (flags & PAM_UPDATE_AUTHTOK) {
#endif

    if (!password || !new_password) { /* ensure we've got passwords */
      retval = PAM_AUTHTOK_ERR;
      goto error;
    }

    /* build and initialize the password change request RADIUS packet */
    request->code = PW_PASSWORD_REQUEST;
    get_random_vector(request->vector);
    request->id = request->vector[0]; /* this should be evenly distributed */

    /* the secret here can not be know to the user, so it's the new password */
    _pam_forget(config.server->secret);
    config.server->secret = strdup(password); /* it's free'd later */

    build_radius_packet(request, user, new_password, &config);
    add_password(request, PW_OLD_PASSWORD, password, password);

    retval = talk_radius(&config, request, response, new_password, password, 1);
    PAM_FAIL_CHECK;

    /* Whew! Done password changing, check for password acknowledge */
    if (response->code != PW_PASSWORD_ACK) {
      retval = PAM_AUTHTOK_ERR;
      goto error;
    }
  }

  /*
   * Send the passwords to the next stage if preliminary checks fail,
   * or if the password change request fails.
   */
  if ((flags & PAM_PRELIM_CHECK) || (retval != PAM_SUCCESS)) {
  error:

    /* If there was a password pass it to the next layer */
    if (password && *password) {
      pam_set_item(pamh, PAM_OLDAUTHTOK, password);
    }

    if (new_password && *new_password) {
      pam_set_item(pamh, PAM_AUTHTOK, new_password);
    }
  }

  if (ctrl & PAM_DEBUG_ARG) {
    _pam_log(LOG_DEBUG, "password change %s"
       , retval==PAM_SUCCESS ? "succeeded":"failed" );
  }

  close(config.sockfd);
  cleanup(config.server);

  _pam_forget(password);
  _pam_forget(new_password);
  return retval;
}

/*
 *  Do nothing for account management.  This is apparently needed by
 *  some programs.
 */
PAM_EXTERN int
pam_sm_acct_mgmt(pam_handle_t *pamh,int flags,int argc,CONST char **argv)
{
  int retval;
  retval = PAM_SUCCESS;
  return retval;
}

#ifdef PAM_STATIC

/* static module data */

struct pam_module _pam_radius_modstruct = {
  "pam_radius_auth",
  pam_sm_authenticate,
  pam_sm_setcred,
  pam_sm_acct_mgmt,
  pam_sm_open_session,
  pam_sm_close_session,
  pam_sm_chauthtok,
};
#endif


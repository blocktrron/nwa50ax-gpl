/* -*- mode: c; c-file-style: "openbsd" -*- */
/*
 * Copyright (c) 2012 Vincent Bernat <bernat@luffy.cx>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef _LOG_H
#define _LOG_H
#include <stdio.h>
#include <string.h>
#include "zld-spec.h"

/* log.c */
void             log_init(int, const char *);
void             log_warn(const char *, const char *, ...) __attribute__ ((format (printf, 2, 3)));
void             log_warnx(const char *, const char *, ...) __attribute__ ((format (printf, 2, 3)));
void             log_info(const char *, const char *, ...) __attribute__ ((format (printf, 2, 3)));
void             log_debug(const char *, const char *, ...) __attribute__ ((format (printf, 2, 3)));
void             fatal(const char*, const char *) __attribute__((__noreturn__));
void             fatalx(const char *) __attribute__((__noreturn__));

void		 log_register(void (*cb)(int, const char*));
void             log_accept(const char *);

#if defined(ZLDCONFIG_LLDP)
#include "iface_generic.h"

struct wds_maps_s {
	const char *int_ifname;
	const char *ext_ifname;
	const int no;
};

static inline int internal_to_external_wds(char *internal_iface_name, char* external_iface_name, int *id)
{
	int i=0, rc=1;
	static struct wds_maps_s wdsmaps[]={
		{"wds-1-9",   "WDS-2.4G",  9},
		{"wds-2-9",   "WDS-5G",    9},
		{"wds-1-10",  "WDS-2.4G", 10},
		{"wds-2-10",  "WDS-5G",   10},
		{"wlds-1-9",  "WDS-2.4G",  9},
		{"wlds-2-9",  "WDS-5G",    9},
		{"wlds-1-10", "WDS-2.4G", 10},
		{"wlds-2-10", "WDS-5G",   10},
#if defined(ZLDCONFIG_BOARD_WAC5300)
		{"wds2.8",    "WDS-2.4G",  9},
		{"wds0.8",    "WDS-5G",    9},
#else
		{"wds0.8",    "WDS-2.4G",  9},
		{"wds2.8",    "WDS-5G",    9},
#endif
		{"",          "",          0}
	};

	for(i=0; strlen(wdsmaps[i].int_ifname); i++)
	{
		if(strstr(internal_iface_name, wdsmaps[i].int_ifname) !=NULL)
		{
			sprintf(external_iface_name, "%s", wdsmaps[i].ext_ifname);
			*id=wdsmaps[i].no;
			rc=0;
			break;
		}
	}
	return rc;
}

static inline void internal_to_external_port(char *internal_port_name, char* external_port_name)
{
	#define PORT_MAPPING_FOLDER	"/var/zyxel/Port"
	FILE *fp=NULL;
	char filename[FILENAMESIZE];
	char fake_port_name[MAX_IFACE_NAME_LEN]="\0";	
	
	int max_port_num = zykit_get_current_model_portnum();

	if (max_port_num > 1) {
#if !defined(ZLDCONFIG_SWITCHPORT_REMAP_DEV)
		char *port_no=&internal_port_name[strlen("eth")];

		if(strstr(internal_port_name, "eth")!=NULL){
			sprintf(fake_port_name, "PORT%d",atoi(port_no) + 1);
		} else
#endif
		{
			sprintf(fake_port_name, "%s",internal_port_name);
		}

		sprintf(filename, PORT_MAPPING_FOLDER"/%s",fake_port_name);
		fp = fopen(filename, "r");
		if(fp)
		{
			fscanf(fp, "%s", external_port_name);
			fclose(fp);
		}

	} else if (max_port_num == 1) {
		if(strcmp(internal_port_name,"eth0")==0)
			sprintf(external_port_name, "%s", "lan");
	} else {
		/* error case */
	}	
}
#endif /* ZLDCONFIG_LLDP */

#endif

/* -*- mode: c; c-file-style: "openbsd" -*- */
/*
 * Copyright (c) 2008 Vincent Bernat <bernat@luffy.cx>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "lldpd.h"
#include "frame.h"

#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#if defined(ZLDCONFIG_LLDP) /* zyxel organizationally specific TLV */
#include <arpa/inet.h>
#include "zld_lib.h"
#include "zykit.h"
const uint8_t zyOUI[] = LLDP_TLV_ORG_ZYXEL;
extern unsigned short zyRCD_wait;
extern unsigned short zyRCD_retransmit;
#endif

#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
#ifdef ENABLE_DOT3
#include "power_util.h"
#include "platform_common.h"
#endif
#endif

inline static int
lldpd_af_to_lldp_proto(int af)
{
	switch (af) {
	case LLDPD_AF_IPV4:
		return LLDP_MGMT_ADDR_IP4;
	case LLDPD_AF_IPV6:
		return LLDP_MGMT_ADDR_IP6;
	default:
		return LLDP_MGMT_ADDR_NONE;
	}
}

inline static int
lldpd_af_from_lldp_proto(int proto)
{
	switch (proto) {
	case LLDP_MGMT_ADDR_IP4:
		return LLDPD_AF_IPV4;
	case LLDP_MGMT_ADDR_IP6:
		return LLDPD_AF_IPV6;
	default:
		return LLDPD_AF_UNSPEC;
	}
}

int
lldp_send(struct lldpd *global,
	  struct lldpd_hardware *hardware)
{
	struct lldpd_port *port;
	struct lldpd_chassis *chassis;
	struct lldpd_frame *frame;
	int length;
	u_int8_t *packet, *pos, *tlv;
	struct lldpd_mgmt *mgmt;
	int proto;

	u_int8_t mcastaddr[] = LLDP_MULTICAST_ADDR;
#ifdef ENABLE_DOT1
	const u_int8_t dot1[] = LLDP_TLV_ORG_DOT1;
	struct lldpd_vlan *vlan;
	struct lldpd_ppvid *ppvid;
	struct lldpd_pi *pi;
#endif
#ifdef ENABLE_DOT3
	const u_int8_t dot3[] = LLDP_TLV_ORG_DOT3;
#endif
#ifdef ENABLE_LLDPMED
	int i;
	const u_int8_t med[] = LLDP_TLV_ORG_MED;
#endif
#if defined(ZLDCONFIG_LLDP) /* waiting for zyshell initial done */
    if((access("/var/run/zysh-configuring", F_OK) == 0) || (access("/var/run/zyshd-init.lock", F_OK) == 0)) {
		return 0;
	}
#endif

	log_debug("lldp", "send LLDP PDU to %s",
	    hardware->h_ifname);

	port = &hardware->h_lport;
	chassis = port->p_chassis;
	length = hardware->h_mtu;
	if ((packet = (u_int8_t*)calloc(1, length)) == NULL)
		return ENOMEM;
	pos = packet;

	/* Ethernet header */
	if (!(
	      /* LLDP multicast address */
	      POKE_BYTES(mcastaddr, sizeof(mcastaddr)) &&
	      /* Source MAC address */
	      POKE_BYTES(&hardware->h_lladdr, ETHER_ADDR_LEN) &&
	      /* LLDP frame */
	      POKE_UINT16(ETHERTYPE_LLDP)))
		goto toobig;

	/* Chassis ID */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_CHASSIS_ID) &&
	      POKE_UINT8(chassis->c_id_subtype) &&
	      POKE_BYTES(chassis->c_id, chassis->c_id_len) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	/* Port ID */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_PORT_ID) &&
	      POKE_UINT8(port->p_id_subtype) &&
	      POKE_BYTES(port->p_id, port->p_id_len) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	/* Time to live */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_TTL) &&
	      POKE_UINT16(chassis->c_ttl) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	/* System name */
	if (chassis->c_name && *chassis->c_name != '\0') {
		if (!(
			    POKE_START_LLDP_TLV(LLDP_TLV_SYSTEM_NAME) &&
			    POKE_BYTES(chassis->c_name, strlen(chassis->c_name)) &&
			    POKE_END_LLDP_TLV))
			goto toobig;
	}

	/* System description (skip it if empty) */
	if (chassis->c_descr && *chassis->c_descr != '\0') {
		if (!(
			    POKE_START_LLDP_TLV(LLDP_TLV_SYSTEM_DESCR) &&
			    POKE_BYTES(chassis->c_descr, strlen(chassis->c_descr)) &&
			    POKE_END_LLDP_TLV))
			goto toobig;
	}

	/* System capabilities */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_SYSTEM_CAP) &&
	      POKE_UINT16(chassis->c_cap_available) &&
	      POKE_UINT16(chassis->c_cap_enabled) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	/* Management addresses */
	TAILQ_FOREACH(mgmt, &chassis->c_mgmt, m_entries) {
		proto = lldpd_af_to_lldp_proto(mgmt->m_family);
		if(proto == LLDP_MGMT_ADDR_NONE) continue;
		if (!(
			  POKE_START_LLDP_TLV(LLDP_TLV_MGMT_ADDR) &&
			  /* Size of the address, including its type */
			  POKE_UINT8(mgmt->m_addrsize + 1) &&
			  POKE_UINT8(proto) &&
			  POKE_BYTES(&mgmt->m_addr, mgmt->m_addrsize)))
			goto toobig;

		/* Interface port type, OID */
		if (mgmt->m_iface == 0) {
			if (!(
				  /* We don't know the management interface */
				  POKE_UINT8(LLDP_MGMT_IFACE_UNKNOWN) &&
				  POKE_UINT32(0)))
				goto toobig;
		} else {
			if (!(
				  /* We have the index of the management interface */
				  POKE_UINT8(LLDP_MGMT_IFACE_IFINDEX) &&
				  POKE_UINT32(mgmt->m_iface)))
				goto toobig;
		}
		if (!(
			  /* We don't provide an OID for management */
			  POKE_UINT8(0) &&
			  POKE_END_LLDP_TLV))
			goto toobig;
	}

	/* Port description */
	if (port->p_descr && *port->p_descr != '\0') {
		if (!(
			    POKE_START_LLDP_TLV(LLDP_TLV_PORT_DESCR) &&
			    POKE_BYTES(port->p_descr, strlen(port->p_descr)) &&
			    POKE_END_LLDP_TLV))
			goto toobig;
	}

#ifdef ENABLE_DOT1
	/* Port VLAN ID */
	if(port->p_pvid != 0) {
		if (!(
		    POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		    POKE_BYTES(dot1, sizeof(dot1)) &&
		    POKE_UINT8(LLDP_TLV_DOT1_PVID) &&
		    POKE_UINT16(port->p_pvid) &&
		    POKE_END_LLDP_TLV)) {
		    goto toobig;
		}
	}
	/* Port and Protocol VLAN IDs */
	TAILQ_FOREACH(ppvid, &port->p_ppvids, p_entries) {
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(dot1, sizeof(dot1)) &&
		      POKE_UINT8(LLDP_TLV_DOT1_PPVID) &&
		      POKE_UINT8(ppvid->p_cap_status) &&
		      POKE_UINT16(ppvid->p_ppvid) &&
		      POKE_END_LLDP_TLV)) {
			goto toobig;
		}
	}
	/* VLANs */
	TAILQ_FOREACH(vlan, &port->p_vlans, v_entries) {
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(dot1, sizeof(dot1)) &&
		      POKE_UINT8(LLDP_TLV_DOT1_VLANNAME) &&
		      POKE_UINT16(vlan->v_vid) &&
		      POKE_UINT8(strlen(vlan->v_name)) &&
		      POKE_BYTES(vlan->v_name, strlen(vlan->v_name)) &&
		      POKE_END_LLDP_TLV))
			goto toobig;
	}
	/* Protocol Identities */
	TAILQ_FOREACH(pi, &port->p_pids, p_entries) {
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(dot1, sizeof(dot1)) &&
		      POKE_UINT8(LLDP_TLV_DOT1_PI) &&
		      POKE_UINT8(pi->p_pi_len) &&
		      POKE_BYTES(pi->p_pi, pi->p_pi_len) &&
		      POKE_END_LLDP_TLV))
			goto toobig;
	}
#endif

#ifdef ENABLE_DOT3
	/* Aggregation status */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
	      POKE_BYTES(dot3, sizeof(dot3)) &&
	      POKE_UINT8(LLDP_TLV_DOT3_LA) &&
	      /* Bit 0 = capability ; Bit 1 = status */
	      POKE_UINT8((port->p_aggregid) ? 3:1) &&
	      POKE_UINT32(port->p_aggregid) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	/* MAC/PHY */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
	      POKE_BYTES(dot3, sizeof(dot3)) &&
	      POKE_UINT8(LLDP_TLV_DOT3_MAC) &&
	      POKE_UINT8(port->p_macphy.autoneg_support |
			 (port->p_macphy.autoneg_enabled << 1)) &&
	      POKE_UINT16(port->p_macphy.autoneg_advertised) &&
	      POKE_UINT16(port->p_macphy.mau_type) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	/* MFS */
	if (port->p_mfs) {
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(dot3, sizeof(dot3)) &&
		      POKE_UINT8(LLDP_TLV_DOT3_MFS) &&
		      POKE_UINT16(port->p_mfs) &&
		      POKE_END_LLDP_TLV))
			goto toobig;
	}
	/* Power */
	if (port->p_power.devicetype) {
#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(dot3, sizeof(dot3)) &&
		      POKE_UINT8(LLDP_TLV_DOT3_POWER) &&
		      POKE_UINT8((
				  (((2 - port->p_power.devicetype)    %(1<< 1))<<0) |
				  (( port->p_power.supported          %(1<< 1))<<1) |
				  (( port->p_power.enabled            %(1<< 1))<<2) |
				  (( port->p_power.paircontrol        %(1<< 1))<<3))) &&
		      POKE_UINT8(port->p_power.pairs) &&
		      POKE_UINT8((port->p_power.class > 5 ? 5 : port->p_power.class)) ))
			goto toobig;

		if (port->p_power.powertype == LLDP_DOT3_POWER_8023AT_TYPE1 ||
				port->p_power.powertype == LLDP_DOT3_POWER_8023AT_TYPE2 ||
				port->p_power.pse_type == LLDP_DOT3_POWER_8023AT_TYPE1 ||
				port->p_power.pse_type == LLDP_DOT3_POWER_8023AT_TYPE2 ||
				port->p_power.pse_type == LLDP_DOT3_POWER_8023AT_OFF) {
			/* 802.3at - Run the case if PD is 802.3at or PSE is not 802.3bt. */
			if (!(
			      POKE_UINT8((
					  (((port->p_power.powertype ==
					      LLDP_DOT3_POWER_8023AT_TYPE1)?1:0) << 7) |
					   (((port->p_power.devicetype ==
					      LLDP_DOT3_POWER_PSE)?0:1) << 6) |
					   ((port->p_power.source   %(1<< 2))<<4) |
					   ((port->p_power.priority %(1<< 2))<<0))) &&
			      POKE_UINT16(port->p_power.requested) &&
			      POKE_UINT16(port->p_power.allocated)))
				goto toobig;
		} 
		else if (port->p_power.powertype != LLDP_DOT3_POWER_8023AT_OFF) {  /* 802.3bt */
			/* 
			 * We mainly implement single signature PD.
			 * Dual signature PD is only implemented partially.
			 */
			if (!(
			      POKE_UINT8((
					  (((port->p_power.powertype ==
					      LLDP_DOT3_POWER_8023AT_TYPE1)?1:0) << 7) |
					   ( ((port->p_power.devicetype ==
					      LLDP_DOT3_POWER_PSE)?0:1) << 6) |
					   ((port->p_power.source   %(1<< 2))<<4) |
					   ( ((port->p_power.devicetype ==
                                              LLDP_DOT3_POWER_PSE)?0: 
					     port->p_power.four_pair_capable %(1<< 1))<<2) |
					   ((port->p_power.priority %(1<< 2))<<0))) &&
			      POKE_UINT16(port->p_power.requested) &&
			      POKE_UINT16(port->p_power.allocated) &&
			      POKE_UINT16(port->p_power.requested_mode_a) &&
			      POKE_UINT16(port->p_power.requested_mode_b) &&
			      POKE_UINT16(port->p_power.allocated_mode_a) &&
			      POKE_UINT16(port->p_power.allocated_mode_b) &&
			      POKE_UINT16(((1<< 12) | 
                                           (((port->p_power.signature ==
                                              LLDP_DOT3_POWER_SINGLE_SIGNATURE)? 7:
					     (port->p_power.class_a % (1<<3)))<<7) |
                                           (((port->p_power.signature ==
                                              LLDP_DOT3_POWER_SINGLE_SIGNATURE)? 7:
					     (port->p_power.class_b % (1<<3)))<<4) |
					      (port->p_power.class - 1))) && 
			      POKE_UINT8((
                                          (((port->p_power.powertype ==
                                              LLDP_DOT3_POWER_8023BT_TYPE4)?1:0) << 3) |
                                           (((port->p_power.powertype ==
                                              LLDP_DOT3_POWER_8023BT_TYPE3)?1:0) << 2) |
                                           (((port->p_power.signature ==
                                              LLDP_DOT3_POWER_SINGLE_SIGNATURE)? 0:1)<<1))) &&
			      POKE_UINT16(0) &&
			      POKE_UINT8(0) &&
			      POKE_UINT8(0) &&
			      POKE_UINT16(0)))
				goto toobig;
		}

#else
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(dot3, sizeof(dot3)) &&
		      POKE_UINT8(LLDP_TLV_DOT3_POWER) &&
		      POKE_UINT8((
				  (((2 - port->p_power.devicetype)    %(1<< 1))<<0) |
				  (( port->p_power.supported          %(1<< 1))<<1) |
				  (( port->p_power.enabled            %(1<< 1))<<2) |
				  (( port->p_power.paircontrol        %(1<< 1))<<3))) &&
		      POKE_UINT8(port->p_power.pairs) &&
		      POKE_UINT8(port->p_power.class)))
			goto toobig;

		/* 802.3at */
		if (port->p_power.powertype != LLDP_DOT3_POWER_8023AT_OFF) {
			if (!(
			      POKE_UINT8((
					  (((port->p_power.powertype ==
					      LLDP_DOT3_POWER_8023AT_TYPE1)?1:0) << 7) |
					   (((port->p_power.devicetype ==
					      LLDP_DOT3_POWER_PSE)?0:1) << 6) |
					   ((port->p_power.source   %(1<< 2))<<4) |
					   ((port->p_power.priority %(1<< 2))<<0))) &&
			      POKE_UINT16(port->p_power.requested) &&
			      POKE_UINT16(port->p_power.allocated)))
				goto toobig;
		}

#endif /* #if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI) */


		if (!(POKE_END_LLDP_TLV))
			goto toobig;
	}
#endif

#ifdef ENABLE_LLDPMED
	if (port->p_med_cap_enabled) {
		/* LLDP-MED cap */
		if (!(
		      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
		      POKE_BYTES(med, sizeof(med)) &&
		      POKE_UINT8(LLDP_TLV_MED_CAP) &&
		      POKE_UINT16(chassis->c_med_cap_available) &&
		      POKE_UINT8(chassis->c_med_type) &&
		      POKE_END_LLDP_TLV))
			goto toobig;

		/* LLDP-MED inventory */
#define LLDP_INVENTORY(value, subtype)					\
		if (value) {						\
		    if (!(						\
			  POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&		\
			  POKE_BYTES(med, sizeof(med)) &&		\
			  POKE_UINT8(subtype) &&			\
			  POKE_BYTES(value,				\
				(strlen(value)>32)?32:strlen(value)) &&	\
			  POKE_END_LLDP_TLV))				\
			    goto toobig;				\
		}

		if (port->p_med_cap_enabled & LLDP_MED_CAP_IV) {
			LLDP_INVENTORY(chassis->c_med_hw,
			    LLDP_TLV_MED_IV_HW);
			LLDP_INVENTORY(chassis->c_med_fw,
			    LLDP_TLV_MED_IV_FW);
			LLDP_INVENTORY(chassis->c_med_sw,
			    LLDP_TLV_MED_IV_SW);
			LLDP_INVENTORY(chassis->c_med_sn,
			    LLDP_TLV_MED_IV_SN);
			LLDP_INVENTORY(chassis->c_med_manuf,
			    LLDP_TLV_MED_IV_MANUF);
			LLDP_INVENTORY(chassis->c_med_model,
			    LLDP_TLV_MED_IV_MODEL);
			LLDP_INVENTORY(chassis->c_med_asset,
			    LLDP_TLV_MED_IV_ASSET);
		}

		/* LLDP-MED location */
		for (i = 0; i < LLDP_MED_LOCFORMAT_LAST; i++) {
			if (port->p_med_location[i].format == i + 1) {
				if (!(
				      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
				      POKE_BYTES(med, sizeof(med)) &&
				      POKE_UINT8(LLDP_TLV_MED_LOCATION) &&
				      POKE_UINT8(port->p_med_location[i].format) &&
				      POKE_BYTES(port->p_med_location[i].data,
					  port->p_med_location[i].data_len) &&
				      POKE_END_LLDP_TLV))
					goto toobig;
			}
		}

		/* LLDP-MED network policy */
		for (i = 0; i < LLDP_MED_APPTYPE_LAST; i++) {
			if (port->p_med_policy[i].type == i + 1) {
				if (!(
				      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
				      POKE_BYTES(med, sizeof(med)) &&
				      POKE_UINT8(LLDP_TLV_MED_POLICY) &&
				      POKE_UINT32((
					((port->p_med_policy[i].type     %(1<< 8))<<24) |
					((port->p_med_policy[i].unknown  %(1<< 1))<<23) |
					((port->p_med_policy[i].tagged   %(1<< 1))<<22) |
				      /*((0                              %(1<< 1))<<21) |*/
					((port->p_med_policy[i].vid      %(1<<12))<< 9) |
					((port->p_med_policy[i].priority %(1<< 3))<< 6) |
					((port->p_med_policy[i].dscp     %(1<< 6))<< 0) )) &&
				      POKE_END_LLDP_TLV))
					goto toobig;
			}
		}

		/* LLDP-MED POE-MDI */
		if ((port->p_med_power.devicetype == LLDP_MED_POW_TYPE_PSE) ||
		    (port->p_med_power.devicetype == LLDP_MED_POW_TYPE_PD)) {
			int devicetype = 0, source = 0;
			if (!(
			      POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&
			      POKE_BYTES(med, sizeof(med)) &&
			      POKE_UINT8(LLDP_TLV_MED_MDI)))
				goto toobig;
			switch (port->p_med_power.devicetype) {
			case LLDP_MED_POW_TYPE_PSE:
				devicetype = 0;
				switch (port->p_med_power.source) {
				case LLDP_MED_POW_SOURCE_PRIMARY: source = 1; break;
				case LLDP_MED_POW_SOURCE_BACKUP: source = 2; break;
				case LLDP_MED_POW_SOURCE_RESERVED: source = 3; break;
				default: source = 0; break;
				}
				break;
			case LLDP_MED_POW_TYPE_PD:
				devicetype = 1;
				switch (port->p_med_power.source) {
				case LLDP_MED_POW_SOURCE_PSE: source = 1; break;
				case LLDP_MED_POW_SOURCE_LOCAL: source = 2; break;
				case LLDP_MED_POW_SOURCE_BOTH: source = 3; break;
				default: source = 0; break;
				}
				break;
			}
			if (!(
			      POKE_UINT8((
				((devicetype                   %(1<< 2))<<6) |
				((source                       %(1<< 2))<<4) |
				((port->p_med_power.priority   %(1<< 4))<<0) )) &&
			      POKE_UINT16(port->p_med_power.val) &&
			      POKE_END_LLDP_TLV))
				goto toobig;
		}
	}
#endif

#if defined(ZLDCONFIG_LLDP) /* zyxel organizationally specific TLV */
	{
		struct lldpd_zyxel_info *zy_info=&global->g_zy_info;
		extern char zyHttpInfo[];
		extern char zyIPInfo[];
		extern char zyMgmtURL[];
		/*extern int zyHybridMode;*/
#if 1
		if(zyIPInfo[0]=='\0'){  /* get IP address */
			size_t len; int af;
			/* Management addresses */
			TAILQ_FOREACH(mgmt, &chassis->c_mgmt, m_entries) {
				proto = lldpd_af_to_lldp_proto(mgmt->m_family);
				if( proto == LLDP_MGMT_ADDR_NONE ) continue;
				switch (mgmt->m_family) {
					case LLDPD_AF_IPV4:
						len = INET_ADDRSTRLEN + 1;
						af  = AF_INET;
					break;
					case LLDPD_AF_IPV6:
						len = INET6_ADDRSTRLEN + 1;
						af = AF_INET6;
					break;
					default:
						len =0;;
				};
				if (len != 0){
					if (inet_ntop(af, &mgmt->m_addr, zyIPInfo, (socklen_t)len) != NULL){
						break;
					}
				}
			}
			log_info("zyxel", "get ip address: %s", zyIPInfo);
			zyMgmtURL[0]='\0';
		}

		/*if http or https are disable, generate default MgmtURL*/
		if(zyIPInfo[0]!='\0'){
			if(zyMgmtURL[0] == '\0'){
				snprintf(zyMgmtURL, 254, zyHttpInfo, zyIPInfo);
				log_info("zyxel", "get MGMT URL: %s", zyMgmtURL);
			}
		}
		else{  /* ip is not ready, or no http/https service */
			log_info("zyxel", "ip is not ready, or no http/https service");
			zyMgmtURL[0]='\0';
		}

#endif
		if(strlen(zy_info->zy_Caps)>0)
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                               /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_CAPS) &&                                 /* Org SubType = 1 */
				POKE_UINT8(strlen(zy_info->zy_Caps)) &&                            /* Length */
				POKE_BYTES(zy_info->zy_Caps, strlen(zy_info->zy_Caps)) &&          /* InfoString = Capability */
				POKE_END_LLDP_TLV))
					goto toobig;

		if(strlen(zy_info->zy_Mod)>0)
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                                /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                 /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_MODEL) &&                                 /* Org SubType = 2 */
				POKE_UINT8(strlen(zy_info->zy_Mod)) &&                              /* Length */
				POKE_BYTES(zy_info->zy_Mod, strlen(zy_info->zy_Mod)) &&             /* InfoString = Model Name */
				POKE_END_LLDP_TLV))
					goto toobig;

		if(strlen(zy_info->zy_FWVer)>0)
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                                /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                 /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_FW_VERSION) &&                            /* Org SubType = 3 */
				POKE_UINT8(strlen(zy_info->zy_FWVer)) &&                            /* Length */
				POKE_BYTES(zy_info->zy_FWVer, strlen(zy_info->zy_FWVer)) &&         /* InfoString = FW Version */
				POKE_END_LLDP_TLV))
					goto toobig;

		if(strlen(zy_info->zy_DevMAC)==LLDP_ZYXEL_DEVICE_MAC_LENGTH)
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                                /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                 /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_DEVICE_MAC) &&                            /* Org SubType = 4 */
				POKE_UINT8(strlen(zy_info->zy_DevMAC)) &&                           /* Length */
				POKE_BYTES(zy_info->zy_DevMAC, strlen(zy_info->zy_DevMAC)) &&       /* InfoString = Device MAC */
				POKE_END_LLDP_TLV))
					goto toobig;

		if(strlen(zy_info->zy_MgmtURL)>0)
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                                /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                 /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_MGMT_URL) &&                              /* Org SubType = 5 */
				POKE_UINT8(strlen(zy_info->zy_MgmtURL)) &&                          /* Length */
				POKE_BYTES(zy_info->zy_MgmtURL, strlen(zy_info->zy_MgmtURL)) &&     /* InfoString = Management URL */
				POKE_END_LLDP_TLV))
					goto toobig;

#if defined(ZLDCONFIG_LLDP_SUPPORT_RCD) /* support Reset Config to Default */
		zy_info->zy_RCD_W = zyRCD_wait;
		zy_info->zy_RCD_X = zyRCD_retransmit;
		if(strstr(zy_info->zy_Caps, LLDP_ZYXEL_RESET_CONF_CAPS)!=NULL)
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                                /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                 /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_RESET_PARM) &&                            /* Org SubType = 6 */
				POKE_UINT8(LLDP_ZYXEL_RESET_PARM_LENGTH) &&                         /* Length */
				POKE_UINT16(zy_info->zy_RCD_W) &&                                   /* InfoString = RCD Parameters: W */
				POKE_UINT16(zy_info->zy_RCD_X) &&                                   /* InfoString = RCD Parameters: X */
				POKE_END_LLDP_TLV))
					goto toobig;
#endif
      if((strlen(zy_info->zy_Location)>0))
			if (!(
				POKE_START_LLDP_TLV(LLDP_TLV_ORG) &&                                   /* T=127            */
				POKE_BYTES(zyOUI, sizeof(zyOUI)) &&                                    /* V=OUI{00-A0-C5}  */
				POKE_UINT8(LLDP_TLV_ZYXEL_LOCATION) &&                                 /* Org SubType = 7 */
				POKE_UINT8(strlen(zy_info->zy_Location)) &&                            /* Length */
				POKE_BYTES(zy_info->zy_Location, strlen(zy_info->zy_Location)) &&      /* InfoString = FW Version */
				POKE_END_LLDP_TLV))
					goto toobig;

	}
#endif
	/* END */
	if (!(
	      POKE_START_LLDP_TLV(LLDP_TLV_END) &&
	      POKE_END_LLDP_TLV))
		goto toobig;

	if (interfaces_send_helper(global, hardware,
		(char *)packet, pos - packet) == -1) {
		log_warn("lldp", "unable to send packet on real device for %s",
		    hardware->h_ifname);
		free(packet);
		return ENETDOWN;
	}

	hardware->h_tx_cnt++;

	/* We assume that LLDP frame is the reference */
	if ((frame = (struct lldpd_frame*)malloc(
			sizeof(int) + pos - packet)) != NULL) {
		frame->size = pos - packet;
		memcpy(&frame->frame, packet, frame->size);
		if ((hardware->h_lport.p_lastframe == NULL) ||
		    (hardware->h_lport.p_lastframe->size != frame->size) ||
		    (memcmp(hardware->h_lport.p_lastframe->frame, frame->frame,
			frame->size) != 0)) {
			free(hardware->h_lport.p_lastframe);
		hardware->h_lport.p_lastframe = frame;
		hardware->h_lport.p_lastchange = time(NULL);
		} else
			free(frame);
	}

	free(packet);
	return 0;

toobig:
	free(packet);
	return E2BIG;
}

#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
#ifdef ENABLE_DOT3

int
update_current_power_file(uint16_t current_power){
	FILE *fp = NULL;
	if( (fp = fopen(TMP_LLDP_PD_CURRENT_POWER, "w")) == NULL ){
		log_debug("lldp", "Write current to file failed.\n");
		return -1;
	}
	fprintf(fp, "%u00", current_power);
	fclose(fp);
	return 0;
}

static void 
power_negotiation(struct lldpd_hardware *hardware, struct lldpd_dot3_power *pse_power) {

	struct lldpd_dot3_power *pd_power = &(hardware->h_lport.p_power);
	u_int16_t old_power = 0;

	/* Run PD State Machine */
	if (pd_power->allocated != pse_power->allocated) {

		/* 
		 * Upon different allocated powers, the PD needs to reply PSE in 10 seconds
		 * based on SPEC.
		 */
		pd_power->quick_reply_needed = 1;

		pd_power->allocated = pse_power->allocated;
		if (pd_power->requested < pd_power->current_power ||
				pd_power->allocated < pd_power->current_power) {
			log_debug("lldp", "Adjust AP current power from %d to %d on %s (requested:%d, allocated:%d)", 
					pd_power->current_power, 
					pd_power->requested < pd_power->allocated? pd_power->requested : 
					pd_power->allocated,
					hardware->h_ifname,
					pd_power->requested, pse_power->allocated);
			pd_power->current_power = pd_power->requested < pd_power->allocated? 
									pd_power->requested : pd_power->allocated;

			/* Update the power mode and take the corresponding actions */
			write_power_status( decide_power_status(pd_power->current_power, pd_power->requested_goal) );
			update_current_power_file(pd_power->current_power);
		}
	}
	if (pd_power->requested <= pse_power->requested &&
			((pd_power->current_power < pd_power->requested &&
			pd_power->requested <= pse_power->allocated) ||
			(pd_power->current_power < pse_power->allocated &&
			              pse_power->allocated < pd_power->requested))) {
		log_debug("lldp", "Adjust AP current power from %d to %d on %s (requested:%d, allocated:%d)", 
				pd_power->current_power, 
				pd_power->requested < pd_power->allocated? pd_power->requested : pd_power->allocated,
				hardware->h_ifname,
				pd_power->requested, pse_power->allocated);
		pd_power->current_power = pd_power->requested < pd_power->allocated?
									pd_power->requested : pd_power->allocated;

		/* Update the power mode and take the corresponding actions */
		write_power_status( decide_power_status(pd_power->current_power, pd_power->requested_goal) );
		update_current_power_file(pd_power->current_power);
	} 

	/* Adjust PD requested power basd on PSE type. */
	if (pse_power->powertype < pd_power->powertype) {
		if (pse_power->powertype <= LLDP_DOT3_POWER_8023AT_TYPE2) {  /* For 802.3at compatible */
			old_power = pd_power->requested;
			pd_power->requested = (pd_power->requested > power_level[POWER_AT]) ? 
					power_level[POWER_AT] : pd_power->requested;
			log_debug("lldp", "Adjust the Type%d PD requested power from %d to %d for the Type%d PSE.", 
					pd_power->powertype, old_power, pd_power->requested,
					pse_power->powertype);
		}
	} else {
		log_debug("lldp", "Adjust the Type%d PD requested power from %d to %d for the Type%d PSE.", 
				pd_power->powertype, pd_power->requested, pd_power->requested_goal,
				pse_power->powertype);
		pd_power->requested = pd_power->requested_goal;
	}


	return;
}
#endif /* #ifdef ENABLE_DOT3 */
#endif /* #ifdefined(ZLDCONFIG_LLDP_POWER_VIA_MDI) */

#define CHECK_TLV_SIZE(x, name)				   \
	do { if (tlv_size < (x)) {			   \
			log_warnx("lldp", name " TLV too short received on %s",	\
	       hardware->h_ifname);			   \
	   goto malformed;				   \
	} } while (0)

int
lldp_decode(struct lldpd *cfg, char *frame, int s,
    struct lldpd_hardware *hardware,
    struct lldpd_chassis **newchassis, struct lldpd_port **newport)
{
	struct lldpd_chassis *chassis;
	struct lldpd_port *port;
	const char lldpaddr[] = LLDP_MULTICAST_ADDR;
	const char dot1[] = LLDP_TLV_ORG_DOT1;
	const char dot3[] = LLDP_TLV_ORG_DOT3;
	const char med[] = LLDP_TLV_ORG_MED;
	char orgid[3];
	int length, gotend = 0;
	int tlv_size, tlv_type, tlv_subtype;
	u_int8_t *pos, *tlv;
	char *b;
#ifdef ENABLE_DOT1
	struct lldpd_vlan *vlan = NULL;
	int vlan_len;
	struct lldpd_ppvid *ppvid;
	struct lldpd_pi *pi = NULL;
#endif
	struct lldpd_mgmt *mgmt;
	int af;
	u_int8_t addr_str_length, addr_str_buffer[32];
	u_int8_t addr_family, addr_length, *addr_ptr, iface_subtype;
	u_int32_t iface_number, iface;

	log_debug("lldp", "receive LLDP PDU on %s",
	    hardware->h_ifname);

	if ((chassis = calloc(1, sizeof(struct lldpd_chassis))) == NULL) {
		log_warn("lldp", "failed to allocate remote chassis");
		return -1;
	}
	TAILQ_INIT(&chassis->c_mgmt);
	if ((port = calloc(1, sizeof(struct lldpd_port))) == NULL) {
		log_warn("lldp", "failed to allocate remote port");
		free(chassis);
		return -1;
	}
#ifdef ENABLE_DOT1
	TAILQ_INIT(&port->p_vlans);
	TAILQ_INIT(&port->p_ppvids);
	TAILQ_INIT(&port->p_pids);
#endif

	length = s;
	pos = (u_int8_t*)frame;

	if (length < 2*ETHER_ADDR_LEN + sizeof(u_int16_t)) {
		log_warnx("lldp", "too short frame received on %s", hardware->h_ifname);
		goto malformed;
	}
	if (PEEK_CMP(lldpaddr, ETHER_ADDR_LEN) != 0) {
		log_info("lldp", "frame not targeted at LLDP multicast address received on %s",
		    hardware->h_ifname);
		goto malformed;
	}
	PEEK_DISCARD(ETHER_ADDR_LEN);	/* Skip source address */
	if (PEEK_UINT16 != ETHERTYPE_LLDP) {
		log_info("lldp", "non LLDP frame received on %s",
		    hardware->h_ifname);
		goto malformed;
	}

	while (length && (!gotend)) {
		if (length < 2) {
			log_warnx("lldp", "tlv header too short received on %s",
			    hardware->h_ifname);
			goto malformed;
		}
		tlv_size = PEEK_UINT16;
		tlv_type = tlv_size >> 9;
		tlv_size = tlv_size & 0x1ff;
		(void)PEEK_SAVE(tlv);
		if (length < tlv_size) {
			log_warnx("lldp", "frame too short for tlv received on %s",
			    hardware->h_ifname);
			goto malformed;
		}
		switch (tlv_type) {
		case LLDP_TLV_END:
			if (tlv_size != 0) {
				log_warnx("lldp", "lldp end received with size not null on %s",
				    hardware->h_ifname);
				goto malformed;
			}
			if (length)
				log_debug("lldp", "extra data after lldp end on %s",
				    hardware->h_ifname);
			gotend = 1;
			break;
		case LLDP_TLV_CHASSIS_ID:
		case LLDP_TLV_PORT_ID:
			CHECK_TLV_SIZE(2, "Port Id");
			tlv_subtype = PEEK_UINT8;
			if ((tlv_subtype == 0) || (tlv_subtype > 7)) {
				log_warnx("lldp", "unknown subtype for tlv id received on %s",
				    hardware->h_ifname);
				goto malformed;
			}
			if ((b = (char *)calloc(1, tlv_size - 1)) == NULL) {
				log_warn("lldp", "unable to allocate memory for id tlv "
				    "received on %s",
				    hardware->h_ifname);
				goto malformed;
			}
			PEEK_BYTES(b, tlv_size - 1);
			if (tlv_type == LLDP_TLV_PORT_ID) {
				port->p_id_subtype = tlv_subtype;
				if(port->p_id) free(port->p_id);
				port->p_id = b;
				port->p_id_len = tlv_size - 1;
			} else {
				chassis->c_id_subtype = tlv_subtype;
				if(chassis->c_id) free(chassis->c_id);
				chassis->c_id = b;
				chassis->c_id_len = tlv_size - 1;
			}
			break;
		case LLDP_TLV_TTL:
			CHECK_TLV_SIZE(2, "TTL");
			chassis->c_ttl = PEEK_UINT16;
			break;
		case LLDP_TLV_PORT_DESCR:
		case LLDP_TLV_SYSTEM_NAME:
		case LLDP_TLV_SYSTEM_DESCR:
			if (tlv_size < 1) {
				log_debug("lldp", "empty tlv received on %s",
				    hardware->h_ifname);
				break;
			}
			if ((b = (char *)calloc(1, tlv_size + 1)) == NULL) {
				log_warn("lldp", "unable to allocate memory for string tlv "
				    "received on %s",
				    hardware->h_ifname);
				goto malformed;
			}
			PEEK_BYTES(b, tlv_size);
			switch (tlv_type) {
			case LLDP_TLV_PORT_DESCR:
				if(port->p_descr) free(port->p_descr);
				port->p_descr = b;
				break;
			case LLDP_TLV_SYSTEM_NAME:
				if(chassis->c_name) free(chassis->c_name);
				chassis->c_name = b;
				break;
			case LLDP_TLV_SYSTEM_DESCR:
				if(chassis->c_descr) free(chassis->c_descr);
				chassis->c_descr = b;
				break;
			default:
				/* unreachable */
				free(b);
				break;
			}
			break;
		case LLDP_TLV_SYSTEM_CAP:
			CHECK_TLV_SIZE(4, "System capabilities");
			chassis->c_cap_available = PEEK_UINT16;
			chassis->c_cap_enabled = PEEK_UINT16;
			break;
		case LLDP_TLV_MGMT_ADDR:
			CHECK_TLV_SIZE(1, "Management address");
			addr_str_length = PEEK_UINT8;
			if (addr_str_length > sizeof(addr_str_buffer)) {
				log_warnx("lldp", "too large management address on %s",
				    hardware->h_ifname);
				goto malformed;
			}
			CHECK_TLV_SIZE(1 + addr_str_length, "Management address");
			PEEK_BYTES(addr_str_buffer, addr_str_length);
			addr_length = addr_str_length - 1;
			addr_family = addr_str_buffer[0];
			addr_ptr = &addr_str_buffer[1];
			CHECK_TLV_SIZE(1 + addr_str_length + 5, "Management address");
			iface_subtype = PEEK_UINT8;
			iface_number = PEEK_UINT32;

			af = lldpd_af_from_lldp_proto(addr_family);
			if (af == LLDPD_AF_UNSPEC)
				break;
			if (iface_subtype == LLDP_MGMT_IFACE_IFINDEX)
				iface = iface_number;
			else
				iface = 0;
			mgmt = lldpd_alloc_mgmt(af, addr_ptr, addr_length, iface);
			if (mgmt == NULL) {
				if( errno==ENOMEM ){
					log_warn("lldp", "unable to allocate memory "
							"for management address");
				}else{
					log_warn("lldp", "too large management address "
								"for management address");
				}
						goto malformed;
			}
			TAILQ_INSERT_TAIL(&chassis->c_mgmt, mgmt, m_entries);
			break;
		case LLDP_TLV_ORG:
			CHECK_TLV_SIZE(1 + (int)sizeof(orgid), "Organisational");
			PEEK_BYTES(orgid, sizeof(orgid));
			tlv_subtype = PEEK_UINT8;
			if (memcmp(dot1, orgid, sizeof(orgid)) == 0) {
#ifndef ENABLE_DOT1
				hardware->h_rx_unrecognized_cnt++;
#else
				/* Dot1 */
				switch (tlv_subtype) {
				case LLDP_TLV_DOT1_VLANNAME:
					CHECK_TLV_SIZE(7, "VLAN");
					if ((vlan = (struct lldpd_vlan *)calloc(1,
						    sizeof(struct lldpd_vlan))) == NULL) {
						log_warn("lldp", "unable to alloc vlan "
						    "structure for "
						    "tlv received on %s",
						    hardware->h_ifname);
						goto malformed;
					}
					vlan->v_vid = PEEK_UINT16;
					vlan_len = PEEK_UINT8;
					CHECK_TLV_SIZE(7 + vlan_len, "VLAN");
					if ((vlan->v_name =
						(char *)calloc(1, vlan_len + 1)) == NULL) {
						log_warn("lldp", "unable to alloc vlan name for "
						    "tlv received on %s",
						    hardware->h_ifname);
						goto malformed;
					}
					PEEK_BYTES(vlan->v_name, vlan_len);
					TAILQ_INSERT_TAIL(&port->p_vlans,
					    vlan, v_entries);
					vlan = NULL;
					break;
				case LLDP_TLV_DOT1_PVID:
					CHECK_TLV_SIZE(6, "PVID");
					port->p_pvid = PEEK_UINT16;
					break;
				case LLDP_TLV_DOT1_PPVID:
					CHECK_TLV_SIZE(7, "PPVID");
					/* validation needed */
					/* PPVID has to be unique if more than
					   one PPVID TLVs are received  -
					   discard if duplicate */
					/* if support bit is not set and
					   enabled bit is set - PPVID TLV is
					   considered error  and discarded */
					/* if PPVID > 4096 - bad and discard */
					if ((ppvid = (struct lldpd_ppvid *)calloc(1,
						    sizeof(struct lldpd_ppvid))) == NULL) {
						log_warn("lldp", "unable to alloc ppvid "
						    "structure for "
						    "tlv received on %s",
						    hardware->h_ifname);
						goto malformed;
					}
					ppvid->p_cap_status = PEEK_UINT8;
					ppvid->p_ppvid = PEEK_UINT16;
					TAILQ_INSERT_TAIL(&port->p_ppvids,
					    ppvid, p_entries);
					break;
				case LLDP_TLV_DOT1_PI:
					/* validation needed */
					/* PI has to be unique if more than
					   one PI TLVs are received  - discard
					   if duplicate ?? */
					CHECK_TLV_SIZE(5, "PI");
					if ((pi = (struct lldpd_pi *)calloc(1,
						    sizeof(struct lldpd_pi))) == NULL) {
						log_warn("lldp", "unable to alloc PI "
						    "structure for "
						    "tlv received on %s",
						    hardware->h_ifname);
						goto malformed;
					}
					pi->p_pi_len = PEEK_UINT8;
					CHECK_TLV_SIZE(5 + pi->p_pi_len, "PI");
					if ((pi->p_pi =
						(char *)calloc(1, pi->p_pi_len)) == NULL) {
						log_warn("lldp", "unable to alloc pid name for "
						    "tlv received on %s",
						    hardware->h_ifname);
						goto malformed;
					}
					PEEK_BYTES(pi->p_pi, pi->p_pi_len);
					TAILQ_INSERT_TAIL(&port->p_pids,
					    pi, p_entries);
					pi = NULL;
					break;
				default:
					/* Unknown Dot1 TLV, ignore it */
					hardware->h_rx_unrecognized_cnt++;
				}
#endif
			} else if (memcmp(dot3, orgid, sizeof(orgid)) == 0) {
#ifndef ENABLE_DOT3
				hardware->h_rx_unrecognized_cnt++;
#else
				/* Dot3 */
				switch (tlv_subtype) {
				case LLDP_TLV_DOT3_MAC:
					CHECK_TLV_SIZE(9, "MAC/PHY");
					port->p_macphy.autoneg_support = PEEK_UINT8;
					port->p_macphy.autoneg_enabled =
					    (port->p_macphy.autoneg_support & 0x2) >> 1;
					port->p_macphy.autoneg_support =
					    port->p_macphy.autoneg_support & 0x1;
					port->p_macphy.autoneg_advertised =
					    PEEK_UINT16;
					port->p_macphy.mau_type = PEEK_UINT16;
					break;
				case LLDP_TLV_DOT3_LA:
					CHECK_TLV_SIZE(9, "Link aggregation");
					PEEK_DISCARD_UINT8;
					port->p_aggregid = PEEK_UINT32;
					break;
				case LLDP_TLV_DOT3_MFS:
					CHECK_TLV_SIZE(6, "MFS");
					port->p_mfs = PEEK_UINT16;
					break;
				case LLDP_TLV_DOT3_POWER:
					CHECK_TLV_SIZE(7, "Power");
					port->p_power.devicetype = PEEK_UINT8;
					port->p_power.supported =
						(port->p_power.devicetype & 0x2) >> 1;
					port->p_power.enabled =
						(port->p_power.devicetype & 0x4) >> 2;
					port->p_power.paircontrol =
						(port->p_power.devicetype & 0x8) >> 3;
					port->p_power.devicetype =
						(port->p_power.devicetype & 0x1)?
						LLDP_DOT3_POWER_PSE:LLDP_DOT3_POWER_PD;
					port->p_power.pairs = PEEK_UINT8;
					port->p_power.class = PEEK_UINT8;
					/* 802.3at? */
					if (tlv_size >= 12) {
						port->p_power.powertype = PEEK_UINT8;
						port->p_power.source =
						    (port->p_power.powertype & (1<<5 | 1<<4)) >> 4;
						port->p_power.priority =
						    (port->p_power.powertype & (1<<1 | 1<<0));
						port->p_power.powertype =
						    (port->p_power.powertype & (1<<7))?
						    LLDP_DOT3_POWER_8023AT_TYPE1:
						    LLDP_DOT3_POWER_8023AT_TYPE2;
						port->p_power.requested = PEEK_UINT16;
						port->p_power.allocated = PEEK_UINT16;
					} else
						port->p_power.powertype =
						    LLDP_DOT3_POWER_8023AT_OFF;

#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
					/* 
					 * 802.3bt
					 *
					 * We mainly implement single signature PD.
					 * Dual signature PD is only implemented partially.
					 */
					if (tlv_size >= 29) {
						port->p_power.requested_mode_a = PEEK_UINT16;
						port->p_power.requested_mode_b = PEEK_UINT16;
						port->p_power.allocated_mode_a = PEEK_UINT16;
						port->p_power.allocated_mode_b = PEEK_UINT16;
						port->p_power.power_status = PEEK_UINT16;

						port->p_power.four_pair_capable =
						    ((port->p_power.power_status & (1<<15)) >> 15);
						port->p_power.signature =
						    ((port->p_power.power_status & (1<<15)) >> 15) &
						    ((port->p_power.power_status & (1<<14)) >> 14);
						port->p_power.pairs_ext = 
						    (port->p_power.power_status & (1<<11 | 1<<10)) >> 10;
						port->p_power.class_a =
						    (port->p_power.power_status & (1<<9 | 1<< 8 | 1<<7)) >> 7;
						port->p_power.class_b =
						    (port->p_power.power_status & (1<<6 | 1<< 5 | 1<<4)) >> 4;
						port->p_power.class =
						    port->p_power.power_status & (1<<3 | 1<< 2 | 1<<1 | 1);
						port->p_power.system_setup = PEEK_UINT8;
						port->p_power.powertype =
						    ((port->p_power.system_setup & (1<<1)) ? 
						     LLDP_DOT3_POWER_8023BT_TYPE4 : LLDP_DOT3_POWER_8023BT_TYPE3);
						port->p_power.pse_max_power = PEEK_UINT16;
						/* The fields which are not peeked will be discarded at the end of the loop. */
					}
					power_negotiation(hardware, &(port->p_power));

					{
						/* Record PSE type to make PD's power-via-mdi TLV is compatible with PSE's. */
						struct lldpd_dot3_power *pd_power = &(hardware->h_lport.p_power);
						pd_power->pse_type = port->p_power.powertype;
					}
#endif /* #if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI) */

					break;
				default:
					/* Unknown Dot3 TLV, ignore it */
					hardware->h_rx_unrecognized_cnt++;
				}
#endif
			} else if (memcmp(med, orgid, sizeof(orgid)) == 0) {
				/* LLDP-MED */
#ifndef ENABLE_LLDPMED
				hardware->h_rx_unrecognized_cnt++;
#else
				u_int32_t policy;
				unsigned loctype;
				unsigned power;

				switch (tlv_subtype) {
				case LLDP_TLV_MED_CAP:
					CHECK_TLV_SIZE(7, "LLDP-MED capabilities");
					chassis->c_med_cap_available = PEEK_UINT16;
					chassis->c_med_type = PEEK_UINT8;
					port->p_med_cap_enabled |=
					    LLDP_MED_CAP_CAP;
					break;
				case LLDP_TLV_MED_POLICY:
					CHECK_TLV_SIZE(8, "LLDP-MED policy");
					policy = PEEK_UINT32;
					if (((policy >> 24) < 1) ||
					    ((policy >> 24) > LLDP_MED_APPTYPE_LAST)) {
						log_info("lldp", "unknown policy field %d "
						    "received on %s",
						    policy,
						    hardware->h_ifname);
						break;
					}
					port->p_med_policy[(policy >> 24) - 1].type =
					    (policy >> 24);
					port->p_med_policy[(policy >> 24) - 1].unknown =
					    ((policy & 0x800000) != 0);
					port->p_med_policy[(policy >> 24) - 1].tagged =
					    ((policy & 0x400000) != 0);
					port->p_med_policy[(policy >> 24) - 1].vid =
					    (policy & 0x001FFE00) >> 9;
					port->p_med_policy[(policy >> 24) - 1].priority =
					    (policy & 0x1C0) >> 6;
					port->p_med_policy[(policy >> 24) - 1].dscp =
					    policy & 0x3F;
					port->p_med_cap_enabled |=
					    LLDP_MED_CAP_POLICY;
					break;
				case LLDP_TLV_MED_LOCATION:
					CHECK_TLV_SIZE(5, "LLDP-MED Location");
					loctype = PEEK_UINT8;
					if ((loctype < 1) ||
					    (loctype > LLDP_MED_LOCFORMAT_LAST)) {
						log_info("lldp", "unknown location type "
						    "received on %s",
						    hardware->h_ifname);
						break;
					}
					free(port->p_med_location[loctype - 1].data);
					if ((port->p_med_location[loctype - 1].data =
						(char*)malloc(tlv_size - 5)) == NULL) {
						log_warn("lldp", "unable to allocate memory "
						    "for LLDP-MED location for "
						    "frame received on %s",
						    hardware->h_ifname);
						goto malformed;
					}
					PEEK_BYTES(port->p_med_location[loctype - 1].data,
					    tlv_size - 5);
					port->p_med_location[loctype - 1].data_len =
					    tlv_size - 5;
					port->p_med_location[loctype - 1].format = loctype;
					port->p_med_cap_enabled |=
					    LLDP_MED_CAP_LOCATION;
					break;
				case LLDP_TLV_MED_MDI:
					CHECK_TLV_SIZE(7, "LLDP-MED PoE-MDI");
					power = PEEK_UINT8;
					switch (power & 0xC0) {
					case 0x0:
						port->p_med_power.devicetype = LLDP_MED_POW_TYPE_PSE;
						port->p_med_cap_enabled |=
						    LLDP_MED_CAP_MDI_PSE;
						switch (power & 0x30) {
						case 0x0:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_UNKNOWN;
							break;
						case 0x10:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_PRIMARY;
							break;
						case 0x20:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_BACKUP;
							break;
						default:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_RESERVED;
						}
						break;
					case 0x40:
						port->p_med_power.devicetype = LLDP_MED_POW_TYPE_PD;
						port->p_med_cap_enabled |=
						    LLDP_MED_CAP_MDI_PD;
						switch (power & 0x30) {
						case 0x0:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_UNKNOWN;
							break;
						case 0x10:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_PSE;
							break;
						case 0x20:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_LOCAL;
							break;
						default:
							port->p_med_power.source =
							    LLDP_MED_POW_SOURCE_BOTH;
						}
						break;
					default:
						port->p_med_power.devicetype =
						    LLDP_MED_POW_TYPE_RESERVED;
					}
					if ((power & 0x0F) > LLDP_MED_POW_PRIO_LOW)
						port->p_med_power.priority =
						    LLDP_MED_POW_PRIO_UNKNOWN;
					else
						port->p_med_power.priority =
						    power & 0x0F;
					port->p_med_power.val = PEEK_UINT16;
					break;
				case LLDP_TLV_MED_IV_HW:
				case LLDP_TLV_MED_IV_SW:
				case LLDP_TLV_MED_IV_FW:
				case LLDP_TLV_MED_IV_SN:
				case LLDP_TLV_MED_IV_MANUF:
				case LLDP_TLV_MED_IV_MODEL:
				case LLDP_TLV_MED_IV_ASSET:
					if (tlv_size <= 4)
						b = NULL;
					else {
						if ((b = (char*)malloc(tlv_size - 3)) ==
						    NULL) {
							log_warn("lldp", "unable to allocate "
							    "memory for LLDP-MED "
							    "inventory for frame "
							    "received on %s",
							    hardware->h_ifname);
							goto malformed;
						}
						PEEK_BYTES(b, tlv_size - 4);
						b[tlv_size - 4] = '\0';
					}
					switch (tlv_subtype) {
					case LLDP_TLV_MED_IV_HW:
						free(chassis->c_med_hw);
						chassis->c_med_hw = b;
						break;
					case LLDP_TLV_MED_IV_FW:
						free(chassis->c_med_fw);
						chassis->c_med_fw = b;
						break;
					case LLDP_TLV_MED_IV_SW:
						free(chassis->c_med_sw);
						chassis->c_med_sw = b;
						break;
					case LLDP_TLV_MED_IV_SN:
						free(chassis->c_med_sn);
						chassis->c_med_sn = b;
						break;
					case LLDP_TLV_MED_IV_MANUF:
						free(chassis->c_med_manuf);
						chassis->c_med_manuf = b;
						break;
					case LLDP_TLV_MED_IV_MODEL:
						free(chassis->c_med_model);
						chassis->c_med_model = b;
						break;
					case LLDP_TLV_MED_IV_ASSET:
						free(chassis->c_med_asset);
						chassis->c_med_asset = b;
						break;
					default:
						/* unreachable */
						free(b);
						break;
					}
					port->p_med_cap_enabled |=
					    LLDP_MED_CAP_IV;
					break;
				default:
					/* Unknown LLDP MED, ignore it */
					hardware->h_rx_unrecognized_cnt++;
				}
#endif /* ENABLE_LLDPMED */
#if defined(ZLDCONFIG_LLDP) /* zyxel organizationally specific TLV */
			} else if (memcmp(zyOUI, orgid, sizeof(orgid)) == 0) {
				char foo[256]="\0";
				uint8_t sub_length=0;

				sub_length = PEEK_UINT8;
				log_info("lldp", "Zyxel org tlv [%d] received on %s, length[%d]:[%d]", tlv_subtype, hardware->h_ifname, tlv_size, sub_length);
				CHECK_TLV_SIZE(sub_length+5, "Zyxel Org. ");
				switch (tlv_subtype) {
				case LLDP_TLV_ZYXEL_CAPS:
					PEEK_BYTES(port->zy_Caps, sub_length);
					port->zy_Caps[sub_length] = '\0';
					break;
				case LLDP_TLV_ZYXEL_MODEL:
					PEEK_BYTES(port->zy_Mod, sub_length);
					port->zy_Mod[sub_length] = '\0';
					break;
				case LLDP_TLV_ZYXEL_FW_VERSION:
					PEEK_BYTES(port->zy_FWVer, sub_length);
					port->zy_FWVer[sub_length] = '\0';
					break;
				case LLDP_TLV_ZYXEL_DEVICE_MAC:
					if (sub_length != LLDP_ZYXEL_DEVICE_MAC_LENGTH) {
						log_warnx("lldp", " Zyxel TLV %d wrong length received on %s", tlv_subtype, hardware->h_ifname);
						goto malformed;
					}
					PEEK_BYTES(port->zy_DevMAC, sub_length);
					port->zy_DevMAC[sub_length] = '\0';
					break;
				case LLDP_TLV_ZYXEL_MGMT_URL:
					PEEK_BYTES(port->zy_MgmtURL, sub_length);
					port->zy_MgmtURL[sub_length] = '\0';
					break;
				case LLDP_TLV_ZYXEL_RESET_PARM:
					if (sub_length != LLDP_ZYXEL_RESET_PARM_LENGTH) {
						log_warnx("lldp", " Zyxel TLV %d wrong length received on %s", tlv_subtype, hardware->h_ifname);
						goto malformed;
					}
					port->zy_RCD_W=PEEK_UINT16;
					port->zy_RCD_X=PEEK_UINT16;
					break;
				case LLDP_TLV_ZYXEL_RESET_CONF:
					if (sub_length != LLDP_ZYXEL_RESET_CONF_LENGTH) {
						log_warnx("lldp", " Zyxel TLV %d wrong length received on %s", tlv_subtype, hardware->h_ifname);
						goto malformed;
					}
					PEEK_BYTES(foo, sub_length);
					foo[sub_length] = '\0';
					break;
				case LLDP_TLV_ZYXEL_LOCATION:
					PEEK_BYTES(port->zy_Location, sub_length);
					port->zy_Location[sub_length] = '\0';
					break;
				default:
					/* Unknown LLDP ZyXEL org TLV, ignore it */
					hardware->h_rx_unrecognized_cnt++;
				};
				port->zy_tlvs++;
#endif
			} else {
				log_info("lldp", "unknown org tlv received on %s",
				    hardware->h_ifname);
				hardware->h_rx_unrecognized_cnt++;
			}
			break;
		default:
			log_warnx("lldp", "unknown tlv (%d) received on %s",
			    tlv_type, hardware->h_ifname);
			goto malformed;
		}
		if (pos > tlv + tlv_size) {
			log_warnx("lldp", "BUG: already past TLV!");
			goto malformed;
		}
		PEEK_DISCARD(tlv + tlv_size - pos);
	}

	/* Some random check */
	if ((chassis->c_id == NULL) ||
	    (port->p_id == NULL) ||
	    (chassis->c_ttl == 0) ||
	    (gotend == 0)) {
		log_warnx("lldp", "some mandatory tlv are missing for frame received on %s",
		    hardware->h_ifname);
		goto malformed;
	}
	*newchassis = chassis;
	*newport = port;
	return 1;
malformed:
	log_warnx("lldp", "malformed!!!!!");
#ifdef ENABLE_DOT1
	free(vlan);
	free(pi);
#endif
	lldpd_chassis_cleanup(chassis, 1);
	lldpd_port_cleanup(port, 1);
	free(port);
	return -1;
}

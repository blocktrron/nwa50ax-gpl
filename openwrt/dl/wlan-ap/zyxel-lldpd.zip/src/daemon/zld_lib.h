#ifndef ZLD_LIB_H
#define ZLD_LIB_H   1

#define ZLD_ZON_ZYSH_PATH                       "/bin/zysh"
#define ZLD_ZON_ZYSH_100                        "/bin/zysh -p 100"
#define ZLD_ZON_ZYSH_110                        "/bin/zysh -p 110"
#define ZLD_ZON_ZYSH_120                        "/bin/zysh -p 120"
#define ZLD_ZON_ZYSH_CTSTR                      "configure terminal"

#define ZLD_ZON_TFTP                            "/usr/bin/tftp"

#define MAX_ZLD_ZON_ZYSH_SCRIPT_NAME_LEN        64
#define MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN     1024
#define MAX_ZLD_ZON_ZYSH_RESULT_LINE_LEN        1024

#define SCRIPT_TEMPDIR "/tmp"
#define SCRIPT_TEMPFILE "ZLD_ZON_ZYSH_XXXXXX"

int get_systemMAC(uint8_t *data);
int get_modelName(uint8_t *data);
int get_fwVersion(uint8_t *data);

int get_DHCPSetting(uint8_t *data);
int get_IPv4Address(uint8_t *data);
int get_IPv4Netmask(uint8_t *data);
int get_IPv4GW(uint8_t *data);
int get_IPv4DNS1(uint8_t *data);
int get_IPv4DNS2(uint8_t *data);
int get_512xIPv4DNS1(uint8_t *data);
int get_512xIPv4DNS2(uint8_t *data);
int get_IPv4NTP(uint8_t *data);
int get_SNMPGetComm(uint8_t *data);
int get_SNMPSetComm(uint8_t *data);
int get_SNMPTrapComm(uint8_t *data);
int get_IPv4SNMPTrapSrv(uint8_t *data);
int get_IPv4SyslogSrv1(uint8_t *data);
int get_IPv4SyslogSrv2(uint8_t *data);

int get_IPv4NTP_DN(uint8_t *data);
int get_IPv4SyslogSrv1_DN(uint8_t *data);
int get_IPv4SyslogSrv2_DN(uint8_t *data);

int get_systemName(uint8_t *data);
int get_password(uint8_t *data);
int get_location(uint8_t *data);

int get_IPv4WebURL(uint8_t *data);
int get_HttpFormatInfo(uint8_t *data);
int get_httpPort(uint8_t *data);
int get_httpActive(uint8_t *data);
int get_httpsPort(uint8_t *data);
int get_httpsActive(uint8_t *data);

int set_DHCPSetting(uint16_t setting);
int set_IPv4Address(uint8_t *addr);
int set_IPv4Netmask(uint8_t *netmask);
int set_IPv4GW(uint8_t *gw);
int set_IPv4DNS1(uint8_t *dns1);
int set_IPv4DNS2(uint8_t *dns2);
int set_IPv4NTP(uint8_t *ntp);
int set_SNMPGetComm(char *ro);
int set_SNMPSetComm(char *rw);
int set_SNMPTrapComm(char *trap);
int set_IPv4SNMPTrapSrv(uint8_t *addr);
int set_IPv4SyslogSrv1(uint8_t *srv1);
int set_IPv4SyslogSrv2(uint8_t *srv2);

int set_IPv4NTP_DN(char *ntp);
int set_IPv4SyslogSrv1_DN(char *srv1);
int set_IPv4SyslogSrv2_DN(char *srv2);

int set_systemName(char *name);
int set_location(char *location);

int set_password(char *password);
int set_DHCPRenew(void);
int set_deviceReboot(void);
int set_locatorLEDFlash(uint16_t setting);
int set_tftp_fw_upgrade(char *url);

/* test */
void test_wtp_get(void);
/* test */
extern int32_t update_firmware(char *fileName);

#endif // ZLD_LIB_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <arpa/inet.h>

#include "zld_lib.h"

/*
Thin AP:show interface br0
FAT AP:show interface lan
*/
char show_MAC_CLI[]="show mac\n";
char show_version_CLI[]="show version\n";
//char show_Interface_CLI_thin[]="show interface br0\n";
char show_Interface_CLI_fat[]="show interface lan\n";
char show_IP_DNS_CLI[]="show ip dns server database\n";
char show_NTP_CLI[]="show ntp server\n";
char show_SNMP_CLI[]="show snmp status\n";
char show_SysLog_CLI[]="show logging status syslog\n";
char resolvFile[]="/etc/resolv.conf";
char show_hostname_CLI[]="show fqdn\n";
char show_admin_CLI[]="show username admin\n";
char show_location_CLI[]="show snmp status\n";
char show_http_CLI[]="show ip http server status\n";
char show_https_CLI[]="show ip http server secure status\n";
//char enable_DHCP_CLI_thin[]="configure terminal capwap ap vlan ip address dhcp";
//char set_IPAddr_CLI_thin[]="configure terminal capwap ap vlan ip address %d.%d.%d.%d %d.%d.%d.%d";
//char set_IP_GW_CLI_thin[]="configure terminal capwap ap vlan ip gateway %d.%d.%d.%d";
//char set_IP_DNS_CLI_thin[]="configure terminal capwap ap vlan ip dns %d.%d.%d.%d";
char enable_DHCP_CLI_fat[]="configure terminal manager ap vlan ip address dhcp";
char set_IPAddr_CLI_fat[]="configure terminal manager ap vlan ip address %d.%d.%d.%d %d.%d.%d.%d";
char set_IP_GW_CLI_fat[]="configure terminal manager ap vlan ip gateway %d.%d.%d.%d";
char set_IP_DNS_CLI_fat[]="configure terminal manager ap vlan ip dns %d.%d.%d.%d";
char set_NTP_CLI1[]="configure terminal ntp server %d.%d.%d.%d";
char set_NTP_CLI2[]="configure terminal ntp server %s";
char set_SNMP_RO_Comm_CLI[]="configure terminal snmp-server community %s ro";
char set_SNMP_RW_Comm_CLI[]="configure terminal snmp-server community %s rw";
char set_SNMP_Trap_Comm_CLI[]="configure terminal snmp-server host %d.%d.%d.%d %s";
char set_SNMP_Trap_Srv_Comm_CLI[]="configure terminal snmp-server host %d.%d.%d.%d";
char set_SysLog_CLI1[]="configure terminal logging syslog %d address %d.%d.%d.%d";
char set_SysLog_CLI2[]="configure terminal logging syslog %d address %s";
char set_hostname_CLI[]="configure terminal hostname %s";
char set_location_CLI[]="configure terminal snmp-server location %s";
char set_password_CLI[]="configure terminal username admin password %s user-type admin";
//char renew_CLI_thin[]="renew dhcp br0";
char renew_CLI_fat[]="renew dhcp lan";
char reboot_CLI[]="reboot";
char locatorLED[]="/proc/support/sysled_ctrl";

char tftp_get_CLI[]="-r %s -l %s -g %s";

int simple_parse_string(char *raw_strp, void *data, const char *needle);

/*******************************************************************************
* Description :
*       create a tmp script then write CLI commands into this file
*
* Parameters:
*       *script_name - the name of the script, give a empty string and
*                                  will be filled here
*       *cli_cmd - the CLI cmds which will be write into script
*
* Return Val:
*       0 when OK, -1 when error
*
* Notes:
*       don't forget delete this file at end
*******************************************************************************/
int
create_zysh_script(char *script_name, char *cli_cmd)
{
    int retval = 0;
    FILE *fp = NULL;
    int tmpFD;

    /* create script filename */
    /*sprintf(script_name, "/tmp/SNMP_ZYSH_XXXXXX");*/
    if ( access(SCRIPT_TEMPDIR, F_OK) == -1 ) {
        mkdir(SCRIPT_TEMPDIR, 0777);
    }
    sprintf(script_name, "%s/%s",SCRIPT_TEMPDIR, SCRIPT_TEMPFILE);
    if( (tmpFD = mkstemp(script_name)) < 0) {
        retval = -1;
        goto end;
    }
    else {
        close(tmpFD);
    }

    /* open script file */
    if( !(fp = fopen(script_name, "w")) ) {
        retval = -1;
        goto end;
    }

    /* Write CLI commands */
    fprintf(fp, "%s", cli_cmd);
    fflush(fp);
    fclose(fp);

end:
    return retval;
}

/*******************************************************************************
* Description :
*       execute the ZYSH CLI commands and parse the result
*
* Parameters:
*       *cli_cmd - CLI commands needed to be executed
*       *data - value pointer needed to be filled up after parsing, can be a string
*                       or a structure, if NULL means no parse needed
*       *parse - function pointer to the function which responses fro parsing,
*                       if NULL means no parse needed
*
* Return Val:
*       0 when OK, -1 when error
*******************************************************************************/
int
execute_zysh_script(char *cli_cmd, void *data, int (*parse)(char *raw_strp, void *data))
{
    int retval = 0;
    char script_name[MAX_ZLD_ZON_ZYSH_SCRIPT_NAME_LEN]="\0";
    char zysh_cmd[MAX_ZLD_ZON_ZYSH_RESULT_LINE_LEN]="\0";
    char result_line[MAX_ZLD_ZON_ZYSH_RESULT_LINE_LEN]="\0";
    FILE *pfp = NULL;
    char *strp;
    char error_pattern_1[] = "% (after";
    char error_pattern_2[] = "retval = -";

/* 1. Create ZYSH CLI Script */
    if( (retval = create_zysh_script(script_name, cli_cmd)) ) {
        goto end;
    }
    /* debug */
    printf("WTP: %s", cli_cmd);
    /* debug */

/* 2. Execute Script */
    /*
        error result is via stderr, since popen can only read from stdout,
        so we need to redirect all stderr to stdout
    */
    snprintf(zysh_cmd, sizeof(zysh_cmd), "%s %s 2>&1", ZLD_ZON_ZYSH_110, script_name);
    if( !(pfp = popen(zysh_cmd, "r")) ) {
        retval = -1;
        goto remove; /*remove ZYSH CLI Script file that created in create_zysh_script()*/
    }
    else {
        /* debug */
        //printf("WTP: %s\n", zysh_cmd);
        /* debug */
    }

    /* read_result */
    while( fgets(result_line, sizeof(result_line), pfp) )
    {
        /* check if contain error_pattern which indicating exec error */
        if( !strncmp(result_line, error_pattern_1, strlen(error_pattern_1)) ||
            !strncmp(result_line, error_pattern_2, strlen(error_pattern_2)))
        {
            retval = -1;
            break;
        }

        if( data )
        { /* Need to parse the result */
            /* del newline '\n' */
            strp = NULL;
            if( (strp = strrchr(result_line, '\n')) ) {
                *strp = '\0';
            }
            /* parse per line */
            retval=parse(result_line, data);
            if(retval==0) break;
        }
    }
    /* close and delete script */
    pclose(pfp);

remove:
    unlink(script_name);

end:
    return retval;
}

int
execv_zysh_script(char *cli_cmd)
{
    int retval = 0;
    pid_t child;
    int status=0;
    int waitoptions = 0;
    char *args[16];

    args[0] = ZLD_ZON_ZYSH_PATH;
    args[1] = "-p 110";
    args[2] = "-e";
    args[3] = cli_cmd;
    args[4] = NULL;

    /* debug */
    printf("WTP: %s %s %s %s\n", args[0], args[1], args[2], args[3]);
    /* debug */
    child = fork();
    /* parent */
    if(child > 0) {
        waitpid(child, &status, waitoptions);
        if( WIFEXITED(status)){
            retval=WEXITSTATUS(status);
            if(retval)
                printf("Pcommand [%s %s %s %s] return error code: %d\n", args[0], args[1], args[2], args[3], retval);
            else{
                /* do we need to write cli */
                //args[3] = "write";
                //execv(args[0], args);
            }
        }
    }
    else if(child == 0) /* children */
    {
        retval=execv(args[0], args);
        if(retval)
            printf("Ccommand [%s %s %s %s] return error code: %d(%s)\n", args[0], args[1], args[2], args[3], errno, strerror(errno));
        exit(retval);
    }

    if(retval)
        printf("Tcommand [%s %s %s %s] return error code: %d(%s)\n", args[0], args[1], args[2], args[3], errno, strerror(errno));
    return retval;
}

int
execv_tftp_get(char *remote_file, char *local_file, char *host)
{
    int retval = 0;
    pid_t child;
    int status=0;
    char *args[16];

    args[0] = ZLD_ZON_TFTP;
    args[1] = "-r";
    args[2] = remote_file;
    args[3] = "-l";
    args[4] = local_file;
    args[5] = "-g";
    args[6] = host;
    args[7] = NULL;

    /* debug */
    printf("WTP: %s %s %s %s %s %s %s\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
    /* debug */
    child = fork();
    /* parent */
    if(child > 0) {
        #if 0
        int waitoptions = 0;

        waitpid(child, &status, waitoptions);
        if( WIFEXITED(status)){
            retval=WEXITSTATUS(status);
            if(retval)
                printf("Pcommand [%s %s %s %s %s %s %s] return error code: %d\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6], retval);
            else{
                /* do we need to write cli */
                //args[3] = "write";
                //execv(args[0], args);
            }
        }
        #else
        do {
            pid_t w = waitpid(child, &status, WUNTRACED);

            if (w == -1) { perror("waitpid"); exit(EXIT_FAILURE); }

            if (WIFEXITED(status)) {
                retval=WEXITSTATUS(status);
                fprintf(stderr, "exited, Pcommand [%s %s %s %s %s %s %s] return error code: %d\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6], retval);
            } else if (WIFSIGNALED(status)) {
                fprintf(stderr, "killed by signal, Pcommand [%s %s %s %s %s %s %s] return error code: %d\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6], WTERMSIG(status));
            } else if (WIFSTOPPED(status)) {
                fprintf(stderr, "stopped by signal, Pcommand [%s %s %s %s %s %s %s] return error code: %d\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6], WSTOPSIG(status));
            }
        } while (!WIFEXITED(status) && !WIFSIGNALED(status));
        #endif
    }
    else if(child == 0) /* children */
    {
        retval=execv(args[0], args);
        if(retval)
            printf("Ccommand [%s %s %s %s %s %s %s] return error code: %d(%s)\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6], errno, strerror(errno));
        exit(retval);
    }

    if(retval)
        printf("Tcommand [%s %s %s %s %s %s %ss] return error code: %d(%s)\n", args[0], args[1], args[2], args[3], args[4], args[5], args[6], errno, strerror(errno));
    return retval;
}

/* read & parse config from file */
int
parse_conf(char *conf, void *data, int (*parse)(char *raw_strp, void *data))
{
    FILE *pFile=NULL;
    off_t length;
    int retval = 0;
    char *strp;
    char result_line[MAX_ZLD_ZON_ZYSH_RESULT_LINE_LEN]="\0";

    if(NULL==conf) return -1;

    pFile=fopen(conf,"r");

    if(pFile==NULL) {
        retval=-1;
        return retval;
    }

    /* obtain file size */
    fseeko(pFile, 0, SEEK_END);
    length=ftello(pFile);
    rewind(pFile);

    if(length==0){
        retval=-1;
    }
    else{
        /* read_result */
        while( fgets(result_line, sizeof(result_line), pFile) )
        {
            if( data )
            { /* Need to parse the result */
                /* del newline '\n' */
                strp = NULL;
                if( (strp = strrchr(result_line, '\n')) ) {
                    *strp = '\0';
                }
                /* parse per line */
                retval=parse(result_line, data);
                if(retval==0) break;
            }
        }
    }
    // terminate
    fclose (pFile);
    return retval;
}

int is_IPv4AddressString(const char *str)
{
    struct in_addr addr;
    int ret;

    if(str==NULL)
        return -1;
    if(strlen(str)<7) /*1.1.1.1*/
        return -2;
    ret = inet_pton(AF_INET, str, &addr);
    return ret;
}

int
is_IPv4Address(const uint8_t *addr)
{
    char addrstr[256]="\0";

    if(addr==NULL)
        return -1;
    sprintf(addrstr, "%d.%d.%d.%d", *addr, *(addr+1), *(addr+2), *(addr+3));
    return is_IPv4AddressString(addrstr);
}

int
is_IPv4Netmask(const uint8_t *netmask)
{
    struct in_addr mask;
    uint32_t ip, foo = 0x80000000;
    int length = 0, zero = 0;
    char maskstr[256]="\0";
    int ret=0;


    if(netmask==NULL)
        return -1;
    sprintf(maskstr, "%d.%d.%d.%d", *netmask, *(netmask+1), *(netmask+2), *(netmask+3) );
    ret = inet_pton(AF_INET, maskstr, &mask);
    if(ret==0)
        return -1;
    ip = ntohl(mask.s_addr);

    while(foo) {
        if(ip & foo) {
            if(zero)
                return -1;
            length++;
        }
        else
            zero++;
        foo >>= 1;
    }
    return length;
}
int
simple_parse_string_accept_blank(char *raw_strp, void *data, const char *needle)
{
    int retval = 0;
    const char delim[] = ":";
    char *strp, *str_token;

    /* parse result */
    /* check needle */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    /* remove needle */
    str_token+=strlen(needle);
     /* check delim */
    strp = strstr(str_token, delim);
    if(NULL == strp)
        return -1;
    /* remove space */
    for(strp+=strlen(delim); *strp==' '; strp++);
    /* copy result */
    if(strp) sprintf((char *)data, "%s", strp);
    else sprintf((char *)data, "%c", '\0');
    return retval;
}

/* common parse string function */
int
simple_parse_string(char *raw_strp, void *data, const char *needle)
{
    int retval = 0;
    const char delim[] = " :\t";
    char *strp, *str_token;

    /* parse result */
    /* check needle */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    /* remove needle */
    str_token+=strlen(needle);
    strp = strtok(str_token, delim);
    /* copy result */
    if(strp) sprintf((char *)data, "%s", strp);
    else return -1;

    return retval;
}

/* common parse IPv4 address froamt */
int
simple_parse_IPv4_format(char *raw_strp, void *data, const char *needle)
{
    int retval = 0;
    const char delim[] = " :,\t";
    const char delim2[] = " :,\t.";
    char *strp, *str_token;
    unsigned char p[4]="\0";
    int i=0;

    /* parse result */
    /* check needle */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    /* remove needle */
    str_token+=strlen(needle);
    /* check ip address or dn */
    strp = strtok(str_token, delim);
    if(strp==NULL)
        return -1;
    if(is_IPv4AddressString(strp) != 1)
        return -1;
    /* copy result */
    for(i=0, strp = strtok(str_token, delim2); strp!=NULL; strp = strtok(NULL, delim2)){
        p[i++]=(unsigned char)strtol(strp, NULL, 10);
        if(4==i) break;
    }
    /* verify IPv4 address */
    if(is_IPv4Address(p) != 1)
        return -1;
    memcpy(data, p, 4);
    return retval;
}

/*
root@nwa5123-ni:/etc# zysh -p 110 -e "show mac"
MAC address: B0:B2:DC:6F:12:E5-B0:B2:DC:6F:12:E7
*/
int
parse_systemMAC(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "MAC address";
    const char delim[] = " :-";
    char *strp, *str_token;
    unsigned char *p=(unsigned char *)data;
    int i=0;

    /* parse result */
    /* check 'MAC address' */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    /* remove ' :' */
    str_token+=sizeof(needle);

    /* copy result */
    for(strp = strtok(str_token, delim); strp!=NULL; strp = strtok(NULL, delim)){
        *p=(unsigned char)strtol(strp, NULL, 16);
        p++;
        i++;
        if(6==i) break;
    }

    return retval;
}

/*
root@nwa5123-ni:/etc# zysh -p 110 -e "show version"
ZyXEL Communications Corp.
model           : NWA5123-NI
firmware version: V4.10(AAHX.0)IT_20131222172252
BM version      : V1.08
build date      : 2013-12-22 17:48:15
*/
int
parse_modelName(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "model";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}

int
parse_fwVersion(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "firmware version";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}
/*
root@nwa5123-ni:/etc# zysh -p 100 -e "show interface br0"
active: yes
interface name: br0
description:
join count: 1
member: vlan1
IP type: dhcp
IP address: 192.168.1.12
netmask: 255.255.255.0
gateway: 192.168.1.2
metric: 0
upstream: 1048576
downstream: 1048576
MTU: 1500
MSS: 0
forward delay time: 15
stp: off
tcp-ack traffic prioritize:
.........
*/
int
parse_DHCPSetting(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "IP type";
    const char symbol[] = "dhcp";
    char temp[256]="\0";

    retval=simple_parse_string(raw_strp, temp, needle);
    if(retval==0){
        uint16_t *setting=(uint16_t *)data;
        if(strcmp(temp, symbol)==0){
            *setting=1;
        }
        else{
            *setting=0;
        }
    }

    return retval;
}

int
parse_IPv4Address(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "IP address";

    retval=simple_parse_IPv4_format(raw_strp, data, needle);
    return retval;
}

/*
Router> show ip http server secure status
active               : no
port                 : 443
certificate          : default
force redirect       : no
authentication client: no
cipher suite         : rc4 aes des 3des
*/
int
parse_Port(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "port";
    char temp[256]="\0";
    uintptr_t *port=(uintptr_t *)data;

    retval=simple_parse_string(raw_strp, temp, needle);
    if(retval==0){
        *port=strtoul(temp, NULL, 10);
    }
    else *port=0;
    return retval;
}

int
parse_Active(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "active";
    const char symbol[] = "yes";
    char temp[256]="\0";
    uint32_t *active=(uint32_t *)data;

    retval=simple_parse_string(raw_strp, temp, needle);
    if(retval==0){
        if(strcmp(temp, symbol)==0){
            *active=1;
        }
        else{
            *active=0;
        }
    }

    return retval;
}

int
parse_IPv4WebURL(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "IP address";
    const char delim[] = " :";
    char *strp, *str_token;

    /* parse result */
    /* check 'IP address' */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    /* remove ' :.' */
    str_token+=sizeof(needle);
    /* copy result */
    strp = strtok(str_token, delim);
    /* copy result */
    if(strp){
        sprintf((char *)data, "http://%s/", strp);
    }
    else return -1;


    return retval;
}

int
parse_IPv4Netmask(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "netmask";

    retval=simple_parse_IPv4_format(raw_strp, data, needle);
    return retval;
}

int
parse_IPv4GW(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "gateway";

    retval=simple_parse_IPv4_format(raw_strp, data, needle);
    return retval;
}

/*
Zone-Forwarder : -
  Domain Name: *
  From : Default
  DNS Server count: 3
  DNS Server : 172.24.80.254,168.95.1.1,8.8.8.8
  Interface  : br0,br0,br0
*/
int
parse_IPv4DNS1(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle1[] = "DNS Server count";
    const char needle2[] = "DNS Server";
    const char delim[] = " :.,";
    char *strp, *str_token;
    unsigned char p[4]="\n";
    int i=0;

    /* parse result */
    /* skip 'DNS Server count' */
    str_token = strstr(raw_strp, needle1);
    if(NULL != str_token)
        return -1;
    /* check 'DNS Server' */
    str_token = strstr(raw_strp, needle2);
    if(NULL == str_token)
        return -1;
    /* remove ' :.' */
    str_token+=sizeof(needle2);
    /* copy result */
    for(i=0, strp = strtok(str_token, delim); strp!=NULL; strp = strtok(NULL, delim)){
        p[i++]=(unsigned char)strtol(strp, NULL, 10);
        if(4==i) break;
    }
    /* verify dns address */
    if(is_IPv4Address(p) != 1) return -1;
    memcpy(data, p, 4);

    return retval;
}

int
parse_IPv4DNS2(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle1[] = "DNS Server count";
    const char needle2[] = "DNS Server";
    const char delim[] = " :.,";
    char *strp, *str_token;
    unsigned char p[4]="\0";
    int i=0;

    /* parse result */
    /* skip 'DNS Server count' */
    str_token = strstr(raw_strp, needle1);
    if(NULL != str_token)
        return -1;
    /* check 'DNS Server' */
    str_token = strstr(raw_strp, needle2);
    if(NULL == str_token)
        return -1;
    /* remove ' :.' */
    str_token+=sizeof(needle2);
    /* skip DNS1 */
    for(i=0, strp = strtok(str_token, delim); strp!=NULL; strp = strtok(NULL, delim)){
        i++;
        if(4==i) break;
    }
    /* copy result */
    for(i=0, strp = strtok(NULL, delim); strp!=NULL; strp = strtok(NULL, delim)){
        p[i++]=(unsigned char)strtol(strp, NULL, 10);
        if(4==i) break;
    }
    /* verify dns address */
    if(is_IPv4Address(p) != 1) return -1;
    memcpy(data, p, 4);

    return retval;
}

/*
root@nwa5123-ni:/tmp# cat /etc/resolv.conf
nameserver 172.24.80.254
nameserver 168.95.1.1
nameserver 8.8.8.8
AC_IP_1=192.168.1.2
*/

int
parse_confIPv4DNS1(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "nameserver";

    retval=simple_parse_IPv4_format(raw_strp, data, needle);
    return retval;
}

int
parse_confIPv4DNS2(char *raw_strp, void *data)
{
    int i=0, retval = 0;
    const char needle[] = "nameserver";
    const char delim[] = " :.";
    char *strp, *str_token;
    static int cnt=0;
    unsigned char p[4]="\0";

    /* parse result */
    /* check 'nameserver' */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    if(cnt==0){
        cnt++;
        return -1;
    }
    cnt=0;
    /* remove ' ' */
    str_token+=sizeof(needle);
    /* copy result */
    for(i=0, strp = strtok(str_token, delim); strp!=NULL; strp = strtok(NULL, delim)){
        p[i++]=(unsigned char)strtol(strp, NULL, 10);
        if(4==i) break;
    }
    /* verify dns address */
    if(is_IPv4Address(p) != 1) return -1;
    memcpy(data, p, 4);

    return retval;
}
/*
root@NXC2500:~# zysh -p 110 -e "show ntp server"
NTP active      : yes
NTP server      : 0.pool.ntp.org
*/

int
parse_IPv4NTP(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "NTP server";

    retval=simple_parse_IPv4_format(raw_strp, data, needle);
    return retval;
}

int
parse_IPv4NTP_DN(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "NTP server";
    char temp[256]="\0";

    retval=simple_parse_string(raw_strp, temp, needle);
    if(retval==0){
        /* ip or domain name */
        if(is_IPv4AddressString(temp) == 1)
            return -1;
        else /* copy result */
            sprintf((char *)data, "%s", temp);
    }

    return retval;
}

int
parse_SNMPGetComm(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "get community";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}

int
parse_SNMPSetComm(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "set community";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}

int
parse_SNMPTrapComm(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "trap community";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}

int
parse_IPv4SNMPTrapSrv(char *raw_strp, void *data)
{
    const char needle[] = "trap host";
    const char delim[] = " :";
    const char delim2[] = " :.";
    char *strp, *str_token;
    unsigned char p[4]="\0";
    int i=0;

    /* parse result */
    /* check 'trap host' */
    str_token = strstr(raw_strp, needle);
    if(NULL == str_token)
        return -1;
    /* remove ' :' */
    str_token+=sizeof(needle);
    strp = strtok(str_token, delim);
    /* copy result */
    if(strp){
        if(strcmp(strp, "none")==0) return -1;
        if(is_IPv4AddressString(strp) == 1){/* copy result */
            //sprintf((char *)data, "%s", strp);
            for(i=0, strp = strtok(str_token, delim2); strp!=NULL; strp = strtok(NULL, delim2)){
                p[i++]=(unsigned char)strtol(strp, NULL, 10);
                if(4==i) break;
            }
            memcpy(data, p, 4);
            return 0;
        }
        else{
            return -1;
        }
    }
    else return -1;

    return 0;
}
/*
root@NYPI:/# zysh -p 100 -e "show logging status syslog"
remote server: 1
  enable: no
  log format: vrpt, server address: , log facility: Local_1
  category settings:
    user              : no     , zysh              : no     ,
    built-in-service  : no     , system            : no     ,
    system-monitoring : no     , connectivity-check: no     ,
    device-ha         : no     , pki               : no     ,
    interface         : no     , interface-statistics: no     ,
    account           : no     , traffic-log       : no     ,
    file-manage       : no     , wlan              : no     ,
    daily-report      : no     , dhcp              : no     ,
    default           : no     , capwap            : no     ,
    wlan-monitor      : no     , wlan-rogueap      : no     ,
    wlan-dcs          : no     , wlan-band-select  : no     ,
    wlan-load-balancing: no     , capwap-dataforward: no     ,
    wlan-station-info : no     ,
remote server: 2
  enable: no
  log format: vrpt, server address: , log facility: Local_1
  category settings:
    user              : no     , zysh              : no     ,
    built-in-service  : no     , system            : no     ,
    system-monitoring : no     , connectivity-check: no     ,
    device-ha         : no     , pki               : no     ,
    interface         : no     , interface-statistics: no     ,
    account           : no     , traffic-log       : no     ,
    file-manage       : no     , wlan              : no     ,
    daily-report      : no     , dhcp              : no     ,
    default           : no     , capwap            : no     ,
    wlan-monitor      : no     , wlan-rogueap      : no     ,
    wlan-dcs          : no     , wlan-band-select  : no     ,
    wlan-load-balancing: no     , capwap-dataforward: no     ,
    wlan-station-info : no     ,
remote server: 3
  enable: no
  log format: vrpt, server address: , log facility: Local_1
  category settings:
    user              : no     , zysh              : no     ,
    built-in-service  : no     , system            : no     ,
    system-monitoring : no     , connectivity-check: no     ,
    device-ha         : no     , pki               : no     ,
    interface         : no     , interface-statistics: no     ,
    account           : no     , traffic-log       : no     ,
    file-manage       : no     , wlan              : no     ,
    daily-report      : no     , dhcp              : no     ,
    default           : no     , capwap            : no     ,
    wlan-monitor      : no     , wlan-rogueap      : no     ,
    wlan-dcs          : no     , wlan-band-select  : no     ,
    wlan-load-balancing: no     , capwap-dataforward: no     ,
    wlan-station-info : no     ,
remote server: 4
  enable: no
  log format: vrpt, server address: , log facility: Local_1
  category settings:
    user              : no     , zysh              : no     ,
    built-in-service  : no     , system            : no     ,
    system-monitoring : no     , connectivity-check: no     ,
    device-ha         : no     , pki               : no     ,
    interface         : no     , interface-statistics: no     ,
    account           : no     , traffic-log       : no     ,
    file-manage       : no     , wlan              : no     ,
    daily-report      : no     , dhcp              : no     ,
    default           : no     , capwap            : no     ,
    wlan-monitor      : no     , wlan-rogueap      : no     ,
    wlan-dcs          : no     , wlan-band-select  : no     ,
    wlan-load-balancing: no     , capwap-dataforward: no     ,
    wlan-station-info : no     ,
*/
int
parse_IPv4SyslogSrv1(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle1[] = "remote server";
    const char needle2[] = "server address";
    const char delim[] = " :,";
    const char delim2[] = " :,.";
    char *strp, *str_token;
    unsigned char p[4]="\0";
    static int remote=0;
    int i=0;

    /* parse result */
    /* find remote server no first we need no 1*/
    if(remote!=1)
    {
        str_token = strstr(raw_strp, needle1);
        if(NULL == str_token){
            return -1;
        }
        else{
            /* record remote server no */
            /* remove ' :.' */
            str_token+=sizeof(needle1);
            strp = strtok(str_token, delim);
            if(strp==NULL)
                return -1;
            remote=(int)strtol(strp, NULL, 10);
            return -1;
        }
    }
    /* check 'server address' */
    str_token = strstr(raw_strp, needle2);
    if(NULL == str_token)
        return -1;
    remote=0;
    /* remove ' :.' */
    str_token+=sizeof(needle2);
    /* check ip address or dn */
    strp = strtok(str_token, delim);
    if(strp==NULL)
        return -1;
    if(is_IPv4AddressString(strp) != 1) return -1;
    /* copy result */
    for(i=0, strp = strtok(str_token, delim2); strp!=NULL; strp = strtok(NULL, delim2)){
        p[i++]=(unsigned char)strtol(strp, NULL, 10);
        if(4==i) break;
    }
    memcpy(data, p, 4);

    return retval;
}

int
parse_IPv4SyslogSrv2(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle1[] = "remote server";
    const char needle2[] = "server address";
    const char delim[] = " :,";
    const char delim2[] = " :,.";
    char *strp, *str_token;
    unsigned char p[4]="\0";
    static int remote=0;
    int i=0;

    /* parse result */
    /* find remote server no first, we need no 2*/
    if(remote!=2)
    {
        str_token = strstr(raw_strp, needle1);
        if(NULL == str_token){
            return -1;
        }
        else{
            /* record remote server no */
            /* remove ' :.' */
            str_token+=sizeof(needle1);
            strp = strtok(str_token, delim);
            if(strp==NULL)
                return -1;
            remote=(int)strtol(strp, NULL, 10);
            return -1;
        }
    }
    /* check 'server address' */
    str_token = strstr(raw_strp, needle2);
    if(NULL == str_token)
        return -1;
    remote=0;
    /* remove ' :.' */
    str_token+=sizeof(needle2);
    /* check ip address or dn */
    strp = strtok(str_token, delim);
    if(strp==NULL)
        return -1;
    if(is_IPv4AddressString(strp) != 1) return -1;
    /* copy result */
    for(i=0, strtok(str_token, delim2); strp!=NULL; strp = strtok(NULL, delim2)){
        p[i++]=(unsigned char)strtol(strp, NULL, 10);
        if(4==i) break;
    }
    memcpy(data, p, 4);

    return retval;
}

int
parse_IPv4SyslogSrv1_DN(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle1[] = "remote server";
    const char needle2[] = "server address";
    const char delim[] = " :,";
    char *strp, *str_token;
    static int remote=0;

    /* parse result */
    /* find remote server no first we need no 1*/
    if(remote!=1)
    {
        str_token = strstr(raw_strp, needle1);
        if(NULL == str_token){
            return -1;
        }
        else{
            /* record remote server no */
            /* remove ' :.' */
            str_token+=sizeof(needle1);
            strp = strtok(str_token, delim);
            if(strp==NULL)
                return -1;
            remote=(int)strtol(strp, NULL, 10);
            return -1;
        }
    }
    /* check 'server address' */
    str_token = strstr(raw_strp, needle2);
    if(NULL == str_token)
        return -1;
    remote=0;
    /* remove ' :.' */
    str_token+=sizeof(needle2);
    /* check ip address or dn */
    strp = strtok(str_token, delim);
    if(strp==NULL)
        return -1;
    if(is_IPv4AddressString(strp) == 1) return -1;
    /* hard code */
    if(strlen(strp)==3 && (strncmp(strp, "log", 3)==0)) return -1;
    /* copy result */
    if(strp) sprintf((char *)data, "%s", strp);

    return retval;
}

int
parse_IPv4SyslogSrv2_DN(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle1[] = "remote server";
    const char needle2[] = "server address";
    const char delim[] = " :,";
    char *strp, *str_token;
    static int remote=0;

    /* parse result */
    /* find remote server no first, we need no 2*/
    if(remote!=2)
    {
        str_token = strstr(raw_strp, needle1);
        if(NULL == str_token){
            return -1;
        }
        else{
            /* record remote server no */
            /* remove ' :.' */
            str_token+=sizeof(needle1);
            strp = strtok(str_token, delim);
            if(strp==NULL)
                return -1;
            remote=(int)strtol(strp, NULL, 10);
            return -1;
        }
    }
    /* check 'server address' */
    str_token = strstr(raw_strp, needle2);
    if(NULL == str_token)
        return -1;
    remote=0;
    /* remove ' :.' */
    str_token+=sizeof(needle2);
    /* check ip address or dn */
    strp = strtok(str_token, delim);
    if(strp==NULL)
        return -1;
    if(is_IPv4AddressString(strp) == 1) return -1;
    /* hard code */
    if(strlen(strp)==3 && (strncmp(strp, "log", 3)==0)) return -1;
    /* copy result */
    if(strp) sprintf((char *)data, "%s", strp);

    return retval;
}

/*
root@nwa5123-ni:/etc# zysh -p 100 -e "show fqdn"
host name  : nwa5123-ni
domain name: none
FQDN       : nwa5123-ni
*/
int
parse_systemName(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "host name";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}

/*
root@nwa5123-ni:~# zysh -p 110 -e "configure terminal show username admin"
username              : admin
password              : $4$9YzgoQNq$8h5o18DfMUv2kd/slegn/JZYbvn5+Rure8rlH7WvBQIUMBTPbFlR1T+uN4KoXr+VVplv50u5/JrWpRJoQfUFXsfNl1TZnJtyzZm8s6a67No$
description           : Administration account
user type             : admin
time setting          : manual
lease time            : 30
re-auth time          : 0
reference count       : 0
*/
int
parse_password(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "password";

    retval=simple_parse_string(raw_strp, data, needle);
    return retval;
}

/*
root@NYPI:/# zysh -p 110 -e "show capwap ap info"
                AC-IP                   192.168.2.2
             Fallback                   Disable
    Fallback Interval                   30
       Discovery type                   DHCP
             SM-State                   RUN(8)
        msg-buf-usage                   0/10 (Usage/Max)
       capwap-version                   10002
         Radio Number                   2/4 (Usage/Max)
           BSS Number                   16/16 (Usage/Max)
              IANA ID                   037a
          Description                   AP-5067F037FDB0
          Link Status                   Connection Up
*/

int
parse_location(char *raw_strp, void *data)
{
    int retval = 0;
    const char needle[] = "location";

    retval=simple_parse_string_accept_blank(raw_strp, data, needle);
    return retval;
}

/* basic */
int
get_systemMAC(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_MAC_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_systemMAC);

    return retval;
}

int
get_modelName(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_version_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_modelName);

    return retval;
}

int
get_fwVersion(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_version_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_fwVersion);

    return retval;
}
/* basic */
/* network */
int
get_DHCPSetting(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_Interface_CLI_fat);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_DHCPSetting);

    return retval;
}

/*
Thin AP:show interface br0
FAT AP:show interface lan
*/
int
get_IPv4Address(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_Interface_CLI_fat);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4Address);

    return retval;
}

int
get_IPv4WebURL(uint8_t *data)
{
    int retval = 0;
    unsigned int https_enabled=0, https_port=0;
    unsigned int http_enabled=0, http_port=0;
    uint8_t ip[512]="\0";

    retval=get_IPv4Address(&ip[0]);
    if(0==retval){
        get_httpsActive((uint8_t *)&https_enabled);
        get_httpActive((uint8_t *)&http_enabled);
        get_httpsPort((uint8_t *)&https_port);
        get_httpPort((uint8_t *)&http_port);
        if(https_enabled || http_enabled){
            snprintf((char *)data, 254, "%s://%d.%d.%d.%d:%d/",
                         (https_enabled==1)?"https":"http",
                         ip[0], ip[1], ip[2], ip[3],
                        (https_enabled==1)?https_port:http_port
                     );
        }
        else{
            data[0]='\0';
            retval=-1;
        }
    }

    return retval;
}

int
get_HttpFormatInfo(uint8_t *data)
{
    unsigned int https_enabled=0, https_port=0;
    unsigned int http_enabled=0, http_port=0;

    /* https first!! */
    /* Feature request discussion with Sbit, PM:Peter@2018/7/13 */
    get_httpsActive((uint8_t *)&https_enabled);
    if(https_enabled){
        get_httpsPort((uint8_t *)&https_port);
        snprintf((char *)data, 254, "https://%%s:%d/", https_port);
        return 0;
    }

    get_httpActive((uint8_t *)&http_enabled);
    if(http_enabled){
        get_httpPort((uint8_t *)&http_port);
        snprintf((char *)data, 254, "http://%%s:%d/", http_port);
        return 0;
    }
    data[0]='\0';
    return -1;
}

int
get_httpPort(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_http_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_Port);

    return retval;
}

int
get_httpActive(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_http_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_Active);

    return retval;
}

int
get_httpsPort(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_https_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_Port);

    return retval;
}

int
get_httpsActive(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_https_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_Active);

    return retval;
}

int
get_IPv4Netmask(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_Interface_CLI_fat);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4Netmask);

    return retval;
}

int
get_IPv4GW(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_Interface_CLI_fat);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4GW);

    return retval;
}

int
get_IPv4DNS1(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_IP_DNS_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4DNS1);

    return retval;
}

int
get_IPv4DNS2(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_IP_DNS_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4DNS2);

    return retval;
}

int
get_512xIPv4DNS1(uint8_t *data)
{
    int retval = 0;

    retval = parse_conf(resolvFile, (void *)data, parse_confIPv4DNS1);
    return retval;
}

int
get_512xIPv4DNS2(uint8_t *data)
{
    int retval = 0;

    retval = parse_conf(resolvFile, (void *)data, parse_confIPv4DNS2);
    return retval;
}

int
get_IPv4NTP(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_NTP_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4NTP);

    return retval;
}

int
get_IPv4NTP_DN(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_NTP_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4NTP_DN);

    return retval;
}

int
get_SNMPGetComm(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SNMP_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_SNMPGetComm);

    return retval;
}

int
get_SNMPSetComm(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SNMP_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_SNMPSetComm);

    return retval;
}

int
get_SNMPTrapComm(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SNMP_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_SNMPTrapComm);

    return retval;
}

int
get_IPv4SNMPTrapSrv(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SNMP_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4SNMPTrapSrv);

    return retval;
}

int
get_IPv4SyslogSrv1(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SysLog_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4SyslogSrv1);

    return retval;
}

int
get_IPv4SyslogSrv2(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SysLog_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4SyslogSrv2);

    return retval;
}

int
get_IPv4SyslogSrv1_DN(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SysLog_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4SyslogSrv1_DN);

    return retval;
}

int
get_IPv4SyslogSrv2_DN(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_SysLog_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_IPv4SyslogSrv2_DN);

    return retval;
}

/* network */
/*******************************************************************************
* Description :
*       get System Name from ZYSH
*
* Return Val:
*       0 when OK, -1 when error
*******************************************************************************/
int
get_systemName(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_hostname_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_systemName);

    return retval;
}

/* get user's encrypted password */
int
get_password(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_admin_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_password);

    return retval;
}

int
get_location(uint8_t *data)
{
    int retval = 0;
    char cli_cmd[MAX_ZLD_ZON_ZYSH_SCRIPT_CONTENT_LEN];

    snprintf(cli_cmd, sizeof(cli_cmd), "%s", show_location_CLI);
    retval = execute_zysh_script(cli_cmd, (void *)data, parse_location);

    return retval;
}

#if 0
/* test */
void test_wtp_get(void)
{
    uint8_t data[2000]="\0";
    int rec=0;

//int get_systemMAC(char *data);
    rec=get_systemMAC(&data[0]);
    if(0==rec){
        printf("get_systemMAC: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_systemMAC: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_systemMAC: \"%s\" \n", data);
    }
    else
       printf("get_systemMAC failed \n");

//int get_modelName(char *data);
    rec=get_modelName(&data[0]);
    if(0==rec){
        //printf("get_modelName: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_modelName: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_modelName: \"%s\" \n", data);
    }
    else
       printf("get_modelName failed \n");

//int get_fwVersion(char *data);
    rec=get_fwVersion(&data[0]);
    if(0==rec){
        //printf("get_fwVersion: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_fwVersion: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_fwVersion: \"%s\" \n", data);
    }
    else
       printf("get_fwVersion failed \n");

//int get_DHCPSetting(char *data);
    rec=get_DHCPSetting(&data[0]);
    if(0==rec){
        uint16_t *setting=(uint16_t *)&data[0];
        //printf("get_DHCPSetting: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_DHCPSetting: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_DHCPSetting: \"0x%x\" \n", *setting);
        //printf("get_DHCPSetting: \"%s\" \n", data);
    }
    else
       printf("get_DHCPSetting failed \n");

//int get_IPv4Address(char *data);
    rec=get_IPv4Address(&data[0]);
    if(0==rec){
        //printf("get_IPv4Address: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4Address: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4Address: \"%d\" \n", data[0]);
        //printf("get_IPv4Address: \"%s\" \n", data);
    }
    else
       printf("get_DHCPSetting failed \n");

//int get_IPv4Netmask(char *data);
    rec=get_IPv4Netmask(&data[0]);
    if(0==rec){
        //printf("get_IPv4Netmask: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4Netmask: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4Netmask: \"%d\" \n", data[0]);
        //printf("get_IPv4Netmask: \"%s\" \n", data);
    }
    else
       printf("get_IPv4Netmask failed \n");

//int get_IPv4GW(char *data);
    rec=get_IPv4GW(&data[0]);
    if(0==rec){
        //printf("get_IPv4GW: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4GW: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4GW: \"%d\" \n", data[0]);
        //printf("get_IPv4GW: \"%s\" \n", data);
    }
    else
       printf("get_IPv4GW failed \n");

//int get_IPv4DNS1(char *data);
    rec=get_IPv4DNS1(&data[0]);
    if(0==rec){
        //printf("get_IPv4DNS1: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4DNS1: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4DNS1: \"%d\" \n", data[0]);
        //printf("get_IPv4DNS1: \"%s\" \n", data);
    }
    else
       printf("get_IPv4DNS1 failed \n");

//int get_IPv4DNS2(char *data);
    rec=get_IPv4DNS2(&data[0]);
    if(0==rec){
        //printf("get_IPv4DNS2: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4DNS2: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4DNS2: \"%d\" \n", data[0]);
        //printf("get_IPv4DNS2: \"%s\" \n", data);
    }
    else
       printf("get_IPv4DNS2 failed \n");

//int get_512xIPv4DNS1(char *data);
    rec=get_512xIPv4DNS1(&data[0]);
    if(0==rec){
        //printf("get_512xIPv4DNS1: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_512xIPv4DNS1: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_512xIPv4DNS1: \"%d\" \n", data[0]);
        //printf("get_512xIPv4DNS1: \"%s\" \n", data);
    }
    else
       printf("get_512xIPv4DNS1 failed \n");

//int get_512xIPv4DNS2(char *data);
    rec=get_512xIPv4DNS2(&data[0]);
    if(0==rec){
        //printf("get_512xIPv4DNS2: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_512xIPv4DNS2: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_512xIPv4DNS2: \"%d\" \n", data[0]);
        //printf("get_512xIPv4DNS2: \"%s\" \n", data);
    }
    else
       printf("get_512xIPv4DNS2 failed \n");

//int get_IPv4NTP(char *data);
    rec=get_IPv4NTP(&data[0]);
    if(0==rec){
        //printf("get_IPv4NTP: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4NTP: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4NTP: \"%d\" \n", data[0]);
        //printf("get_IPv4NTP: \"%s\" \n", data);
    }
    else
       printf("get_IPv4NTP failed \n");

//int get_SNMPGetComm(char *data);
    rec=get_SNMPGetComm(&data[0]);
    if(0==rec){
        //printf("get_SNMPGetComm: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_SNMPGetComm: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_SNMPGetComm: \"%d\" \n", data[0]);
        printf("get_SNMPGetComm: \"%s\" \n", data);
    }
    else
       printf("get_SNMPGetComm failed \n");

//int get_SNMPSetComm(char *data);
    rec=get_SNMPSetComm(&data[0]);
    if(0==rec){
        //printf("get_SNMPSetComm: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_SNMPSetComm: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_SNMPSetComm: \"%d\" \n", data[0]);
        printf("get_SNMPSetComm: \"%s\" \n", data);
    }
    else
       printf("get_SNMPSetComm failed \n");

//int get_SNMPTrapComm(char *data);
    rec=get_SNMPTrapComm(&data[0]);
    if(0==rec){
        //printf("get_SNMPTrapComm: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_SNMPTrapComm: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_SNMPTrapComm: \"%d\" \n", data[0]);
        printf("get_SNMPTrapComm: \"%s\" \n", data);
    }
    else
       printf("get_SNMPTrapComm failed \n");

//int get_IPv4SNMPTrapSrv(char *data);
    rec=get_IPv4SNMPTrapSrv(&data[0]);
    if(0==rec){
        //printf("get_IPv4SNMPTrapSrv: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4SNMPTrapSrv: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4SNMPTrapSrv: \"%d\" \n", data[0]);
        //printf("get_IPv4SNMPTrapSrv: \"%s\" \n", data);
    }
    else
       printf("get_IPv4SNMPTrapSrv failed \n");

//int get_IPv4SyslogSrv1(char *data);
    rec=get_IPv4SyslogSrv1(&data[0]);
    if(0==rec){
        //printf("get_IPv4SyslogSrv1: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4SyslogSrv1: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4SyslogSrv1: \"%d\" \n", data[0]);
        //printf("get_IPv4SyslogSrv1: \"%s\" \n", data);
    }
    else
       printf("get_IPv4SyslogSrv1 failed \n");

//int get_IPv4SyslogSrv2(char *data);
    rec=get_IPv4SyslogSrv2(&data[0]);
    if(0==rec){
        //printf("get_IPv4SyslogSrv2: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        printf("get_IPv4SyslogSrv2: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4SyslogSrv2: \"%d\" \n", data[0]);
        //printf("get_IPv4SyslogSrv2: \"%s\" \n", data);
    }
    else
       printf("get_IPv4SyslogSrv2 failed \n");

//int get_IPv4NTP_DN(char *data);
    rec=get_IPv4NTP_DN(&data[0]);
    if(0==rec){
        //printf("get_IPv4NTP_DN: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_IPv4NTP_DN: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4NTP_DN: \"%d\" \n", data[0]);
        printf("get_IPv4NTP_DN: \"%s\" \n", data);
    }
    else
       printf("get_IPv4NTP_DN failed \n");

//int get_IPv4SyslogSrv1_DN(char *data);
    rec=get_IPv4SyslogSrv1_DN(&data[0]);
    if(0==rec){
        //printf("get_IPv4SyslogSrv1_DN: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_IPv4SyslogSrv1_DN: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        //printf("get_IPv4SyslogSrv1_DN: \"%d\" \n", data[0]);
        printf("get_IPv4SyslogSrv1_DN: \"%s\" \n", data);
    }
    else
       printf("get_IPv4SyslogSrv1_DN failed \n");

//int get_IPv4SyslogSrv2_DN(char *data);
    rec=get_IPv4SyslogSrv2_DN(&data[0]);
    if(0==rec){
        //printf("get_IPv4SyslogSrv2_DN: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_IPv4SyslogSrv2_DN: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_IPv4SyslogSrv2_DN: \"%s\" \n", data);
    }
    else
       printf("get_IPv4SyslogSrv2_DN failed \n");

//int get_systemName(char *data);
    rec=get_systemName(&data[0]);
    if(0==rec){
        //printf("get_systemName: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_systemName: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_systemName: \"%s\" \n", data);
    }
    else
       printf("get_systemName failed \n");

//int get_location(char *data);
    rec=get_location(&data[0]);
    if(0==rec){
        //printf("get_location: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_location: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_location: \"%s\" \n", data);
    }
    else
       printf("get_location failed \n");

//int get_IPv4WebURL(char *data);
    rec=get_IPv4WebURL(&data[0]);
    if(0==rec){
        //printf("get_IPv4WebURL: \"%02X:%02X:%02X:%02X:%02X:%02X\" \n", data[0],data[1],data[2],data[3],data[4],data[5]);
        //printf("get_IPv4WebURL: \"%d.%d.%d.%d\" \n", data[0],data[1],data[2],data[3]);
        printf("get_IPv4WebURL: \"%s\" \n", data);
    }
    else
       printf("get_IPv4WebURL failed \n");
{
    uint32_t act=0, port=0;

    get_httpsActive((uint8_t *)&act);
    printf("https act=%d, ", act);
    get_httpsPort((uint8_t *)&port);
    printf("port=%d\n", port);

    get_httpActive((uint8_t *)&act);
    printf("http act=%d, ", act);
    get_httpPort((uint8_t *)&port);
    printf("port=%d\n", port);
}
}
/* test */
#endif

int set_DHCPSetting(uint16_t setting)
{
    char cmd[255]="\0";
    int err=0;

    if(setting){
        snprintf(cmd, 254, "%s", enable_DHCP_CLI_fat);
        err=execv_zysh_script(&cmd[0]);
        printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    }
    else return -1;

    return err;
}

int set_IPv4Address(uint8_t *addr)
{
    char cmd[255]="\0";
    uint8_t mask[4]="\0";
    int err=0;

    err=is_IPv4Address(addr);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }
    err=get_IPv4Netmask(&mask[0]);
    if(err){ /* default netmask 255.255.255.0 */
        mask[0]=0xff;
        mask[1]=0xff;
        mask[2]=0xff;
    }
    if((mask[0]+mask[1]+mask[2]+mask[3])==0){ /* default netmask 255.255.255.0 */
        mask[0]=0xff;
        mask[1]=0xff;
        mask[2]=0xff;
    }

    snprintf(cmd, 254, set_IPAddr_CLI_fat, *addr, *(addr+1), *(addr+2), *(addr+3), mask[0], mask[1], mask[2], mask[3]);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4Netmask(uint8_t *netmask)
{
    char cmd[255]="\0";
    uint8_t addr[4]="\0";
    int err=0;

    err=is_IPv4Netmask(netmask);
    if(err <= 0){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }
    err=get_IPv4Address(&addr[0]);
    if(err)
        return err;

    snprintf(cmd, 254, set_IPAddr_CLI_fat, addr[0], addr[1], addr[2], addr[3], *netmask, *(netmask+1), *(netmask+2), *(netmask+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4GW(uint8_t *gw)
{
    char cmd[255]="\0";
    int err=0;

    err=is_IPv4Address(gw);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }

    snprintf(cmd, 254, set_IP_GW_CLI_fat, *gw, *(gw+1), *(gw+2), *(gw+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4DNS1(uint8_t *dns1)
{
    char cmd[255]="\0";
    int err=0;

    err=is_IPv4Address(dns1);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }

    snprintf(cmd, 254, set_IP_DNS_CLI_fat, *dns1, *(dns1+1), *(dns1+2), *(dns1+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4DNS2(uint8_t *dns2)
{
    return -1;
}

int set_IPv4NTP(uint8_t *ntp)
{
    char cmd[255]="\0";
    int err=0;

    err=is_IPv4Address(ntp);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }

    snprintf(cmd, 254, set_NTP_CLI1, *ntp, *(ntp+1), *(ntp+2), *(ntp+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_SNMPGetComm(char *ro)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(ro)==0) return -1;
    snprintf(cmd, 254, set_SNMP_RO_Comm_CLI, ro);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_SNMPSetComm(char *rw)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(rw)==0) return -1;
    snprintf(cmd, 254, set_SNMP_RW_Comm_CLI, rw);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_SNMPTrapComm(char *trap)
{
    char cmd[255]="\0";
    uint8_t host[4]="\0";
    int err=0;

    if(strlen(trap)==0) return -1;
    err=get_IPv4SNMPTrapSrv(host);
    if(err) return err;
    snprintf(cmd, 254, set_SNMP_Trap_Comm_CLI, host[0], host[1], host[2], host[3], trap);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4SNMPTrapSrv(uint8_t *addr)
{
    char cmd[255]="\0";
    int err=0;

    err=is_IPv4Address(addr);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }

    snprintf(cmd, 254, set_SNMP_Trap_Srv_Comm_CLI, *addr, *(addr+1), *(addr+2), *(addr+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4SyslogSrv1(uint8_t *srv1)
{
    char cmd[255]="\0";
    int err=0;

    err=is_IPv4Address(srv1);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }

    snprintf(cmd, 254, set_SysLog_CLI1, 1, *srv1, *(srv1+1), *(srv1+2), *(srv1+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4SyslogSrv2(uint8_t *srv2)
{
    char cmd[255]="\0";
    int err=0;

    err=is_IPv4Address(srv2);
    if(err != 1){
        printf("WTP: %s wrong format: err = %d\n", __FUNCTION__, -1);
        return -1;
    }

    snprintf(cmd, 254, set_SysLog_CLI1, 2, *srv2, *(srv2+1), *(srv2+2), *(srv2+3));
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4NTP_DN(char *ntp)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(ntp)==0) return -1;
    snprintf(cmd, 254, set_NTP_CLI2, ntp);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_IPv4SyslogSrv1_DN(char *srv1)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(srv1)==0) return -1;
    snprintf(cmd, 254, set_SysLog_CLI2, 1, srv1);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}
int set_IPv4SyslogSrv2_DN(char *srv2)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(srv2)==0) return -1;
    snprintf(cmd, 254, set_SysLog_CLI2, 2, srv2);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_systemName(char *name)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(name)==0) return -1;
    snprintf(cmd, 254, set_hostname_CLI, name);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_location(char *location)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(location)==0) return -1;
    snprintf(cmd, 254, set_location_CLI, location);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;

}

int set_password(char *password)
{
    char cmd[255]="\0";
    int err=0;

    if(strlen(password)==0) return -1;
    snprintf(cmd, 254, set_password_CLI, password);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_DHCPRenew(void)
{
    char cmd[255]="\0";
    int err=0;

    snprintf(cmd, 254, "%s", renew_CLI_fat);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_deviceReboot(void)
{
    char cmd[255]="\0";
    int err=0;

    snprintf(cmd, 254, "%s", reboot_CLI);
    err=execv_zysh_script(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}

int set_locatorLEDFlash(uint16_t setting)
{
    char cmd[255]="\0";
    int err=0;

    if(setting) snprintf(cmd, 254, "echo 2 > %s", locatorLED);
    else snprintf(cmd, 254, "echo 0 > %s", locatorLED);
    err=system(&cmd[0]);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    return err;
}
#ifdef ZON_FATAP_SUPPORT_TFTP_UPGRADE
/* format: tftp://192.168.1.102/ZLD-current */
int set_tftp_fw_upgrade(char *url)
{
    const char needle[] = "tftp://";
    char host[255]="\0";
    char remote_file[255]="\0";
    char local_file[255]="\0";
    const char delim[] = ":/";
    char buf[FW_VERIFY_MSG_LEN];
    char *strp, *str_token;
    int err=0;

    /* parse result */
    /* check needle */
    str_token = strstr(url, needle);
    if(NULL == str_token)
        return -1;
    /* remove needle */
    str_token+=strlen(needle);
    strp = strtok(str_token, delim);
    /* copy result */
    if(strp) sprintf((char *)host, "%s", strp);
    else return -2;
    strp = strtok(NULL, delim);
    if(strp) sprintf((char *)remote_file, "%s", strp);
    else return -3;
    snprintf(local_file, 254, "/tmp/%s", remote_file);
    err=execv_tftp_get(remote_file, local_file, host);
    printf("WTP: %s : err = %d\n", __FUNCTION__, err);
    if(err==0) {
        err=verify_firmware(local_file, buf);
        if(err != FW_VERIFY_OK)
            return -1;
        else
            return update_firmware(local_file);
    }
    return err;
}
#endif

/* -*- mode: c; c-file-style: "openbsd" -*- */
/*
 * Copyright (c) 2008 Vincent Bernat <bernat@luffy.cx>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "lldpd.h"
#include "trace.h"
#include <arpa/inet.h>
#include <sys/time.h>

static int
client_handle_none(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	log_info("rpc", "received noop request from client");
	*type = NONE;
	return 0;
}

/* Return the global configuration */
static int
client_handle_get_configuration(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	ssize_t output_len;
	log_debug("rpc", "client requested configuration");
	output_len = lldpd_config_serialize(&cfg->g_config, output);
	if (output_len <= 0) {
		output_len = 0;
		*type = NONE;
	}
	return output_len;
}

/* Change the global configuration */
static int
client_handle_set_configuration(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	struct lldpd_config *config;

	log_debug("rpc", "client request a change in configuration");
	/* Get the proposed configuration. */
	if (lldpd_config_unserialize(input, input_len, &config) <= 0) {
		*type = NONE;
		return 0;
	}

	/* What needs to be done? Transmit delay? */
	if (config->c_tx_interval > 0) {
		log_debug("rpc", "client change transmit interval to %d",
			config->c_tx_interval);
		cfg->g_config.c_tx_interval = config->c_tx_interval;
		LOCAL_CHASSIS(cfg)->c_ttl = cfg->g_config.c_tx_interval *
			cfg->g_config.c_tx_hold;
	}
	if (config->c_receiveonly != cfg->g_config.c_receiveonly) {
		log_debug("rpc", "client change receiveonly mode to %d",
			config->c_receiveonly);
		cfg->g_config.c_receiveonly = config->c_receiveonly;
	}
	if (config->c_tx_hold > 0) {
		log_debug("rpc", "client change transmit hold to %d",
			config->c_tx_hold);
		cfg->g_config.c_tx_hold = config->c_tx_hold;
		LOCAL_CHASSIS(cfg)->c_ttl = cfg->g_config.c_tx_interval *
			cfg->g_config.c_tx_hold;
	}
	if (config->c_tx_interval < 0) {
		log_debug("rpc", "client asked for immediate retransmission");
		levent_send_now(cfg);
	}
	/* Pause/resume */
	if (config->c_paused != cfg->g_config.c_paused) {
		log_debug("rpc", "client asked to %s lldpd",
		    config->c_paused?"pause":"resume");
		cfg->g_config.c_paused = config->c_paused;
                if(!cfg->g_config.c_paused) levent_update_now(cfg);
		levent_send_now(cfg);
	}

#ifdef ENABLE_LLDPMED
	if (config->c_enable_fast_start) {
		cfg->g_config.c_enable_fast_start = (config->c_enable_fast_start == 1);
		log_debug("rpc", "client asked to %s fast start",
		    cfg->g_config.c_enable_fast_start?"enable":"disable");
	}
	if (config->c_tx_fast_interval) {
		log_debug("rpc", "change fast interval to %d", config->c_tx_fast_interval);
		cfg->g_config.c_tx_fast_interval = config->c_tx_fast_interval;
	}
#endif
	if (config->c_iface_pattern) {
		log_debug("rpc", "change interface pattern to %s", config->c_iface_pattern);
		free(cfg->g_config.c_iface_pattern);
		cfg->g_config.c_iface_pattern = strdup(config->c_iface_pattern);
		levent_update_now(cfg);
	}
	if (config->c_description) {
		log_debug("rpc", "change chassis description to %s", config->c_description);
		free(cfg->g_config.c_description);
		cfg->g_config.c_description = strdup(config->c_description);
		levent_update_now(cfg);
	}
	if (config->c_platform) {
		log_debug("rpc", "change platform description to %s", config->c_platform);
		free(cfg->g_config.c_platform);
		cfg->g_config.c_platform = strdup(config->c_platform);
		levent_update_now(cfg);
	}
	if (config->c_set_ifdescr != cfg->g_config.c_set_ifdescr) {
		log_debug("rpc", "%s setting of interface description based on discovered neighbors",
		    config->c_set_ifdescr?"enable":"disable");
		cfg->g_config.c_set_ifdescr = config->c_set_ifdescr;
		levent_update_now(cfg);
	}
	if (config->c_bond_slave_src_mac_type != 0) {
		if (config->c_bond_slave_src_mac_type >
		    LLDP_BOND_SLAVE_SRC_MAC_TYPE_UNKNOWN &&
		    config->c_bond_slave_src_mac_type <=
		    LLDP_BOND_SLAVE_SRC_MAC_TYPE_MAX) {
			log_debug("rpc", "change bond src mac type to %d",
			    config->c_bond_slave_src_mac_type);
			cfg->g_config.c_bond_slave_src_mac_type =
			    config->c_bond_slave_src_mac_type;
		} else {
			log_info("rpc", "Invalid bond slave src mac type: %d\n",
			    config->c_bond_slave_src_mac_type);
		}
	}

	lldpd_config_cleanup(config);
	free(config);

	return 0;
}

/* Return the list of interfaces.
   Input:  nothing.
   Output: list of interface names (lldpd_interface_list)
*/
static int
client_handle_get_interfaces(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	struct lldpd_interface *iff, *iff_next;
	struct lldpd_hardware *hardware;
	int output_len;

	/* Build the list of interfaces */
	struct lldpd_interface_list ifs;

	log_debug("rpc", "client request the list of interfaces");
	TAILQ_INIT(&ifs);
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries) {
		if ((iff = (struct lldpd_interface*)malloc(sizeof(
			    struct lldpd_interface))) == NULL)
			fatal("rpc", NULL);
		iff->name = hardware->h_ifname;
		TAILQ_INSERT_TAIL(&ifs, iff, next);
	}

	output_len = lldpd_interface_list_serialize(&ifs, output);
	if (output_len <= 0) {
		output_len = 0;
		*type = NONE;
	}

	/* Free the temporary list */
	for (iff = TAILQ_FIRST(&ifs);
	    iff != NULL;
	    iff = iff_next) {
		iff_next = TAILQ_NEXT(iff, next);
		TAILQ_REMOVE(&ifs, iff, next);
		free(iff);
	}

	return output_len;
}

/* Return all available information related to an interface
   Input:  name of the interface (serialized)
   Output: Information about the interface (lldpd_hardware)
*/
static int
client_handle_get_interface(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	char *name;
	struct lldpd_hardware *hardware;
	void *p;

	/* Get name of the interface */
	if (marshal_unserialize(string, input, input_len, &p) <= 0) {
		*type = NONE;
		return 0;
	}
	name = p;

	/* Search appropriate hardware */
	log_debug("rpc", "client request interface %s", name);
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries)
		if (!strcmp(hardware->h_ifname, name)) {
			int output_len = lldpd_hardware_serialize(hardware, output);
			free(name);
			if (output_len <= 0) {
				*type = NONE;
				return 0;
			}
			return output_len;
		}

	log_warnx("rpc", "no interface %s found", name);
	free(name);
	*type = NONE;
	return 0;
}

/* Set some port related settings (policy, location, power)
   Input: name of the interface, policy/location/power setting to be modified
   Output: nothing
*/
static int
client_handle_set_port(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	int ret = 0;
	struct lldpd_port_set *set = NULL;
	struct lldpd_hardware *hardware = NULL;
#ifdef ENABLE_LLDPMED
	struct lldpd_med_loc *loc = NULL;
#endif

	if (lldpd_port_set_unserialize(input, input_len, &set) <= 0) {
		*type = NONE;
		return 0;
	}
	if (!set->ifname) {
		log_warnx("rpc", "no interface provided");
		goto set_port_finished;
	}

	/* Search the appropriate hardware */
	log_debug("rpc", "client request change to port %s", set->ifname);
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries)
	    if (!strcmp(hardware->h_ifname, set->ifname)) {
		    struct lldpd_port *port = &hardware->h_lport;
		    (void)port;
#ifdef ENABLE_LLDPMED
		    if (set->med_policy && set->med_policy->type > 0) {
			    log_debug("rpc", "requested change to MED policy");
			    if (set->med_policy->type > LLDP_MED_APPTYPE_LAST) {
				    log_warnx("rpc", "invalid policy provided: %d",
					set->med_policy->type);
				    goto set_port_finished;
			    }
			    memcpy(&port->p_med_policy[set->med_policy->type - 1],
				set->med_policy, sizeof(struct lldpd_med_policy));
			    port->p_med_cap_enabled |= LLDP_MED_CAP_POLICY;
		    }
		    if (set->med_location && set->med_location->format > 0) {
			    char *newdata = NULL;
			    log_debug("rpc", "requested change to MED location");
			    if (set->med_location->format > LLDP_MED_LOCFORMAT_LAST) {
				    log_warnx("rpc", "invalid location format provided: %d",
					set->med_location->format);
				    goto set_port_finished;
			    }
			    loc = \
				&port->p_med_location[set->med_location->format - 1];
			    free(loc->data);
			    memcpy(loc, set->med_location, sizeof(struct lldpd_med_loc));
			    if (!loc->data || !(newdata = malloc(loc->data_len))) loc->data_len = 0;
			    if (newdata) memcpy(newdata, loc->data, loc->data_len);
			    loc->data = newdata;
			    port->p_med_cap_enabled |= LLDP_MED_CAP_LOCATION;
		    }
		    if (set->med_power) {
			    log_debug("rpc", "requested change to MED power");
			    memcpy(&port->p_med_power, set->med_power,
				sizeof(struct lldpd_med_power));
			    switch (set->med_power->devicetype) {
			    case LLDP_MED_POW_TYPE_PD:
				    port->p_med_cap_enabled |= LLDP_MED_CAP_MDI_PD;
				    port->p_med_cap_enabled &= ~LLDP_MED_CAP_MDI_PSE;
				    break;
			    case LLDP_MED_POW_TYPE_PSE:
				    port->p_med_cap_enabled |= LLDP_MED_CAP_MDI_PSE;
				    port->p_med_cap_enabled &= ~LLDP_MED_CAP_MDI_PD;
				    break;
			    }
		    }
#endif
#ifdef ENABLE_DOT3
		    if (set->dot3_power) {

#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
				/* Remain the same port->p_power.allocated power. */
				u_int16_t allocated_ori;
				allocated_ori = port->p_power.allocated;
#endif /*  #if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI) */

			    log_debug("rpc", "requested change to Dot3 power");
			    memcpy(&port->p_power, set->dot3_power,
				sizeof(struct lldpd_dot3_power));

#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
				/* Do initialization  */
				port->p_power.current_power = port->p_power.allocated = allocated_ori;

				/* 
				 * 802.3bt
				 *
				 * We mainly implement single signature PD.
				 * Dual signature PD is only implemented partially.
				 */
				port->p_power.four_pair_capable = 1;
				port->p_power.requested_mode_a = 0;
				port->p_power.requested_mode_b = 0;
				port->p_power.allocated_mode_a = 0;
				port->p_power.allocated_mode_b = 0;
				port->p_power.power_status = 0;
				port->p_power.signature = LLDP_DOT3_POWER_SINGLE_SIGNATURE;
				port->p_power.pairs_ext = 0;
				port->p_power.class_a = 0;
				port->p_power.class_b = 0;
				port->p_power.system_setup = 0;
				port->p_power.pse_max_power = 0;
				port->p_power.requested_goal = port->p_power.requested;
				port->p_power.pse_type = 0xff;
#endif /*  #if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI) */

		    }
#endif
		    ret = 1;
		    break;
	    }

	if (ret == 0)
		log_warn("rpc", "no interface %s found", set->ifname);

set_port_finished:
	if (!ret) *type = NONE;
	free(set->ifname);
#ifdef ENABLE_LLDPMED
	free(set->med_policy);
	if (set->med_location) free(set->med_location->data);
	free(set->med_location);
	free(set->med_power);
#endif
#ifdef ENABLE_DOT3
	free(set->dot3_power);
#endif
	return 0;
}

/* Register subscribtion to neighbor changes */
static int
client_handle_subscribe(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	log_debug("rpc", "client subscribe to changes");
	*subscribed = 1;
	return 0;
}


/* Register subscribtion to neighbor changes */
#define LLDP_CONFIGURATION_XML_PATH         "/tmp/lldp-mib-conf.xml"
#define LLDP_STATISTICS_XML_PATH            "/tmp/lldp-mib-stat.xml"
#define LLDP_LOCALSYSTEMDATA_XML_PATH       "/tmp/lldp-mib-local.xml"
#define LLDP_REMOTESYSTEMSDATA_XML_PATH     "/tmp/lldp-mib-remote.xml"

inline static int
lldpd_af_to_lldp_proto(int af)
{
	switch (af) {
	case LLDPD_AF_IPV4:
		return LLDP_MGMT_ADDR_IP4;
	case LLDPD_AF_IPV6:
		return LLDP_MGMT_ADDR_IP6;
	default:
		return LLDP_MGMT_ADDR_NONE;
	}
}

#define LLDP_STATS_REMTABLES_BASE               100
#define LLDP_STATS_REMTABLES_LASTCHANGETIME     101
#define LLDP_STATS_REMTABLES_INSERTS            102
#define LLDP_STATS_REMTABLES_DELETES            103
#define LLDP_STATS_REMTABLES_DROPS              104
#define LLDP_STATS_REMTABLES_AGEOUTS            105

static u_int64_t
get_hardware_scalars(struct lldpd *cfg, unsigned int key)
{
	struct lldpd_hardware *hardware=NULL;
	struct lldpd_port *port=NULL;
	u_int64_t llu_ret=0;

	switch (key) {
	case LLDP_STATS_REMTABLES_LASTCHANGETIME:
		TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries){
			TAILQ_FOREACH(port, &hardware->h_rports, p_entries) {
				if (SMART_HIDDEN(port)) continue;
				if (port->p_lastchange > llu_ret)
					llu_ret = port->p_lastchange;
			}
		}
		llu_ret *= 100;
		break;
	case LLDP_STATS_REMTABLES_INSERTS:
		/* We assume this is equal to valid frames received on all ports */
		TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries)
			llu_ret += hardware->h_insert_cnt;
		break;
	case LLDP_STATS_REMTABLES_AGEOUTS:
		TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries)
			llu_ret += hardware->h_ageout_cnt;
		break;
	case LLDP_STATS_REMTABLES_DELETES:
		TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries)
			llu_ret += hardware->h_delete_cnt;
		break;
	case LLDP_STATS_REMTABLES_DROPS:
		TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries)
			llu_ret += hardware->h_drop_cnt;
		break;
	default:
		log_debug("netconf", "%s: unhandled key type:0x%x", __FUNCTION__, key);
		break;
	}
	return llu_ret;
}

static char *transfer_chassis_id(u_int8_t subtype, char *id)
{
	static char buf[256]="\0";

	buf[0]='\0';
	switch(subtype){
		case LLDP_CHASSISID_SUBTYPE_IFNAME:
		case LLDP_CHASSISID_SUBTYPE_IFALIAS:
		case LLDP_CHASSISID_SUBTYPE_LOCAL:
			snprintf(buf, 255, "%s", id);
		break;
		case LLDP_CHASSISID_SUBTYPE_LLADDR:
		{
			u_int8_t *cid=(u_int8_t *)id;
			snprintf(buf, 255, "%02X-%02X-%02X-%02X-%02X-%02X", *cid, *(cid+1), *(cid+2), *(cid+3), *(cid+4), *(cid+5));
		}
		break;
		case LLDP_CHASSISID_SUBTYPE_ADDR:
		{
			char ipaddress[62]="\0";
			size_t len;
			switch (id[0]) {
				case LLDP_MGMT_ADDR_IP4: len = INET_ADDRSTRLEN + 1; break;
				case LLDP_MGMT_ADDR_IP6: len = INET6_ADDRSTRLEN + 1; break;
				default: len = 0;
			}
			if (len > 0) {
				if (inet_ntop((id[0] == LLDP_MGMT_ADDR_IP4)?
					AF_INET:AF_INET6,
					&id[1], &ipaddress[0], len) == NULL)
					break;
				snprintf(buf, 255, "%s", ipaddress);
			}
		}
		break;
		default:
		snprintf(buf, 255, "0x%x,unhandled", subtype);
	}
	return &buf[0];
}

static char *transfer_port_id(u_int8_t subtype, char *id)
{
	static char buf[256]="\0";

	buf[0]='\0';
	switch(subtype){
		case LLDP_PORTID_SUBTYPE_IFNAME:
		case LLDP_PORTID_SUBTYPE_IFALIAS:
		case LLDP_PORTID_SUBTYPE_LOCAL:
			snprintf(buf, 255, "%s", id);
		break;
		case LLDP_PORTID_SUBTYPE_LLADDR:
		{
			u_int8_t *cid=(u_int8_t *)id;
			snprintf(buf, 255, "%02X-%02X-%02X-%02X-%02X-%02X", *cid, *(cid+1), *(cid+2), *(cid+3), *(cid+4), *(cid+5));
		}
		break;
		case LLDP_PORTID_SUBTYPE_ADDR:
		{
			char ipaddress[62]="\0";
			size_t len;
			switch (id[0]) {
				case LLDP_MGMT_ADDR_IP4: len = INET_ADDRSTRLEN + 1; break;
				case LLDP_MGMT_ADDR_IP6: len = INET6_ADDRSTRLEN + 1; break;
				default: len = 0;
			}
			if (len > 0) {
				if (inet_ntop((id[0] == LLDP_MGMT_ADDR_IP4)?
					AF_INET:AF_INET6,
					&id[1], &ipaddress[0], len) == NULL)
					break;
				snprintf(buf, 255, "%s", ipaddress);
			}
		}
		break;
		default:
		snprintf(buf, 255, "0x%x,unhandled", subtype);
	}
	return &buf[0];
}

static char *transfer_ip_address(int proto, void *addr)
{
	static char ipaddress[128]="\0";
	size_t len=0;

	switch (proto) {
		case LLDP_MGMT_ADDR_IP4: len = INET_ADDRSTRLEN + 1; break;
		case LLDP_MGMT_ADDR_IP6: len = INET6_ADDRSTRLEN + 1; break;
		default: len = 0;
	}
	if (inet_ntop((proto == LLDP_MGMT_ADDR_IP4)?AF_INET:AF_INET6, addr, &ipaddress[0], len) == NULL)
		snprintf(ipaddress, 128,"unable to convert IP address");

	return &ipaddress[0];
}

static void netconf_strfprintf(FILE *stream, const char *tag, const char *value)
{
	if(stream==NULL) return;
	if(tag==NULL) return;
	fprintf(stream, "<%s>", tag);
	if(value!=NULL) fprintf(stream, "%s", value);
	else fprintf(stream, "N/A");
	fprintf(stream, "</%s>", tag);
}

static void netconf_rawstrfprintf(FILE *stream, const char *tag, const char *value)
{
	if(stream==NULL) return;
	if(tag==NULL) return;
	fprintf(stream, "<%s>", tag);
	if(value!=NULL) fprintf(stream, "<![CDATA[%s]]>", value);
	else fprintf(stream, "N/A");
	fprintf(stream, "</%s>", tag);
}

static int
client_handle_netconf(struct lldpd *cfg, enum hmsg_type *type,
    void *input, int input_len, void **output, int *subscribed)
{
	FILE *fp = NULL;
	struct timeval tv;
	u_int64_t mib_epoch=0;
	char epoch[32]="\0";
	struct lldpd_chassis *chassis = LOCAL_CHASSIS(cfg);
	struct lldpd_hardware *hardware=NULL;
	struct lldpd_port *port=NULL;
	struct lldpd_mgmt *mgmt=NULL;
	int lldpLocPortNum=0;

	gettimeofday(&tv, NULL);
	mib_epoch= (unsigned long long)(tv.tv_sec)*1000 + (unsigned long long)(tv.tv_usec/1000);
	snprintf(epoch, 32, "%llu", mib_epoch);

/*
 * lldpConfiguration
 */
	if( !(fp = fopen(LLDP_CONFIGURATION_XML_PATH, "w")) ) {
		return -1;
	}

	fprintf(fp, "<lldpConfiguration xmlns=\"urn:ietf:params:xml:ns:yang:smiv2:LLDP-MIB\">");
	fprintf(fp, "<lldpMessageTxInterval>");
	fprintf(fp, "%d", cfg->g_config.c_tx_interval);
	fprintf(fp, "</lldpMessageTxInterval>");
	fprintf(fp, "<lldpMessageTxHoldMultiplier>");
	fprintf(fp, "%d", chassis->c_ttl / cfg->g_config.c_tx_interval);
	fprintf(fp, "</lldpMessageTxHoldMultiplier>");
	netconf_strfprintf(fp, "lldpReinitDelay", "1");
	fprintf(fp, "<lldpTxDelay>");
	fprintf(fp, "%d", LLDPD_TX_MSGDELAY);
	fprintf(fp, "</lldpTxDelay>");
	netconf_strfprintf(fp, "lldpNotificationInterval", "5");
	fprintf(fp, "</lldpConfiguration>");

	fflush(fp);
	fclose(fp);
/**************************************************************************************************/
/*
 * lldpStatistics
 */
	if( !(fp = fopen(LLDP_STATISTICS_XML_PATH, "w")) ) {
		return -1;
	}

	fprintf(fp, "<lldpStatistics xmlns=\"urn:ietf:params:xml:ns:yang:smiv2:LLDP-MIB\">");
	netconf_strfprintf(fp, "epoch", epoch);
	fprintf(fp, "<lldpStatsRemTablesLastChangeTime>");
	fprintf(fp, "%llu", get_hardware_scalars(cfg, LLDP_STATS_REMTABLES_LASTCHANGETIME));
	fprintf(fp, "</lldpStatsRemTablesLastChangeTime>");
	fprintf(fp, "<lldpStatsRemTablesInserts>");
	fprintf(fp, "%llu", get_hardware_scalars(cfg, LLDP_STATS_REMTABLES_INSERTS));
	fprintf(fp, "</lldpStatsRemTablesInserts>");
	fprintf(fp, "<lldpStatsRemTablesDeletes>");
	fprintf(fp, "%llu", get_hardware_scalars(cfg, LLDP_STATS_REMTABLES_DELETES));
	fprintf(fp, "</lldpStatsRemTablesDeletes>");
	fprintf(fp, "<lldpStatsRemTablesDrops>");
	fprintf(fp, "%llu", get_hardware_scalars(cfg, LLDP_STATS_REMTABLES_DROPS));
	fprintf(fp, "</lldpStatsRemTablesDrops>");
	fprintf(fp, "<lldpStatsRemTablesAgeouts>");
	fprintf(fp, "%llu", get_hardware_scalars(cfg, LLDP_STATS_REMTABLES_AGEOUTS));
	fprintf(fp, "</lldpStatsRemTablesAgeouts>");
	lldpLocPortNum=0;
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries) {
		lldpLocPortNum++;
		fprintf(fp, "<lldpStatsTxPortEntry>");
		fprintf(fp, "<lldpStatsTxPortNum>");
		fprintf(fp, "%d", lldpLocPortNum);
		fprintf(fp, "</lldpStatsTxPortNum>");
		fprintf(fp, "<lldpStatsTxPortFramesTotal>");
		fprintf(fp, "%llu", hardware->h_tx_cnt);
		fprintf(fp, "</lldpStatsTxPortFramesTotal>");
		fprintf(fp, "</lldpStatsTxPortEntry>");
	}
	lldpLocPortNum=0;
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries) {
		lldpLocPortNum++;
		fprintf(fp, "<lldpStatsRxPortEntry>");
		fprintf(fp, "<lldpStatsRxPortNum>");
		fprintf(fp, "%d", lldpLocPortNum);
		fprintf(fp, "</lldpStatsRxPortNum>");
		fprintf(fp, "<lldpStatsRxPortFramesDiscardedTotal>");
		fprintf(fp, "%llu", hardware->h_rx_discarded_cnt);
		fprintf(fp, "</lldpStatsRxPortFramesDiscardedTotal>");
		fprintf(fp, "<lldpStatsRxPortFramesErrors>");
		fprintf(fp, "%llu", hardware->h_rx_discarded_cnt);
		fprintf(fp, "</lldpStatsRxPortFramesErrors>");
		fprintf(fp, "<lldpStatsRxPortFramesTotal>");
		fprintf(fp, "%llu", hardware->h_rx_cnt);
		fprintf(fp, "</lldpStatsRxPortFramesTotal>");
		fprintf(fp, "<lldpStatsRxPortTLVsDiscardedTotal>");
		fprintf(fp, "%llu", hardware->h_rx_unrecognized_cnt);
		fprintf(fp, "</lldpStatsRxPortTLVsDiscardedTotal>");
		fprintf(fp, "<lldpStatsRxPortTLVsUnrecognizedTotal>");
		fprintf(fp, "%llu", hardware->h_rx_unrecognized_cnt);
		fprintf(fp, "</lldpStatsRxPortTLVsUnrecognizedTotal>");
		fprintf(fp, "<lldpStatsRxPortAgeoutsTotal>");
		fprintf(fp, "%llu", hardware->h_ageout_cnt);
		fprintf(fp, "</lldpStatsRxPortAgeoutsTotal>");
		fprintf(fp, "</lldpStatsRxPortEntry>");
	}
	fprintf(fp, "</lldpStatistics>");

	fflush(fp);
	fclose(fp);
/**************************************************************************************************/
/*
 * lldpLocalSystemData
 */
	if( !(fp = fopen(LLDP_LOCALSYSTEMDATA_XML_PATH, "w")) ) {
		return -1;
	}

	fprintf(fp, "<lldpLocalSystemData xmlns=\"urn:ietf:params:xml:ns:yang:smiv2:LLDP-MIB\">");
	netconf_strfprintf(fp, "epoch", epoch);
	fprintf(fp, "<lldpLocChassisIdSubtype>");
	fprintf(fp, "%d", chassis->c_id_subtype);
	fprintf(fp, "</lldpLocChassisIdSubtype>");
	netconf_strfprintf(fp, "lldpLocChassisId", transfer_chassis_id(chassis->c_id_subtype, chassis->c_id));
	netconf_strfprintf(fp, "lldpLocSysName", chassis->c_name);
	netconf_rawstrfprintf(fp, "lldpLocSysDesc", chassis->c_descr);
	fprintf(fp, "<lldpLocSysCapSupported>");
	fprintf(fp, "%d", chassis->c_cap_available);
	fprintf(fp, "</lldpLocSysCapSupported>");
	fprintf(fp, "<lldpLocSysCapEnabled>");
	fprintf(fp, "%d", chassis->c_cap_enabled);
	fprintf(fp, "</lldpLocSysCapEnabled>");
	/* Local port */
	lldpLocPortNum=0;
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries) {
		port = &hardware->h_lport;
		lldpLocPortNum++;
		fprintf(fp, "<lldpLocPortEntry>");
		fprintf(fp, "<lldpLocPortNum>");
		fprintf(fp, "%d", lldpLocPortNum);
		fprintf(fp, "</lldpLocPortNum>");
		fprintf(fp, "<lldpLocPortIdSubtype>");
		fprintf(fp, "%d", port->p_id_subtype);
		fprintf(fp, "</lldpLocPortIdSubtype>");
		netconf_strfprintf(fp, "lldpLocPortId", transfer_port_id(port->p_id_subtype, port->p_id));
		netconf_strfprintf(fp, "lldpLocPortDesc", port->p_descr);
		fprintf(fp, "</lldpLocPortEntry>");
		/* Management addresses */
		TAILQ_FOREACH(mgmt, &chassis->c_mgmt, m_entries) {
			int proto = lldpd_af_to_lldp_proto(mgmt->m_family);
			fprintf(fp, "<lldpLocManAddrEntry>");
			fprintf(fp, "<lldpLocManAddrSubtype>");
			fprintf(fp, "%d", proto);
			fprintf(fp, "</lldpLocManAddrSubtype>");
			netconf_strfprintf(fp, "lldpLocManAddr", transfer_ip_address(proto, &mgmt->m_addr));
			fprintf(fp, "<lldpLocManAddrLen>");
			fprintf(fp, "%d", mgmt->m_addrsize);
			fprintf(fp, "</lldpLocManAddrLen>");
			fprintf(fp, "<lldpLocManAddrIfSubtype>");
			if (mgmt->m_iface == 0) {
				fprintf(fp, "%d", LLDP_MGMT_IFACE_UNKNOWN);
			}
			else{
				fprintf(fp, "%d", LLDP_MGMT_IFACE_IFINDEX);
			}
			fprintf(fp, "</lldpLocManAddrIfSubtype>");
			fprintf(fp, "<lldpLocManAddrIfId>");
			if (mgmt->m_iface == 0)
				fprintf(fp, "0");
			else
				fprintf(fp, "%d", mgmt->m_iface);
			fprintf(fp, "</lldpLocManAddrIfId>");
			fprintf(fp, "</lldpLocManAddrEntry>");
		}
	}
	fprintf(fp, "</lldpLocalSystemData>");

	fflush(fp);
	fclose(fp);
/**************************************************************************************************/
/*
 * lldpRemoteSystemsData
 */
	if( !(fp = fopen(LLDP_REMOTESYSTEMSDATA_XML_PATH, "w")) ) {
		return -1;
	}

	fprintf(fp, "<lldpRemoteSystemsData xmlns=\"urn:ietf:params:xml:ns:yang:smiv2:LLDP-MIB\">");
	netconf_strfprintf(fp, "epoch", epoch);
	lldpLocPortNum=0;
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries) {
		lldpLocPortNum++;
		TAILQ_FOREACH(port, &hardware->h_rports, p_entries) {
			struct lldpd_chassis *chassis=port->p_chassis;
			if (SMART_HIDDEN(port)) continue;
			fprintf(fp, "<lldpRemEntry>");
			fprintf(fp, "<lldpRemTimeMark>");
			mib_epoch=port->p_lastupdate;
			mib_epoch*=100;
			fprintf(fp, "%llu", mib_epoch);
			fprintf(fp, "</lldpRemTimeMark>");
			fprintf(fp, "<lldpRemLocalPortNum>");
			fprintf(fp, "%d", lldpLocPortNum);
			fprintf(fp, "</lldpRemLocalPortNum>");
			fprintf(fp, "<lldpRemIndex>");
			fprintf(fp, "%d", chassis->c_index);
			fprintf(fp, "</lldpRemIndex>");
			fprintf(fp, "<lldpRemChassisIdSubtype>");
			fprintf(fp, "%d", chassis->c_id_subtype);
			fprintf(fp, "</lldpRemChassisIdSubtype>");
			netconf_strfprintf(fp, "lldpRemChassisId", transfer_chassis_id(chassis->c_id_subtype, chassis->c_id));
			fprintf(fp, "<lldpRemPortIdSubtype>");
			fprintf(fp, "%d", port->p_id_subtype);
			fprintf(fp, "</lldpRemPortIdSubtype>");
			netconf_strfprintf(fp, "lldpRemPortId", transfer_port_id(port->p_id_subtype, port->p_id));
			netconf_strfprintf(fp, "lldpRemPortDesc", port->p_descr);
			netconf_strfprintf(fp, "lldpRemSysName", chassis->c_name);
			netconf_rawstrfprintf(fp, "lldpRemSysDesc", chassis->c_descr);
			fprintf(fp, "<lldpRemSysCapSupported>");
			fprintf(fp, "%d", chassis->c_cap_available);
			fprintf(fp, "</lldpRemSysCapSupported>");
			fprintf(fp, "<lldpRemSysCapEnabled>");
			fprintf(fp, "%d", chassis->c_cap_enabled);
			fprintf(fp, "</lldpRemSysCapEnabled>");
			fprintf(fp, "</lldpRemEntry>");
		}
	}
	lldpLocPortNum=0;
	TAILQ_FOREACH(hardware, &cfg->g_hardware, h_entries) {
		lldpLocPortNum++;
		TAILQ_FOREACH(port, &hardware->h_rports, p_entries) {
			struct lldpd_chassis *chassis=port->p_chassis;
			if (SMART_HIDDEN(port)) continue;
			TAILQ_FOREACH(mgmt, &chassis->c_mgmt, m_entries) {
				int proto = lldpd_af_to_lldp_proto(mgmt->m_family);
				fprintf(fp, "<lldpRemManAddrEntry>");
				fprintf(fp, "<lldpRemTimeMark>");
				mib_epoch=port->p_lastupdate;
				mib_epoch*=100;
				fprintf(fp, "%llu", mib_epoch);
				fprintf(fp, "</lldpRemTimeMark>");
				fprintf(fp, "<lldpRemLocalPortNum>");
				fprintf(fp, "%d", lldpLocPortNum);
				fprintf(fp, "</lldpRemLocalPortNum>");
				fprintf(fp, "<lldpRemIndex>");
				fprintf(fp, "%d", chassis->c_index);
				fprintf(fp, "</lldpRemIndex>");
				fprintf(fp, "<lldpRemManAddrSubtype>");
				fprintf(fp, "%d", proto);
				fprintf(fp, "</lldpRemManAddrSubtype>");
				netconf_strfprintf(fp, "lldpRemManAddr", transfer_ip_address(proto, &mgmt->m_addr));
				fprintf(fp, "<lldpRemManAddrIfSubtype>");
				if (mgmt->m_iface == 0) {
					fprintf(fp, "%d", LLDP_MGMT_IFACE_UNKNOWN);
				}
				else{
					fprintf(fp, "%d", LLDP_MGMT_IFACE_IFINDEX);
				}
				fprintf(fp, "</lldpRemManAddrIfSubtype>");
				fprintf(fp, "<lldpRemManAddrIfId>");
				if (mgmt->m_iface == 0)
					fprintf(fp, "0");
				else
					fprintf(fp, "%d", mgmt->m_iface);
				fprintf(fp, "</lldpRemManAddrIfId>");
				fprintf(fp, "</lldpRemManAddrEntry>");
			}
		}
	}
	fprintf(fp, "</lldpRemoteSystemsData>");

	fflush(fp);
	fclose(fp);
/**************************************************************************************************/

	*type = NETCONF;
	return 0;
}

struct client_handle {
	enum hmsg_type type;
	const char *name;
	int (*handle)(struct lldpd*, enum hmsg_type *,
	    void *, int, void **, int *);
};

static struct client_handle client_handles[] = {
	{ NONE,			"None",              client_handle_none },
	{ GET_CONFIG,		"Get configuration", client_handle_get_configuration },
	{ SET_CONFIG,		"Set configuration", client_handle_set_configuration },
	{ GET_INTERFACES,	"Get interfaces",    client_handle_get_interfaces },
	{ GET_INTERFACE,	"Get interface",     client_handle_get_interface },
	{ SET_PORT,		"Set port",          client_handle_set_port },
	{ SUBSCRIBE,		"Subscribe",         client_handle_subscribe },
	{ NETCONF,		"NETCONF",         client_handle_netconf },
	{ 0,			NULL } };

int
client_handle_client(struct lldpd *cfg,
    ssize_t(*send)(void *, int, void *, size_t),
    void *out,
    enum hmsg_type type, void *buffer, size_t n,
    int *subscribed)
{
	struct client_handle *ch;
	void *answer; size_t len, sent;

	log_debug("rpc", "handle client request");
	for (ch = client_handles; ch->handle != NULL; ch++) {
		if (ch->type == type) {
			TRACE(LLDPD_CLIENT_REQUEST(ch->name));
			answer = NULL;
			len  = ch->handle(cfg, &type, buffer, n, &answer,
			    subscribed);
			sent = send(out, type, answer, len);
			free(answer);
			return sent;
		}
	}

	log_warnx("rpc", "unknown message request (%d) received",
	    type);
	return -1;
}


struct iaaddr_leasefile {
	struct iaaddr_leasefile *next;
	struct dhcp6_statefuladdr saddr;
	time_t starts;
};

struct iana_leasefile {
	struct iana_leasefile *next;
	struct dhcp6_ia ia;
	time_t starts;
	struct iaaddr_leasefile *iaaddr;
};

struct dhcp6_leasefile {
	struct dhcp6_leasefile *next;
	struct dhcp6_if *ifp;
	struct duid cid;
	struct duid sid;
	struct iana_leasefile *iana;
};

#define IAADDR_LEASEFILE_SIZE 	(sizeof(struct iaaddr_leasefile))
#define IANA_LEASEFILE_SIZE 	(sizeof(struct iana_leasefile))
#define LEASEFILE_SIZE 		(sizeof(struct dhcp6_leasefile))

#define KEY_INTERFACE "interface"
#define KEY_CLIENTID "cid"
#define KEY_SERVERID "sid"
#define KEY_IANA "iana"
#define KEY_IAADDR "iaaddr"

#define SIZE_INTERFACE strlen(KEY_INTERFACE)
#define SIZE_CLIENTID strlen(KEY_CLIENTID)
#define SIZE_SERVERID strlen(KEY_SERVERID)
#define SIZE_IANA strlen(KEY_IANA)
#define SIZE_IAADDR strlen(KEY_IAADDR)

void remove_leasefile(void);
int restore_ia_from_leasefile(struct dhcp6_if *ifp, struct dhcp6_leasefile *lease);
struct dhcp6_leasefile 
	*find_if_in_leasefile(struct dhcp6_if *ifp, struct dhcp6_leasefile *lease_root);
void free_leasefile(struct dhcp6_leasefile *);
struct dhcp6_leasefile *parse_client_leasefile(void);
void print_leasefile(struct dhcp6_leasefile *lease);
int construct_client_leasefile(struct dhcp6_if *ifp, struct duid *serverid, 
			struct ia_conf *iac, struct ia *ia, struct dhcp6_listval *siav);

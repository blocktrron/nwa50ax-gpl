int get_tentative_addr(struct in6_addr *iana);
char* link_detect_main(int fd);
int link_detect_init();


#include <sys/types.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/queue.h>
#include <errno.h>
#include <limits.h>
#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif
#include <net/if.h>
#ifdef __FreeBSD__
#include <net/if_var.h>
#endif

#include <netinet/in.h>
#ifdef __KAME__
#include <net/if_dl.h>
#include <netinet6/in6_var.h>
#endif

#include <arpa/inet.h>
#include <netdb.h>

#include <signal.h>
#include <stdio.h>
#include <stdarg.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <ifaddrs.h>

#include <dhcp6.h>
#include <config.h>
#include <common.h>
#include <timer.h>
#include <dhcp6c.h>
#include <control.h>
#include <dhcp6_ctl.h>
#include <dhcp6c_ia.h>
#include <prefixconf.h>
#include <auth.h>
#include "leasefile.h"
#include <addrconf.h>

#ifdef CLIENT_CONFIRM_SUPPORT

static void free_all_iaaddr(struct iaaddr_leasefile *iaaddr_root);
static void free_all_iana(struct iana_leasefile *iana_root);


#define xtod(c) ((c>='0' && c<='9') ? c-'0' : ((c>='A' && c<='F') ? \
			c-'A'+10 : ((c>='a' && c<='f') ? c-'a'+10 : 0)))

#define INSERT_TAIL(type, root, obj) 				\
{								\
	type *tmp;						\
	if (*root == NULL) {					\
		*root = obj;					\
	}							\
	else {							\
		for (tmp = *root; tmp->next; tmp = tmp->next);	\
		tmp->next = obj;				\
	}							\
}

void
remove_leasefile()
{
	char buf[30];
	
	sprintf(buf, "rm %s", DHCP6C_LEASEFILE);
	system(buf);
	return;
}

int
restore_ia_from_leasefile(struct dhcp6_if *ifp, struct dhcp6_leasefile *lease)
{
	struct iana_leasefile *iana_lf;
	struct iaaddr_leasefile *iaaddr_lf;
	struct ia_conf *iac;
	struct ia *ia;
	struct statefuladdr *sa;
	int ia_count, sa_count;

	if (!lease || !lease->iana)
		return;

	iana_lf = lease->iana;
	ia_count = 0;
	while (iana_lf) {
		iac = find_iaconf(&ifp->iaconf_list, IATYPE_NA, iana_lf->ia.iaid);
		if (!iac) {
			dhcp6_dprintf(LOG_ERR, FNAME, "no iac found for iaid %x", iana_lf->ia.iaid);
			iana_lf = iana_lf->next;
			continue;
		}

		iaaddr_lf = iana_lf->iaaddr;
		if (iaaddr_lf) {
			ia = create_ia(IATYPE_NA, ifp, iac, iana_lf->ia.iaid,
					iana_lf->ia.t1, iana_lf->ia.t2,
					lease->sid.duid_id, lease->sid.duid_len);
			if (ia) {
				sa_count = 0;
				while (iaaddr_lf) {
					sa = create_sa(ia->ctl, iana_lf, iaaddr_lf);
					if (sa) {
						sa_count++;
					}
					else {
						dhcp6_dprintf(LOG_NOTICE, FNAME, "Can't create sa");
					}
					iaaddr_lf = iaaddr_lf->next;
				}
				if (sa_count == 0) {
					remove_ia(ia, 0);
				}
				else {
					ia_count++;
				}
			}
			else {
				dhcp6_dprintf(LOG_ERR, FNAME, "Can't create ia");
			}
		}
		else {
			dhcp6_dprintf(LOG_NOTICE, FNAME, "no iaaddr in ia! ignore it");
		}
		iana_lf = iana_lf->next;
	}
	return (ia_count);
}

struct dhcp6_leasefile*
find_if_in_leasefile(struct dhcp6_if *ifp, struct dhcp6_leasefile *lease_root)
{
	struct dhcp6_leasefile *lease = lease_root;
	while (lease) {
		if (lease->ifp == ifp) {
			return lease; 
		}
		lease = lease->next;
	}
	return (NULL);
}

static void free_all_iaaddr(struct iaaddr_leasefile *iaaddr_root)
{
	struct iaaddr_leasefile *iaaddr_lf, *iaaddr_next;

	iaaddr_lf = iaaddr_root;
	while (iaaddr_lf) {
		iaaddr_next = iaaddr_lf->next;
		free(iaaddr_lf);
		iaaddr_lf = iaaddr_next;
	}
	return;
}

static void free_all_iana(struct iana_leasefile *iana_root)
{
	struct iana_leasefile *iana_lf, *iana_next2;

	iana_lf = iana_root;
	while (iana_lf) {
		iana_next2 = iana_lf->next;
		free_all_iaaddr(iana_lf->iaaddr);
		free(iana_lf);
		iana_lf = iana_next2;
	}
	return;
}

void 
free_leasefile(struct dhcp6_leasefile *lease)
{
	struct iana_leasefile *iana_lf, *iana_next2;
	struct dhcp6_leasefile *lease_next;

	while (lease) {
		lease_next = lease->next;
		free_all_iana(lease->iana);
		if (lease->cid.duid_id) {
			free(lease->cid.duid_id);
		}
		if (lease->sid.duid_id) {
			free(lease->sid.duid_id);
		}
		free(lease);
		lease = lease_next;
	}
	return;
}

struct dhcp6_leasefile *
parse_client_leasefile(void)
{
	struct dhcp6_leasefile *lease, *lease_root;
	struct iana_leasefile *iana_lf;
	struct iaaddr_leasefile *iaaddr_lf;
	struct dhcp6_ia *ia;
	struct dhcp6_statefuladdr *saddr;
	FILE *fp;
	int ret, i;
	struct duid *duid;
	char buf[50], ifname[16];
	unsigned char c1, c2;

#define CHECK_LEASE	if (!lease) goto error;
#define CHECK_IANA	if (!iana_lf) goto error;
#define ERROR(r)	ret = r; goto error;

	if ((fp = fopen(DHCP6C_LEASEFILE, "r")) == NULL) {
		dhcp6_dprintf(LOG_NOTICE, FNAME, "Can't open %s for reading", DHCP6C_LEASEFILE);
		return (NULL);
	}
	lease_root = NULL;
	lease = NULL;
	while(1) {
		if ((ret = fscanf(fp, "%s", buf)) == EOF) {
			break;
		}
		if (strcmp(KEY_INTERFACE, buf) == 0) {
			if ((lease = calloc(LEASEFILE_SIZE, 1)) == NULL) {
				ERROR(-1);
			}
			if ((ret = fscanf(fp, "%s", ifname)) == EOF) {
				ERROR(-2);
			}
			if ((lease->ifp = find_ifconfbyname(ifname)) == NULL) {
				ERROR(-3);
			}
			INSERT_TAIL(struct dhcp6_leasefile, &lease_root, lease);
			iana_lf = NULL;
			iaaddr_lf = NULL;
		}
		else if (strcmp(KEY_CLIENTID, buf) == 0) {
			CHECK_LEASE;

			duid = &lease->cid;
			if ((ret = fscanf(fp, "%x", &duid->duid_len)) == EOF) {
				ERROR(-4);
			}
			if (duid->duid_id ||
				((duid->duid_id = malloc(duid->duid_len)) == NULL)) {
				ERROR(-5);
			}
			fgetc(fp);
			for (i=0; i<duid->duid_len; i++) {
				c1 = fgetc(fp);
				c2 = fgetc(fp);
				duid->duid_id[i] = (xtod(c1))*16 + xtod(c2);
			}
		}
		else if (strcmp(KEY_SERVERID, buf) == 0) {
			CHECK_LEASE;

			duid = &lease->sid;
			if ((ret = fscanf(fp, "%x", &duid->duid_len)) == EOF) {
				ERROR(-6);
			}
			if (duid->duid_id ||
				((duid->duid_id = malloc(duid->duid_len)) == NULL)) {
				ERROR(-7);
			}
			fgetc(fp);
			for (i=0; i<duid->duid_len; i++) {
				c1 = fgetc(fp);
				c2 = fgetc(fp);
				duid->duid_id[i] = (xtod(c1))*16 + xtod(c2);
			}
		}
		else if (strcmp(KEY_IANA, buf) == 0) {
			CHECK_LEASE;

			if ((iana_lf = calloc(IANA_LEASEFILE_SIZE, 1)) == NULL) {
				ERROR(-8);
			}
			ia = &iana_lf->ia;
			if ((ret = fscanf(fp, "%x %d %d %d", 
				&ia->iaid, &ia->t1, &ia->t2, &iana_lf->starts)) == EOF) {
				ERROR(-9);
			}
			INSERT_TAIL(struct iana_leasefile, &lease->iana, iana_lf);
		}
		else if (strcmp(KEY_IAADDR, buf) == 0) {
			CHECK_LEASE;
			CHECK_IANA;

			if ((iaaddr_lf = calloc(IAADDR_LEASEFILE_SIZE, 1)) == NULL) {
				ERROR(-10);
			}
			saddr = &iaaddr_lf->saddr;
			fgetc(fp);
			for (i=0; i<16; i++) {
				c1 = fgetc(fp);
				c2 = fgetc(fp);
				saddr->addr.s6_addr[i] = (xtod(c1))*16 + xtod(c2);
			}
			if ((ret = fscanf(fp, "%d %d %d", &saddr->pltime, &saddr->vltime, 
						&iaaddr_lf->starts)) == EOF) 
			{
				ERROR(-11);
			}
			INSERT_TAIL(struct iaaddr_leasefile, &iana_lf->iaaddr, iaaddr_lf);
		}
		else {
			ERROR(-12);
		}
	}	

	fclose(fp);
	remove_leasefile();
	return (lease_root);

error:
	if (fp) {
		fclose(fp);
	}
	free_leasefile(lease_root);
	dhcp6_dprintf(LOG_NOTICE, FNAME, "error %d", ret);
	return (NULL);
}

void print_leasefile(struct dhcp6_leasefile *lease)
{
	struct iana_leasefile *iana_lf;
	struct iaaddr_leasefile *iaaddr_lf;
	struct dhcp6_ia *ia;
	struct dhcp6_statefuladdr *saddr;
	struct duid *duid;
	int i;

	while(lease) {
		printf("lease->ifp->ifname=%s\n", lease->ifp->ifname);
		duid = &lease->cid;
		printf("cid len=%x, ", duid->duid_len);
		for (i=0; i<duid->duid_len; i++) {
			printf("%02x", (unsigned char)duid->duid_id[i]);
		}
		printf("\n");

		duid = &lease->sid;
		printf("sid len=%x, ", duid->duid_len);
		for (i=0; i<duid->duid_len; i++) {
			printf("%02x", (unsigned char)duid->duid_id[i]);
		}
		printf("\n");

		iana_lf = lease->iana;
		while (iana_lf) {
			ia = &iana_lf->ia;
			printf("iana iaid=%x, t1=%d, t2=%d, starts=%d\n", 
					ia->iaid, ia->t1, ia->t2, iana_lf->starts);

			iaaddr_lf = iana_lf->iaaddr;
			while (iaaddr_lf) {
				saddr = &iaaddr_lf->saddr;
				printf("iaaddr ");
				for (i=0; i<16; i++) {
					printf("%02x", (unsigned char)saddr->addr.s6_addr[i]);
				}
				printf(", pltime=%d, vltime=%d, starts=%d\n", 
						saddr->pltime, saddr->vltime, iaaddr_lf->starts);
				iaaddr_lf = iaaddr_lf->next;
			}
			iana_lf = iana_lf->next;
		}

		fflush(stdout);
		lease = lease->next;
	}
	return;
}

int construct_client_leasefile(ifp, serverid, iac, ia, siav)
	struct dhcp6_if *ifp;
	struct duid *serverid;
	struct ia_conf *iac;
	struct ia *ia;
	struct dhcp6_listval *siav;
{
#define DHCP6C_LEASEFILE_TMP	"/var/db/dhcp6c.leases.tmp"
#define BUFSIZE	100

	FILE *fp, *fp_read;
	struct dhcp6_statefuladdr *saddr;
	int i, need_search_iana = 0, need_search_iaaddr = 0;
	struct duid *clientid;
	u_int32_t iaid;
	char buf[BUFSIZE], *cp;
	struct in6_addr addr;

	if ((fp_read = fopen(DHCP6C_LEASEFILE, "r")) == NULL) {
		/* no lease file. write to lease file directly */
		if ((fp = fopen(DHCP6C_LEASEFILE, "w")) == NULL) {
			return (-1);
		}

		/* interface name */
		fprintf(fp, "interface %s\n", ifp->ifname);

		/* client id */
		clientid = get_cid();
		fprintf(fp, "cid %x ", clientid->duid_len);
		for (i = 0; i < clientid->duid_len; i++) {
			fprintf(fp, "%02x", (unsigned char)clientid->duid_id[i]);
		}
		fprintf(fp, "\n");

		/* server id */
		fprintf(fp, "sid %x ", serverid->duid_len);
		for (i = 0; i < serverid->duid_len; i++) {
			fprintf(fp, "%02x", (unsigned char)serverid->duid_id[i]);
		}
		fprintf(fp, "\n");

		/* ia */
		fprintf(fp, "iana %x %d %d %d\n", iac->iaid, ia->t1, ia->t2, time(NULL));

		/* iaaddr */
		fprintf(fp, "iaaddr ");
		saddr = &siav->val_statefuladdr6;
		for (i=0; i<16; i++) {
			fprintf(fp, "%02x", (unsigned char)saddr->addr.s6_addr[i]);
		}
		fprintf(fp, " %d %d %d\n", saddr->pltime, saddr->vltime, time(NULL));
		
		fclose(fp);
		return (0);
	}

	/* lease file exist. open lease file and write to tmp lease file */
	if ((fp = fopen(DHCP6C_LEASEFILE_TMP, "w")) == NULL) {
		fclose(fp_read);
		return (-1);
	}

	saddr = &siav->val_statefuladdr6;
	while (fgets(buf, BUFSIZE-1, fp_read) != NULL) {
		if ((need_search_iaaddr) && (strncmp(buf, KEY_IAADDR, SIZE_IAADDR) == 0)) {
			cp = &buf[SIZE_IAADDR+1];
			for (i=0; i<16; i++) {
				addr.s6_addr[i] = (xtod(*cp))*16 + xtod(*(cp+1));
				cp+=2;
			}
			if (!IN6_ARE_ADDR_EQUAL(&addr, &saddr->addr)) {
				fputs(buf, fp);
			}
		}
		else if ((need_search_iana) && (strncmp(buf, KEY_IANA, SIZE_IANA) == 0)) {
			need_search_iaaddr = 0;
			cp = &buf[SIZE_IANA+1];
			if (sscanf(cp, "%x", &iaid) == EOF) {
				fclose(fp_read);
				fclose(fp);
				return (-1);
			}
			if (iac->iaid == iaid) {
				/* match iana. search iaaddr */
				need_search_iaaddr = 1;

				/* write iana information with new starts */
				fprintf(fp, "iana %x %d %d %d\n", 
						iac->iaid, ia->t1, ia->t2, time(NULL));

				/* write iaaddr information directly */
				fprintf(fp, "iaaddr ");
				for (i=0; i<16; i++) {
					fprintf(fp, "%02x", 
						(unsigned char)saddr->addr.s6_addr[i]);
				}
				fprintf(fp, " %d %d %d\n", 
						saddr->pltime, saddr->vltime, time(NULL));
			}
			else {
				fputs(buf, fp);
			}
		}
		else if (strncmp(buf, KEY_INTERFACE, SIZE_INTERFACE) == 0) {
			need_search_iana = need_search_iaaddr = 0;
			cp = &buf[SIZE_INTERFACE+1];
			if (strncmp(cp, ifp->ifname, strlen(ifp->ifname)) == 0) {
				/* match interface. search iana */
				need_search_iana = 1;
			}
			fputs(buf, fp);
		}
		else {
			fputs(buf, fp);
		}
	}
		
	fclose(fp);
	fclose(fp_read);

	/* move DHCP6C_LEASEFILE_TMP to DHCP6C_LEASEFILE */
	sprintf(buf, "mv %s %s", DHCP6C_LEASEFILE_TMP, DHCP6C_LEASEFILE);
	system(buf);	
	
	return (0);
}

#endif


#!/bin/sh

scp dhcp6s root@192.168.105.105:/tmp

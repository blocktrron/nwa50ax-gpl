#!/bin/sh
dir=`dirname $1`

if [ $dir = "/etc/zyxel/ftp" ] 
then
	/util/zld_pa
elif [ $dir = "/etc/zyxel/ftp/tmp" ] 
then
	/util/tmp_pa
elif [ $dir = "/etc/zyxel/ftp/conf" ] 
then
	/util/conf_pa
elif [ $dir = "/etc/zyxel/ftp/script" ] 
then
	/util/script_pa
else
	echo "invalid folder name!"
fi


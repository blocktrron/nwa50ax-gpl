#!/bin/sh
PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:$PATH

FLASH_PATH=/etc/zyxel/ftp/nc_conn_dbg
RAM_PATH=/tmp/nc_conn_dbg
RAM_LOG_FILE="${RAM_PATH}"/nc_dbg_$1.log
TMP_LOG_FILE="${RAM_PATH}"/nc_dbg_$1.tmp
LOG_FILE="${FLASH_PATH}"/nc_dbg_$1.log
TMP_BUF=/tmp/nc_dbg_$1.tmp

# 100 KB
LOG_MAX=102400

if [ $# -lt 1 ]; then
	echo "$(date) Invalid args for $0 to operate."
	exit -1;
fi

if [ -f ${RAM_LOG_FILE} ]; then

	if [ ! -d ${FLASH_PATH} ]; then
		mkdir ${FLASH_PATH}
	fi

	cp -f ${RAM_LOG_FILE} ${TMP_LOG_FILE}
	cat ${TMP_LOG_FILE} >> ${LOG_FILE}

	echo ">>> $(date) System reboot! <<<"  >> ${LOG_FILE}

#Check size
	FILE_SIZE=`ls -al ${LOG_FILE} | awk '{print $5}'`

	if [ ${FILE_SIZE} -ge ${LOG_MAX} ]; then
		echo ">>> $(date) File size of $1 log hit the limit. <<<"  > ${TMP_BUF}
		cat ${LOG_FILE}|tail -n 600 >> ${TMP_BUF}
		rm -f ${LOG_FILE} 2>&1 > /dev/null
		mv -f ${TMP_BUF} ${LOG_FILE}
	fi
fi

exit 0

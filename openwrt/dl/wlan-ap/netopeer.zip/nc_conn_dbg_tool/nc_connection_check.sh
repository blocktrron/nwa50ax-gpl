#!/bin/sh
PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:$PATH

#Connection target
TARGET=d.nebula.zyxel.com

#Check tool
PING_BIN=/usr/bin/paping
TRACEROUTE_BIN=/usr/bin/traceroute
#Check log
LOG_PATH=/tmp/nc_conn_dbg
LOG_FILE="${LOG_PATH}"/nc_dbg_$1.log
PID_FILE=/var/run/nc_$1_check.pid
SUB_PID_FILE=/var/run/nc_sub_$1_check.pid
TMP_BUF=/tmp/nc_dbg_$1.tmp

# 100 KB
LOG_MAX=102400

if [ $# -lt 1 ]; then
	echo "$(date) Invalid args for $0 to operate."
	exit -1;
fi

if [ $1 != traceroute ] && [ $1 != tcpping ]; then
	echo "unexpected $1 catched!"
	exit -1
fi

if [ -f ${PID_FILE} ]; then
	PID=`cat ${PID_FILE}`
	PID_EXIST=`kill -0 ${PID} 2>&1`
	if [ -z "${PID_EXIST}" ]; then
		#Script already operating.
		exit 0
	fi
fi

echo $$ > ${PID_FILE}

if [ $1 == tcpping ]; then
	sleep 600 & JOB_PID=$!
	echo $JOB_PID > ${SUB_PID_FILE}
	wait $!
	JOB_RET=$?
	if [ $JOB_RET != 0 ]; then
		exit 0
	fi
fi

if [ -f ${LOG_FILE} ]; then
	FILE_SIZE=`ls -al ${LOG_FILE} | awk '{print $5}'`

	if [ ${FILE_SIZE} -ge ${LOG_MAX} ]; then
		echo ">>> $(date) File size of $1 log hit the limit. <<<"  > ${TMP_BUF}
		cat ${LOG_FILE}|tail -n 500 >> ${TMP_BUF}
		rm -f ${LOG_FILE} 2>&1 > /dev/null
		mv -f ${TMP_BUF} ${LOG_FILE}
	fi
else
	if [ ! -d ${LOG_PATH} ]; then
		mkdir ${LOG_PATH}
	fi
fi

while true
do
	date >> ${LOG_FILE} 2>&1

if [ $1 == traceroute ]; then
	${TRACEROUTE_BIN} ${TARGET} -I -m 64 -q 3 -w 3 >> ${LOG_FILE} 2>&1 & JOB_PID=$!
	echo $JOB_PID > ${SUB_PID_FILE}
	wait $!
	JOB_RET=$?
	if [ $JOB_RET != 0 ]; then
		exit 0
	fi
elif [ $1 == tcpping ]; then
	if [ $2 != 0 ]; then
		${PING_BIN} ${TARGET} -p $2 -c 1 -t 189000 --nocolor >> ${LOG_FILE} 2>&1 & JOB_PID=$!
		echo $JOB_PID > ${SUB_PID_FILE}
		wait $!
		JOB_RET=$?
		if [ $JOB_RET != 0 ]; then
			exit 0
		fi
	else
		${PING_BIN} ${TARGET} -p 4335 -c 1 -t 189000 --nocolor >> ${LOG_FILE} 2>&1
		${PING_BIN} ${TARGET} -p 6667 -c 1 -t 189000 --nocolor >> ${LOG_FILE} 2>&1
	fi
fi
	FILE_SIZE=`ls -al ${LOG_FILE} | awk '{print $5}'`

	if [ ${FILE_SIZE} -ge ${LOG_MAX} ]; then
		echo ">>> $(date) File size of $1 log hit the limit. <<<"  > ${TMP_BUF}
		cat ${LOG_FILE}|tail -n 500 >> ${TMP_BUF}
		rm -f ${LOG_FILE} 2>&1 > /dev/null
		mv -f ${TMP_BUF} ${LOG_FILE}
	fi

	sleep 180 & JOB_PID=$!
	echo $JOB_PID > ${SUB_PID_FILE}
	wait $!
	JOB_RET=$?
	if [ $JOB_RET != 0 ]; then
		exit 0
	fi
done

rm -f ${PID_FILE} 2>&1 > /dev/null
exit 0

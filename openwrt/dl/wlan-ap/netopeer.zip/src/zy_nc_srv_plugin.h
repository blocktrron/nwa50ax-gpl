/****************************************************************************/
/*
* Copyright (C) 2017-2023 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/
#ifndef NC_SRV_PLUGIN_H
#define NC_SRV_PLUGIN_H

#include "capwap_cli/parser_module.h"
#include "nc_wd.h"

#define CMD_LEN 64
#define MSG_LEN 64
#define DNS_LIST_LEN 128
#define BUF_LEN 256
#define DB_STR_LEN 256
#define ZYSH_IF_UPLINK "lan"
#define NEBULA_TABLE_NAME "Nebula"
#define STATUS_KEY_NAME "nebula-status"
#define NEBULA_CALLHOME "nebula-callhome"
#define PROXY_KEY_NAME "proxy-conf"
#define KEEP_ALIVE "keep-alive"
#define PARSER_ROLE 0x20170306
#define PING_CMD "ping nebula.zyxel.com -c 1 -i 3"
#define ARPPING_BIN "/usr/sbin/arping"
#define NC_IF_UPLINK "br0"

#define CC_PING_PID_FILE "/var/run/nc_tcpping_check.pid"
#define SUB_CC_PING_PID_FILE "/var/run/nc_sub_tcpping_check.pid"
#define TRACERT_PID_FILE "/var/run/nc_traceroute_check.pid"
#define SUB_TRACERT_PID_FILE "/var/run/nc_sub_traceroute_check.pid"
#define NC_DBG_CONN_LOG_PATH "/tmp/nc_conn_dbg/"
#define NC_DBG_CONN_LOG "/tmp/nc_conn_dbg/nc_dbg_connection.log"
#define NC_DBG_CONN_BUF "/tmp/nc_conn_dbg/nc_dbg_connection.tmp"
#define CURL_DEBUG_FILE "/tmp/curl_debug_file"
#define DBG_FILE_SIZE (100*1024) /* 100K */
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
#define NEBULA_MANAGED_TO_CLOUD_FLAG (ZLDSYSPARM_ETC_WRITABLE_ZYXEL_CFG_DIR"/nebula-managed-to-cloud")
#endif
#define CLOUD_CERT_EXP_DBG "/etc/zyxel/ftp/tmp/cloud_cert_expired.log"

/* Netconf daemon offline reason code. */
enum{
	CERT_FAILED = 0,
	GATEWAY_UNAVAILABLE,
	DNS_FAILED,
	PROXY_AUTH_FAILED,
	PORT_BLOCKED,
	REASON_CODE_MAX
};
/* End of Netconf daemon offline reason code. */

enum{
	SUCCESS = 0,
	CONNECT_FAIL,
	DISCONNECT,
	DEBUG_SCENE_MAX
};

int32_t nc_get_ip_status(void);
int32_t get_from_db(char *table, char *key, char *field, char *msg);
int32_t set_to_db(char *table, char *key, char *field, char *value, char *msg);
void renew_if_dhcp(const char *interface);
int32_t check_internet_status(void);
int MyPower(int x, int n);
void CURL_DebugInfo_to_file(void);
int32_t netconf_kit_wlan_get_hybridmode(void);
int32_t zylog_agent_in_netconf(char* msg, uint32_t* reason_code);
int32_t netconf_connection_log( char *msg );
int32_t query_hostname_by_default_dns(char *hostname, char *ip);
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
int32_t managed_to_cloud_flag(void);
#endif
int32_t nc_debug_procedure(int32_t debug_scene, uint32_t *reason_code, uint32_t cur_port);
int cert_valid_check(char *exp_date_str);
void exit_if_cloud_cert_expired(void);
#endif

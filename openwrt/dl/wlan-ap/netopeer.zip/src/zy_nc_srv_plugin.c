/****************************************************************************/
/*
* Copyright (C) 2017-2023 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/

#include <libnetconf/netconf.h>
#include "zykit.h"
#include "zylog.h"
#include "zy_nc_srv_plugin.h"
#include "zld-spec.h"
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <errno.h>
#define STATUS_KEY_NAME "nebula-status"

struct {
	int32_t index;
	char *reason;
	int32_t utl;
}

reason_table[] = {
	{  CERT_FAILED, "Certificate problem", 1  },
	{  GATEWAY_UNAVAILABLE, "Gateway unreachable", 1  },
	{  DNS_FAILED, "DNS queries failed", 0  },
	{  PROXY_AUTH_FAILED, "Proxy authentication failed", 1  },
	{  PORT_BLOCKED, "TCP port 4335 blocked", 0  },
	{  -1, NULL  }//end
},
	*reason_item = reason_table;

int32_t get_from_db(char *table, char *key, char *field, char *msg)
{
	struct parser_module *module = NULL;
	void *client_fd = NULL;
	int32_t ret;

	*msg = '\0';

	module = parser_open("dbcmd");

	if(!module)
	{
		nc_verb_error("Parser open failed!");
		return 0;
	}

	if((client_fd = (*module->init_sock)(PARSER_ROLE)) == NULL)
	{
		nc_verb_error("socket init failed!");
		parser_close(module);
		return 0;
	}

	ret = (*module->gen_cmd)(client_fd, msg, "dbctl", "-t", table, "-k", key, "-g", field, NULL);

	(*module->close_sock)(client_fd, PARSER_ROLE);
	parser_close(module);

	return ret;
}

int32_t set_to_db(char *table, char *key, char *field, char *value, char *msg)
{
        struct parser_module *module = NULL;
        void *client_fd = NULL;
        int32_t ret;

        *msg = '\0';

        module = parser_open("dbcmd");

        if(!module)
        {
                nc_verb_error("Parser open failed!");
                return 0;
        }

        if((client_fd = (*module->init_sock)(PARSER_ROLE)) == NULL)
        {
                nc_verb_error("socket init failed!");
                parser_close(module);
                return 0;
        }

        ret = (*module->gen_cmd)(client_fd, msg, "dbctl", "-t", table, "-k", key, "-f", field, "-s", value, NULL);

        (*module->close_sock)(client_fd, PARSER_ROLE);
        parser_close(module);

        return ret;
}

void renew_if_dhcp(const char *interface){
	char zysh_cmd[CMD_LEN] = {'\0'};

	zylog(ZYLOG_SRC_SYSTEM, ZYLOG_PRI_ERR, ZYLOG_FAC_SYSTEM, 0,0,0,0,
	"Nebula",
	"Netconf will do the DHCP renew for recovery.");
	netconf_connection_log( "Netconf will do the DHCP renew for recovery." );

	sprintf(zysh_cmd, "zysh -p100 -e \"renew dhcp %s\"", interface);
	system(zysh_cmd);
	return;
}

int32_t check_internet_status(void){
	int32_t status = -1;

	status = system(PING_CMD);
/*
 * Zyxel: Considering system() may have it's own exception case,
 * return 0 for all the cases like that to avoid action which is not necessary.
 */
	if(status == -1){
		return 0;
	}
	if( WIFEXITED(status) )
		return WEXITSTATUS(status);
	else
		return 0;
}

int32_t netconf_kit_wlan_get_hybridmode(void){
	return zykit_wlan_get_hybridmode();
}

int32_t interface_type_dhcp(void) {
	FILE *fp = NULL;
	char line[256] = {0};
	int32_t result = 0;

	fp = popen("zysh -p100 -e \"show interface lan\" |grep \"IP type\"", "r");
	if(fp) {
		if(fgets(line, sizeof(line), fp)) {
			if(strstr(line, "dhcp")) {
				result = 1;
			}
		}
		pclose(fp);
	}

	return result;
}

int32_t zylog_agent_in_netconf(char* msg, uint32_t* reason_code)
{
	char log_buf[ZYLOG_MAX_MESSAGE_LEN] = {0};
	char db_msg[BUF_LEN] = {0};
	char db_reason[BUF_LEN] = {0};
	char last_reason[BUF_LEN] = {0};

	if(*reason_code) {
		snprintf(log_buf, ZYLOG_MAX_MESSAGE_LEN, "%s: ", msg);
		for(reason_item = reason_table; reason_item->reason; ++reason_item) {
			if(*reason_code & (1U << reason_item->index)){
				strncat(db_reason, reason_item->reason, (ZYLOG_MAX_MESSAGE_LEN - strlen(log_buf) - 1));
				set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "connect_failed_reason", db_reason, db_msg);
				if(reason_item->utl) {
					db_reason[0] = tolower(db_reason[0]);
				}
				break;
			}
		}

		strncat(log_buf, db_reason, (ZYLOG_MAX_MESSAGE_LEN - strlen(log_buf) - 1));

		/* gateway unreachable */
		if((!strcmp(db_reason, "gateway unreachable")) && interface_type_dhcp()) {
			strncat(log_buf, " and start DHCP renew for recovery", (ZYLOG_MAX_MESSAGE_LEN - strlen(log_buf) - 1));
		}

		/* DNS queries failed */
		if(!strcmp(db_reason, "DNS queries failed")) {
			strncat(log_buf, " (d.nebula.zyxel.com)", (ZYLOG_MAX_MESSAGE_LEN - strlen(log_buf) - 1));
		}

		strncat(log_buf, ".", (ZYLOG_MAX_MESSAGE_LEN - strlen(log_buf) - 1));
	} else {
		snprintf(log_buf, ZYLOG_MAX_MESSAGE_LEN, "%s.", msg);
	}

	if(WHOPMODE_STANDALONE == netconf_kit_wlan_get_hybridmode()) {
		get_from_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "the_last_reason", last_reason);
		if((db_reason[0] != '\0') && (strcmp(last_reason, db_reason))) {
			zylog(ZYLOG_SRC_SYSTEM, ZYLOG_PRI_ERR, ZYLOG_FAC_SYSTEM, 0,0,0,0, "Nebula", "%s", log_buf);
			set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "the_last_reason", db_reason, db_msg);
		}
	}

	if(WHOPMODE_CLOUD == netconf_kit_wlan_get_hybridmode()) {
		zylog(ZYLOG_SRC_SYSTEM, ZYLOG_PRI_ERR, ZYLOG_FAC_SYSTEM, 0,0,0,0, "Nebula", "%s", log_buf);
	}

	netconf_connection_log(log_buf);

	*reason_code = 0;

	return 0;
}

void nc_get_default_gateway(char *gateway_str){
	FILE *fp = NULL;
	char line[256] = {0};

	*gateway_str = '\0';
	fp = fopen("/proc/net/route", "r");
	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			uint32_t gateway, dest;
			struct in_addr addr;
			int ret = sscanf(line, "br0 %x %x %*s",  &dest, &gateway);

			if(ret == 2 && dest == 0) {
				addr.s_addr = gateway;
				sprintf(gateway_str, "%s", inet_ntoa(addr));
				break;
			}
		}
		fclose(fp);
	}
}

int32_t nc_arping(char *dst_addr){
	int status = -1;
	char cmd[320] = {'\0'};

	sprintf(cmd, "%s %s -I %s -c 5 -w 3 -f", ARPPING_BIN, dst_addr, NC_IF_UPLINK);
	status = system(cmd);

	if(status == -1){
		return 0;
	}
	if( WIFEXITED(status) )
		return WEXITSTATUS(status);
	else
		return 0;
}

int32_t nc_get_gateway_status(void)
{
	char gateway_addr[32] = {'\0'};
	nc_get_default_gateway(gateway_addr);

	if( ( strlen(gateway_addr) < 7 ) ){
		//GW addr not found.
		return -1;
	}

	return nc_arping(gateway_addr);
}

int32_t nc_get_ip_status(void){
	FILE *fp = NULL;
	char line[256] = {'\0'};
	int32_t result = 0;
	fp = popen("/sbin/ip addr | grep br0", "r");

	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			/* check ip status */
			if (strstr(line,"inet")) {
				result = 1;
				break;
			}
		}
		pclose(fp);
	}
	return result;
}

void CURL_DebugInfo_to_file(void) {
	char cmd[128] = {'\0'};
	char port[16] = {'\0'};

	netconf_connection_log( "CURL Debug Info." );

	get_from_db(NEBULA_TABLE_NAME, NEBULA_CALLHOME, "port", port);

	snprintf(cmd, sizeof(cmd), "curl -m 10 -sS --tlsv1.2 --trace %s d.nebula.zyxel.com:%s 2>&1", CURL_DEBUG_FILE, port);
	system(cmd);

	/* cat curl result file >>> nc_dbg_connection.log */
	snprintf(cmd, sizeof(cmd), "cat %s >> %s && rm %s", CURL_DEBUG_FILE, NC_DBG_CONN_LOG, CURL_DEBUG_FILE);
	system(cmd);
}

int32_t query_hostname_by_default_dns(char *hostname, char *ip){
	FILE *fp = NULL;
	char line[32] = {'\0'};
	char cmd[64] = {'\0'};
	char dns[32] = {'\0'};
	char dns_list[DNS_LIST_LEN] = {'\0'};
	int32_t result = 1;

	if (access("/var/nebula-help-dns-status", F_OK) == 0) {
		return result;
	}

	snprintf(cmd, sizeof(cmd), "/usr/local/bin/nslookup %s 8.8.8.8 -sil", hostname);
	fp = popen(cmd, "r");

	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			/* We use first ip address  */
			if (strstr(line, "Address: ") && !strstr(line, hostname)) {
				line[strlen(line)-1] = '\0';
				strcpy(ip, line+9);
				result = 0;
				break;
			}
		}
		pclose(fp);
	}

	/*print debug log with user's DNS info*/
	snprintf(cmd, sizeof(cmd), "cat /etc/resolv.conf");
	fp = popen(cmd,"r");

	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			if (strstr(line, "nameserver ")) {
				line[strlen(line)-1] = '/';
				sscanf(line, "nameserver %s", dns);
				strncat(dns_list, dns, (DNS_LIST_LEN - strlen(dns_list)));
			}
		}
		pclose(fp);
		dns_list[strlen(dns_list)-1] = '\0';
	}

	if(!result) {
		nc_verb_verbose("Hostname_to_ip : User's DNS(%s) quires failed,try default DNS(8.8.8.8) quires successful",dns_list);
	}

	return result;
}

int MyPower(int x, int  n) {
	int number = 1;

	while(n > 0) {
		number *= x;
		n--;
	}

	return number;
}

int32_t lan_port_status(void) {
        FILE *fp = NULL;
        char line[32] = {'\0'};
        char cmd[64] = {'\0'};
        int32_t result = 0;

        snprintf(cmd, sizeof(cmd), "zysh -p100 -e \"show interface all\"|grep lan");
        fp = popen(cmd, "r");

	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			if(strstr(line, "Down")) {
				result = 1;
			}
			break;
		}
		pclose(fp);
	}

	return result;
}

int32_t kill_process_by_pid_in_file(char *filepath){
	FILE *pid_fp = NULL;
	char pid[8] = {'\0'};
	char cmd[128] = {'\0'};
	char *pos;

	if( !access(filepath, F_OK) ){
		pid_fp = fopen(filepath, "r");
		if( pid_fp ){
			if( fgets(pid, sizeof(pid), pid_fp) ){
				if ((pos=strchr(pid, '\n')) != NULL)
					*pos = '\0';
				snprintf(cmd, sizeof(cmd), "kill -9 %s >>/dev/null 2>&1", pid);
				system(cmd);
			}
			fclose(pid_fp);
			unlink(filepath);
		}else{
			/* PID existed but unavailable. */
			return -1;
		}
	}

	return 0;
}

int32_t record_local_interface(void) {
	FILE *fp = NULL;
	char line[32] = {'\0'}, cmd[128] = {'\0'};
	char dns[32] = {'\0'}, ip[32] = {'\0'}, gateway[32] = {'\0'}, type[32] = {'\0'}, interface[32] = {'\0'};
	char debug[128] = {'\0'};
	char dns_list[DNS_LIST_LEN] = {'\0'};
	char *pos;

	/* collect interface info */
	snprintf(cmd, sizeof(cmd), "zysh -p 100 -e \"show interface lan\"| grep -E \"interface name|IP type|IP address|gateway\"");
	fp = popen(cmd, "r");

	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			if(strstr(line, "interface name")) {
				sscanf(line, "interface name: %s", interface);
				if ((pos=strchr(interface, '\n')) != NULL)
					*pos = '\0';
			}
			if(strstr(line, "IP type")) {
				sscanf(line, "IP type: %s", type);
				if ((pos=strchr(type, '\n')) != NULL)
					*pos = '\0';
			}
			if(strstr(line, "IP address")) {
				sscanf(line, "IP address: %s", ip);
				if ((pos=strchr(ip, '\n')) != NULL)
					*pos = '\0';
			}
			if(strstr(line, "gateway")) {
				sscanf(line, "gateway: %s", gateway);
				if ((pos=strchr(gateway, '\n')) != NULL)
					*pos = '\0';
			}
		}
		pclose(fp);
	}

	/* collect DNS info */
	snprintf(cmd, sizeof(cmd), "cat /etc/resolv.conf");
	fp = popen(cmd, "r");

	if(fp) {
		while(fgets(line, sizeof(line), fp)) {
			if (strstr(line, "nameserver ")) {
				line[strlen(line)-1] = '/';
				sscanf(line, "nameserver %s", dns);
				strncat(dns_list, dns, (DNS_LIST_LEN - strlen(dns_list)));
			}
		}
		pclose(fp);
		dns_list[strlen(dns_list)-1] = '\0';
	}

	/* assemble debug log */
	snprintf(debug, sizeof(debug), "Local interface Info : Interface is %s, Type is %s, IP is %s, Gateway is %s, DNS is %s", interface, type, ip, gateway, dns_list);
	netconf_connection_log(debug);
}

int nebula_port_status(void) {
	FILE *fp = NULL;
	char line[32] = {0}, cmd[128] = {0};
	int result = 0;

	snprintf(cmd, sizeof(cmd), "/usr/bin/paping d.nebula.zyxel.com -p 4335 -c 1 --nocolor |grep \"Attempted\"");
	fp = popen(cmd, "r");
	if(fp) {
		if(fgets(line, sizeof(line), fp)) {
			if(strstr(line, "Connected = 1")) {
				result = 1;
			}
		}
		pclose(fp);
	}

	return result;
}


#define DPRINT_DEBUG 0

#if 1 /* DEBUG */
#define VAR_ZYSH_PATH "/var/zyxel/zysh/"
static void DPRINT(char *format) {
	
	#if DPRINT_DEBUG /* 0 or 1 */
	FILE *fp = NULL;
	char strbuf[1024];

	sprintf(strbuf, VAR_ZYSH_PATH "/_ip_conflict_log");
	if( (fp = fopen(strbuf, "a+")) ) {
		fprintf(fp, "%s", format);
		fclose(fp);
		fp = NULL;
	}
	#endif
	return;
}
#endif

#define _ZYLOG(pri,msg,arg...) zylog(ZYLOG_SRC_SYSTEM, \
                                        pri,\
                                        ZYLOG_FAC_SYSTEM,\
                                        0,0,0,0,\
                                        "",\
                                        msg,\
                                        ##arg)

#define BASE_GW_MAC   "/tmp/base_gw_mac"
/*
	Process for checking AP br0 IP conflicted or duplicted and printing ZYLOG
*/
static void _ap_ip_conflict()
{
	char buf[1024] = { 0 };
	char cmd_arping[256] = { 0 };
	char mac_buf[64] = { 0 };
	FILE *fp = NULL;	
		
	char cmd_ifconfig[256] = { 0 };
	char ip_buf[64] = { 0 };
	
	sprintf(cmd_ifconfig," ifconfig br0 | grep -Eo \'inet (addr:)?([0-9]*\\.){3}[0-9]*\' | grep -Eo \'([0-9]*\\.){3}[0-9]*\' ");
	
	if ((fp = popen(cmd_ifconfig, "r"))) {
		fscanf(fp, "%s", ip_buf);
		pclose(fp);
	} else {
		DPRINT("popen fail");
		return;
	}

	if (strlen(ip_buf)) {
		sprintf(cmd_arping,"%s -I br0 %s -b -c 1 -D | awk \'/reply from/ {print $5}\'", ARPPING_BIN, ip_buf);
		if ((fp = popen(cmd_arping, "r"))) {
			fscanf(fp, "%s", mac_buf);
			pclose(fp);
		} else {
			DPRINT("popen fail");
			return; 
		}
		sprintf(buf,"cmd_arping: <%s>  \n", cmd_arping);
		DPRINT(buf);
		memset(buf, 0, sizeof(buf));
		
		
		sprintf(buf,"%s: [%d], mac_buf: <%s>  \n", __FILE__, __LINE__, mac_buf);
		DPRINT(buf);
		memset(buf, 0, sizeof(buf));

		if (strlen(mac_buf) == 19) {  // [XX:XX:XX:XX:XX:XX]
			sprintf(buf,"AP IP %s is conflicted (conflicted MAC address: %s)", ip_buf, mac_buf);
			_ZYLOG(LOG_ALERT,"%s", buf);
			memset(buf, 0, sizeof(buf));
		
			sprintf(buf,"**** %s: %d deubg: IP conflicted ****\n", __FUNCTION__, __LINE__);
			DPRINT(buf);
			memset(buf, 0, sizeof(buf));
			return;
		} else {
			sprintf(buf,"%s: %d NO Conflict do-nothing \n", __FUNCTION__, __LINE__);
			DPRINT(buf);
			memset(buf, 0, sizeof(buf));
			return;
		}
	}
}

/*
	Process for checking GATEWAY IP conflicted and printing ZYLOG
*/
static void _gateway_ip_duplicated(void)
{
	char buf[1024]= { 0 };
	char cmd_line[256] = { 0 };
	char cmd_ip_route[256] = { 0 };
	char mac_counter[64] = { 0 };
	char mac_base[64] = { 0 };
	char mac_compare[64] = { 0 } ;
	char ip_buf[128] = { 0 };
	char existed_gw_mac[64] = { 0 };
	
	int  check_value = 0;
	FILE *fp = NULL;	
	
	sprintf(cmd_ip_route," ip route | grep default | awk \'{print$3}\' ");
	if ((fp = popen(cmd_ip_route, "r"))) {
		fscanf(fp, "%s", ip_buf);
		pclose(fp);
	} else {
		DPRINT("popen fail");
		return;
	}
	// get gateway IP store to ip_buf	
	sprintf(buf,"cmd_ip_route: [%s] ,ip_buf: <%s>  \n", cmd_ip_route, ip_buf);
	DPRINT(buf);
	memset(buf, 0, sizeof(buf));

	if (strlen(ip_buf)) {
		sprintf(cmd_line,"%s -I br0 %s -b -c 1  | awk \'/Unicast reply from/ {print $5}\' | wc -l ", ARPPING_BIN, ip_buf);
		DPRINT(cmd_line);
		if ((fp = popen(cmd_line, "r"))) {
			fscanf(fp, "%s", mac_counter);
			pclose(fp);
		} else {
			return; 
		}
		
		check_value = atoi(mac_counter);
		sprintf(buf,"check_value: [%d]  , mac_counter: <%s>  \n", check_value, mac_counter);
		DPRINT(buf);
		memset(buf, 0, sizeof(buf));
		
		if (check_value >= 2) {
			memset(cmd_line, 0, sizeof(cmd_line));
			sprintf(cmd_line,"%s -I br0 %s -b -c 1  | awk \'/Unicast reply from/ {print $5}\'", ARPPING_BIN, ip_buf);
			sprintf(buf,"cmd_line: <%s>\r\n", cmd_line);
			DPRINT(buf);
			memset(buf, 0, sizeof(buf));
			
			if ((fp = popen(cmd_line, "r"))) {
				fscanf(fp, "%s", mac_base);
				fscanf(fp, "%s", mac_compare);
				pclose(fp);
			} else {
				return; 
			}
			
			sprintf(buf,"mac_base: <%s> mac_compare: <%s>\r\n", mac_base, mac_compare);
			DPRINT(buf);
			memset(buf, 0, sizeof(buf));
			
			if (strcmp(mac_base, mac_compare) != 0 	&& 
				strcmp(mac_base		, "") != 0		&& 
				strcmp(mac_compare	, "") != 0    	) {
				sprintf(buf," Gateway IP %s is conflicted on %s and %s, please check network setting.", ip_buf, mac_base, mac_compare);
				_ZYLOG(LOG_ALERT,"%s", buf);
				memset(buf, 0, sizeof(buf));		
			}
		} else {
			if (check_value == 1) { /* normal status, only find one gateway */
				memset(cmd_line, 0, sizeof(cmd_line));
				sprintf(cmd_line,"%s -I br0 %s -b -c 1  | awk \'/Unicast reply from/ {print $5}\'", ARPPING_BIN, ip_buf);
				sprintf(buf,"cmd_line: <%s>\r\n", cmd_line);
				DPRINT(buf);
				memset(buf, 0, sizeof(buf));
				
				if ((fp = popen(cmd_line, "r"))) {
					fscanf(fp, "%s", mac_compare);
					pclose(fp);
				} else { /* no reply  */
					return;  
				}
				

				// Access BASE_GW_MAC file check
				if (access(BASE_GW_MAC, F_OK) != 0) {
					// generate file to write existed MAC
					fp = fopen(BASE_GW_MAC, "w");
					if (fp)
					{
						fprintf(fp,"%s\n", mac_compare);
						fclose(fp);
					}
					sprintf(buf,"%s %d mac_compare: <%s>\r\n", __FUNCTION__, __LINE__, mac_compare);
					DPRINT(buf);
					memset(buf, 0, sizeof(buf));
				} else { 
					/* BASE_GW_MAC exist */
					memset(cmd_line, 0, sizeof(cmd_line));
					sprintf(cmd_line,"cat %s", BASE_GW_MAC);
					
					if ((fp = popen(cmd_line, "r"))) {
						fscanf(fp, "%s", existed_gw_mac);
                                          	pclose(fp);
					} else {
						return;  // popen fail
					}
					
					if ( strcmp(mac_compare   , "")          != 0 && 
					     strcmp(existed_gw_mac, mac_compare) != 0) {
						sprintf(buf," System detected new gateway MAC %s is different than existed gateway MAC %s.", mac_compare, existed_gw_mac);
						_ZYLOG(LOG_ALERT,"%s", buf);
						
						// update BASE_GW_MAC, write BASE_GW_MAC file
						unlink(BASE_GW_MAC); //clear 
						fp = fopen(BASE_GW_MAC, "w");
						if (fp)
						{
							fprintf(fp,"%s\n", mac_compare);
							fclose(fp);
						}
						memset(buf, 0, sizeof(buf));
						sprintf(buf,"existed_gw_mac: <%s> mac_compare: <%s>\r\n", existed_gw_mac, mac_compare);
						DPRINT(buf);
					}
				}				
			}
		}
	}
}

int32_t nc_debug_procedure( int debug_scene, uint32_t *reason_code, uint32_t cur_port ){
	char db_msg[256] = {0};
	char command[128] = {0};
	set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "connect_failed_reason", "", db_msg);

	switch (debug_scene){
		case SUCCESS:
			if( kill_process_by_pid_in_file(CC_PING_PID_FILE) ){
				nc_verb_error("Cleaning subprocess of TCPPING failed.");
			}
			if( kill_process_by_pid_in_file(SUB_CC_PING_PID_FILE) ){
				nc_verb_error("Cleaning process of TCPPING failed.");
			}
			if( kill_process_by_pid_in_file(TRACERT_PID_FILE) ){
				nc_verb_error("Cleaning subprocess of TRACERT failed.");
			}
			if( kill_process_by_pid_in_file(SUB_TRACERT_PID_FILE) ){
				nc_verb_error("Cleaning process of TRACERT failed.");
			}
			break;
		case CONNECT_FAIL:
		case DISCONNECT:
			_ap_ip_conflict();
			_gateway_ip_duplicated();

			if( (nc_get_gateway_status())!=0 ){
				*reason_code |= ( 1 << GATEWAY_UNAVAILABLE );
				record_local_interface();
				if( debug_scene == CONNECT_FAIL ){
					zylog_agent_in_netconf("Nebula connection failed", reason_code);
					set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN_CLI", "0", db_msg);
					/* Do not renew dhcp when SMESH working */
					if (lan_port_status()) {
						netconf_connection_log("Lan port(br0) is down, skip renew dhcp");
						break;
					}
				}else{
					zylog_agent_in_netconf("Netconf connection is disconnected", reason_code);
				}

				if( WHOPMODE_CLOUD == netconf_kit_wlan_get_hybridmode()
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
						&& !managed_to_cloud_flag()
#endif
				){
					nc_verb_verbose("[%s:%d] Is going to renew dhcp!", __func__, __LINE__);
					renew_if_dhcp(ZYSH_IF_UPLINK);
				}
			}else{
				record_local_interface();
				if( debug_scene == CONNECT_FAIL ){
					/* Check 4335 port when connect fail with no reason */
					if(*reason_code == 0) {
						if(!nebula_port_status()) {
							*reason_code |= ( 1 << PORT_BLOCKED );
						}
					}
					zylog_agent_in_netconf("Nebula connection failed", reason_code);
					set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN_CLI", "0", db_msg);
				}else{
					zylog_agent_in_netconf("Netconf connection is disconnected", reason_code);
				}

				if ( WHOPMODE_CLOUD == netconf_kit_wlan_get_hybridmode()
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
						&& !managed_to_cloud_flag()
#endif
				 ){
					nc_verb_verbose("[%s:%d] Gateway check success, skip renew dhcp.", __func__, __LINE__);
					system("/usr/sbin/nc_connection_check.sh traceroute &");
					sprintf(command, "/usr/sbin/nc_connection_check.sh tcpping %d &",cur_port);
					system(command);
				}
			}
			break;

		default:
			nc_verb_error("[%s:%d] Unexpected debug case with code: %d, r_code: %u.\n", __func__, __LINE__, debug_scene, *reason_code);
			break;
	}
	return 0;
}

int32_t netconf_connection_log( char *msg )
{
	FILE *fp = NULL;
	time_t now;
	struct tm *sTime;
	char cmd[512] = {'\0'};

	if( access(NC_DBG_CONN_LOG_PATH, F_OK) ){
		mkdir(NC_DBG_CONN_LOG_PATH, 0600);
	}

	fp = fopen(NC_DBG_CONN_LOG, "a+");
	if(fp == NULL){
		nc_verb_verbose("[%s:%d] Failed to open local conn log file.\n", __func__, __LINE__);
		return -1;
	}

	fseek(fp, 0, SEEK_END);

	if( ftell(fp) >= DBG_FILE_SIZE ){
		fclose(fp);
		snprintf(cmd, sizeof(cmd), "cat %s|tail -n 500 >> %s ; rm -rf %s 2>&1 > /dev/null ; mv -f %s %s", NC_DBG_CONN_LOG, NC_DBG_CONN_BUF, NC_DBG_CONN_LOG, NC_DBG_CONN_BUF, NC_DBG_CONN_LOG);
		system(cmd);
		fp = fopen(NC_DBG_CONN_LOG, "a+");
		if(fp == NULL){
			nc_verb_verbose("[%s:%d] Failed to open local conn log file.\n", __func__, __LINE__);
			return -1;
		}
		fputs("####### Debug file too large, overwrite it #######\r\n", fp);
	}

	time(&now);
	sTime = localtime(&now);

	fprintf(fp, "%04d/%02d/%02d %02d:%02d:%02d: %s\n", \
	sTime->tm_year + 1900, sTime->tm_mon + 1, sTime->tm_mday, \
	sTime->tm_hour, sTime->tm_min, sTime->tm_sec, \
	msg);

	fclose(fp);
	return 0;
}

#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
int32_t managed_to_cloud_flag(void)
{
	return !access(NEBULA_MANAGED_TO_CLOUD_FLAG, F_OK);	//flag exist return TRUE, flag not exist return FALSE.
}
#endif

#ifndef __LP64__
/*
 *	Due to the size limit of mktime() on 32-bit platform,
 *	we'll have this function to transfer tm to epoch for expiration date.
 */
int64_t mktime64( struct tm *time_in)
{
	unsigned int mon = (time_in->tm_mon+1), year = (time_in->tm_year+1900);

	/* 1..12 -> 11,12,1..10 */
	if (0 >= (int) (mon -= 2)) {
		mon += 12;	/* Puts Feb last since it has leap day */
		year -= 1;
	}

	return ((((int64_t)
		  (year/4 - year/100 + year/400 + 367*mon/12 + time_in->tm_mday) +
		  year*365 - 719499
	    )*24 + time_in->tm_hour /* now have hours */
	  )*60 + time_in->tm_min /* now have minutes */
	)*60 + time_in->tm_sec; /* finally seconds */
}
#endif

int cert_valid_check(char *exp_date_str){
	int valid = 0; /* 0:Expired, 1:valid */
	struct tm exp_date;
	int64_t exp_date_epoch;
	time_t now_epoch;
	FILE *log_fp = NULL;

	strptime(exp_date_str, "notAfter=%b %d %T %Y GMT\n", &exp_date);
	now_epoch = time(NULL);
#ifndef __LP64__
	exp_date_epoch = mktime64( &exp_date );
#else
	exp_date_epoch = mktime( &exp_date );
#endif
	if(exp_date_epoch < 0){
		nc_verb_error("(%s) To epoch failed with %s.(%s)", __func__, exp_date_str, strerror(errno));
		return 0;
	}

	if( exp_date_epoch > now_epoch ){
		valid = 1;
	}else{
		/* Cert expired.*/
		nc_verb_error("(%s) Cert expired! %s", __func__, exp_date_str);
		if(log_fp = fopen(CLOUD_CERT_EXP_DBG, "w")){
			fprintf(log_fp, "Cert expired! Download new cert...\n");
			fclose(log_fp);
		}
		valid = 0;
	}

	return valid;
}

void exit_if_cloud_cert_expired(void){
	/* Get certificate expired time */
	char buf[40]={'\0'};
	char cmd[256];

	sprintf(cmd, "/usr/bin/verify_cert %s enddate 2> /dev/null", ZLDSYSPARM_CERT_DEV);

	FILE *fp = popen(cmd, "r");
	if( fp==NULL ){
		nc_verb_error("(%s) popen: Failed to check cloud cert expiration date!", __func__);
		return;
	}

	fgets(buf, sizeof(buf), fp);
	pclose(fp);

	if((strlen(buf)) && (strstr(buf, "notAfter=")) && (strlen(buf) != strlen("notAfter")) ){
		if(!(cert_valid_check(buf))){
			exit((int32_t)(CLOUD_CERT_EXPIRED));
		}
		return; /* Not expired */
	}else{
		nc_verb_error("(%s) Check Cert status: Incomplete cert info: %s", __func__, buf);
	}
	return;
}

/**
 * @file server.c
 * @author David Kupka <xkupka01@stud.fit.vutbr.cz>
 *         Radek Krejci <rkrejci@cesnet.cz
 * @brief Netopeer server.
 *
 * Copyright (c) 2011, CESNET, z.s.p.o.
 * All rights reserved.
 *
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the CESNET, z.s.p.o. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#define _GNU_SOURCE
#define _XOPEN_SOURCE

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <linux/limits.h>
#include <poll.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#include <shadow.h>
#include <pwd.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <syslog.h>

#include <libnetconf_xml.h>
#include <openssl/comp.h>
#include <openssl/obj_mac.h>

#include "server.h"
#if 1 /* ZyXEL */
#include "zld-spec.h"
#include "zykit.h"
#include <linux/unistd.h>
#include <linux/kernel.h>
#include <sys/sysinfo.h>
#include "zy_nc_srv_plugin.h"
#endif

static const char rcsid[] __attribute__((used)) ="$Id: "__FILE__": "RCSID" $";

extern struct np_options netopeer_options;

extern pthread_mutex_t callhome_lock;
extern pthread_cond_t callhome_cond;
extern struct ch_app* callhome_app;

/* one global structure holding all the client information */
struct np_state netopeer_state = {
	.global_lock = PTHREAD_RWLOCK_INITIALIZER
};

/* flags of main server loop, they are turned when a signal comes */
volatile int quit = 0, restart_soft = 0, restart_hard = 0;

volatile int server_start = 0;

#if 1 /*ZyXEL*/
void gettimefromsys (long* time) {
        struct sysinfo s_info;

        int error = sysinfo(&s_info);

        if (error != 0) {
                nc_verb_verbose("Get sysinfo failed");
        }

        *time = s_info.uptime;
}
#endif

void clb_print(NC_VERB_LEVEL level, const char* msg) {
#if 1 /* ZyXEL */
	FILE *diagnos;
#endif
	switch (level) {
	case NC_VERB_ERROR:
#if 1 /* ZyXEL */
		diagnos = fopen("/tmp/nc_dbg_file", "a+");
		if(!diagnos)
		{
			return;
		}
		fseek(diagnos, 0L, SEEK_END);
		if (ftell(diagnos) >= (100*1024))/* 100K */
		{
			fclose(diagnos);
			unlink("/tmp/nc_dbg_file");
			diagnos = fopen("/tmp/nc_dbg_file", "a+");
			if(!diagnos)
			{
				return;
			}
		}
		fprintf(diagnos, "%s[%d]: %s\n", program_invocation_short_name, getpid(), msg);
		fclose(diagnos);
#else
		syslog(LOG_ERR, "%s", msg);
#endif
		break;
	case NC_VERB_WARNING:
		syslog(LOG_WARNING, "%s", msg);
		break;
	case NC_VERB_VERBOSE:
		syslog(LOG_INFO, "%s", msg);
		break;
	case NC_VERB_DEBUG:
		syslog(LOG_DEBUG, "%s", msg);
		break;
	}
}

void print_debug(const char* format, ...) {
#define MAX_DEBUG_LEN 4096
	char msg[MAX_DEBUG_LEN];
	va_list ap;

	va_start(ap, format);
	vsnprintf(msg, MAX_DEBUG_LEN, format, ap);
	va_end(ap);

	clb_print(NC_VERB_DEBUG, msg);
}

static void print_version(char* progname) {
	fprintf(stdout, "%s version %s\n", progname, VERSION);
	fprintf(stdout, "%s\n", RCSID);
	fprintf(stdout, "compile time: %s, %s\n", __DATE__, __TIME__);
	exit(0);
}

static void print_usage(char* progname) {
	fprintf(stdout, "Usage: %s [-dhV] [-v level]\n", progname);
	fprintf(stdout, " -d                  daemonize server\n");
	fprintf(stdout, " -h                  display help\n");
	fprintf(stdout, " -v level            verbose output level\n");
	fprintf(stdout, " -V                  show program version\n");
	exit(0);
}

#define OPTSTRING "dhv:V"

/*!
 * \brief Signal handler
 *
 * Handles received UNIX signals and sets value to control main loop
 *
 * \param sig 	signal number
 */
void signal_handler(int sig) {

	switch (sig) {
	case SIGINT:
	case SIGTERM:
	case SIGQUIT:
		if (quit == 0) {
			/* first attempt */
			quit = 1;
		} else {
			/* second attempt */
			exit(EXIT_FAILURE);
		}
		break;
	case SIGHUP:
		/* restart the daemon */
#if 1 /* ZyXEL */
		nc_verb_verbose("Caught signal SIGHUP\n\r");
#endif
		restart_soft = 1;
		break;
#if 1 /* ZyXEL */
	case SIGPIPE:
		nc_verb_verbose("Caught signal SIGPIPE\n\r");
		break;
#endif
	default:
		exit(EXIT_FAILURE);
		break;
	}
}

static void client_append(struct client_struct** root, struct client_struct* clients) {
	struct client_struct* cur;

	if (root == NULL) {
		return;
	}

	if (*root == NULL) {
		*root = clients;
		return;
	}

	for (cur = *root; cur->next != NULL; cur = cur->next);

	cur->next = clients;
}

void np_client_detach(struct client_struct** root, struct client_struct* del_client) {
	struct client_struct* client, *prev_client = NULL;

	for (client = *root; client != NULL; client = client->next) {
		if (client == del_client) {
			break;
		}
		prev_client = client;
	}

	if (client == NULL) {
		nc_verb_error("%s: internal error: client not found (%s:%d)", __func__, __FILE__, __LINE__);
		return;
	}

	if (prev_client == NULL) {
		*root = (*root)->next;
	} else {
		prev_client->next = client->next;
	}
}

/* return seconds rounded down */
unsigned int timeval_diff(struct timeval tv1, struct timeval tv2) {
	time_t sec;
#if 0	/*ZyXEL*/
	if (tv1.tv_usec > 1000000) {
		tv1.tv_sec += tv1.tv_usec / 1000000;
		tv1.tv_usec = tv1.tv_usec % 1000000;
	}

	if (tv2.tv_usec > 1000000) {
		tv2.tv_sec += tv2.tv_usec / 1000000;
		tv2.tv_usec = tv2.tv_usec % 1000000;
	}
#endif
	sec = (tv1.tv_sec > tv2.tv_sec ? tv1.tv_sec-tv2.tv_sec : tv2.tv_sec-tv1.tv_sec);
	return sec;
}

void* client_notif_thread(void* arg) {
	struct ntf_thread_config *config = (struct ntf_thread_config*)arg;

	ncntf_dispatch_send(config->session, config->subscribe_rpc);
	nc_rpc_free(config->subscribe_rpc);
	free(config);

	return NULL;
}

void* client_main_thread(void* arg) {
	struct client_struct* client = (struct client_struct*)arg;
	int skip_sleep;

	struct timeval cur_time = { 0, 0 };
	struct timeval next_time = { 0, 0 };
	int db_val = 1;
	char db_str[DB_STR_LEN];
	char db_msg[DB_STR_LEN];

	/* RPC thread starting */
	set_to_db(NEBULA_TABLE_NAME, KEEP_ALIVE, "rpc_thread", "1", db_msg);
	set_to_db(NEBULA_TABLE_NAME, KEEP_ALIVE, "check_both", "1", db_msg);

	gettimefromsys(&cur_time.tv_sec);
	next_time.tv_sec = cur_time.tv_sec + 60;

	do {
		skip_sleep = 0;

		/* GLOBAL READ LOCK */
		pthread_rwlock_rdlock(&netopeer_state.global_lock);

		switch (client->transport) {
#ifdef NP_SSH
		case NC_TRANSPORT_SSH:
			skip_sleep += np_ssh_client_transport((struct client_struct_ssh*)client);
			skip_sleep += np_ssh_client_netconf_rpc((struct client_struct_ssh*)client);
			break;
#endif
#ifdef NP_TLS
		case NC_TRANSPORT_TLS:
			skip_sleep += np_tls_client_transport((struct client_struct_tls*)client);
			skip_sleep += np_tls_client_netconf_rpc((struct client_struct_tls*)client);
			break;
#endif
		default:
			nc_verb_error("%s: internal error (%s:%d)", __func__, __FILE__, __LINE__);
		}

		/* GLOBAL READ UNLOCK */
		pthread_rwlock_unlock(&netopeer_state.global_lock);

		if (!skip_sleep) {
			/* we did not do anything productive, so let the thread sleep */
			usleep(netopeer_options.response_time*1000);
		}

		gettimefromsys(&cur_time.tv_sec);
		if (cur_time.tv_sec >= next_time.tv_sec) {
			db_val++;
			snprintf(db_str, sizeof(db_str), "%d", db_val);
			set_to_db(NEBULA_TABLE_NAME, KEEP_ALIVE, "rpc_thread", db_str, db_msg);
			next_time.tv_sec = cur_time.tv_sec + 60;
		}

		if (!access(IF_MGNT_RPC_THREAD_FLAG, F_OK)) {
			/* zysh will apply cloud interface, do not handle following RPC, just waiting netopeer re-spawn */
			sleep(100);
		}
	} while (!client->to_free);

	/* Let nc-wd stop monitor rpc thred  */
	set_to_db(NEBULA_TABLE_NAME, KEEP_ALIVE, "check_both", "0", db_msg);

	/* GLOBAL WRITE LOCK */
	pthread_rwlock_wrlock(&netopeer_state.global_lock);

	np_client_detach(&netopeer_state.clients, client);

	if (client->pthread_status == JOINABLE) {
		client->pthread_status = DETACHED;
		/* GLOBAL WRITE UNLOCK */
		pthread_rwlock_unlock(&netopeer_state.global_lock);
		pthread_detach(pthread_self());
        } else {
		/* GLOBAL WRITE UNLOCK */
		pthread_rwlock_unlock(&netopeer_state.global_lock);
	}

	switch (client->transport) {
#ifdef NP_SSH
	case NC_TRANSPORT_SSH:
		client_free_ssh((struct client_struct_ssh*)client);
		break;
#endif
#ifdef NP_TLS
	case NC_TRANSPORT_TLS:
		client_free_tls((struct client_struct_tls*)client);
		break;
#endif
	default:
		free(client);
		break;
	}
#ifdef NP_TLS
	np_tls_thread_cleanup();
#endif
	return NULL;
}

static void sock_cleanup(struct np_sock* npsock) {
	unsigned int i;

	if (npsock == NULL) {
		return;
	}

	for (i = 0; i < npsock->count; ++i) {
		close(npsock->pollsock[i].fd);
	}
	free(npsock->pollsock);
	npsock->pollsock = NULL;
	free(npsock->transport);
	npsock->transport = NULL;
	npsock->count = 0;
}

static void sock_listen(const struct np_bind_addr* addrs, struct np_sock* npsock) {
	const int optVal = 1;
	const socklen_t optLen = sizeof(optVal);
	char is_ipv4;
	struct sockaddr_storage saddr;

	struct sockaddr_in* saddr4;
	struct sockaddr_in6* saddr6;

	if (addrs == NULL || npsock == NULL) {
		return;
	}

	if (npsock->count > 0) {
		sock_cleanup(npsock);
	}

	/*
	 * Always have the last pollfd structure ready -
	 * this way we can reuse it safely (continue;)
	 * every time an error occurs during its
	 * modification.
	 */
	npsock->count = 1;
	npsock->pollsock = calloc(1, sizeof(struct pollfd));
	npsock->transport = calloc(1, sizeof(NC_TRANSPORT));

	/* for every address and port a pollfd struct is created */
	for (;addrs != NULL; addrs = addrs->next) {
		npsock->transport[npsock->count-1] = addrs->transport;

		if (strchr(addrs->addr, ':') == NULL) {
			is_ipv4 = 1;
		} else {
			is_ipv4 = 0;
		}

		npsock->pollsock[npsock->count-1].fd = socket((is_ipv4 ? AF_INET : AF_INET6), SOCK_STREAM, 0);
		if (npsock->pollsock[npsock->count-1].fd == -1) {
			nc_verb_error("%s: could not create socket (%s)", __func__, strerror(errno));
			continue;
		}

		if (setsockopt(npsock->pollsock[npsock->count-1].fd, SOL_SOCKET, SO_REUSEADDR, (void*) &optVal, optLen) != 0) {
			nc_verb_error("%s: could not set socket SO_REUSEADDR option (%s)", __func__, strerror(errno));
			continue;
		}

		if (fcntl(npsock->pollsock[npsock->count-1].fd, F_SETFD, FD_CLOEXEC) != 0) {
			nc_verb_error("%s: fcntl failed (%s)", __func__, strerror(errno));
			continue;
		}

		bzero(&saddr, sizeof(struct sockaddr_storage));
		if (is_ipv4) {
			saddr4 = (struct sockaddr_in*)&saddr;

			saddr4->sin_family = AF_INET;
			saddr4->sin_port = htons(addrs->port);

			if (inet_pton(AF_INET, addrs->addr, &saddr4->sin_addr) != 1) {
				nc_verb_error("%s: failed to convert IPv4 address \"%s\"", __func__, addrs->addr);
				continue;
			}

			if (bind(npsock->pollsock[npsock->count-1].fd, (struct sockaddr*)saddr4, sizeof(struct sockaddr_in)) == -1) {
				nc_verb_error("%s: could not bind \"%s\" port %d (%s)", __func__, addrs->addr, addrs->port, strerror(errno));
				continue;
			}

		} else {
			saddr6 = (struct sockaddr_in6*)&saddr;

			saddr6->sin6_family = AF_INET6;
			saddr6->sin6_port = htons(addrs->port);

			if (inet_pton(AF_INET6, addrs->addr, &saddr6->sin6_addr) != 1) {
				nc_verb_error("%s: failed to convert IPv6 address \"%s\"", __func__, addrs->addr);
				continue;
			}

			if (bind(npsock->pollsock[npsock->count-1].fd, (struct sockaddr*)saddr6, sizeof(struct sockaddr_in6)) == -1) {
				nc_verb_error("%s: could not bind \"%s\" port %d (%s)", __func__, addrs->addr, addrs->port, strerror(errno));
				continue;
			}
		}

		if (listen(npsock->pollsock[npsock->count-1].fd, 5) == -1) {
			nc_verb_error("%s: unable to start listening on \"%s\" port %d (%s)", __func__, addrs->addr, addrs->port, strerror(errno));
			continue;
		}

		npsock->pollsock[npsock->count-1].events = POLLIN;

		npsock->pollsock = realloc(npsock->pollsock, (npsock->count+1)*sizeof(struct pollfd));
		bzero(npsock->pollsock+npsock->count, sizeof(struct pollfd));
		npsock->transport = realloc(npsock->transport, (npsock->count+1)*sizeof(NC_TRANSPORT));
		++npsock->count;
	}

	/* the last pollsock is not valid */
	--npsock->count;
}

/* always returns only a single new connection */
static struct client_struct* sock_accept(const struct np_sock* npsock) {
	int r;
	unsigned int i;
	socklen_t client_saddr_len;
	struct client_struct* ret;

	if (npsock == NULL) {
		return NULL;
	}

	/* poll for a new connection */
	errno = 0;
	r = poll(npsock->pollsock, npsock->count, netopeer_options.response_time);
	if (r == 0 || (r == -1 && errno == EINTR)) {
		/* we either timeouted or going to exit or restart */
		return NULL;
	}
	if (r == -1) {
		nc_verb_error("%s: poll failed (%s)", __func__, strerror(errno));
		return NULL;
	}

	ret = calloc(1, sizeof(struct client_struct));
	client_saddr_len = sizeof(struct sockaddr_storage);

	/* accept the first polled connection */
	for (i = 0; i < npsock->count; ++i) {
		if (npsock->pollsock[i].revents & POLLIN) {
			ret->sock = accept(npsock->pollsock[i].fd, (struct sockaddr*)&ret->saddr, &client_saddr_len);
			if (ret->sock == -1) {
				nc_verb_error("%s: accept failed (%s)", __func__, strerror(errno));
				free(ret);
				return NULL;
			}
			ret->transport = npsock->transport[i];
			npsock->pollsock[i].revents = 0;
			break;
		}
	}

	return ret;
}

static void clear_broadcast_callhome_client(int fail) {
    /* CALLHOME LOCK */
    pthread_mutex_lock(&callhome_lock);
    if (callhome_app) {
        if (fail) {
            callhome_app->client = NULL;
        }
        callhome_app = NULL;
        pthread_cond_broadcast(&callhome_cond);
    }
    /* CALLHOME UNLOCK */
    pthread_mutex_unlock(&callhome_lock);
}

void listen_loop(int do_init) {
	struct client_struct* new_client;
	struct np_sock npsock = {.count = 0};
	pthread_t client_tid;
	struct timeval cur_time = { 0, 0 };
	struct timeval next_time = { 0, 0 };
	int ret;
	int db_val = 1;
	char db_str[DB_STR_LEN];
	char db_msg[DB_STR_LEN];
#ifdef NP_SSH
	ssh_bind sshbind = NULL;
#endif
#ifdef NP_TLS
	SSL_CTX* tlsctx = NULL;
#endif

	gettimefromsys(&cur_time.tv_sec);
	next_time.tv_sec = cur_time.tv_sec + 60;

	/* Init */
	if (do_init) {
#ifdef NP_SSH
		np_ssh_init();
#endif
#ifdef NP_TLS
		np_tls_init();
#endif
	}

	/* Main accept loop */
	do {
		new_client = NULL;

		/* Binds change check */
		if (netopeer_options.binds_change_flag) {
			/* BINDS LOCK */
			pthread_mutex_lock(&netopeer_options.binds_lock);

			sock_cleanup(&npsock);
			sock_listen(netopeer_options.binds, &npsock);

			netopeer_options.binds_change_flag = 0;
			/* BINDS UNLOCK */
			pthread_mutex_unlock(&netopeer_options.binds_lock);

			if (npsock.count == 0) {
				nc_verb_warning("Server is not listening on any address!");
			}
		}

#ifdef NP_SSH
		sshbind = np_ssh_server_id_check(sshbind);
#endif
#ifdef NP_TLS
		tlsctx = np_tls_server_id_check(tlsctx);
#endif

		/* Callhome client check */
		/* CALLHOME LOCK */
		pthread_mutex_lock(&callhome_lock);
		if (callhome_app) {
			new_client = callhome_app->client;
		}
		/* CALLHOME UNLOCK */
		pthread_mutex_unlock(&callhome_lock);

		/* Listen client check */
		if (new_client == NULL) {
			new_client = sock_accept(&npsock);
		}

		/* New client full structure creation */
		if (new_client != NULL) {

			/* Maximum number of sessions check */
			if (netopeer_options.max_sessions > 0) {
				ret = 0;
#ifdef NP_SSH
				ret += np_ssh_session_count();
#endif
#ifdef NP_TLS
				ret += np_tls_session_count();
#endif

				if (ret >= netopeer_options.max_sessions) {
					nc_verb_error("Maximum number of sessions reached, droppping the new client.");
					new_client->to_free = 1;
					switch (new_client->transport) {
#ifdef NP_SSH
					case NC_TRANSPORT_SSH:
						client_free_ssh((struct client_struct_ssh*)new_client);
						break;
#endif
#ifdef NP_TLS
					case NC_TRANSPORT_TLS:
						client_free_tls((struct client_struct_tls*)new_client);
						break;
#endif
					default:
						free(new_client);
						nc_verb_error("%s: internal error (%s:%d)", __func__, __FILE__, __LINE__);
					}

					clear_broadcast_callhome_client(1);

					/* sleep to prevent clients from immediate connection retry */
					usleep(netopeer_options.response_time*1000);
					continue;
				}
			}

			switch (new_client->transport) {
#ifdef NP_SSH
			case NC_TRANSPORT_SSH:
				ret = np_ssh_create_client((struct client_struct_ssh*)new_client, sshbind);
				if (ret != 0) {
					new_client->to_free = 1;
					client_free_ssh((struct client_struct_ssh*)new_client);
				}
				break;
#endif
#ifdef NP_TLS
			case NC_TRANSPORT_TLS:
				ret = np_tls_create_client((struct client_struct_tls*)new_client, tlsctx);
				if (ret != 0) {
					new_client->to_free = 1;
					client_free_tls((struct client_struct_tls*)new_client);
				}
				break;
#endif
			default:
				nc_verb_error("Client with an unknown transport protocol, dropping it.");
				free(new_client);
				ret = 1;
			}

			/* client is not valid, some error occured */
			if (ret != 0) {
				clear_broadcast_callhome_client(1);
				continue;
			}

			/* add the client into the global clients structure */
			/* GLOBAL WRITE LOCK */
			pthread_rwlock_wrlock(&netopeer_state.global_lock);
			client_append(&netopeer_state.clients, new_client);
			/* GLOBAL WRITE UNLOCK */
			pthread_rwlock_unlock(&netopeer_state.global_lock);

			/* start the client thread */
			if ((ret = pthread_create((pthread_t*)&new_client->tid, NULL, client_main_thread, (void*)new_client)) != 0) {
				nc_verb_error("%s: failed to create a thread (%s)", __func__, strerror(ret));
				np_client_detach(&netopeer_state.clients, new_client);

				new_client->tid = 0;
				new_client->to_free = 1;
				switch (new_client->transport) {
#ifdef NP_SSH
				case NC_TRANSPORT_SSH:
					client_free_ssh((struct client_struct_ssh*)new_client);
					break;
#endif
#ifdef NP_TLS
				case NC_TRANSPORT_TLS:
					client_free_tls((struct client_struct_tls*)new_client);
					break;
#endif
				default:
					free(new_client);
					break;
				}

				clear_broadcast_callhome_client(1);
				continue;
			}

			/* Signal app loops if needed */
			clear_broadcast_callhome_client(0);
		}

		gettimefromsys(&cur_time.tv_sec);
		if (cur_time.tv_sec >= next_time.tv_sec) {
			db_val++;
			snprintf(db_str, sizeof(db_str), "%d", db_val);
			set_to_db(NEBULA_TABLE_NAME, KEEP_ALIVE, "main_thread", db_str, db_msg);
			next_time.tv_sec = cur_time.tv_sec + 60;
		}

	} while (!quit && !restart_soft);

	/* Cleanup */
	sock_cleanup(&npsock);
#ifdef NP_SSH
	ssh_bind_free(sshbind);
#endif
#ifdef NP_TLS
	SSL_CTX_free(tlsctx);
#endif
	if (!restart_soft) {
		/* wait for all the clients to exit nicely themselves */
		while (1) {
			/* GLOBAL READ LOCK */
			pthread_rwlock_rdlock(&netopeer_state.global_lock);

			if (netopeer_state.clients == NULL) {
				/* GLOBAL READ UNLOCK */
				pthread_rwlock_unlock(&netopeer_state.global_lock);
				break;
			}

			client_tid = netopeer_state.clients->tid;

			if (client_tid != NULL) {
				if (netopeer_state.clients->pthread_status == JOINABLE) {
					netopeer_state.clients->pthread_status = JOINED;
					/* GLOBAL READ UNLOCK */
					pthread_rwlock_unlock(&netopeer_state.global_lock);

					ret = pthread_join(client_tid, NULL);

					if (ret != 0) {
						nc_verb_error("Failed to join client thread (%s).", strerror(ret));
					}
				} else {
					/* GLOBAL READ UNLOCK */
					pthread_rwlock_unlock(&netopeer_state.global_lock);
					/* Call Home app is already waiting for it, let it handle it */
					sleep(1);
					continue;
				}
			} else {
				/* GLOBAL READ UNLOCK */
				pthread_rwlock_unlock(&netopeer_state.global_lock);
			}
		}

#ifdef NP_SSH
		np_ssh_cleanup();
#endif
#ifdef NP_TLS
		np_tls_cleanup();
#endif
	}
}

#if 1 /* ZyXEL */

int certificate_verify(void)
{
	FILE *fp = NULL;
	char cmd[256] = {0};
	char line[256] = {0};

	sprintf(cmd, "/usr/bin/verify_cert %s fingerprint 2> /dev/null", ZLDSYSPARM_CERT_DEV);
	fp = popen(cmd, "r");
	if(fp)
	{
		fgets(line, sizeof(line), fp);
		pclose(fp);
	}

	if( (strlen(line)) && (strstr(line, "SHA1 Fingerprint=") ) )
	{
		if( ( strlen(line) == strlen("SHA1 Fingerprint=") ) ){
			/* Cert missing. */
			return 0;
		}
	}else{
		/* Parse error. */
		return 0;
	}

	sprintf(cmd, "/usr/bin/verify_cert %s enddate 2> /dev/null", ZLDSYSPARM_CERT_DEV);
	fp = popen(cmd, "r");
	if(fp)
	{
		fgets(line, sizeof(line), fp);
		pclose(fp);
	}

	if( (strlen(line)) && (strstr(line, "notAfter=")) ){
		return (cert_valid_check(line));
	}else{
		return 0;
	}

	return 1;
}

int certificate_check(void)
{
	uint32_t reason_code = 0;

	if(!certificate_verify())
	{
		int min = 0, max = 3, seconds = 0;
		unsigned char macaddr[6], serial[32], cmd[200];

		zykit_mrd_get_etheraddr(macaddr);
		zykit_mrd_get_serial_no((char *)serial);

		/* before exec blueberry sleep a random seconds (0s ~ 3s) */
		pid_t pid = getpid();
		srand((unsigned int)pid);
		seconds = rand() % (max - min + 1) + min;
		sleep(seconds);

		sprintf(cmd, "/usr/bin/blueberry %02X%02X%02X%02X%02X%02X %s 2> /dev/null", macaddr[0], macaddr[1], macaddr[2], macaddr[3], macaddr[4], macaddr[5], serial);
		system(cmd);
		system("/usr/bin/cert_util -d /var/netopeer/netopeer/cfgnetopeer/datastore.xml -m "ZLDSYSPARM_CERT_DEV" 2> /dev/null");
		if(!certificate_verify())
		{
			/* When Get certificate failed, show reason on GUI & zylog */
			reason_code |= ( 1U << CERT_FAILED );
			zylog_agent_in_netconf("Nebula connection failed", &reason_code);
			nc_verb_error("(%s)Get certificate fail! Delay 45 seconds...\n\r", __func__);
			sleep(45);
			return 0;
		}
	}
	return 1;
}
#endif

int main(int argc, char** argv) {
	struct sigaction action;
	sigset_t block_mask;

	char *aux_string = NULL, path[PATH_MAX+1];
	int next_option;
	int daemonize = 0, len;
	int listen_init = 1;
	struct np_module* netopeer_module = NULL, *server_module = NULL;

	/* initialize message system and set verbose and debug variables */
	if ((aux_string = getenv(ENVIRONMENT_VERBOSE)) == NULL) {
		netopeer_options.verbose = NC_VERB_ERROR;
	} else {
		netopeer_options.verbose = atoi(aux_string);
	}
#if 1 /*ZyXEL*/
        /* Some table in database need initialize in this step */
	char msg[256];
	char db_msg[256];
	struct parser_module *module = NULL;
	void *client_fd = NULL;

	module = parser_open("dbcmd");

	if((client_fd = (*module->init_sock)(PARSER_ROLE)) != NULL) {
		(*module->gen_cmd)(client_fd, msg, "dbctl", "-a", "Nebula", NULL);
		(*module->gen_cmd)(client_fd, msg, "dbctl", "-t", "Nebula", "-i", STATUS_KEY_NAME, NULL);
		(*module->gen_cmd)(client_fd, msg, "dbctl", "-t", "Nebula", "-i", NEBULA_CALLHOME, NULL);
		(*module->gen_cmd)(client_fd, msg, "dbctl", "-t", "Nebula", "-i", KEEP_ALIVE, NULL);
		set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "connect_failed_reason", "", db_msg);
		set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN", "0", db_msg);
		set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN_CLI", "0", db_msg);
		set_to_db(NEBULA_TABLE_NAME, NEBULA_CALLHOME, "port", "", db_msg);
	}
#endif
	aux_string = NULL; /* for sure to avoid unwanted changes in environment */

#if OPENSSL_VERSION_NUMBER < 0x10101000L
	{
		COMP_METHOD *comp_method;
		comp_method = COMP_zlib();
		if(comp_method != NULL)
		{
			if (comp_method->type != NID_undef)
			{
				nc_verb_verbose("Compression name: %s\n", (comp_method->name !=
							NULL? comp_method->name:""));
				SSL_COMP_add_compression_method(1, comp_method);
			}
			else
			{
				nc_verb_error("Compression is not suported\n");
			}
		}
		else
		{
			nc_verb_error("Failed to init compression\n");
		}
	}
#endif

	/* parse given options */
	while ((next_option = getopt(argc, argv, OPTSTRING)) != -1) {
		switch (next_option) {
		case 'd':
			daemonize = 1;
			break;
		case 'h':
			print_usage(argv[0]);
			break;
		case 'v':
			netopeer_options.verbose = atoi(optarg);
			break;
		case 'V':
			print_version(argv[0]);
			break;
		default:
			print_usage(argv[0]);
			break;
		}
	}

	/* set signal handler */
	sigfillset (&block_mask);
	action.sa_handler = signal_handler;
	action.sa_mask = block_mask;
	action.sa_flags = 0;
	sigaction(SIGINT, &action, NULL);
	sigaction(SIGQUIT, &action, NULL);
	sigaction(SIGTERM, &action, NULL);
	sigaction(SIGHUP, &action, NULL);
#if 1 /* ZyXEL */
	sigaction(SIGPIPE, &action, NULL);
#endif
#if 1 /* ZyXEL */
restart:
#endif
	nc_callback_print(clb_print);

	/* normalize value if not from the enum */
	if (netopeer_options.verbose > NC_VERB_DEBUG) {
		netopeer_options.verbose = NC_VERB_DEBUG;
	}
	nc_verbosity(netopeer_options.verbose);

	/* go to the background as a daemon */
	if (daemonize == 1) {
		if (daemon(0, 0) != 0) {
			nc_verb_error("Going to background failed (%s)", strerror(errno));
			return EXIT_FAILURE;
		}
		openlog("netopeer-server", LOG_PID, LOG_DAEMON);
	} else {
		openlog("netopeer-server", LOG_PID|LOG_PERROR, LOG_DAEMON);
	}

	/* make sure we were executed by root */
	if (geteuid() != 0) {
		nc_verb_error("Failed to start, must have root privileges.");
		return EXIT_FAILURE;
	}

	/*
	 * this initialize the library and check potential ABI mismatches
	 * between the version it was compiled for and the actual shared
	 * library used.
	 */
	LIBXML_TEST_VERSION

	/* initialize library including internal datastores and maybee something more */
#if 1 /* ZyXEL */
	if(server_start == 0)
	{
		if(!certificate_check())
		{
			nc_verb_error("(%s)Get certificate fail! Exit netopeer server!\n\r", __func__);
			return EXIT_FAILURE;
		}
#endif
		if (nc_init(NC_INIT_ALL | NC_INIT_MULTILAYER) < 0) {
			nc_verb_error("Library initialization failed.");
			return EXIT_FAILURE;
		}
#if 1 /* ZyXEL */
		server_start = 1;
	}
#endif

#if 0 /* ZyXEL */
restart:
#endif
	/* start NETCONF server module */
	if ((server_module = calloc(1, sizeof(struct np_module))) == NULL) {
		nc_verb_error("Creating necessary NETCONF server plugin failed!");
		return EXIT_FAILURE;
	}
	server_module->name = strdup(NCSERVER_MODULE_NAME);
	if (module_enable(server_module, 0)) {
		nc_verb_error("Starting necessary NETCONF server plugin failed!");
		free(server_module->name);
		free(server_module);
		return EXIT_FAILURE;
	}

	/* start netopeer device module - it will start all modules that are
	 * in its configuration and in server configuration */
	if ((netopeer_module = calloc(1, sizeof(struct np_module))) == NULL) {
		nc_verb_error("Creating necessary Netopeer plugin failed!");
		module_disable(server_module, 1);
		return EXIT_FAILURE;
	}
	netopeer_module->name = strdup(NETOPEER_MODULE_NAME);
	if (module_enable(netopeer_module, 0)) {
		nc_verb_error("Starting necessary Netopeer plugin failed!");
		module_disable(server_module, 1);
		free(netopeer_module->name);
		free(netopeer_module);
		return EXIT_FAILURE;
	}
#if 0 /* ZyXEL */
	server_start = 0;
#endif
	nc_verb_verbose("Netopeer server successfully initialized.");
#if 1 /* ZyXEL */
	if(server_start == 1)
	{
		char cmd[256] = {0};
#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
		snprintf(cmd, sizeof(cmd), "cp -rf /etc_writable/zyxel/conf/netopeer/* /var/netopeer/netopeer/ 2>/dev/null");
#else
		snprintf(cmd, sizeof(cmd), "cp -rf /etc/zyxel/ftp/netopeer/* /var/netopeer/netopeer/ 2>/dev/null");
#endif
		system(cmd);
		nc_verb_verbose("Copy running configuration from conf partition.\n\r");
	}
	server_start = 0;
#endif

	listen_loop(listen_init);

	/* unload Netopeer module -> unload all modules */
	module_disable(server_module, 1);
	module_disable(netopeer_module, 1);

	/* main cleanup */

	if (!restart_soft) {
		/* close libnetconf only when shutting down or hard restarting the server */
		nc_close();
	}

	if (restart_soft) {
#if 0 /* ZyXEL */
		nc_verb_verbose("Server is going to soft restart.");
#endif
		restart_soft = 0;
		listen_init = 0;
#if 1 /* ZyXEL */
		server_start = 2;
#endif
		goto restart;
	} else if (restart_hard) {
		nc_verb_verbose("Server is going to hard restart.");
		len = readlink("/proc/self/exe", path, PATH_MAX);
		if (len > 0) {
			path[len] = 0;
			xmlCleanupParser();
			execv(path, argv);
		}
		nc_verb_error("Failed to get the path to self.");
		xmlCleanupParser();
		return EXIT_FAILURE;
	}

	/*
	 *Free the global variables that may
	 *have been allocated by the parser.
	 */
	xmlCleanupParser();

	return EXIT_SUCCESS;
}

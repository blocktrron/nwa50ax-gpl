/**
 * \file netconf-server-transapi.c
 * \author Radek Krejci <rkrejci@cesnet.cz>
 * @brief NETCONF device module to configure netconf server following
 * ietf-netconf-server data model
 *
 * Copyright (C) 2014 CESNET, z.s.p.o.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Company nor the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * ALTERNATIVELY, provided that this notice is retained in full, this
 * product may be distributed under the terms of the GNU General Public
 * License (GPL) version 2 or later, in which case the provisions
 * of the GPL apply INSTEAD OF those given above.
 *
 * This software is provided ``as is, and any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 * In no event shall the company or contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential
 * damages (including, but not limited to, procurement of substitute
 * goods or services; loss of use, data, or profits; or business
 * interruption) however caused and on any theory of liability, whether
 * in contract, strict liability, or tort (including negligence or
 * otherwise) arising in any way out of the use of this software, even
 * if advised of the possibility of such damage.
 */

/*
 * This is automatically generated callbacks file
 * It contains 3 parts: Configuration callbacks, RPC callbacks and state data callbacks.
 * Do NOT alter function signatures or any structures unless you know exactly what you are doing.
 */

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <poll.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <ctype.h>
#include <arpa/nameser.h>
#include <resolv.h>


#include <libxml/tree.h>
#include <libnetconf_xml.h>
#include <libnetconf_ssh.h>

#include "server.h"

#if 1 /* ZyXEL */
#include "capwap_cli/rrm_common.h"
#include "capwap_cli/sta.h"
#include "zld-spec.h"
#include "zy_nc_srv_plugin.h"
#include "socks.h"
#include <zykit.h>

#define STANDALONE_LONG_WAIT_TIME_SEC 1800
#define STANDALONE_LONG_WAIT_TIME_CONDI 604800 /* 7 days */
#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
#define NEBULA_STATUS "/etc_writable/zyxel/conf/nebula-status"
#else
#define NEBULA_STATUS "/etc/zyxel/ftp/nebula/nebula-status"
#endif
#define STATUS_KEY_NAME "nebula-status"
#define PROXY_MODE_LEN 32
#define PROXY_AUTH_LEN 32
#define PROXY_HOST_LEN 32
#define PROXY_PORT_LEN 10
#define PROXY_USER_LEN 70
#define PROXY_PASS_TMP_LEN 150
#define PROXY_PASS_LEN 64
#define NO_ZYLOG 0
#define ZYLOG 1

static uint32_t netconf_disconnect_reason_code = 0;
#endif

static const char rcsid[] __attribute__((used)) ="$Id: "__FILE__": "RCSID" $";

extern struct np_state netopeer_state;
extern struct np_options netopeer_options;
extern int quit;
static int get_ip_count = 0;
/* EXPORT FUNCTION */
extern int bohr(char *b64_buffer, char *password);

static struct ch_app* callhome_apps = NULL;

static void free_all_bind_addr(struct np_bind_addr** list) {
	struct np_bind_addr* prev;

	if (list == NULL) {
		return;
	}

	while (*list != NULL) {
		prev = *list;
		*list = (*list)->next;
		free(prev->addr);
		free(prev);
	}
}

static void add_bind_addr(struct np_bind_addr** root, NC_TRANSPORT transport, const char* addr, unsigned int port) {
	struct np_bind_addr* cur;

	if (root == NULL) {
		return;
	}

	if (*root == NULL) {
		*root = malloc(sizeof(struct np_bind_addr));
		(*root)->transport = transport;
		(*root)->addr = strdup(addr);
		(*root)->port = port;
		(*root)->next = NULL;
		return;
	}

	for (cur = *root; cur->next != NULL; cur = cur->next);

	cur->next = malloc(sizeof(struct np_bind_addr));
	cur->next->transport = transport;
	cur->next->addr = strdup(addr);
	cur->next->port = port;
	cur->next->next = NULL;
}

static void del_bind_addr(struct np_bind_addr** root, NC_TRANSPORT transport, const char* addr, unsigned int port) {
	struct np_bind_addr* cur, *prev = NULL;

	if (root == NULL || addr == NULL) {
		return;
	}

	for (cur = *root; cur != NULL; cur = cur->next) {
		if (cur->transport == transport && strcmp(cur->addr, addr) == 0 && cur->port == port) {
			if (prev == NULL) {
				/* we're deleting the root */
				*root = cur->next;
				free(cur->addr);
				free(cur);
			} else {
				/* standard list member deletion */
				prev->next = cur->next;
				free(cur->addr);
				free(cur);
			}
			return;
		}
		prev = cur;
	}
}

/* Signal to libnetconf that configuration data were modified by any callback.
 * 0 - data not modified
 * 1 - data have been modified
 */
int server_config_modified = 0;

/*
 * Determines the callbacks order.
 * Set this variable before compilation and DO NOT modify it in runtime.
 * TRANSAPI_CLBCKS_LEAF_TO_ROOT (default)
 * TRANSAPI_CLBCKS_ROOT_TO_LEAF
 */
const TRANSAPI_CLBCKS_ORDER_TYPE callbacks_order = TRANSAPI_CLBCKS_ORDER_DEFAULT;

/* Do not modify or set! This variable is set by libnetconf to announce edit-config's error-option
Feel free to use it to distinguish module behavior for different error-option values.
 * Possible values:
 * NC_EDIT_ERROPT_STOP - Following callback after failure are not executed, all successful callbacks executed till
                         failure point must be applied to the device.
 * NC_EDIT_ERROPT_CONT - Failed callbacks are skipped, but all callbacks needed to apply configuration changes are executed
 * NC_EDIT_ERROPT_ROLLBACK - After failure, following callbacks are not executed, but previous successful callbacks are
                         executed again with previous configuration data to roll it back.
 */
NC_EDIT_ERROPT_TYPE server_erropt = NC_EDIT_ERROPT_NOTSET;

static char* get_node_content(xmlNodePtr node) {
	if (node == NULL || node->children == NULL) {
		return NULL;
	}
	return (char*)node->children->content;
}

xmlDocPtr server_get_state_data(xmlDocPtr UNUSED(model), xmlDocPtr UNUSED(running), struct nc_err **UNUSED(err)) {
	/* model doesn't contain any status data */
	return NULL;
}
/*
 * Mapping prefixes with namespaces.
 * Do NOT modify this structure!
 */
struct ns_pair server_namespace_mapping[] = {{"srv", "urn:ietf:params:xml:ns:yang:ietf-netconf-server"}, {NULL, NULL}};

int callback_srv_netconf_srv_listen_srv_port(XMLDIFF_OP op, xmlNodePtr old_node, xmlNodePtr new_node, struct nc_err** error, NC_TRANSPORT transport) {
	unsigned int port = 0, new_port = 0;
	char* content;

	if (op & (XMLDIFF_REM | XMLDIFF_MOD)) {
		content = get_node_content(old_node);
		if (content == NULL) {
			nc_verb_error("%s: internal error at %s:%s", __func__, __FILE__, __LINE__);
			*error = nc_err_new(NC_ERR_OP_FAILED);
			nc_err_set(*error, NC_ERR_PARAM_MSG, "Check server logs.");
			return EXIT_FAILURE;
		}
		port = atoi(content);
	}

	if (op & (XMLDIFF_MOD | XMLDIFF_ADD)) {
		content = get_node_content(new_node);
		if (content == NULL) {
			nc_verb_error("%s: internal error at %s:%s", __func__, __FILE__, __LINE__);
			*error = nc_err_new(NC_ERR_OP_FAILED);
			nc_err_set(*error, NC_ERR_PARAM_MSG, "Check server logs.");
			return EXIT_FAILURE;
		}
		new_port = atoi(content);
	}

	/* BINDS LOCK */
	pthread_mutex_lock(&netopeer_options.binds_lock);

	if (op & (XMLDIFF_REM | XMLDIFF_MOD)) {
		del_bind_addr(&netopeer_options.binds, transport, "::0", port);
		netopeer_options.binds_change_flag = 1;

		nc_verb_verbose("%s: %s stopped listening on the port %d", __func__, (transport == NC_TRANSPORT_SSH ? "SSH" : "TLS"), port);
	}
	if (op & (XMLDIFF_MOD | XMLDIFF_ADD)) {
		add_bind_addr(&netopeer_options.binds, transport, "::0", new_port);
		netopeer_options.binds_change_flag = 1;

		nc_verb_verbose("%s: %s listening on the port %d", __func__, (transport == NC_TRANSPORT_SSH ? "SSH" : "TLS"), new_port);
	}

	/* BINDS UNLOCK */
	pthread_mutex_unlock(&netopeer_options.binds_lock);

	return EXIT_SUCCESS;
}

int callback_srv_netconf_srv_listen_srv_interface(XMLDIFF_OP op, xmlNodePtr old_node, xmlNodePtr new_node, struct nc_err** error, NC_TRANSPORT transport) {
	xmlNodePtr cur;
	char* addr = NULL, *new_addr = NULL, *content;
	unsigned int port = 0, new_port = 0;

	if (op & (XMLDIFF_REM | XMLDIFF_MOD)) {
		for (cur = old_node->children; cur != NULL; cur = cur->next) {
			if (cur->type != XML_ELEMENT_NODE) {
				continue;
			}

			if (xmlStrEqual(cur->name, BAD_CAST "address")) {
				addr = get_node_content(cur);
			}
			if (xmlStrEqual(cur->name, BAD_CAST "port")) {
				content = get_node_content(cur);
				if (content != NULL) {
					port = atoi(content);
				}
			}
		}

		if (addr == NULL || port == 0) {
			nc_verb_error("%s: missing either address or port at %s:%s", __func__, __FILE__, __LINE__);
			*error = nc_err_new(NC_ERR_OP_FAILED);
			nc_err_set(*error, NC_ERR_PARAM_MSG, "Check server logs.");
			return EXIT_FAILURE;
		}
	}

	if (op & (XMLDIFF_MOD | XMLDIFF_ADD)) {
		for (cur = new_node->children; cur != NULL; cur = cur->next) {
			if (cur->type != XML_ELEMENT_NODE) {
				continue;
			}

			if (xmlStrEqual(cur->name, BAD_CAST "address")) {
				new_addr = get_node_content(cur);
			}
			if (xmlStrEqual(cur->name, BAD_CAST "port")) {
				content = get_node_content(cur);
				if (content != NULL) {
					new_port = atoi(content);
				}
			}
		}

		if (new_addr == NULL || new_port == 0) {
			nc_verb_error("%s: missing either address or port at %s:%s", __func__, __FILE__, __LINE__);
			*error = nc_err_new(NC_ERR_OP_FAILED);
			nc_err_set(*error, NC_ERR_PARAM_MSG, "Check server logs.");
			return EXIT_FAILURE;
		}
	}

	/* BINDS LOCK */
	pthread_mutex_lock(&netopeer_options.binds_lock);

	if (op & (XMLDIFF_REM | XMLDIFF_MOD)) {
		del_bind_addr(&netopeer_options.binds, transport, addr, port);
		netopeer_options.binds_change_flag = 1;

		nc_verb_verbose("%s: %s stopped listening on the address %s:%d", __func__, (transport == NC_TRANSPORT_SSH ? "SSH" : "TLS"), addr, port);
	}
	if (op & (XMLDIFF_MOD | XMLDIFF_ADD)) {
		add_bind_addr(&netopeer_options.binds, transport, new_addr, new_port);
		netopeer_options.binds_change_flag = 1;

		nc_verb_verbose("%s: %s listening on the address %s:%d", __func__, (transport == NC_TRANSPORT_SSH ? "SSH" : "TLS"), new_addr, new_port);
	}

	/* BINDS UNLOCK */
	pthread_mutex_unlock(&netopeer_options.binds_lock);

	return EXIT_SUCCESS;
}

static xmlNodePtr find_node(xmlNodePtr parent, xmlChar* name) {
	xmlNodePtr child;

	for (child = parent->children; child != NULL; child = child->next) {
		if (child->type != XML_ELEMENT_NODE) {
			continue;
		}
		if (xmlStrcmp(name, child->name) == 0) {
			return child;
		}
	}

	return NULL;
}

#if 1 /* ZyXEL */
int hostname_to_ip(char *hostname , char *ip)
{
	struct addrinfo hints, *servinfo, *p;
	struct sockaddr_in *h;
	int rv, ret = 0;

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET; // use AF_INET to force IPv4
	hints.ai_socktype = SOCK_STREAM;
	
	res_init();
	if ((rv = getaddrinfo( hostname , NULL , &hints , &servinfo)) != 0 )
	{
		if(get_ip_count <= 3){
			get_ip_count++;
			return ret;
                }
		if ((rv = query_hostname_by_default_dns(hostname, ip)) != 0)
		{
			netconf_disconnect_reason_code |= ( 1U << DNS_FAILED );
			nc_verb_error("%s: getaddrinfo %s\n", __func__, gai_strerror(rv));
			return ret;
		}
		ret = 1;
	}
	else
	{	// loop through all the results and connect to the first we can
		for(p = servinfo; p != NULL; p = p->ai_next)
		{
			h = (struct sockaddr_in *) p->ai_addr;
			strcpy(ip , inet_ntoa( h->sin_addr ) );
			ret = 1;
			break;
		}
		freeaddrinfo(servinfo); // all done with this structure
	}
	netconf_disconnect_reason_code &= ~( 1U << DNS_FAILED );
	return ret;
}
#endif

#if 1 /* ZyXEL */
#define VALID_FQDN_LEN 255 /* rfc1035 2.3.4 */
static struct client_struct* sock_connect(const char* ori_address, uint16_t port) {
	struct client_struct* ret = NULL;
#else
static struct client_struct* sock_connect(const char* address, uint16_t port) {
	struct client_struct* ret;
#endif
	int is_ipv4;

	struct sockaddr_in* saddr4;
	struct sockaddr_in6* saddr6;

#if 1 /* ZyXEL */
	char hostname[VALID_FQDN_LEN + 1] = {0};
	char *host = hostname;
	char ip_address[INET6_ADDRSTRLEN] = {0};
	char *address = ip_address;
	char proxymode[PROXY_MODE_LEN];
	char proxyauthfailed[PROXY_AUTH_LEN];
	char cmd[128];
	int syncnt = 1;
	int syncnt_sz = sizeof(syncnt);
	int dontfragment = 0; /* 0 is disable TCP dont fragment */
#endif

	ret = calloc(1, sizeof(struct client_struct));
#if 1 /* ZyXEL */
	if (ret == NULL) {
		nc_verb_error("%s: socket connect calloc failed", __func__);
		return NULL;
	}
#endif
	ret->sock = -1;

#if 1 /* ZyXEL */
	/* hostname check */
	strcpy(host, ori_address);
	if(isalpha(host[0]))
	{
		char ip_address_tmp[INET6_ADDRSTRLEN] = {0};
		char *ip = ip_address_tmp;

		/* support only IPv4 now */
		if(hostname_to_ip(host , ip))
			strncpy(address, ip, INET6_ADDRSTRLEN);
		else
		{
			nc_verb_error("%s: hostname to ip address failed", __func__);
			goto fail;
		}
	}
	else
		strncpy(address, host, INET6_ADDRSTRLEN);
#endif

#if 1 /* ZyXEL */
	get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "active", proxymode);
	get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "failed_auth", proxyauthfailed);

	if(strcmp(proxymode, "1") || !strcmp(proxyauthfailed, "N/A")){
		sprintf(cmd, "/usr/local/bin/dbctl -t %s -k %s -f failed_auth -s 0", NEBULA_TABLE_NAME, PROXY_KEY_NAME);
		system(cmd);
	}

	if(!strcmp(proxymode, "1"))
	{
		struct addrinfo proxyhints;
		struct addrinfo hints;
		memset(&proxyhints, 0, sizeof(struct addrinfo));
		memset(&hints, 0, sizeof(struct addrinfo));

                char callhome_port[16] = {0};
                snprintf(callhome_port, sizeof(callhome_port), "%d", port);
                char *netconfport = callhome_port;
		char proxyhost[PROXY_HOST_LEN] = {'\0'};
		char proxyport[PROXY_PORT_LEN] = {'\0'};
		char proxyauth[PROXY_AUTH_LEN] = {'\0'};
		char proxyuser[PROXY_USER_LEN] = {'\0'};
		char proxypass_tmp[PROXY_PASS_TMP_LEN] = {'\0'};
		char proxypass[PROXY_PASS_LEN] = {'\0'};

		get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "server", proxyhost);
		get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "port", proxyport);
		get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "auth_active", proxyauth);
		if(!strcmp(proxyauth, "1")){
			get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "auth_username", proxyuser);
			get_from_db(NEBULA_TABLE_NAME, PROXY_KEY_NAME, "auth_password", proxypass_tmp);

#ifdef ZLDCONFIG_PCI_DSS_SUPPORT
			if((strlen(proxypass_tmp))>12){
        		if(bohr(proxypass_tmp+12, proxypass) < 0){
					nc_verb_error("ZLD-Password: decrypted proxypass error!\n");
					goto fail;
				}
			}else{
				sprintf(proxypass, "N/A");
			}
#endif
		}
		proxyhints.ai_family = AF_INET;
		proxyhints.ai_socktype = SOCK_STREAM;
		proxyhints.ai_protocol = IPPROTO_TCP;

		nc_verb_verbose("Proxy mode enabled");

		if((ret->sock = socks_connect(host, netconfport, hints, proxyhost, proxyport, proxyhints, -1, proxyauth, proxyuser, proxypass)) == -1) {
			nc_verb_error("%s: connect proxy failed (%s)", __func__, strerror(errno));
			goto fail;
		}
		goto success;
	}
#endif

	if (strchr(address, ':') != NULL) {
		is_ipv4 = 0;
	} else {
		is_ipv4 = 1;
	}

	if ((ret->sock = socket((is_ipv4 ? AF_INET : AF_INET6), SOCK_STREAM, IPPROTO_TCP)) == -1) {
		nc_verb_error("%s: creating socket failed (%s)", __func__, strerror(errno));
		goto fail;
	}
#if 1 /* ZyXEL */
	if (setsockopt(ret->sock, IPPROTO_TCP, TCP_SYNCNT, &syncnt, syncnt_sz) < 0) {
                nc_verb_error("%s: setting sockopt TCP_SYNCNT failed", __func__);
                goto fail;
        }

	if (setsockopt(ret->sock, IPPROTO_IP, IP_MTU_DISCOVER, &dontfragment, sizeof(dontfragment))) {
		nc_verb_error("%s: setting sockopt IP_MTU_DISCOVER failed", __func__);
		goto fail;
	}
#endif
	if (is_ipv4) {
		saddr4 = (struct sockaddr_in*)&ret->saddr;

		saddr4->sin_family = AF_INET;
		saddr4->sin_port = htons(port);

		if (inet_pton(AF_INET, address, &saddr4->sin_addr) != 1) {
			nc_verb_error("%s: failed to convert IPv4 address \"%s\"", __func__, address);
			goto fail;
		}

		if (connect(ret->sock, (struct sockaddr*)saddr4, sizeof(struct sockaddr_in)) == -1) {
			nc_verb_error("Call Home: could not connect to %s:%u (%s)", address, port, strerror(errno));
			goto fail;
		}

	} else {
		saddr6 = (struct sockaddr_in6*)&ret->saddr;

		saddr6->sin6_family = AF_INET6;
		saddr6->sin6_port = htons(port);

		if (inet_pton(AF_INET6, address, &saddr6->sin6_addr) != 1) {
			nc_verb_error("%s: failed to convert IPv6 address \"%s\"", __func__, address);
			goto fail;
		}

		if (connect(ret->sock, (struct sockaddr*)saddr6, sizeof(struct sockaddr_in6)) == -1) {
			nc_verb_error("Call Home: could not connect %s:%u (%s)",address, port, strerror(errno));
			goto fail;
		}
	}
success:
	nc_verb_verbose("Call Home: connected to %s:%u", address, port);
	sprintf(cmd, "/usr/local/bin/dbctl -t %s -k %s -f failed_auth -s 0", NEBULA_TABLE_NAME, PROXY_KEY_NAME);
	system(cmd);
	return ret;

fail:
	if(ret->sock != -1)
	{
		close(ret->sock);
	}
	free(ret);
	return NULL;
}

pthread_mutex_t callhome_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t callhome_cond = PTHREAD_COND_INITIALIZER;
volatile struct ch_app* callhome_app = NULL;

#if 1 /* ZyXEL */ /* ZLDCONFIG_CLOUD_MODE_SUPPORT */
static void rrm_sta_notify(struct sta_module_msg *sta_msg)
{
	sta_lib_check_ch((char *)NULL);
	sta_lib_notify(sta_msg);
	return;
}

static void notify_cc_status(enum reg_type type)
{
	struct sta_module_msg sta_msg;

	sta_msg.op = STA_MODULE_NOTIFY;
	sta_msg.info.type = type;

	rrm_sta_notify(&sta_msg);
}
#endif

#if 1 /* ZyXEL */
void nc_ntp_try_sync(void){
	int i = 0;
	int status, retval = -1;

	char cmd[64] = {'\0'};
	char *ntp_server_list[]={
		"0.pool.ntp.org",
		"1.pool.ntp.org",
		"2.pool.ntp.org"};

#define NTP_NUMBER (sizeof(ntp_server_list)/sizeof(char *))

	srand(time(NULL));
	i = rand() % NTP_NUMBER;
	sprintf(cmd, "ntpdate \"%s\" 2>&1>>/dev/null", ntp_server_list[i]);

	status = system(cmd);

	if(WIFEXITED(status))
		retval = WEXITSTATUS(status);

	return;
}
#endif
/* each app has its own thread */
__attribute__((noreturn))
static void* app_loop(void* app_v) {
	struct ch_app* app = (struct ch_app*)app_v;
	struct ch_server* cur_server = NULL;
	struct timespec ts;
	struct timeval start_time;
	struct timeval cur_time;
	char db_port[16] = {'\0'};
	char db_msg[256];
	char left_time[256] = {0};
	int standalone_sleep_time = 0;
	int i, ret;
	int j = 0, sleep_time = 15; /* Dynamic sleep time for standalone mode */
	uint32_t reason_code = 0;
	/* TODO sigmask for the thread? */

	nc_verb_verbose("Starting Call Home thread (%s).", app->name);

	nc_session_transport(app->transport);

#if 1   /* ZyXEL */
	for (;;) {
		if (nc_get_ip_status()) {
			/* NTP sync */
			nc_ntp_try_sync();
			break;
		}
		nc_verb_error("[%s:%d] check ip status failed", __func__, __LINE__);
		sleep(1);
        }
	gettimefromsys(&start_time.tv_sec);
#endif
	for (;;) {
		pthread_testcancel();

		/* get last connected server if any */
		for (cur_server = app->servers; cur_server != NULL && cur_server->active == 0; cur_server = cur_server->next);
		if (cur_server == NULL) {
			/*
			 * first-listed start-with's value is set in config or this is the
			 * first attempt to connect, so use the first listed server spec
			 */
			cur_server = app->servers;
		} else {
			/* remove active flag */
			cur_server->active = 0;
		}
		/* try to connect to a server indefinitely */
		for (;;) {
			for (i = 0; i < app->rec_count; ++i) {
				if ((app->client = sock_connect(cur_server->address, cur_server->port)) != NULL) {
                    			app->client->transport = app->transport;
#if 1	/* ZyXEL */
					nc_debug_procedure( SUCCESS, &netconf_disconnect_reason_code, cur_server->port );
#endif
					get_ip_count = 0;
					break;
				}
				sleep(app->rec_interval);
			}
#if 1   /*ZyXEL*/
			/*Set current port to db*/
			snprintf(db_port, sizeof(db_port), "%d", cur_server->port);
			set_to_db(NEBULA_TABLE_NAME, NEBULA_CALLHOME, "port", db_port, db_msg);
#endif
			if (app->client != NULL) {
				break;
			}
#if 1    /* ZyXEL */
			if(WHOPMODE_CLOUD == netconf_kit_wlan_get_hybridmode()
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
				&& !managed_to_cloud_flag()
#endif
			){
				nc_verb_error("[%s:%d] Netconf is unable to connect NCC by port %d", __func__, __LINE__,cur_server->port);
			}
#endif
			cur_server = cur_server->next;

			if (cur_server == NULL) {
#if 1    /* ZyXEL */
                        	if(WHOPMODE_CLOUD == netconf_kit_wlan_get_hybridmode()) {
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
					if (managed_to_cloud_flag())
					{
						nc_debug_procedure( CONNECT_FAIL, &netconf_disconnect_reason_code, 0 );
						sleep(30);
					} else
#endif
					{
						nc_debug_procedure( CONNECT_FAIL, &netconf_disconnect_reason_code, 0 );
					}
				}

				if(WHOPMODE_STANDALONE == netconf_kit_wlan_get_hybridmode()) {
					nc_debug_procedure( CONNECT_FAIL, &netconf_disconnect_reason_code, 0 );
					gettimefromsys(&cur_time.tv_sec);
					/* Dynamic sleep time 15s/30s/60s/120s/180s  */
					if(j < 4) {
						standalone_sleep_time = sleep_time*(MyPower(2,j));
						j++;
					} else {
						if(timeval_diff(cur_time, start_time) >= STANDALONE_LONG_WAIT_TIME_CONDI) {
							/* AP is standalone mode lasting 7 days */
							standalone_sleep_time = STANDALONE_LONG_WAIT_TIME_SEC;
						} else {
							standalone_sleep_time = 180;
						}
					}

					snprintf(left_time, sizeof(left_time), "%d", cur_time.tv_sec + standalone_sleep_time);
					set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "NEXT_TIME_CALLHOME", left_time, db_msg);
					sleep(standalone_sleep_time);

					/* Standalone AP no wlan_module for notify */
					set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN", "0", db_msg);
				}

				notify_cc_status(NETOPEER_OFFLINE);
#endif
				cur_server = app->servers;
			}
		}

		/* publish the new client for the main application loop to create a new session */
		/* CALLHOME LOCK */
		pthread_mutex_lock(&callhome_lock);
		while (callhome_app) {
			/* someone else is waiting already, let's wait with them */
			pthread_cond_wait(&callhome_cond, &callhome_lock);
		}
		callhome_app = app;

		while (callhome_app) {
			/* wait for client thread creation */
			pthread_cond_wait(&callhome_cond, &callhome_lock);
		}

		/* CALLHOME UNLOCK */
		pthread_mutex_unlock(&callhome_lock);

		if (!app->client) {
			nc_verb_error("Call Home (app %s) client creation failed.", app->name);
			continue;
		}

		cur_server->active = 1;

#if 1 /* ZyXEL */
		if(!quit) {
			set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN_CLI", "1", db_msg);

			if (WHOPMODE_STANDALONE == netconf_kit_wlan_get_hybridmode()) {
				/* Standalone AP no wlan_module for notify */
				set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN", "1", db_msg);
			}
			notify_cc_status(NETOPEER_ONLINE);
			if(!access(NEBULA_STATUS, F_OK))
				notify_cc_status(NETOPEER_CLAIM);
			else
				notify_cc_status(NETOPEER_DECLAIM);
		}
#endif
		if (app->connection) {
			/* periodic connection */
			while (1) {
				clock_gettime(CLOCK_REALTIME, &ts);
				ts.tv_sec += CALLHOME_PERIODIC_LINGER_CHECK;
				ret = pthread_timedjoin_np(app->client->tid, NULL, &ts);
				if (ret == 0) {
					break;
				} else if (ret == ETIMEDOUT) {
					switch (app->client->transport) {
#ifdef NP_SSH
					case NC_TRANSPORT_SSH:
						i = np_ssh_chapp_linger_check(app);
						break;
#endif
#ifdef NP_TLS
					case NC_TRANSPORT_TLS:
						i =  np_tls_chapp_linger_check(app);
						break;
#endif
					default:
						nc_verb_error("%s: unknown client transport", __func__);
					}
					if (i) {
						break;
					}
				} else {
					nc_verb_error("Call Home (app %s) client thread timed join failed (%s).", app->name, strerror(ret));
					app->client->to_free = 1;
					break;
				}
			}
		} else {
			/* persistent connection */
			/* GLOBAL READ LOCK */
			pthread_rwlock_rdlock(&netopeer_state.global_lock);

			if (app->client->pthread_status == JOINABLE) {
				app->client->pthread_status = JOINED;
				/* GLOBAL READ UNLOCK */
				pthread_rwlock_unlock(&netopeer_state.global_lock);

				ret = pthread_join(app->client->tid, NULL);
				if (ret != 0) {
					nc_verb_error("Call Home (app %s) client thread join failed (%s).", app->name, strerror(ret));
				}
			} else {
				/* GLOBAL READ UNLOCK */
				pthread_rwlock_unlock(&netopeer_state.global_lock);
			}
		}
		app->client = NULL;
		nc_verb_verbose("Call Home (app %s) disconnected.", app->name);
#if 1 /* ZyXEL */
		if(!quit) {
			if (WHOPMODE_STANDALONE == netconf_kit_wlan_get_hybridmode()) {
				/* Standalone AP no wlan_module for notify */
				set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "CC_CONN", "0", db_msg);
			}
			notify_cc_status(NETOPEER_OFFLINE);
		}

		if(WHOPMODE_CLOUD == netconf_kit_wlan_get_hybridmode()) {
#ifdef ZLDCONFIG_CAPWAP_WTP_SUPPORT
			if(managed_to_cloud_flag())
			{
				nc_debug_procedure( DISCONNECT, &netconf_disconnect_reason_code, 0 );
				sleep(30);
			} else
#endif
			{
				nc_debug_procedure( DISCONNECT, &netconf_disconnect_reason_code, cur_server->port );
			}
		}

		if(WHOPMODE_STANDALONE == netconf_kit_wlan_get_hybridmode()) {
			nc_debug_procedure( DISCONNECT, &netconf_disconnect_reason_code, 0 );
			gettimefromsys(&cur_time.tv_sec);
			/* Dynamic sleep time 15s/30s/60s/120s/180s  */
			if(j < 4) {
				standalone_sleep_time = sleep_time*(MyPower(2,j));
				j++;
			} else {
				if(timeval_diff(cur_time, start_time) >= STANDALONE_LONG_WAIT_TIME_CONDI) {
					/* AP is standalone mode lasting 7 days */
					standalone_sleep_time = STANDALONE_LONG_WAIT_TIME_SEC;
				} else {
					standalone_sleep_time = 180;
				}
			}

			nc_verb_verbose("[%s:%d] sleep(%d) when disconnected for standalone mode.", __func__, __LINE__, standalone_sleep_time);
			snprintf(left_time, sizeof(left_time), "%d", cur_time.tv_sec + standalone_sleep_time);
			set_to_db(NEBULA_TABLE_NAME, STATUS_KEY_NAME, "NEXT_TIME_CALLHOME", left_time, db_msg);
			sleep(standalone_sleep_time);
		}

		if (quit) {
			pthread_exit(NULL);
		}
#endif
	}
}

static int app_create(xmlNodePtr node, struct nc_err** error, NC_TRANSPORT transport) {
	struct ch_app* new;
	struct ch_server* srv, *del_srv;
	xmlNodePtr auxnode, servernode, childnode;
	xmlChar* auxstr;
	int ret;

	new = calloc(1, sizeof(struct ch_app));
	new->transport = transport;

	/* get name */
	auxnode = find_node(node, BAD_CAST "name");
	new->name = (char*)xmlNodeGetContent(auxnode);

	/* get servers list */
	auxnode = find_node(node, BAD_CAST "servers");
	for (servernode = auxnode->children; servernode != NULL; servernode = servernode->next) {
		if ((servernode->type != XML_ELEMENT_NODE) || (xmlStrcmp(servernode->name, BAD_CAST "server") != 0)) {
			continue;
		}

		/* alloc new server */
		if (new->servers == NULL) {
			new->servers = calloc(1, sizeof(struct ch_server));
			srv = new->servers;
		} else {
			for (srv = new->servers; srv->next != NULL; srv = srv->next);

			/* srv is the last server */
			srv->next = calloc(1, sizeof(struct ch_server));
			srv->next->prev = srv;
			srv = srv->next;
		}

		for (childnode = servernode->children; childnode != NULL; childnode = childnode->next) {
			if (childnode->type != XML_ELEMENT_NODE) {
				continue;
			}
			if (xmlStrcmp(childnode->name, BAD_CAST "address") == 0) {
				if (!srv->address) {
					srv->address = strdup(get_node_content(childnode));
				} else {
					nc_verb_error("%s: duplicated %s address element", __func__, (transport == NC_TRANSPORT_SSH ? "SSH" : "TLS"));
					*error = nc_err_new(NC_ERR_BAD_ELEM);
					nc_err_set(*error, NC_ERR_PARAM_INFO_BADELEM, "/netconf/*/call-home/applications/application/servers/address");
					nc_err_set(*error, NC_ERR_PARAM_MSG, "Duplicated address element");
					goto fail;
				}
			} else if (xmlStrcmp(childnode->name, BAD_CAST "port") == 0) {
				srv->port = atoi(get_node_content(childnode));
			}
		}
		if (srv->address == NULL || srv->port == 0) {
			nc_verb_error("%s: invalid %s address specification (host: %s, port: %s)", __func__, (transport == NC_TRANSPORT_SSH ? "SSH" : "TLS"), srv->address, srv->port);
			*error = nc_err_new(NC_ERR_BAD_ELEM);
			nc_err_set(*error, NC_ERR_PARAM_INFO_BADELEM, "/netconf/*/call-home/applications/application/servers/address");
			goto fail;
		}
	}

	if (new->servers == NULL) {
		nc_verb_error("%s: no server to connect to from %s app", __func__, new->name);
		goto fail;
	}

	/* get reconnect settings */
	auxnode = find_node(node, BAD_CAST "reconnect-strategy");
	for (childnode = auxnode->children; childnode != NULL; childnode = childnode->next) {
		if (childnode->type != XML_ELEMENT_NODE) {
			continue;
		}

		if (xmlStrcmp(childnode->name, BAD_CAST "start-with") == 0) {
			auxstr = xmlNodeGetContent(childnode);
			if (xmlStrcmp(auxstr, BAD_CAST "last-connected") == 0) {
				new->start_server = 1;
			} else {
				new->start_server = 0;
			}
			xmlFree(auxstr);
		} else if (xmlStrcmp(childnode->name, BAD_CAST "interval-secs") == 0) {
			auxstr = xmlNodeGetContent(childnode);
			new->rec_interval = atoi((const char*)auxstr);
			xmlFree(auxstr);
		} else if (xmlStrcmp(childnode->name, BAD_CAST "count-max") == 0) {
			auxstr = xmlNodeGetContent(childnode);
			new->rec_count = atoi((const char*)auxstr);
			xmlFree(auxstr);
		}
	}

	/* get connection settings */
	new->connection = 0; /* persistent by default */
	auxnode = find_node(node, BAD_CAST "connection-type");
	for (childnode = auxnode->children; childnode != NULL; childnode = childnode->next) {
		if (childnode->type != XML_ELEMENT_NODE) {
			continue;
		}
		if (xmlStrcmp(childnode->name, BAD_CAST "periodic") == 0) {
			new->connection = 1;

			auxnode = find_node(childnode, BAD_CAST "timeout-mins");
			auxstr = xmlNodeGetContent(auxnode);
			new->rep_timeout = atoi((const char*)auxstr);
			xmlFree(auxstr);

			auxnode = find_node(childnode, BAD_CAST "linger-secs");
			auxstr = xmlNodeGetContent(auxnode);
			new->rep_linger = atoi((const char*)auxstr);
			xmlFree(auxstr);

			break;
		}
	}

	ret = pthread_create(&(new->thread), NULL, app_loop, new);
	if (ret) {
		nc_verb_error("%s: pthread_create() error (%s)", __func__, strerror(ret));
		goto fail;
	}

	/* insert the created app structure into the list */
	if (!callhome_apps) {
		callhome_apps = new;
		callhome_apps->next = NULL;
		callhome_apps->prev = NULL;
	} else {
		new->prev = NULL;
		new->next = callhome_apps;
		callhome_apps->prev = new;
		callhome_apps = new;
	}

	return EXIT_SUCCESS;

fail:
	for (srv = new->servers; srv != NULL;) {
		del_srv = srv;
		srv = srv->next;

		free(del_srv->address);
		free(del_srv);
	}
	free(new->name);
	free(new);

	return EXIT_FAILURE;
}

static struct ch_app* app_get(const char* name, NC_TRANSPORT transport) {
	struct ch_app *iter;

	if (name == NULL) {
		return (NULL);
	}

	for (iter = callhome_apps; iter != NULL; iter = iter->next) {
		if (iter->transport == transport && strcmp(iter->name, name) == 0) {
			break;
		}
	}

	return (iter);
}

static int app_rm(const char* name, NC_TRANSPORT transport) {
	struct ch_app* app;
	struct ch_server* srv, *del_srv;

	if ((app = app_get(name, transport)) == NULL) {
		return EXIT_FAILURE;
	}

	pthread_cancel(app->thread);
	pthread_join(app->thread, NULL);

	if (app->prev) {
		app->prev->next = app->next;
	} else {
		callhome_apps = app->next;
	}
	if (app->next) {
		app->next->prev = app->prev;
	} else if (app->prev) {
		app->prev->next = NULL;
	}

	for (srv = app->servers; srv != NULL;) {
		del_srv = srv;
		srv = srv->next;
		free(del_srv->address);
		free(del_srv);
	}

	/* a valid client running, mark it for deletion */
	if (app->client != NULL && !quit) {
		switch (app->client->transport) {
#ifdef NP_SSH
		case NC_TRANSPORT_SSH:
			((struct client_struct_ssh*)app->client)->ssh_chans->to_free = 1;
			break;
#endif
#ifdef NP_TLS
		case NC_TRANSPORT_TLS:
			app->client->to_free = 1;
			break;
#endif
		default:
			nc_verb_error("%s: internal error (%s:%d)", __func__, __FILE__, __LINE__);
			app->client->to_free = 1;
		}
	}

	free(app->name);
	free(app);

	return EXIT_SUCCESS;
}

int callback_srv_netconf_srv_call_home_srv_applications_srv_application(XMLDIFF_OP op, xmlNodePtr old_node, xmlNodePtr new_node, struct nc_err** error, NC_TRANSPORT transport) {
	char* name;

	switch (op) {
	case XMLDIFF_ADD:
		app_create(new_node, error, transport);
		break;
	case XMLDIFF_REM:
		name = (char*)xmlNodeGetContent(find_node(old_node, BAD_CAST "name"));
		app_rm(name, transport);
		free(name);
		break;
	case XMLDIFF_MOD:
		name = (char*)xmlNodeGetContent(find_node(old_node, BAD_CAST "name"));
		app_rm(name, transport);
		free(name);
		app_create(new_node, error, transport);
		break;
	default:
		;/* do nothing */
	}

	return EXIT_SUCCESS;
}

/**
 * @brief Initialize plugin after loaded and before any other functions are called.

 * This function should not apply any configuration data to the controlled device. If no
 * running is returned (it stays *NULL), complete startup configuration is consequently
 * applied via module callbacks. When a running configuration is returned, libnetconf
 * then applies (via module's callbacks) only the startup configuration data that
 * differ from the returned running configuration data.

 * Please note, that copying startup data to the running is performed only after the
 * libnetconf's system-wide close - see nc_close() function documentation for more
 * information.

 * @param[out] running	Current configuration of managed device.

 * @return EXIT_SUCCESS or EXIT_FAILURE
 */
int server_transapi_init(xmlDocPtr* UNUSED(running)) {
#ifdef NP_SSH
	if (ncds_feature_isenabled("ietf-netconf-server", "ssh") &&	ncds_feature_isenabled("ietf-netconf-server", "inbound-ssh") &&
			server_transapi_init_ssh() != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
#endif
#ifdef NP_TLS
	if (ncds_feature_isenabled("ietf-netconf-server", "tls") &&	ncds_feature_isenabled("ietf-netconf-server", "inbound-tls") &&
			server_transapi_init_tls() != EXIT_SUCCESS) {
		return EXIT_FAILURE;
	}
#endif

	return EXIT_SUCCESS;
}

/**
 * @brief Free all resources allocated on plugin runtime and prepare plugin for removal.
 */
void server_transapi_close(void) {
#ifdef NP_TLS
	if (ncds_feature_isenabled("ietf-netconf-server", "tls") &&	ncds_feature_isenabled("ietf-netconf-server", "inbound-tls")) {
		server_transapi_close_tls();
	}
#endif
#ifdef NP_SSH
	if (ncds_feature_isenabled("ietf-netconf-server", "ssh") &&	ncds_feature_isenabled("ietf-netconf-server", "inbound-ssh")) {
		server_transapi_close_ssh();
	}
#endif

	pthread_mutex_lock(&netopeer_options.binds_lock);
	free_all_bind_addr(&netopeer_options.binds);
	pthread_mutex_unlock(&netopeer_options.binds_lock);

	nc_verb_verbose("NETCONF Call Home cleanup.");
	while (callhome_apps != NULL) {
		app_rm(callhome_apps->name, callhome_apps->transport);
	}
}

/*
* Structure transapi_config_callbacks provide mapping between callback and path in configuration datastore.
* It is used by libnetconf library to decide which callbacks will be run.
* DO NOT alter this structure
*/
struct transapi_data_callbacks server_clbks =  {
#if defined(NP_SSH) && defined(NP_TLS)
	.callbacks_count = 6,
#else
	.callbacks_count = 3,
#endif
	.data = NULL,
	.callbacks = {
#ifdef NP_SSH
		{.path = "/srv:netconf/srv:ssh/srv:listen/srv:port", .func = callback_srv_netconf_srv_ssh_srv_listen_srv_port},
		{.path = "/srv:netconf/srv:ssh/srv:listen/srv:interface", .func = callback_srv_netconf_srv_ssh_srv_listen_srv_interface},
		{.path = "/srv:netconf/srv:ssh/srv:call-home/srv:applications/srv:application", .func = callback_srv_netconf_srv_ssh_srv_call_home_srv_applications_srv_application},
#endif
#ifdef NP_TLS
		{.path = "/srv:netconf/srv:tls/srv:listen/srv:port", .func = callback_srv_netconf_srv_tls_srv_listen_srv_port},
		{.path = "/srv:netconf/srv:tls/srv:listen/srv:interface", .func = callback_srv_netconf_srv_tls_srv_listen_srv_interface},
		{.path = "/srv:netconf/srv:tls/srv:call-home/srv:applications/srv:application", .func = callback_srv_netconf_srv_tls_srv_call_home_srv_applications_srv_application}
#endif
	}
};

/*
* RPC callbacks
* Here follows set of callback functions run every time RPC specific for this device arrives.
* You can safely modify the bodies of all function as well as add new functions for better lucidity of code.
* Every function takes array of inputs as an argument. On few first lines they are assigned to named variables. Avoid accessing the array directly.
* If input was not set in RPC message argument in set to NULL.
*/

/*
* Structure transapi_rpc_callbacks provide mapping between callbacks and RPC messages.
* It is used by libnetconf library to decide which callbacks will be run when RPC arrives.
* DO NOT alter this structure
*/
struct transapi_rpc_callbacks server_rpc_clbks = {
	.callbacks_count = 0,
	.callbacks = {
	}
};

struct transapi server_transapi = {
	.version = 6,
	.init = server_transapi_init,
	.close = server_transapi_close,
	.get_state = server_get_state_data,
	.clbks_order = TRANSAPI_CLBCKS_LEAF_TO_ROOT,
	.data_clbks = &server_clbks,
	.rpc_clbks = &server_rpc_clbks,
	.ns_mapping = server_namespace_mapping,
	.config_modified = &server_config_modified,
	.erropt = &server_erropt,
	.file_clbks = NULL,
};

#ifndef NTP_PROTO_H
#define NTP_PROTO_H

#define NTP_MAXFREQ	500e-6
 
#endif	/* NTP_PROTO_H */

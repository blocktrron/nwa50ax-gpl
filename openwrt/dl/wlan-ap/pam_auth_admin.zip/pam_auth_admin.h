#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include "zylog.h"
#include "zld-spec.h"

#define SHMKEY_PAM_PATH	"/lib/security/pam_auth_admin.so"
#define PERMS_PAM 0666
//#define IN_USER_NAME_LEN 		(ZLDSYSPARM_UAM_USER_NAME_LEN)
#ifdef ZLDSYSPARM_MAX_AUTH_ENTRY
#define MAX_AUTH_ENTRY	ZLDSYSPARM_MAX_AUTH_ENTRY
#define MAX_USER_ENTRY	ZLDSYSPARM_MAX_AUTH_ENTRY
#else
#define MAX_AUTH_ENTRY	50
#define MAX_USER_ENTRY 50
#endif
#ifdef ZLDCONFIG_WEBAUTH
#define DUE_TIME_LEN	8
#endif
#define SEM_PATH	"/lib/security/pam_unix.so"


#define USER_ZYLOG(fmt, arg...) zylog(ZYLOG_SRC_UAM, \
				ZYLOG_PRI_DEBUG, \
				ZYLOG_FAC_UAM, \
				0,0,0,0, "USER", fmt, ##arg)

/*
 * Copyright Alexander O. Yuriev, 1996.  All rights reserved.
 * NIS+ support by Thorsten Kukuk <kukuk@weber.uni-paderborn.de>
 * Copyright Jan Rêkorajski, 1999.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, and the entire permission notice in its entirety,
 *    including the disclaimer of warranties.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior
 *    written permission.
 *
 * ALTERNATIVELY, this product may be distributed under the terms of
 * the GNU Public License, in which case the provisions of the GPL are
 * required INSTEAD OF the above restrictions.  (This clause is
 * necessary due to a potential bad interaction between the GPL and
 * the restrictions contained in a BSD-style copyright.)
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* #define DEBUG */
#include <security/_pam_aconf.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>

/* indicate the following groups are defined */

#define PAM_SM_AUTH

#define _PAM_EXTERN_FUNCTIONS
#include <security/_pam_macros.h>
#include <security/pam_modules.h>

#ifndef LINUX_PAM
#include <security/pam_appl.h>
#endif				/* LINUX_PAM */

#include "support.h"

/* fanny add */
#include <sys/ipc.h>
#include <sys/sem.h>
#include "pam_auth_admin.h"

#include "user_profile.h"

/*
 * PAM framework looks for these entry-points to pass control to the
 * authentication module.
 */

/* Fun starts here :)

 * pam_sm_authenticate() performs UNIX/shadow authentication
 *
 *      First, if shadow support is available, attempt to perform
 *      authentication using shadow passwords. If shadow is not
 *      available, or user does not have a shadow password, fallback
 *      onto a normal UNIX authentication
 */

#define _UNIX_AUTHTOK  "-UN*X-PASS"

#define AUTH_RETURN_ADMIN						\
do {								\
	if (on(UNIX_LIKE_AUTH, ctrl) && ret_data) {		\
		D(("recording return code for next time [%d]",	\
					retval));		\
		*ret_data = retval;				\
		pam_set_data(pamh, "unix_setcred_return",	\
		             (void *) ret_data, setcred_free_admin);	\
	}							\
	/* gen_auth_log(retval, pamh); */ \
	D(("done. [%s]", pam_strerror(pamh, retval)));		\
	return retval;						\
} while (0)


static void setcred_free_admin (pam_handle_t * pamh, void *ptr, int err)
{
	if (ptr)
		free (ptr);
}

#if 0
/* this is for service mapping and pam_get_userinfo() */
#define inline
#include "../../../uam-1.0.0/pam_uam_utils.c"

void gen_auth_log(int pam_retval, pam_handle_t * pamh)
{
	char note[32];
	struct pam_info pinfo;

	if (pam_retval != PAM_AUTH_ERR)
		return;

	if (pam_get_userinfo(pamh, &pinfo) != PAM_SUCCESS) {
		PAM_UAM_DEBUG("Can't get user information!\n");
		return;
	}

	if (pinfo.username && valid_username(pinfo.username))
		sprintf(note, "User: %s", pinfo.username);
	else
		strcpy(note, "");

	if (pinfo.ip == INADDR_NONE)
		pinfo.ip = 0;

	zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM,
			pinfo.ip, 0, 0, 0, note,
			"Failed %s login attempt!", pinfo.service);
}
#endif

PAM_EXTERN int pam_sm_authenticate(pam_handle_t * pamh, int flags
				   ,int argc, const char **argv)
{
	unsigned int ctrl;
	int retval, *ret_data = NULL;
	int auth_module = AUTH_MODULE_LOCAL;
	const char *name, *p;

	D(("called."));

	ctrl = _set_ctrl(pamh, flags, NULL, argc, argv);

	/* Get a few bytes so we can pass our return value to
	   pam_sm_setcred(). */
	if (on(UNIX_LIKE_AUTH, ctrl))
		ret_data = malloc(sizeof(int));


	/* get the user'name' */
	retval = pam_get_user(pamh, &name, NULL);
	if (retval == PAM_SUCCESS) {

		/* 	Peter@2008-04-18
		 *	ITS#29158 User authenticates adminXXXXX failed with external user type
		 *	That means when we configures an user name with prefix of admin it will fail to
		 *	be authenticated by external server
		 */
		if(strcmp(name,"admin")){	/*not admin account	*/
			retval=PAM_USER_UNKNOWN;
			USER_ZYLOG("User:%s has passed pam_auth_admin module." ,name);
			AUTH_RETURN_ADMIN;
		}

		/*
		 * Various libraries at various times have had bugs related to
		 * '+' or '-' as the first character of a user name. Don't take
		 * any chances here. Require that the username starts with an
		 * alphanumeric character.
		 */

		if (name == NULL || name[0] == '-' || name[0] == '+') {
			_log_err(LOG_ERR, pamh, "bad username [%s]", name);
			retval = PAM_USER_UNKNOWN;
			AUTH_RETURN_ADMIN;
		}
		if (retval == PAM_SUCCESS && on(UNIX_DEBUG, ctrl))
			D(("username [%s] obtained", name));
	} else {
		D(("trouble reading username"));
		if (retval == PAM_CONV_AGAIN) {
			D(("pam_get_user/conv() function is not ready yet"));
			/* it is safe to resume this function so we translate this
			 * retval to the value that indicates we're happy to resume.
			 */
			retval = PAM_INCOMPLETE;
		}
		AUTH_RETURN_ADMIN;
	}
       /* disable non-root authentication */
       if (!(strncmp("debug", name, 5)))
       {
               return PAM_USER_UNKNOWN;
       }

	/* if this user does not have a password... */

	if (_unix_blankpasswd(ctrl, name)) {
		D(("user '%s' has blank passwd", name));
		/*name = NULL;
		retval = PAM_SUCCESS;*/
		USER_ZYLOG("Don't allow admin with nopassword.");
		name = NULL;
		retval = PAM_ABORT;
		AUTH_RETURN_ADMIN;
	}
	/* get this user's authentication token */

	retval = _unix_read_password(pamh, ctrl, NULL, "Password: ", NULL
				     ,_UNIX_AUTHTOK, &p);
	if (retval != PAM_SUCCESS) {
		if (retval != PAM_CONV_AGAIN) {
			_log_err(LOG_CRIT, pamh, "auth could not identify password for [%s]"
				 ,name);
		} else {
			D(("conversation function is not ready yet"));
			/*
			 * it is safe to resume this function so we translate this
			 * retval to the value that indicates we're happy to resume.
			 */
			retval = PAM_INCOMPLETE;
		}
		name = NULL;
		AUTH_RETURN_ADMIN;
	}
	D(("user=%s, password=[%s]", name, p));

	/* verify the password of this user */
	retval = _unix_verify_password(pamh, name, p, ctrl);

	/* fanny add */
	if(retval == PAM_SUCCESS){

		user_profile_t *user_p;

		user_p = (user_profile_t * )malloc(1 * sizeof(user_profile_t) );
		if (user_p == NULL) {
			USER_ZYLOG("[%s]Insufficient memory.",__FUNCTION__);
			return PAM_ABORT;
		}


#if 1 /* CASE-SENSITIVE */
		user_p->flag = 0;
#endif
		retval = get_info_from_local(user_p, name, ADMIN_TYPE);
		if (retval < 0) {
			retval = PAM_ABORT;
			free(user_p);
			AUTH_RETURN_ADMIN;
		}

		pam_set_item(pamh, PAM_ZYXEL_USER_TYPE, &user_p->type);
		pam_set_item(pamh, PAM_ZYXEL_USER_ROLE, name);
		pam_set_item(pamh, PAM_ZYXEL_LEASE_TIME, &user_p->lease_time);
		pam_set_item(pamh, PAM_ZYXEL_REAUTH_TIME, &user_p->reauth_time);
		pam_set_item(pamh, PAM_ZYXEL_AUTH_MODULE, &auth_module);
		pam_set_item(pamh, PAM_ZYXEL_DEFINED_USERNAME, name);

		free(user_p);
	}

	USER_ZYLOG("User:%s has passed pam_auth_admin module.", name);

	name = p = NULL;
	AUTH_RETURN_ADMIN;
}

/*
 * The only thing _pam_set_credentials_unix() does is initialization of
 * UNIX group IDs.
 *
 * Well, everybody but me on linux-pam is convinced that it should not
 * initialize group IDs, so I am not doing it but don't say that I haven't
 * warned you. -- AOY
 */

PAM_EXTERN int pam_sm_setcred(pam_handle_t * pamh, int flags
			      ,int argc, const char **argv)
{
	int retval;
	int *pretval = NULL;

	D(("called."));

	retval = PAM_SUCCESS;

	D(("recovering return code from auth call"));
	/* We will only find something here if UNIX_LIKE_AUTH is set --
	   don't worry about an explicit check of argv. */
	pam_get_data(pamh, "unix_setcred_return", (const void **) &pretval);
	if(pretval) {
		retval = *pretval;
		pam_set_data(pamh, "unix_setcred_return", NULL, NULL);
		D(("recovered data indicates that old retval was %d", retval));
	}

	return retval;
}

#ifdef PAM_STATIC
struct pam_module _pam_unix_auth_modstruct = {
    "pam_unix_auth",
    pam_sm_authenticate,
    pam_sm_setcred,
    NULL,
    NULL,
    NULL,
    NULL,
};
#endif

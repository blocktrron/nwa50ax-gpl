config_require(zld/zld_lib)
config_require(proWireless/proWirelessSystem)


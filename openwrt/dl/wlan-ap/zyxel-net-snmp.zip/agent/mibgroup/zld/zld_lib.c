/* $Id$
 *
 *    Copyright (C) 1994-2008 ZyXEL Communications, Corp.
 *    All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and
 * shall not be reproduced, copied, disclosed, or used in whole or
 * in part for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
*/
/******************************************************************************/
/*
 * $Log: zld_lib.c,v $
 * Revision 1.4  2008/04/24 01:38:21  lynn
 * Add a mib object to show the current number of sessions.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/shm.h>
#include <syslog.h>
#include <errno.h>
#include <endian.h>
#include <arpa/inet.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include "zld-spec.h"

#include "zld_lib.h"

#define SCRIPT_TEMPDIR "/tmp"
#define SCRIPT_TEMPFILE "SNMP_ZYSH_XXXXXX"
/*******************************************************************************
* Description : 
*	create a tmp script then write CLI commands into this file
*
* Parameters:
*	*script_name - the name of the script, give a empty string and 
*				   will be filled here
*	*cli_cmd - the CLI cmds which will be write into script
*
* Return Val: 
*	0 when OK, -1 when error
*
* Notes: 
*	don't forget delete this file at end
*******************************************************************************/
int
create_zysh_script(char *script_name, 
				   char *cli_cmd)
{
	int retval = 0;
	FILE *fp = NULL;
	int tmpFD;
	/* create script filename */
	/*sprintf(script_name, "/tmp/SNMP_ZYSH_XXXXXX");*/
	if ( access(SCRIPT_TEMPDIR, F_OK) == -1 ) {
		mkdir(SCRIPT_TEMPDIR, 0777);
	}	
	sprintf(script_name, "%s/%s",SCRIPT_TEMPDIR, SCRIPT_TEMPFILE);	
	if( (tmpFD = mkstemp(script_name)) < 0) {
		ZYWALL_SNMP_LOG(LOG_ERR, "Error Create ZYSH CLI Script File Name\n");
		retval = -1;
		goto end;
	}
	else {
		close(tmpFD);
	}
	/* open script file */
	if( !(fp = fopen(script_name, "w")) ) {
		ZYWALL_SNMP_LOG(LOG_ERR, "Error Create ZYSH CLI Script File\nscript_name: %s\ncli_cmd: %s\n",
						script_name, cli_cmd);
		retval = -1;
		goto end;
	}
    /* Write CLI commands */
    fprintf(fp, "%s", cli_cmd);
    fflush(fp);
    fclose(fp);
	
	ZYWALL_SNMP_MSG("Success Create ZYSH CLI Script File\nscript_name: %s\ncli_cmd: %s\n",
					script_name, cli_cmd);

end:
	return retval;
}

int
parse_sysCPUUsage(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { /* ex. cpu=num */
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "cpu") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get cpu usage from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysCPUUsage(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");
	
	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib cpu status2 one-min\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysCPUUsage);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}


int
get_sysCPUUsage2(char *data,int type)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");
	
	/* set cli_cmd according to request types:five_sec,one_min,five_min */
	switch(type){
		case FIVE_SEC:
			snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib cpu status2 five-sec\n");
			break;
		case ONE_MIN:
			snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib cpu status2 one-min\n");
			break;
		case FIVE_MIN:
			snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib cpu status2 five-min\n");
			break;
	
	}
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysCPUUsage);
	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
get_multiple_sysCPUUsage(int type){
	char sysCPUUsage2[MAX_ZYWALL_SNMP_STR_LEN] = {'\0'};
	int CPUusage2 = 0;

	if( get_sysCPUUsage2( sysCPUUsage2, type ) ){
		return -1;
	}
	return atoi(sysCPUUsage2);
}

int
parse_sysRAMUsage(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { /* ex. mem=num */
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "mem") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get memory usage from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysRAMUsage(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib mem status\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysRAMUsage);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

#if 1
int
parse_sysFLASHUsage(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { /* ex. flash=num */
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "flash") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get flash usage from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysFLASHUsage(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib disk\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysFLASHUsage);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSystemName(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "sysName") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get System Name from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSystemName(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib fqdn\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSystemName);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSystemLocation(char *raw_strp, void *data)
{
	int retval = 0;
#if 0
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);

	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) {
		if( (strp = strchr(str_token, ':')) ) {
			*strp = '\0';
			if( !strncmp(str_token, "location", 8) ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+2));
			}
		}
	}
#else
	const char delimiter[] =":";
	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	char *str_token;
	strtok(raw_strp,delimiter);
	str_token=strtok(NULL,"\n");
	sprintf((char *)data, "%s", str_token+(1));
#endif

	return retval;
}

/*******************************************************************************
* Description : 
*	get System Name from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSystemLocation(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show snmp status | match \"location\"\n");

	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSystemLocation);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSystemContact(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);

	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) {	 
		if( (strp = strchr(str_token, ':')) ) {
			*strp = '\0';
			if(!strncmp(str_token, "contact", 7)) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+2));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get System Name from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSystemContact(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show snmp status | match \"contact\"\n");

	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSystemContact);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysModelName(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "modelName") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get flash usage from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysModelName(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib model name\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysModelName);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysFirmwareVersion(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "FWversion") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get flash usage from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysFirmwareVersion(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib firmware version\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysFirmwareVersion);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSwMajorVersion(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swMajorNumber") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwMajorVersion from ZYSH
*	2.23(UJA.0)b1
*	^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwMajorVersion(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-major-version\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwMajorVersion);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}


int
parse_sysSwMinorVersion(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swMinorNumber") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwMinorVersion from ZYSH
*	2.23(UJA.0)b1
*	  ^^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwMinorVersion(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-minor-version\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwMinorVersion);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}


int
parse_sysSwModel(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swModel") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwModel from ZYSH
*	2.23(UJA.0)b1
*	       ^^^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwModel(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-model\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwModel);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSwPatchNumber(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swPatchNumber") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwPatchNumber from ZYSH
*	2.23(UJA.0)b1
*	              ^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwPatchNumber(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-patch-number\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwPatchNumber);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}


#if 1
int
parse_sysSwBuildDay(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swBuildDay") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwBuildDay from ZYSH
*	2010-09-28 20:54:31
*                   ^^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwBuildDay(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-build-day\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwBuildDay);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSwBuildMonth(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swBuildMonth") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwBuildMonth from ZYSH
*	2010-09-28 20:54:31
*              ^^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwBuildMonth(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-build-month\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwBuildMonth);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSwBuildYear(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "swBuildYear") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get SwBuildMonth from ZYSH
*	2010-09-28 20:54:31
*     ^^^^
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSwBuildYear(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib sw-build-year\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSwBuildYear);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}
#endif

int
parse_sysProductFamily(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "ProductFamily") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get ProductFamily from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysProductFamily(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib product-family\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysProductFamily);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}


int
parse_sysProductSerialNumber(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, ':')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "serial number") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get ProductSerialNumber from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysProductSerialNumber(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show serial-number\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysProductSerialNumber);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}


int 
parse_wlanAPDescription(char *raw_strp, void *data)
{
	int retval = 0;
	int ret = 0;
	char str_title[64];
	char anchor[64];
	char *str_info = NULL;

    ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
    /* parse result */

	str_title[0] = '\0';
	sscanf(raw_strp, "%s", str_title);
	if(!strcmp(str_title, "Description"))
	{
		anchor[0] = '\0';
		if(ret = sscanf(raw_strp,"%*s %s", anchor))
		{
			str_info = strstr(raw_strp, anchor);
			sprintf((char *)data, "%s", str_info);
		}
		else
		{
			sprintf((char *)data, "\0");
		}

	}
	return retval;
}
/*******************************************************************************
* Description : 
*	get ProductDescription from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int 
get_wlanAPDescription(void *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];
	  
	ZYWALL_SNMP_MSG("In\n");
	    
	snprintf(cli_cmd, sizeof(cli_cmd), "show capwap ap info\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_wlanAPDescription);
		   
	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);
			 
	return retval;
}
int
parse_sysOnlineAP(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "Online") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get On Line AP from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysOnlineAP(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib online ap\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysOnlineAP);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysOfflineAP(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "Offline") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get Off Line from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysOfflineAP(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib offline ap\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysOfflineAP);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysUnMgntAP(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "UnMgnt") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get Un-Management AP from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysUnMgntAP(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib unmgnt ap\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysUnMgntAP);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysStation(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "Station") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get Total Stations from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysStation(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib total stations\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysStation);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysUnClassAP(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "unclassified") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get Un-classified AP from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysUnClassAP(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib unclassified ap\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysUnClassAP);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysRogueAP(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "rogue") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get Rogue AP from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysRogueAP(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib rogue ap\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysRogueAP);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysFriendlyAP(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { 
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "friendly") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get Friendly AP from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysFriendlyAP(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib friendly ap\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysFriendlyAP);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}
#endif

int
parse_sysSupport11ag(char *raw_strp, void *data)
{
	char *strp, *str_end;
	char first=0;

	first = raw_strp[0];

	if ( first <= '9' && first > '0') {
		if( (strp = strchr(raw_strp, ' ')) ) { /*filter NUMBER*/
			
			while(*strp == ' ') {    	/*filer space*/
				strp++;
			} 	
			if ( (str_end = strchr(strp,' ')) ) {    /*search end*/
				*str_end = '\0';
			}	

			if(strlen(data))
			{
				strcat((char*)data, " ");
				strcat((char*)data, strp);
			}
			else
				sprintf((char *)data,"%s",strp);
		}
	}

	return 0;
}

int
get_sysSupport11ag(char *data, int flag, char *ch_width, char *country_code)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_STR_LEN];

	ZYWALL_SNMP_MSG("In\n");

	if(flag == CHANNEL_11G) {
		snprintf(cli_cmd, sizeof(cli_cmd), "show wlan channels 11G cw %s country %s\n", ch_width, country_code);
	}
	else { 
		snprintf(cli_cmd, sizeof(cli_cmd), "show wlan channels 11A cw %s country %s\n", ch_width, country_code);
	}
	
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSupport11ag);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_vpnIpSecTotalThroughput(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { /* ex. vpnthroughput=num */
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "vpnthroughput") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get memory usage from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_vpnIpSecTotalThroughput(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib vpn-counters\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_vpnIpSecTotalThroughput);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

int
parse_sysSessionNum(char *raw_strp, void *data)
{
	int retval = 0;
	const char delimiter[] = ";";
	char *strp, *str_token;

	ZYWALL_SNMP_MSG("raw_strp: %s\n", raw_strp);
	/* parse result */
	while( (str_token = strsep(&raw_strp, delimiter)) ) { /* ex. session=num */
		if( (strp = strchr(str_token, '=')) ) {
			*strp = '\0';
			if( !strcmp(str_token, "session") ) {
				sprintf((char *)data, "%s", str_token+(strlen(str_token)+1));
			}
		}
	}

	return retval;
}

/*******************************************************************************
* Description : 
*	get session num from ZYSH
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
get_sysSessionNum(char *data)
{
	int retval = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	ZYWALL_SNMP_MSG("In\n");

	snprintf(cli_cmd, sizeof(cli_cmd), "show _zldmib session status\n");
	retval = execute_zysh_script(cli_cmd, (void *)data, parse_sysSessionNum);

	ZYWALL_SNMP_MSG("Out data %s\n", (char *)data);

	return retval;
}

/*******************************************************************************
* Description : 
*	execute the ZYSH CLI commands and parse the result
*
* Parameters:
*	*cli_cmd - CLI commands needed to be executed 
*	*data - value pointer needed to be filled up after parsing, can be a string
*			or a structure, if NULL means no parse needed
*	*parse - function pointer to the function which responses fro parsing,
*			if NULL means no parse needed
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
int
execute_zysh_script(char *cli_cmd,
					void *data,
					int (*parse)(char *raw_strp, void *data))
{
	int retval = 0;
	char script_name[MAX_ZYWALL_SNMP_SCRIPT_NAME_LEN];
	char zysh_cmd[MAX_ZYWALL_SNMP_RESULT_LINE_LEN];
	char result_line[MAX_ZYWALL_SNMP_RESULT_LINE_LEN];
	FILE *pfp = NULL;
	char *strp;
	char error_pattern_1[] = "% (after";
	char error_pattern_2[] = "retval = -";
	
/* 1. Create ZYSH CLI Script */
	if( (retval = create_zysh_script(script_name, cli_cmd)) ) {
		goto end;
	} 
/* 2. Execute Script */
	/* error result is via stderr, since popen can only read from stdout, 
	   so we need to redirect all stderr to stdout */
	snprintf(zysh_cmd, sizeof(zysh_cmd), "%s %s >/dev/stdout 2>&1",
			ZYWALL_SNMP_ZYSH, script_name);
	if( !(pfp = popen(zysh_cmd, "r")) ) {
		ZYWALL_SNMP_LOG(LOG_ERR, "Error Execute ZYSH CLI Script zysh_cmd: %s\n", zysh_cmd);
		retval = -1;
		goto remove; /*remove ZYSH CLI Script file that created in create_zysh_script()*/
	} 
	else {
		ZYWALL_SNMP_MSG("Success Execute ZYSH CLI Script zysh_cmd: %s\n", zysh_cmd);
	}

	/* read_result */
	while( fgets(result_line, sizeof(result_line), pfp) ) {
			ZYWALL_SNMP_MSG("result_line:%s\n", result_line);
		/* check if contain error_pattern which indicating exec error */
		if( !strncmp(result_line, error_pattern_1, strlen(error_pattern_1)) ||
			!strncmp(result_line, error_pattern_2, strlen(error_pattern_2))) {
			ZYWALL_SNMP_MSG("Find Error Pattern in result_line:%s\n", result_line);
			retval = -1;
			break;
		}
		
		if( data ) { /* Need to parse the result */
			/* del newline '\n' */
			strp = NULL;
			if( (strp = strrchr(result_line, '\n')) ) {
				*strp = '\0';
			}
			/* parse per line */
			parse(result_line, data);
		}
	}
	/* close and delete script */
	pclose(pfp);

remove: 
#if ZYWALL_SNMP_DEBUG
#else
	unlink(script_name);
#endif

end:
	return retval;
}


/*******************************************************************************
* Description : 
*	execute the ZYSH CLI commands and parse the result into a link-list
*
* Parameters:
*	*cli_cmd - CLI commands needed to be executed 
*	**phead - the pointer of pointer of the list head which need to be filled
*				here
*	*parse - function pointer to the function which responses fro parsing,
*
* Return Val: 
*	0 when OK, -1 when error
*******************************************************************************/
void *
execute_zysh_script_table(char *cli_cmd,
						  void* (parse)(FILE *pfp) )
{
	char script_name[MAX_ZYWALL_SNMP_SCRIPT_NAME_LEN];
	char zysh_cmd[MAX_ZYWALL_SNMP_RESULT_LINE_LEN];
	FILE *pfp = NULL;
	void *phead = NULL;

/* 1. Create ZYSH CLI Script */
	if( (create_zysh_script(script_name, cli_cmd)) ) {
		goto end;
	} 
/* 2. Execute Script */
	/* since we only need to read result here, so no need to redirect all 
	   stderr to stdout */
	snprintf(zysh_cmd, sizeof(zysh_cmd), "%s %s",
			ZYWALL_SNMP_ZYSH, script_name);
	if( !(pfp = popen(zysh_cmd, "r")) ) {
		ZYWALL_SNMP_LOG(LOG_ERR, "Error Execute ZYSH CLI Script zysh_cmd: %s\n", zysh_cmd);
		goto end;
	} 
	else {
		ZYWALL_SNMP_MSG("Success Execute ZYSH CLI Script zysh_cmd: %s\n", zysh_cmd);
	}
	/* parse and create the link-list */
	if( !(phead = parse(pfp)) ) {
		ZYWALL_SNMP_LOG(LOG_ERR, "Finish Execute parse Table phead=0x%8.8X\n",(phead)?phead:0);
	}
	else {
		ZYWALL_SNMP_MSG("OK Finish Execute parse Table phead=0x%8.8X\n",(phead)?phead:0);
	}
	/* close and delete script */
	pclose(pfp);

#if ZYWALL_SNMP_DEBUG
#else
	unlink(script_name);
#endif

end:
	return phead;
}

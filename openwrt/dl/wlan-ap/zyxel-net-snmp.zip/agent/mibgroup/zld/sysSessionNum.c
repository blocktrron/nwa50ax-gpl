/* $Id$
 * 
 *    Copyright (C) 1994-2008 ZyXEL Communications, Corp.
 *    All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and
 * shall not be reproduced, copied, disclosed, or used in whole or
 * in part for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 */
/******************************************************************************/
/*
 * $Log: sysSessionNum.c,v $
 * Revision 1.1  2008/04/24 01:59:22  lynn
 * Add a mib object to show the current number of sessions.
 *
 */

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include "zld_lib.h"
#include "sysSessionNum.h"

/** Initializes the sysSessionNum module */
void
init_sysSessionNum(void)
{
    	static oid sysSessionNum_oid[] = { 1,3,6,1,4,1,890,1,6,22,1,6 };

	DEBUGMSGTL(("sysSessionNum", "Initializing\n"));

    	netsnmp_register_scalar(
        netsnmp_create_handler_registration("sysSessionNum", handle_sysSessionNum,
                               sysSessionNum_oid, OID_LENGTH(sysSessionNum_oid),
                               HANDLER_CAN_RONLY
        ));
}

int
handle_sysSessionNum(netsnmp_mib_handler *handler,
                          netsnmp_handler_registration *reginfo,
                          netsnmp_agent_request_info   *reqinfo,
                          netsnmp_request_info         *requests)
{
	char sysSessionNum[MAX_ZYWALL_SNMP_STR_LEN];
	int SessionNum = 0;
    	/* init str */
    	sysSessionNum[0] = '\0';
    	/* get session num */
    	if( get_sysSessionNum(sysSessionNum) ) {
		ZYWALL_SNMP_LOG(LOG_ERR, "Error get session number\n");
    		return SNMP_ERR_GENERR;
	}
	SessionNum = atoi(sysSessionNum);
    	switch (reqinfo->mode) {
    		
    	case MODE_GET:
        	snmp_set_var_typed_value(requests->requestvb, ASN_INTEGER,
                                 (u_char *) &SessionNum,
                                 sizeof(SessionNum));
        	ZYWALL_SNMP_MSG("SessionNum: %d\n", SessionNum);
        	break;

    	default:
        	return SNMP_ERR_READONLY;
    }

    return SNMP_ERR_NOERROR;
}

/* $Id$
 * 
 *    Copyright (C) 1994-2008 ZyXEL Communications, Corp.
 *    All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and
 * shall not be reproduced, copied, disclosed, or used in whole or
 * in part for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 */
/******************************************************************************/
/*
 * $Log: zld_lib.h,v $
 * Revision 1.5  2008/04/24 01:11:46  lynn
 * add an oid to show the current number of sessions
 *
 */

#ifndef ZLD_LIB_H
#define ZLD_LIB_H

/* System Parameters */
#define ZYWALL_SNMP_DEBUG					0

#define MAX_ZYWALL_SNMP_STR_LEN				128
#define MAX_ZYWALL_SNMP_RESULT_LINE_LEN		1024
#define MAX_ZYWALL_SNMP_SCRIPT_NAME_LEN		64
#define	MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN	1024
#define MAX_ZYWALL_SNMP_CACHE_TIME			30
#define MAX_ZYWALL_SNMP_IMPORT_CERT_LEN		1024
#define MAX_ZYWALL_SNMP_CRYPTO_LEN			4096

#define MAX_ZYWALL_SNMP_CERT_LEN			4096
#define ZYWALL_SNMP_CERT_LOCAL				1
#define ZYWALL_SNMP_CERT_REMOTE				2

#define ZYWALL_SNMP_ZYSH					"/bin/zysh -p 110"
#define ZYWALL_SUBCOMMAND_ZYSH			"/bin/zysh -p 120"
#define CONFIGURE_TERMINAL					"configure terminal"
#define ZYWALL_SNMP_DEFAULT_IP				"0.0.0.0"
#define ZYWALL_SNMP_OBJ_ANY					"ALL"
#define ZYWALL_SNMP_STR_NULL				"NULL"
#define ZYWALL_SNMP_STR_NONE				"none"
#define ZYWALL_SNMP_STR_YES					"yes"
#define ZYWALL_SNMP_STR_NO					"no"
#define ZYWALL_SNMP_REBOOT_PASSWD			"ZyWallReboot"
#define ZYWALL_SNMP_ADDROBJ_STR_HOST		"HOST"
#define ZYWALL_SNMP_ADDROBJ_STR_SUBNET		"SUBNET"
#define ZYWALL_SNMP_ADDROBJ_STR_RANGE		"RANGE"
#define ZYWALL_SNMP_STR_CLEAR				"clear"

/* Device Parameters */
#define DEV_MODE_ROUTER		"Router"
#define DEV_MODE_BRIDGE		"Bridge"

#define CHANNEL_11A	1
#define CHANNEL_11G	2

/* Function Marco */
#define ZYWALL_SNMP_LOG(level, format, args...) \
	do { \
		snmp_log(level, "ZYWALLM110: %s:%d in %s(): ", __FILE__, __LINE__, __func__);\
		snmp_log(level, format, ##args); \
	} while(0)

#if ZYWALL_SNMP_DEBUG
	#define ZYWALL_SNMP_MSG(format, args...) \
		do { \
			snmp_log(LOG_ERR, "ZYWALLM110: %s:%d in %s(): ", __FILE__, __LINE__, __func__);\
			snmp_log(LOG_ERR, format, ##args); \
		} while(0)
#else
	#define ZYWALL_SNMP_MSG(format, args...) \
		do { \
		} while(0)
#endif
/* CPU tyep */
enum cpu_tyep { FIVE_SEC,ONE_MIN,FIVE_MIN };

/* Structure Prototype */


/* Function Prototype */
int create_zysh_script(char *script_name, char *cli_cmd);

/* Single Entry Operator */
int execute_zysh_script(char *cli_cmd, void *data, int (*parse)(char *raw_strp, void *data));

/* Table Operator */
void* execute_zysh_script_table(char *cli_cmd, void* (parse)(FILE *pfp));

/* sysCPUUsage */
int get_sysCPUUsage(char *data);
int parse_sysCPUUsage(char *raw_strp, void *data);
int get_multiple_sysCPUUsage(int type);

/* sysRAMUsage */
int get_sysRAMUsage(char *data);
int parse_sysRAMUsage(char *raw_strp, void *data);

/* vpnIpecTotalThroughput */
int get_vpnIpSecTotalThroughput(char *data);
int parse_vpnIpSecTotalThroughput(char *raw_strp, void *data);

/* sysSessionNum */
int get_sysSessionNum(char *data);
int parse_sysSessionNum(char *raw_strp, void *data);

#endif /* ZLD_LIB_H */

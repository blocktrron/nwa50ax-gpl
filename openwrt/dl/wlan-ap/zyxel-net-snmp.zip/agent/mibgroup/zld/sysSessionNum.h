/* $Id$
 *
 *    Copyright (C) 1994-2008 ZyXEL Communications, Corp.
 *    All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and
 * shall not be reproduced, copied, disclosed, or used in whole or
 * in part for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 */
/******************************************************************************/
/*
 * $Log: sysSessionNum.h,v $
 * Revision 1.1  2008/04/24 01:53:34  lynn
 * Add a mib object to show the current number of sessions.
 *
 */

#ifndef SYSSESSIONNUM_H
#define SYSSESSIONNUM_H

/*
 * function declarations 
 */
void            init_sysSessionNum(void);
Netsnmp_Node_Handler handle_sysSessionNum;

#endif                          /* SYSSESSIONNUM_H */


/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "hybrid_ap.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zykit.h"
#include "wireless_hal.h"


u_char         *
Hybrid_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	static long     long_return;
	static U64	    long64_return;
	oid 	newname[MAX_NAME_LEN];
	int 	result;
	wlanStatistic_t entry;
	*write_method = 0;

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	newname[(int)vp->namelen] = 0;
	result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + 1);
	if ((exact && (result != 0)) || (!exact && (result >= 0)))
		return NULL;
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + 1) * sizeof(oid));
	*length = vp->namelen + 1;
	*var_len = sizeof(long);

	get_wlan_rxtx(&entry);
	switch (vp->magic)
	{
		case OPERATION_MODE:
		{
			int mode = 0;
			mode = zykit_wlan_get_hybridmode();

			if(mode == WHOPMODE_UNKNOWN) {
				return NULL;
			}
			
			ZYWALL_SNMP_MSG("Operation Mode: %d\n", mode);

			*var_len = sizeof long_return;
			long_return = mode;
			return (u_char *) & long_return;
		}
		
		case WLANAPTX:
		{
			*var_len = sizeof long64_return;
			long64_return.high = (unsigned long)(entry.TransmittedByte >> 32);
			long64_return.low = (unsigned long)(entry.TransmittedByte & 0xffffffff);
			return (u_char *) & long64_return;
		}

		case WLANAPRX:
		{
			*var_len = sizeof long64_return;
			long64_return.high = (unsigned long)(entry.ReceivedByte >> 32);
			long64_return.low = (unsigned long)(entry.ReceivedByte & 0xffffffff);
			return (u_char *) & long64_return;		
		}
		
		case WLAN_AP_DESCRIPTION:
		{
			char wlanAPDescription[MAX_ZYWALL_SNMP_STR_LEN];
			int mode = 0;
			
			wlanAPDescription[0] = '\0';
			mode = zykit_wlan_get_hybridmode();
			if((mode == WHOPMODE_STANDALONE) || (mode == WHOPMODE_MANAGED))
			{
				if(get_wlanAPDescription(wlanAPDescription))
				{
					ZYWALL_SNMP_MSG(LOG_ERR, "Error get wlanAPDescription\n");
					return NULL;
				}
			}
			
			ZYWALL_SNMP_MSG("wlanAPDescription: %s\n", wlanAPDescription);
			
			*var_len = strlen(wlanAPDescription);
			memcpy(return_buf, wlanAPDescription, *var_len);
			return (u_char *) return_buf;
		}
			

		default:
			return NULL;
	}
	return NULL;
}


static oid Hybrid_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_HYBRID_OID};

struct variable2 Hybrid_vars[]= {
	{OPERATION_MODE, ASN_INTEGER, RONLY, Hybrid_read, 1, {1}},
	{WLANAPTX, ASN_COUNTER64, RONLY, Hybrid_read, 1, {2}},
	{WLANAPRX, ASN_COUNTER64, RONLY, Hybrid_read, 1, {3}},
	{WLAN_AP_DESCRIPTION, ASN_OCTET_STR, RONLY, Hybrid_read, 1, {4}}
};

void
init_hybrid_ap(void)
{
	REGISTER_MIB("HYBRID_AP", Hybrid_vars, variable2, Hybrid_variables_oid);
}


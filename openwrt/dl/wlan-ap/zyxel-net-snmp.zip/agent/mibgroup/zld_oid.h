/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#ifndef MIB_ZLD_OID_H
#define MIB_ZLD_OID_H

/*enterpriseSolution oid*/
#define ES_AGENT_CAPABILITY_OID	1
#define ES_CONFORMANCE_OID		2
#define ES_MGMT_OID				3
#define ES_PRODUCT_SPECIFIC_OID	4
#define ES_PARTNER_PRODUCTS_OID	5

/*esMgmt oid*/
#define ES_SYS_INFO_OID		1
#define ES_SYS_MGMT_OID		2
#define ES_CAPWAP_OID			3
#define ES_HYBRID_OID			4
#define ES_WIRELESS_OID		5
#define ES_RF_MGMT_OID			6

/*esProductSpecific oid*/
#define ES_PROWLAN_OID		1

/*oid*/
#define COMMON_OID			1
#define TRAP_OID			2
#define CAPWAP_OID			3
#define HYBRID_OID			4
#define WIRELESS_OID		5

#endif


/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "zld-spec.h"   /* Zyxel: It is necessary that been included before zykit.h */
#include "sysinfo.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zykit.h"


u_char         *
Sysinfo_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	static long     long_return;
	static u_char   return_buf[MAX_ZYWALL_SNMP_STR_LEN];
	oid 	newname[MAX_NAME_LEN];
	int 	result;

	*write_method = NULL;

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	newname[(int)vp->namelen] = 0;
	result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + 1);
	if ((exact && (result != 0)) || (!exact && (result >= 0)))
		return NULL;
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + 1) * sizeof(oid));
	*length = vp->namelen + 1;
	*var_len = sizeof(long);

	switch (vp->magic)
	{
		case SYS_SW_PLATFORM:
		{
			/*1: Otheros, 2: ZyNOS, 3:ZLD*/
			int sysSWPlatform = 3; /*Hard Code for ZLD Platform*/
			ZYWALL_SNMP_MSG("S/W Platform: %d\n", sysSWPlatform);

			*var_len = sizeof long_return;
			long_return = sysSWPlatform;
			return (u_char *) & long_return;
		}

		case SYS_SW_MAJORV_ERSION:
		{
			char sysSwMajorVersion[MAX_ZYWALL_SNMP_STR_LEN];
			int SWMajorVersion = 0;
			/* init str */
			sysSwMajorVersion[0] = '\0';
			
			if( get_sysSwMajorVersion(sysSwMajorVersion) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swMajorVersion\n");
				return NULL;
			}
			SWMajorVersion = atoi(sysSwMajorVersion);
			ZYWALL_SNMP_MSG("swMajorVersion: %d\n", SWMajorVersion);

			*var_len = sizeof long_return;
			long_return = SWMajorVersion;
			return (u_char *) & long_return;
		}

		case SYS_SW_MINORV_ERSION:
		{
			char sysSwMinorVersion[MAX_ZYWALL_SNMP_STR_LEN];
			int SWMinorVersion = 0;
			/* init str */
			sysSwMinorVersion[0] = '\0';
			
			if( get_sysSwMinorVersion(sysSwMinorVersion) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swMinorVersion\n");
				return NULL;
			}
			SWMinorVersion = atoi(sysSwMinorVersion);
			ZYWALL_SNMP_MSG("swMajorVersion: %d\n", SWMinorVersion);

			*var_len = sizeof long_return;
			long_return = SWMinorVersion;
			return (u_char *) & long_return;
		}

		case SYS_SW_MODEL:		
		{
			char sysSwModel[MAX_ZYWALL_SNMP_STR_LEN];
			/* init str */
			sysSwModel[0] = '\0';
			
			if( get_sysSwModel(sysSwModel) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swModel\n");
				return NULL;
			}

			ZYWALL_SNMP_MSG("swModel: %s\n", sysSwModel);

			*var_len = strlen (sysSwModel);
			memcpy(return_buf, sysSwModel, *var_len);
			return (u_char *) return_buf;
		}

		case SYS_SW_PATCH_NUMBER:		
		{
			char sysSwPatchNumber[MAX_ZYWALL_SNMP_STR_LEN];
			int SWPatchNumber = 0;
			/* init str */
			sysSwPatchNumber[0] = '\0';
			
			if( get_sysSwPatchNumber(sysSwPatchNumber) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swPatchNumber\n");
				return NULL;
			}
			SWPatchNumber = atoi(sysSwPatchNumber);
			ZYWALL_SNMP_MSG("swPatchNumber: %d\n", SWPatchNumber);

			*var_len = sizeof long_return;
			long_return = SWPatchNumber;
			return (u_char *) & long_return;
		}

		case SYS_SW_VERSION_STRING:		
		{

			char sysFirmwareVersion[MAX_ZYWALL_SNMP_STR_LEN];
			 /* init str */
			sysFirmwareVersion[0] = '\0';
	
			/* get ram usage */
			if( get_sysFirmwareVersion(sysFirmwareVersion) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get Firmware Version\n");
				return NULL;
			}

			ZYWALL_SNMP_MSG("SYS_SW_VERSION_STRING: %s\n", sysFirmwareVersion);

			*var_len = strlen(sysFirmwareVersion);
			memcpy(return_buf, sysFirmwareVersion, *var_len);
			return (u_char *) return_buf;	
		}

		case SYS_SW_DAY:		
		{
			char sysSwBuildDay[MAX_ZYWALL_SNMP_STR_LEN];
			int SWBuildDay = 0;
			/* init str */
			sysSwBuildDay[0] = '\0';
			
			if( get_sysSwBuildDay(sysSwBuildDay) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swBuildDay\n");
				return NULL;
			}
			SWBuildDay = atoi(sysSwBuildDay);
			ZYWALL_SNMP_MSG("swBuildDay: %d\n", SWBuildDay);

			*var_len = sizeof long_return;
			long_return = SWBuildDay;
			return (u_char *) & long_return;
		}

		case SYS_SW_MONTH:		
		{
			char sysSwBuildMonth[MAX_ZYWALL_SNMP_STR_LEN];
			int SWBuildMonth = 0;
			/* init str */
			sysSwBuildMonth[0] = '\0';
			
			if( get_sysSwBuildMonth(sysSwBuildMonth) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swBuildMonth\n");
				return NULL;
			}
			SWBuildMonth = atoi(sysSwBuildMonth);
			ZYWALL_SNMP_MSG("swBuildMonth: %d\n", SWBuildMonth);

			*var_len = sizeof long_return;
			long_return = SWBuildMonth;
			return (u_char *) & long_return;
		}

		case SYS_SW_YEAR:		
		{
			char sysSwBuildYear[MAX_ZYWALL_SNMP_STR_LEN];
			int SWBuildYear = 0;
			/* init str */
			sysSwBuildYear[0] = '\0';
			
			if( get_sysSwBuildYear(sysSwBuildYear) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get swBuildYear\n");
				return NULL;
			}
			SWBuildYear = atoi(sysSwBuildYear);
			ZYWALL_SNMP_MSG("swBuildYear: %d\n", SWBuildYear);

			*var_len = sizeof long_return;
			long_return = SWBuildYear;
			return (u_char *) & long_return;
		}

		case SYS_PRODUCT_FAMILY:		
		{
			char sysProductFamily[MAX_ZYWALL_SNMP_STR_LEN];
			/* init str */
			sysProductFamily[0] = '\0';
			
			if( get_sysProductFamily(sysProductFamily) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get ProductFamily\n");
				return NULL;
			}

			ZYWALL_SNMP_MSG("ProductFamily: %s\n", sysProductFamily);

			*var_len = strlen (sysProductFamily);
			memcpy(return_buf, sysProductFamily, *var_len);
			return (u_char *) return_buf;
		}

		case SYS_PRODUCT_MODEL:		
		{
			char sysModelName[MAX_ZYWALL_SNMP_STR_LEN];
			/* init str */
			sysModelName[0] = '\0';
	
			/* get ram usage */
			if( get_sysModelName(sysModelName) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get Model Name\n");
				return NULL;
			}

			ZYWALL_SNMP_MSG("SYS_PRODUCT_MODEL: %s\n", sysModelName);

			*var_len = strlen (sysModelName);
			memcpy(return_buf, sysModelName, *var_len);
			return (u_char *) return_buf;	
		}

		case SYS_PRODUCT_SERIAL_NUMBER:		
		{
			char sysProductSerialNumber[MAX_ZYWALL_SNMP_STR_LEN];
			/* init str */
			sysProductSerialNumber[0] = '\0';
			
			if( get_sysProductSerialNumber(sysProductSerialNumber) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get ProductSerialNumber\n");
				return NULL;
			}

			ZYWALL_SNMP_MSG("ProductSerialNumber: %s\n", sysProductSerialNumber);

			*var_len = strlen (sysProductSerialNumber);
			memcpy(return_buf, sysProductSerialNumber, *var_len);
			return (u_char *) return_buf;
		}

		case SYS_COUNTRY_CODE:
		{
			char *sysCountryName;
			
			sysCountryName = zykit_mrd_get_countryname(0);

			*var_len = strlen(sysCountryName);
			memcpy(return_buf, sysCountryName, *var_len);
			return (u_char *) return_buf;	
			
		}

		case SYS_NEBULA_MANAGED:
		{
			int sysNebulaManaged = 2;

			if( WHOPMODE_CLOUD == zykit_wlan_get_hybridmode() ){
				sysNebulaManaged = 1;
			}

			*var_len = sizeof long_return;
			long_return = sysNebulaManaged;
			return (u_char *) & long_return;
		}
		default:
			return NULL;
	}
	return NULL;
}

static oid 	Sysinfo_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_SYS_INFO_OID};

struct variable2 Sysinfo_vars[]= {
	{SYS_SW_PLATFORM, ASN_INTEGER, RONLY, Sysinfo_read, 1, {1}},
	{SYS_SW_MAJORV_ERSION, ASN_INTEGER, RONLY, Sysinfo_read, 1, {2}},
	{SYS_SW_MINORV_ERSION, ASN_INTEGER, RONLY, Sysinfo_read, 1, {3}},	
	{SYS_SW_MODEL, ASN_OCTET_STR, RONLY, Sysinfo_read, 1, {4}},		
	{SYS_SW_PATCH_NUMBER, ASN_INTEGER, RONLY, Sysinfo_read, 1, {5}},	
	{SYS_SW_VERSION_STRING, ASN_OCTET_STR, RONLY, Sysinfo_read, 1, {6}},		
	{SYS_SW_DAY, ASN_INTEGER, RONLY, Sysinfo_read, 1, {7}},
	{SYS_SW_MONTH, ASN_INTEGER, RONLY, Sysinfo_read, 1, {8}},	
	{SYS_SW_YEAR, ASN_INTEGER, RONLY, Sysinfo_read, 1, {9}},	
	{SYS_PRODUCT_FAMILY, ASN_OCTET_STR, RONLY, Sysinfo_read, 1, {10}},	
	{SYS_PRODUCT_MODEL, ASN_OCTET_STR, RONLY, Sysinfo_read, 1, {11}},	
	{SYS_PRODUCT_SERIAL_NUMBER, ASN_OCTET_STR, RONLY, Sysinfo_read, 1, {12}},	
	{SYS_COUNTRY_CODE, ASN_OCTET_STR, RONLY, Sysinfo_read, 1, {16}},
	{SYS_NEBULA_MANAGED, ASN_INTEGER, RONLY, Sysinfo_read, 1, {20}}
};

void
init_sysinfo(void)
{
	REGISTER_MIB("sysinfo", Sysinfo_vars, variable2, Sysinfo_variables_oid);
}


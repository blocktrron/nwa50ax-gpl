/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#ifndef MIB_SYSINFO_H
#define MIB_SYSINFO_H


/*oid*/

#define SYS_SW_PLATFORM			1
#define SYS_SW_MAJORV_ERSION		2
#define SYS_SW_MINORV_ERSION		3
#define SYS_SW_MODEL				4
#define SYS_SW_PATCH_NUMBER		5
#define SYS_SW_VERSION_STRING		6
#define SYS_SW_DAY					7
#define SYS_SW_MONTH				8
#define SYS_SW_YEAR				9
#define SYS_PRODUCT_FAMILY			10
#define SYS_PRODUCT_MODEL			11
#define SYS_PRODUCT_SERIAL_NUMBER 	12
#define SYS_COUNTRY_CODE			16
#define SYS_NEBULA_MANAGED			20

#endif


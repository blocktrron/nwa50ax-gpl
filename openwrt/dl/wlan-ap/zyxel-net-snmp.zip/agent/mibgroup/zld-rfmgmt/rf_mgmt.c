/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "rf_mgmt.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zysh_io.h"
#include "zld-spec.h"

static int
RFMgmt_write(int action, u_char * var_val, u_char var_val_type,
                 size_t var_val_len, u_char * statP,
                 oid * name, size_t name_len)
{
	int retval = 0;
	int magic = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];

	magic = name[name_len -2];

	switch (magic) {
		case WLAN_DCS:
			if ( var_val_type != ASN_INTEGER ){
				retval = SNMP_ERR_WRONGTYPE;
			}
			
			if (action == COMMIT) {
				if((*((int *) var_val))  == ON) {
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,DCS_ACTIVATE);
					system(cli_cmd);
				}
				else if((*((int *) var_val))  == OFF) {
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s no %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,DCS_ACTIVATE);
					system(cli_cmd);
				}
			}
			break;
			
		default:
			break;
	}

	return retval;
}

u_char         *
RFMgmt_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	confCTX_t *editing_config = NULL;
	static long     long_return;
	oid newname[MAX_OID_LEN] = {0};
	int result;
	
	*write_method = RFMgmt_write;

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	newname[(int)vp->namelen] = 0;
	result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + 1);
	if ((exact && (result != 0)) || (!exact && (result >= 0)))
		return NULL;
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + 1) * sizeof(oid));
	*length = vp->namelen + 1;
	*var_len = sizeof(long);

	switch (vp->magic)
	{
		case WLAN_DCS:
		{
			zyio_entity dcs_entity = NULL;
			char activate[5];
			int dcs = 0;
			
			editing_config = zyio_restore_scope(DCS_XML_FILE);
			dcs_entity = zyio_retrieve_entity(editing_config, SCOPE_DCS, TYPE_DCS, DCS_GLOBAL_SETTING_ENTITY);
			if (!dcs_entity) {
				goto error;
			}
			if(zyio_get(dcs_entity, DCS_ATRB_ACTIVATE, activate) == 0) {
				goto error;
			}


			if (!strcmp(activate,"yes"))
				dcs = ON;
			else if (!strcmp(activate,"no"))
				dcs = OFF;

			ZYWALL_SNMP_MSG("Wlan DCS: %d\n", dcs);
			zyio_close_config(editing_config);
	
			*var_len = sizeof long_return;
			long_return = dcs;
			return (u_char *) & long_return;	
			
		}

		default:
			 return NULL;
	}

error:

	if(editing_config)
		zyio_close_config(editing_config);
	return NULL;
}

static oid	RFMgmt_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_RF_MGMT_OID};

struct variable4 RFMgmt_vars[]= {
	{WLAN_DCS, ASN_INTEGER, RWRITE, RFMgmt_read, 1, {1}}
};

void
init_rf_mgmt(void)
{
	REGISTER_MIB("RFManagement", RFMgmt_vars, variable2, RFMgmt_variables_oid);
}


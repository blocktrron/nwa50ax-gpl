/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "prowlan.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zykit.h"

static int
Prowlan_write(int action, u_char * var_val, u_char var_val_type,
                 size_t var_val_len, u_char * statP,
                 oid * name, size_t name_len)
{
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];
	int magic;
	magic = name[name_len -2];
		
	switch (magic) {
		case ADMIN_PASSWORD:
		{
		#if 0
			char password[33];
			
			if ( var_val_type != ASN_OCTET_STR)
				return SNMP_ERR_WRONGTYPE;

			if ( (var_val_len > 32) || (var_val_len < 1))
				return SNMP_ERR_WRONGVALUE;

			if (action == COMMIT) {
				memcpy(password,var_val,var_val_len);
				snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s username admin password %s user-type admin\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,password);
				system(cli_cmd);
			}
		#else
		/* Don't support this OID any more */	
			return SNMP_ERR_NOSUCHNAME;
		#endif
			break;
		}
			
		default:
			return SNMP_ERR_NOTWRITABLE;
	}
	return 0;
}

u_char         *
Prowlan_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	static long     long_return;
	u_char          return_buf[MAX_ZYWALL_SNMP_STR_LEN];
	oid 	newname[MAX_NAME_LEN];
	int 	result;

	*write_method = Prowlan_write;

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	newname[(int)vp->namelen] = 0;
	result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + 1);
	if ((exact && (result != 0)) || (!exact && (result >= 0)))
		return NULL;
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + 1) * sizeof(oid));
	*length = vp->namelen + 1;
	*var_len = sizeof(long);

	switch (vp->magic)
	{	
		case ADMIN_PASSWORD:
		{
			char wOnly[32];
			
			/* Don't support this OID any more */
			sprintf(wOnly, "Not support.");

			*var_len = strlen(wOnly);
			memcpy(return_buf, wOnly, *var_len);
			return (u_char *) return_buf;	
			
		}
			
		default:
			return NULL;
	}
	return NULL;
}

static oid 	Prowlan_variables_oid[] = {SYSTEM_MIB,ES_PRODUCT_SPECIFIC_OID,ES_PROWLAN_OID};

struct variable2 Prowlan_vars[]= {
	{ADMIN_PASSWORD, ASN_OCTET_STR, RWRITE, Prowlan_read, 1, {1}}
};

void
init_prowlan(void)
{
	REGISTER_MIB("prowlan", Prowlan_vars, variable2, Prowlan_variables_oid);
}


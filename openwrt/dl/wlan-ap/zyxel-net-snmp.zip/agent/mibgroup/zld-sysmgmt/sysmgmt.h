/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#ifndef MIB_SYSMGMT_H
#define MIB_SYSMGMT_H


/*oid*/

#define SYS_MGMT_REBOOT			1
#define SYS_MGMT_CONFIGSAVE		2
#define SYS_MGMT_RESTOREDEFAULT		3
#define SYS_MGMT_CPUUSAGE				4
#define SYS_MGMT_MEMUSAGE		5
#define SYS_MGMT_FLASHUSAGE		6
#define SYS_MGMT_CPU5SECUSAGE	7
#define SYS_MGMT_CPU1MINUSAGE	8
#define SYS_MGMT_CPU5MINUSAGE	9

#endif


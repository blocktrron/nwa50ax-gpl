/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "sysmgmt.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zykit.h"


static int
Sysmgmt_write(int action, u_char * var_val, u_char var_val_type,
                 size_t var_val_len, u_char * statP,
                 oid * name, size_t name_len)
{
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];
	int magic;
	magic = name[name_len -2];
		
	switch (magic) {
		case SYS_MGMT_REBOOT:
		{
			if (var_val_type != ASN_INTEGER)
				return SNMP_ERR_WRONGTYPE;
			
			if ((*((int *) var_val)) == 1 ) {
				if (action == COMMIT) {
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"reboot\"", ZYWALL_SNMP_ZYSH);
					system(cli_cmd);
				}
			}
			else	 if ((*((int *) var_val)) != 0) {
				return SNMP_ERR_WRONGVALUE;
			}
			
			break;
		}
			
		case SYS_MGMT_CONFIGSAVE:
		{
			if (var_val_type != ASN_INTEGER)
				return SNMP_ERR_WRONGTYPE;
			
			if ((*((int *) var_val)) == 1 ) {
				if (action == COMMIT) {
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s write\"", ZYWALL_SUBCOMMAND_ZYSH,CONFIGURE_TERMINAL);
					system(cli_cmd);
				}
			}
			else	 if ((*((int *) var_val)) != 0) {
				return SNMP_ERR_WRONGVALUE;
			}
			
			break;
		}

		case SYS_MGMT_RESTOREDEFAULT:
		{
			if (var_val_type != ASN_INTEGER)
				return SNMP_ERR_WRONGTYPE;
			
			if ((*((int *) var_val)) == 1 ) {
				if (action == COMMIT) {
					system("/bin/kill -USR1 `/bin/pidof zyshd_wd`");
				}
			}
			else	 if ((*((int *) var_val)) != 0) {
				return SNMP_ERR_WRONGVALUE;
			}
			
			break;
		}

		default:
			return SNMP_ERR_NOTWRITABLE;
	}
	return 0;
}


u_char         *
Sysmgmt_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	static long     long_return;
	u_char          return_buf[MAX_ZYWALL_SNMP_STR_LEN];
	oid 	newname[MAX_NAME_LEN];
	int 	result;

	*write_method = Sysmgmt_write;

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	newname[(int)vp->namelen] = 0;
	result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + 1);
	if ((exact && (result != 0)) || (!exact && (result >= 0)))
		return NULL;
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + 1) * sizeof(oid));
	*length = vp->namelen + 1;
	*var_len = sizeof(long);

	switch (vp->magic)
	{
		case SYS_MGMT_REBOOT:
		{
			char wOnly[32];

			*var_len = sizeof long_return;
			long_return = 0;
			return (u_char *) & long_return;	
		}	

		case SYS_MGMT_CONFIGSAVE:
		{
			char wOnly[32];

			*var_len = sizeof long_return;
			long_return = 0;
			return (u_char *) & long_return;	
		}

		case SYS_MGMT_RESTOREDEFAULT:
		{
			char wOnly[32];

			*var_len = sizeof long_return;
			long_return = 0;
			return (u_char *) & long_return;	
		}	

		case SYS_MGMT_CPUUSAGE:
		{
			char sysCPUUsage[MAX_ZYWALL_SNMP_STR_LEN];
			int CPUusage = 0;
			sysCPUUsage[0] = '\0';
			
			/* get cpu usage */
			if( get_sysCPUUsage(sysCPUUsage) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get CPU usage\n");
				return NULL;
			}
			CPUusage = atoi(sysCPUUsage);
			ZYWALL_SNMP_MSG("CPUusage: %d\n", CPUusage);

			*var_len = sizeof long_return;
			long_return = CPUusage;
			return (u_char *) & long_return;
		}	

		case SYS_MGMT_MEMUSAGE:
		{
			char sysRAMUsage[MAX_ZYWALL_SNMP_STR_LEN];
			int RAMusage = 0;
			sysRAMUsage[0] = '\0';
		
			/* get ram usage */
			if( get_sysRAMUsage(sysRAMUsage) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get Memory usage\n");
				return NULL;
			}
	
			RAMusage = atoi(sysRAMUsage);
			ZYWALL_SNMP_MSG("RAMusage: %d\n", RAMusage);

			*var_len = sizeof long_return;
			long_return = RAMusage;
			return (u_char *) & long_return;
		}	

		case SYS_MGMT_FLASHUSAGE:
		{
			char sysFLASHUsage[MAX_ZYWALL_SNMP_STR_LEN];
			int FLASHusage = 0;
			sysFLASHUsage[0] = '\0';
			
			/* get ram usage */
			if( get_sysFLASHUsage(sysFLASHUsage) ) {
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get FLASH Usage\n");
				return NULL;
			}
	
			FLASHusage = atoi(sysFLASHUsage);
			ZYWALL_SNMP_MSG("FLASHusage: %d\n", FLASHusage);

			*var_len = sizeof long_return;
			long_return = FLASHusage;
			return (u_char *) & long_return;
		}	

		case SYS_MGMT_CPU5SECUSAGE:
		{
			int CPUusage2 = 0;
			int type;
			char msg[16];
			type = FIVE_SEC;
			strcpy(msg, "5 secs");

			if( (CPUusage2 = get_multiple_sysCPUUsage(type)) == -1){
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get %d CPU usage\n", msg);
				return NULL;
			}

			ZYWALL_SNMP_MSG("CPU %s usage: %d\n", msg, CPUusage2);

			*var_len = sizeof long_return;
			long_return = CPUusage2;
			return (u_char *) & long_return;
		}

		case SYS_MGMT_CPU1MINUSAGE:
		{
			int CPUusage2 = 0;
			int type;
			char msg[16];
			type = ONE_MIN;
			strcpy(msg, "1 min");

			if( (CPUusage2 = get_multiple_sysCPUUsage(type)) == -1){
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get %d CPU usage\n", msg);
				return NULL;
			}

			ZYWALL_SNMP_MSG("CPU %s usage: %d\n", msg, CPUusage2);

			*var_len = sizeof long_return;
			long_return = CPUusage2;
			return (u_char *) & long_return;
		}

		case SYS_MGMT_CPU5MINUSAGE:
		{
			int CPUusage2 = 0;
			int type;
			char msg[16];
			type = FIVE_MIN;
			strcpy(msg, "5 mins");

			if( (CPUusage2 = get_multiple_sysCPUUsage(type)) == -1){
				ZYWALL_SNMP_LOG(LOG_ERR, "Error get %d CPU usage\n", msg);
				return NULL;
			}

			ZYWALL_SNMP_MSG("CPU %s usage: %d\n", msg, CPUusage2);

			*var_len = sizeof long_return;
			long_return = CPUusage2;
			return (u_char *) & long_return;
		}

		default:
			return NULL;
	}
	return NULL;
}

static oid 	Sysmgmt_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_SYS_MGMT_OID};

struct variable2 Sysmgmt_vars[]= {
	{SYS_MGMT_REBOOT, ASN_INTEGER, RWRITE, Sysmgmt_read, 1, {1}},
	{SYS_MGMT_CONFIGSAVE, ASN_INTEGER, RWRITE, Sysmgmt_read, 1, {2}},
	{SYS_MGMT_RESTOREDEFAULT, ASN_INTEGER, RWRITE, Sysmgmt_read, 1, {3}},
	{SYS_MGMT_CPUUSAGE, ASN_INTEGER, RONLY, Sysmgmt_read, 1, {4}},
	{SYS_MGMT_MEMUSAGE, ASN_INTEGER, RONLY, Sysmgmt_read, 1, {5}},
	{SYS_MGMT_FLASHUSAGE, ASN_INTEGER, RONLY, Sysmgmt_read, 1, {6}},
	{SYS_MGMT_CPU5SECUSAGE, ASN_INTEGER, RONLY, Sysmgmt_read, 1, {7}},
	{SYS_MGMT_CPU1MINUSAGE, ASN_INTEGER, RONLY, Sysmgmt_read, 1, {8}},
	{SYS_MGMT_CPU5MINUSAGE, ASN_INTEGER, RONLY, Sysmgmt_read, 1, {9}}
};

void
init_sysmgmt(void)
{
	REGISTER_MIB("sysmgmt", Sysmgmt_vars, variable2, Sysmgmt_variables_oid);
}


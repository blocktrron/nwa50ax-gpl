/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 


#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "wireless.h"
#include "wireless_total_station.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"

u_char         *
WlanTotalStation_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	u_char          return_buf[MAX_ZYWALL_SNMP_STR_LEN];
	static long     long_return;
	int NEED_INDEX = 1;
	oid newname[MAX_OID_LEN] = {0};
	int chipIndex, result;
	int WIRELESS_DEV_SUPPORT;
	
	*write_method = NULL;

	WIRELESS_DEV_SUPPORT = zykit_get_current_model_slotnum();

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	newname[(int)vp->namelen] = 0;
	result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + NEED_INDEX);
	if ((exact && (result != 0)) || (!exact && (result >= 0)))
		return NULL;
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + NEED_INDEX) * sizeof(oid));
	*length = vp->namelen + NEED_INDEX;
	*var_len = sizeof(long);

	switch (vp->magic)
	{
		case WLAN_TOTAL_STATION_COUNT:
		{
			int StationCount = 0;
			int TotalStationCount = 0;

			for (chipIndex = 1; chipIndex <= WIRELESS_DEV_SUPPORT; chipIndex++)
			{
				if ((StationCount = get_sta_number(chipIndex)) < 0)
					return NULL;
				
				TotalStationCount += StationCount;
			}

			*var_len = sizeof long_return;
			long_return = TotalStationCount;
			return (u_char *) & long_return;
		}
		default:
			return NULL;
	}

	return NULL;
}


static oid	Wireless_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_WIRELESS_OID};

struct variable2 WlanTotalStation_vars[]= {
	{WLAN_TOTAL_STATION_COUNT, ASN_INTEGER, RONLY, WlanTotalStation_read, 1, {15}}
};

void
init_wireless_total_station(void)
{
	REGISTER_MIB("WlanTotalStation", WlanTotalStation_vars, variable2, Wireless_variables_oid);
}


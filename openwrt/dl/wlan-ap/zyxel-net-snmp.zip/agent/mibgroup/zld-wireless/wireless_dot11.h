/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 


#ifndef MIB_WIRELESS_DOT11_H
#define MIB_WIRELESS_DOT11_H


/*oid*/
#define DOT11_FAILED_COUNT				1
#define DOT11_RETRY_COUNT					2
#define DOT11_ACK_FAILURE_COUNT			3
#define DOT11_RECEIVED_FRAME_COUNT		4
#define DOT11_TRANSMITTED_FRAME_COUNT	5
#define DOT11_RECEIVED_PKT_COUNT			6
#define DOT11_TRANSMITTED_PKT_COUNT		7

#endif


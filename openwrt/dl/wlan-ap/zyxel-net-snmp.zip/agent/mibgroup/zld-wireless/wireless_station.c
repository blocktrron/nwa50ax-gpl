/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 


#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "wireless.h"
#include "wireless_station.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zld-spec.h"
#include "wireless_hal.h"
#include <time.h>

#define RSSI_UPPER_BOUND -50
#define RSSI_LOWER_BOUND -100
static int32_t CW_normalizeRSSI2dBm(int32_t rssi)
{
	int32_t normal = 0;

#if !(ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 102)
	normal = rssi;
#else
	normal =  rssi -95;
#endif
#if 0	/* Mark it to remove lower & upper bound limitation */
	if (normal< RSSI_LOWER_BOUND)
	normal = RSSI_LOWER_BOUND;
	else if (normal > RSSI_UPPER_BOUND)
	normal = RSSI_UPPER_BOUND;
#endif
	return normal;
}

static debugMsg_t debugMessage;

u_char         *
WlanStation_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	static u_char	return_buf[MAX_ZYWALL_SNMP_STR_LEN];
	static long	long_return;
	int	NEED_INDEX = 2;
	oid	newname[MAX_OID_LEN] = {0};
	int	result, chipIndex;
	int	plen=(int)vp->namelen-1;	// prefixlen
	int	max_station, stationIndex;
	snmpStaInfo_t entry;
	struct tm *sTime;
	int WIRELESS_DEV_SUPPORT;
	int socket_fd = -1;
	int slotIdx;

	*write_method = NULL;
	
	WIRELESS_DEV_SUPPORT = zykit_get_current_model_slotnum();

	for (slotIdx = 0 ; slotIdx < WIRELESS_DEV_SUPPORT ; slotIdx++)
	{
		memset(&debugMessage, 0x0, sizeof(debugMsg_t));
		debugMessage.radioIdx = slotIdx;
		if ((socket_fd = sendWirelessHalEvent(DEBUG_EVENT_STA_RUNTIME_INFO, &debugMessage, sizeof(debugMessage))) > 0)
		{
			close(socket_fd);
		}
	}
	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	
	for (chipIndex = 1; chipIndex <= WIRELESS_DEV_SUPPORT; chipIndex++) {
		
		if ((max_station = get_sta_number(chipIndex)) < 0)
			break;
		
		for (stationIndex = 1; stationIndex <= max_station ; stationIndex++) {
			
			if (get_sta_entry(chipIndex, stationIndex, &entry) <= 0)
				continue;
			
			
			newname[plen + 1] = chipIndex;
			newname[plen + 1 + 1] = stationIndex;
			
			result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + NEED_INDEX);
			if (exact && result == 0) {
				goto good;
			}
			
			if (!exact && result < 0) {
				goto good;
			}
		}
	}

	/*not find*/
	return NULL;

good:
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + NEED_INDEX) * sizeof(oid));
	*length = vp->namelen + NEED_INDEX;
	*write_method = 0;
	*var_len = sizeof(long);   /* default length */

	switch (vp->magic)
	{
		case WLAN_STATION_INDEX:
			*var_len = sizeof long_return;
			long_return = stationIndex;
			
			return (u_char *) & long_return;

		case WLAN_STATION_MAC_ADDRESS:
		{
			memcpy(return_buf, entry.MAC, 6);
			*var_len = 6;

			return (u_char*) return_buf;
		}

		case WLAN_STATION_ASSOCIATE_TIME:
		{
			sTime = localtime(&entry.assoTime);

			*(u_int8_t *)&return_buf[0] = (u_int8_t)((sTime->tm_year + 1900) >> 8);
			*(u_int8_t *)&return_buf[1] = (u_int8_t)(sTime->tm_year + 1900);
			*(u_int8_t *)&return_buf[2] = sTime->tm_mon + 1;
			*(u_int8_t *)&return_buf[3] = sTime->tm_mday;
			*(u_int8_t *)&return_buf[4] = sTime->tm_hour;
			*(u_int8_t *)&return_buf[5] = sTime->tm_min;
			*(u_int8_t *)&return_buf[6] = sTime->tm_sec;
			*(u_int8_t *)&return_buf[7] = 0;
			
			*var_len = strlen (return_buf);	

			return (u_char *) return_buf;
		}

		case WLAN_STATION_SSID:
		{
			strcpy(return_buf, entry.ssid);
			*var_len = strlen(return_buf);

			return (u_char *) return_buf;
		}
		
		case WLAN_STATION_SIGNAL_STRENGTH:
		{
			sprintf( return_buf, "%d", CW_normalizeRSSI2dBm(entry.rssi) );
			*var_len = strlen(return_buf);

			return (u_char *) return_buf;
		}

		default:
			return NULL;
	}

	return NULL;
}


static oid	Wireless_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_WIRELESS_OID};

struct variable4 WlanStation_vars[]= {
	{WLAN_STATION_INDEX, ASN_INTEGER, RONLY, WlanStation_read, 3, {2,1,1}},
	{WLAN_STATION_MAC_ADDRESS, ASN_OCTET_STR, RONLY, WlanStation_read, 3, {2,1,2}},
	{WLAN_STATION_ASSOCIATE_TIME, ASN_OCTET_STR, RONLY, WlanStation_read, 3, {2,1,3}},
	{WLAN_STATION_SSID, ASN_OCTET_STR, RONLY, WlanStation_read, 3, {2,1,4}},
	{WLAN_STATION_SIGNAL_STRENGTH, ASN_OCTET_STR, RONLY, WlanStation_read, 3, {2,1,5}}
};

void
init_wireless_station(void)
{
	REGISTER_MIB("WlanStation", WlanStation_vars, variable4, Wireless_variables_oid);
}


/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "wireless.h"
#include "wireless_ap.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zysh_io.h"
#include "zld-spec.h"
#include "zykit.h"

int
GetRadioProfileByChipIndex(int chipIndex, char *profile)
{
	confCTX_t *editing_config = NULL;
	zyio_entity	entity = NULL;
	char slot[6], role[32];
	int ret = 1;   /* 1: ap mode, 0: moniter mode, <0: error */

	editing_config = zyio_restore_scope(DOT11_DB_FILE);

	sprintf(slot,"slot%d",chipIndex);
	entity = zyio_retrieve_entity(editing_config, DOT11_XML_SCOPE, DOT11_XML_TYPE, slot);
	if(entity==NULL) {
		ret = -1;
		goto error;
	}

	if (zyio_get(entity, "Role", role)) {
		if (!strcmp(role,"monitor")) {
			ret = 0;
			goto error;
		}
	}

	ret = zyio_get(entity, "Profile", profile);

error:
	if (editing_config)
		zyio_close_config(editing_config);
	return ret;
}

int
GetRadioModeByProfile(char *profile)
{
	confCTX_t *editing_config = NULL;
	zyio_entity	entity = NULL;
	char str_buf[6];
	int ret = 0;

	editing_config = zyio_restore_scope(RADIO_DB_FILE);

	if (strcmp(profile,"none")) {
		entity = zyio_retrieve_entity(editing_config, RADIO_PROFILE_XML_SCOPE, TYPE_RADIO_PROFILE_LIST, profile);
		if (entity) {
			if(zyio_get(entity,RADIO_PROFILE_BAND,str_buf)){
				if(!strcmp(str_buf,RADIO_PROFILE_2G_BAND)) {
					ret = CHANNEL_2G;
				}
				else if(!strcmp(str_buf,RADIO_PROFILE_5G_BAND)) {
					ret = CHANNEL_5G;
				}
			}
		}
	}

	if (editing_config)
		zyio_close_config(editing_config);
	return ret;
}


static int
WlanAP_write(int action, u_char * var_val, u_char var_val_type,
                 size_t var_val_len, u_char * statP,
                 oid * name, size_t name_len)
{
	int retval = 0;
	int chipIndex = 0, magic = 0;
	char cli_cmd[MAX_ZYWALL_SNMP_SCRIPT_CONTENT_LEN];
	char profile[MAX_PROFILE_LEN];

	chipIndex = name[name_len -1];
	magic = name[name_len -2];

	switch (magic) {
#ifdef ZLDCONFIG_WLAN_PROFILE_ENABLE
		case WLAN_MODE:
			if ( var_val_type != ASN_INTEGER){
				retval = SNMP_ERR_WRONGTYPE;
			}
			
			if (action == COMMIT) {
				retval = GetRadioProfileByChipIndex(chipIndex, profile);
				if( retval > 0) {
					if((*((int *) var_val))  == CHANNEL_2G) {
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s band %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,"2.4G");
					system(cli_cmd);
					}
					else if((*((int *) var_val))  == CHANNEL_5G) {
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s band %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,"5G");
					system(cli_cmd);
					}
					else
						retval = SNMP_ERR_WRONGVALUE;

					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s exit\"",
						ZYWALL_SUBCOMMAND_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile);
					system(cli_cmd);
				}
				else
					retval = SNMP_ERR_COMMITFAILED;
			}
			break;
			
		case WLAN_CHANNEL:
			if ( var_val_type != ASN_INTEGER ){
				retval = SNMP_ERR_WRONGTYPE;
			}
			
			if (action == COMMIT) {
				int mode = 0;
				retval = GetRadioProfileByChipIndex(chipIndex, profile);
				if( retval > 0) {
					mode = GetRadioModeByProfile(profile);
					if (mode == CHANNEL_2G) {
						snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s 2g-channel %d\"",
							ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,*((int *) var_val));
						system(cli_cmd);
					}
					else if (mode == CHANNEL_5G) {
						snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s 5g-channel %d\"",
							ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,*((int *) var_val));
						system(cli_cmd);
					}
					else
						retval = SNMP_ERR_WRONGVALUE;
				}
				else
					retval = SNMP_ERR_COMMITFAILED;

				snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s exit\"",
						ZYWALL_SUBCOMMAND_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile);
				system(cli_cmd);
			}
			break;

		case WLAN_TX_POWER:
			if ( var_val_type != ASN_INTEGER ){
				retval = SNMP_ERR_WRONGTYPE;
			}
			
			if (action == COMMIT) {
				retval = GetRadioProfileByChipIndex(chipIndex, profile);
				if( retval > 0) {
					if((*((int *) var_val))  == POWER_100) { 
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s output-power %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,"100%");
					system(cli_cmd);
					}
					else if((*((int *) var_val))  == POWER_50) { 
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s output-power %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,"50%");
					system(cli_cmd);
					}
					else if((*((int *) var_val))  == POWER_25) { 
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s output-power %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,"25%");
					system(cli_cmd);
					}
					else if((*((int *) var_val))  == POWER_12) { 
					snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s output-power %s\"",
						ZYWALL_SNMP_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile,"12.5%");
					system(cli_cmd);
					}
					else
						retval = SNMP_ERR_WRONGVALUE;
				}
				else
					retval = SNMP_ERR_COMMITFAILED;

				snprintf(cli_cmd, sizeof(cli_cmd), "%s -e \"%s %s %s exit\"",
						ZYWALL_SUBCOMMAND_ZYSH,CONFIGURE_TERMINAL,WIRELESS_RADIOS_PROFILE,profile);
				system(cli_cmd);
			}
			break;
#endif
			
		default:
			break;
	}

	return retval;
}

u_char         *
WlanAP_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	confCTX_t *editing_config = NULL;
	static u_char          return_buf[MAX_ZYWALL_SNMP_STR_LEN];
	static long     long_return;
	int NEED_INDEX = 1;
	oid newname[MAX_OID_LEN] = {0};
	int chipIndex, result;
	int plen=(int)vp->namelen;	// prefixlen
	int WIRELESS_DEV_SUPPORT;
	
	*write_method = WlanAP_write;

	WIRELESS_DEV_SUPPORT = zykit_get_current_model_slotnum();

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	for (chipIndex = 1; chipIndex <= WIRELESS_DEV_SUPPORT; chipIndex++)
	{
		newname[plen] = (oid)(chipIndex);
		result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + NEED_INDEX);
		if ((exact && (result == 0)) || (!exact && (result < 0)) ){
			break;
		}
	}
	
	if ((result >= 0) && (chipIndex > WIRELESS_DEV_SUPPORT)){
		return NULL;
	}
	
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + NEED_INDEX) * sizeof(oid));
	*length = vp->namelen + NEED_INDEX;
	*var_len = sizeof(long);

	switch (vp->magic)
	{
#ifdef ZLDCONFIG_WIRELESS_HAL_SUPPORT
		case CURRENT_CHANNEL:
		{
			int Channel = 0;

			if ((Channel = get_current_channel(chipIndex)) < 0)
				return NULL;

			*var_len = sizeof long_return;
			long_return = Channel;
			return (u_char *) & long_return;
		}
		
		case STATION_COUNT:
		{
			int StationCount = 0;

			if ((StationCount = get_sta_number(chipIndex)) < 0)
				return NULL;

			*var_len = sizeof long_return;
			long_return = StationCount;
			return (u_char *) & long_return;
		}
#endif
#ifdef ZLDCONFIG_WLAN_PROFILE_ENABLE
		case WLAN_SUPPORTED_CHANNEL:
		{
			zyio_entity	entity = NULL;
			char profile[MAX_PROFILE_LEN];
			char str_buf[6], ch_width[20] = {0}, country_code[20] = {0};
			char SupportChannel[MAX_ZYWALL_SNMP_STR_LEN];
			int mode = 0;

			/* init str */
			SupportChannel[0] = '\0';

			result = GetRadioProfileByChipIndex(chipIndex, profile);
			if( result < 0) {
				return NULL;
			}
			else if (result == 0) {
				*var_len = 34;
				memcpy(return_buf, "This slot is set as MONITER mode.", *var_len);
				return (u_char *) return_buf;
			}
			
			if (!strcmp(profile,"none")) {
				return NULL;
			}

			editing_config = zyio_restore_scope(RADIO_DB_FILE);
			entity = zyio_retrieve_entity(editing_config, RADIO_PROFILE_XML_SCOPE, TYPE_RADIO_PROFILE_LIST, profile);
			if (!entity) {
				goto error;
			}
			
			mode = zykit_wlan_get_hybridmode();
			
			if(mode == WHOPMODE_STANDALONE) {
				strncpy(country_code, zykit_mrd_get_countryname(1), sizeof(country_code));
			}
			else if(mode == WHOPMODE_MANAGED) {
#ifdef ZLDCONFIG_COUNTRY_CODE_AP
				if(!zyio_get(entity,RADIO_PROFILE_COUNTRY_CODE,country_code))
#endif
					goto error;
			}
			else
				goto error;

			if(zyio_get(entity,RADIO_PROFILE_BAND,str_buf)
				&& zyio_get(entity,RADIO_PROFILE_CHANNEL_WIDTH,ch_width)
			){
				if(!strcmp(str_buf,RADIO_PROFILE_2G_BAND)) {
					if( get_sysSupport11ag(SupportChannel, CHANNEL_11G, ch_width, country_code) ) {
						ZYWALL_SNMP_LOG(LOG_ERR, "Error get Support Channel\n");
						goto error;
					}
				}
				else if(!strcmp(str_buf,RADIO_PROFILE_5G_BAND)) {
					if( get_sysSupport11ag(SupportChannel, CHANNEL_11A, ch_width, country_code) ) {
						ZYWALL_SNMP_LOG(LOG_ERR, "Error get Support Channel\n");
						goto error;
					}
				}
				else
					goto error;
			}
			else
				goto error;
		
			ZYWALL_SNMP_MSG("Supported Channel: %s\n", SupportChannel);
			zyio_close_config(editing_config);

			*var_len = strlen(SupportChannel);
			memcpy(return_buf, SupportChannel, *var_len);
			return (u_char *) return_buf;
		}
			
		case WLAN_SUPPORTED_RATE:
		{
			zyio_entity	entity = NULL;
			char profile[MAX_PROFILE_LEN];
			char SupportRate[MAX_ZYWALL_SNMP_STR_LEN];
			char str_buf[6];

			/* init str */
			SupportRate[0] = '\0';
			
			result = GetRadioProfileByChipIndex(chipIndex, profile);
			if(result < 0) {
				return NULL;
			}
			else if (result == 0) {
				*var_len = 34;
				memcpy(return_buf, "This slot is set as MONITER mode.", *var_len);
				return (u_char *) return_buf;
			}
			
			if (!strcmp(profile,"none")) {
				return NULL;
			}

			editing_config = zyio_restore_scope(RADIO_DB_FILE);
			entity = zyio_retrieve_entity(editing_config, RADIO_PROFILE_XML_SCOPE, TYPE_RADIO_PROFILE_LIST, profile);
			if (!entity) {
				goto error;
			}

			if(zyio_get(entity,RADIO_PROFILE_BAND,str_buf)){
				if(!strcmp(str_buf,RADIO_PROFILE_2G_BAND)) {
					if (zyio_get(entity,RADIO_PROFILE_SUPPORT_SPEED_2G,SupportRate) == 0)
						goto error;
				}
				else if(!strcmp(str_buf,RADIO_PROFILE_5G_BAND)) {
					if (zyio_get(entity,RADIO_PROFILE_SUPPORT_SPEED_5G,SupportRate) == 0)
						goto error;
				}
				else
					goto error;
			}
			else
				goto error;

			ZYWALL_SNMP_MSG("Supported Rate: %s\n", SupportRate);
			zyio_close_config(editing_config);
	
			*var_len = strlen(SupportRate);
			memcpy(return_buf, SupportRate, *var_len);
			return (u_char *) return_buf;
		}

		case WLAN_MODE:
		{
			char profile[MAX_PROFILE_LEN];
			int mode = 0;
			
			result = GetRadioProfileByChipIndex(chipIndex, profile);
			if( result < 0) {
				return NULL;
			}
			else if (result == 0) {
				*var_len = 34;
				memcpy(return_buf, "This slot is set as MONITER mode.", *var_len);
				return (u_char *) return_buf;
			}

			mode = GetRadioModeByProfile(profile);
			if( mode == 0) {
				return NULL;
			}
	
			ZYWALL_SNMP_MSG("Wlan Mode: %d\n", mode);

			*var_len = sizeof long_return;
			long_return = mode;
			return (u_char *) & long_return;
		}

		case WLAN_CHANNEL:
		{
			zyio_entity	entity = NULL;
			char profile[MAX_PROFILE_LEN];
			char channel_buf[3], str_buf[6];
			int channel;
			
			result = GetRadioProfileByChipIndex(chipIndex, profile);
			if( result < 0) {
				return NULL;
			}
			else if (result == 0) {
				*var_len = 34;
				memcpy(return_buf, "This slot is set as MONITER mode.", *var_len);
				return (u_char *) return_buf;
			}
						
			if (!strcmp(profile,"none")) {
				return NULL;
			}

			editing_config = zyio_restore_scope(RADIO_DB_FILE);
			entity = zyio_retrieve_entity(editing_config, RADIO_PROFILE_XML_SCOPE, TYPE_RADIO_PROFILE_LIST, profile);
			if (!entity) {
				goto error;
			}
			if(zyio_get(entity,RADIO_PROFILE_BAND,str_buf)){
				if(!strcmp(str_buf,RADIO_PROFILE_2G_BAND)) {
					if (zyio_get(entity,RADIO_PROFILE_CHANNEL_2G,channel_buf) == 0)
						goto error;
				}
				else if(!strcmp(str_buf,RADIO_PROFILE_5G_BAND)) {
					if (zyio_get(entity,RADIO_PROFILE_CHANNEL_5G,channel_buf) == 0)
						goto error;
				}
				else
					goto error;
			}
			else
				goto error;
			
			channel= atoi(channel_buf);
			ZYWALL_SNMP_MSG("Wlan Chennel: %d\n", channel);
			zyio_close_config(editing_config);

			*var_len = sizeof long_return;
			long_return = channel;
			return (u_char *) & long_return;
			
		}

		case WLAN_TX_POWER:
		{
			
			zyio_entity	entity = NULL;
			char profile[MAX_PROFILE_LEN];
			char TX_buf[5];
			int TX_power;

			result = GetRadioProfileByChipIndex(chipIndex, profile);
			if( result < 0) {
				return NULL;
			}
			else if (result == 0) {
				*var_len = 34;
				memcpy(return_buf, "This slot is set as MONITER mode.", *var_len);
				return (u_char *) return_buf;
			}
						
			if (!strcmp(profile,"none")) {
				return NULL;
			}

			editing_config = zyio_restore_scope(RADIO_DB_FILE);
			entity = zyio_retrieve_entity(editing_config, RADIO_PROFILE_XML_SCOPE, TYPE_RADIO_PROFILE_LIST, profile);
			if (!entity) {
				goto error;
			}
			if(zyio_get(entity,RADIO_PROFILE_OUTPUT_POWER,TX_buf) == 0)
				goto error;

			if (!strcmp(TX_buf,"100%")) {
				TX_power = POWER_100;
			}
			else if (!strcmp(TX_buf,"50%")) {
				TX_power = POWER_50;
			}
			else if (!strcmp(TX_buf,"25%")) {
				TX_power = POWER_25;
			}
			else if (!strcmp(TX_buf,"12.5%")) {
				TX_power = POWER_12;
			}
			else
				goto error;
			
			ZYWALL_SNMP_MSG("Wlan Chennel: %d\n", TX_buf);
			zyio_close_config(editing_config);

			*var_len = sizeof long_return;
			long_return = TX_power;
			return (u_char *) & long_return;
		}
#endif
		
		default:
			 return NULL;
	}

error:

	if(editing_config)
		zyio_close_config(editing_config);
	return NULL;
}

static oid	Wireless_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_WIRELESS_OID};

struct variable4 WlanAP_vars[]= {
	{CURRENT_CHANNEL, ASN_INTEGER, RONLY, WlanAP_read, 3, {1,1,1}},
	{STATION_COUNT, ASN_INTEGER, RONLY, WlanAP_read, 3, {1,1,2}},	
	{WLAN_SUPPORTED_CHANNEL, ASN_OCTET_STR, RONLY, WlanAP_read, 3, {1,1,3}},
	{WLAN_SUPPORTED_RATE, ASN_OCTET_STR, RONLY, WlanAP_read, 3, {1,1,4}},
	{WLAN_MODE, ASN_INTEGER, RWRITE, WlanAP_read, 3, {1,1,5}},
	{WLAN_CHANNEL, ASN_INTEGER, RWRITE, WlanAP_read, 3, {1,1,6}},
	{WLAN_TX_POWER, ASN_INTEGER, RWRITE, WlanAP_read, 3, {1,1,7}}
};

void
init_wireless_ap(void)
{
	REGISTER_MIB("Wireless", WlanAP_vars, variable4, Wireless_variables_oid);
}


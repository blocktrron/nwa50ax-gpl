/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 


#include   <time.h>
#include   <stdio.h>
#include   <stdlib.h>
#include   <string.h>
#include   <signal.h>
#include   <errno.h>
/*for socket*/
#include   <string.h>
#include   <netinet/in.h>
#include   <sys/types.h>
#include   <sys/socket.h>
#include   <sys/un.h>
#include   <netinet/ip.h>
#include   <arpa/inet.h>

#include   "wireless_hal.h"
#include   "../zld/zld_lib.h"

static snmpMsg_t snmpMsg;
static snmpEventMsg_t snmpEvent;

int sendWirelessHalEvent(int eventCode, debugMsg_t *msg, size_t len)
{
	debugEventMsg_t event;
	struct sockaddr_un debugSocket; /* AF_UNIX socket for event IPC */
	int debugIpcFd = -1;
	
	if (len > sizeof(debugMsg_t)) {
		return -1;
	}
	debugSocket.sun_family = AF_UNIX;
	strcpy(debugSocket.sun_path, WIRELESSHAL_DEBUG_PATH);
	debugIpcFd = socket(AF_UNIX, SOCK_STREAM, 0);
	
	if (debugIpcFd < 0) {
		return -1;
	}
	if (connect(debugIpcFd, (struct sockaddr *)&debugSocket, sizeof(struct sockaddr_un)) < 0) {
		close(debugIpcFd);
		return -1;
	}
	
	event.pid = getpid();
	event.code = eventCode;
	memset(&event.msg, 0, sizeof(debugMsg_t));
	
	if ((msg != NULL) && (len > 0))
	{
		memcpy(&event.msg, msg, len);
	}
	
	if (write(debugIpcFd, &event, sizeof(debugEventMsg_t)) < 0)
	{
		close(debugIpcFd);
		return -1;
	}
	return debugIpcFd;
}

int send_snmp_event(int eventCode, snmpMsg_t *msg, int len)
{
	snmpEventMsg_t event;
	struct sockaddr_un snmpSocket; /* AF_UNIX socket for event IPC */
	int snmpIpcFd = -1;
	
	if (len > sizeof(snmpMsg_t))
	{
		ZYWALL_SNMP_MSG("Error, event message size too large\n");
		return -1;
	}

	snmpSocket.sun_family = AF_UNIX;
	strcpy(snmpSocket.sun_path, WIRELESSHAL_EVENT_PATH);
	snmpIpcFd = socket(AF_UNIX, SOCK_STREAM, 0);
	
	if (snmpIpcFd < 0)
	{
		ZYWALL_SNMP_MSG("*** Allocate event socket error, errno=%d, %s ***\n", errno, strerror(errno));
		return -1;
	}

	if (connect(snmpIpcFd, (struct sockaddr *)&snmpSocket, (size_t)(((struct sockaddr_un *)0)->sun_path)+sizeof(snmpSocket.sun_family)+
		strlen(snmpSocket.sun_path)) < 0) 
	{
		ZYWALL_SNMP_MSG("*** Event socket connection failed, errno=%d, %s ***\n", errno, strerror(errno));
		close(snmpIpcFd);
		return -1;
	}

	event.pid = getpid(); /* the process id that sends the event*/
	event.code = eventCode;
	memset(&event.msg, 0, sizeof(snmpMsg_t));
	
	if ((msg != NULL) && (len > 0))
	{
		memcpy(&event.msg, msg, len);
	}

	if (write(snmpIpcFd, &event, sizeof(snmpEventMsg_t)) < 0)
	{
		ZYWALL_SNMP_MSG("Error writing event message !!!\n");
		close(snmpIpcFd);
		return -1;
	}

	/* close the IPC socket*/
	return snmpIpcFd;
}


static void*
process_snmp_event(snmpEventMsg_t *event)
{

	switch (event->code)
	{
		case SNMP_GET_STA_NUM:
			return (int *)&((event->msg.staNum));
		case SNMP_GET_STA_ENTRY:
			return (snmpStaInfo_t *)(&(event->msg.snmpStaInfo));
		case SNMP_GET_STA_ENTRY_END:
			break;
		case SNMP_GET_CURRENT_CHANNEL:
			return (int*)(&(event->msg.chann));
		case SNMP_GET_WLAN_STATISTIC:
			return (wlanStatistic_t *)(&(event->msg.wlanCounter));
		case SNMP_GET_WLAN_TXRX:
			return (wlanStatistic_t *)(&(event->msg.wlanCounter));
			break;
		default:
			ZYWALL_SNMP_MSG("in %s , line %d , rx evt code %d\n\r",__FUNCTION__,__LINE__,event->code);
			break;
	}

	return NULL;
}


int
rx_snmp_event_loop(void *arg,int arg_len,int connectFd)
{
	int		nfds;
	fd_set readfds, allset;
	int maxfds;
	int fd;
	socklen_t clilen;
	struct sockaddr_in clientAddr;
	int nread;
	struct timeval timeout;
	void *ret=NULL;
	int	retval=-1;

	signal(SIGPIPE, SIG_IGN); /*ignore broken pipe error.*/

	/*set timeout value of socket*/
	timeout.tv_sec = 1;
	timeout.tv_usec = 0;
	setsockopt(connectFd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout) );
	
	/* clear temporary event buffer*/
	memset((char *)&snmpEvent, 0, sizeof(snmpEventMsg_t));
	
	nread = read(connectFd, &snmpEvent, sizeof(snmpEventMsg_t));
	if (nread == sizeof(snmpEventMsg_t))
	{
		/* process event immediately*/
		ret= (process_snmp_event(&snmpEvent));
		if(ret)
		{
			memcpy(arg,ret,arg_len);
			retval = 1;
		}
		else
		{
			retval = 0;
		}
	}
	else if (nread < 0) 
	{
		close(connectFd);
		return -1;
	}

	/*remember to close fd*/
	if(connectFd >= 0)
	{
		close(connectFd);
	}

	return retval;

}


int
get_current_channel(int radioIdx){
	int socket_fd = -1, rx_retcode = -1;
	int chann;

	memset(&snmpMsg,0x0,sizeof(snmpMsg_t));
	snmpMsg.radioIdx= radioIdx - 1; 
	if ((socket_fd = send_snmp_event(SNMP_GET_CURRENT_CHANNEL, &snmpMsg, sizeof(snmpMsg))) > 0)
	{
		rx_retcode = rx_snmp_event_loop(&chann,sizeof(chann),socket_fd);
		if (rx_retcode > 0)
		{
			return chann;
		}
	}

	return -1;
}


int
get_sta_number(int radioIdx){
	int socket_fd = -1, rx_retcode = -1;
	int staNum;

	memset(&snmpMsg,0x0,sizeof(snmpMsg_t));
	snmpMsg.radioIdx= radioIdx - 1;
	if ((socket_fd = send_snmp_event(SNMP_GET_STA_NUM, &snmpMsg, sizeof(snmpMsg))) > 0)
	{
		rx_retcode = rx_snmp_event_loop(&staNum,sizeof(staNum),socket_fd);
		if (rx_retcode > 0)
		{
			return staNum;
		}
	}	

	return -1;
}


int
get_sta_entry(int radioIdx, int staIdx, snmpStaInfo_t *entry){
	int socket_fd = -1, rx_retcode = -1;

	memset(&snmpMsg,0x0,sizeof(snmpMsg_t));

	snmpMsg.rStaIdx.staIdx = staIdx - 1;
	snmpMsg.rStaIdx.radioIdx= radioIdx - 1;
	if ((socket_fd = send_snmp_event(SNMP_GET_STA_ENTRY, &snmpMsg, sizeof(snmpMsg))) > 0)
	{
		memset(entry,0x0,sizeof(snmpStaInfo_t));
		rx_retcode = rx_snmp_event_loop(entry,sizeof(snmpStaInfo_t),socket_fd);
	}

	return rx_retcode;
}


int
get_wlan_statistic(int radioIdx, wlanStatistic_t *entry){
	int socket_fd = -1, rx_retcode = -1;

	memset(&snmpMsg,0x0,sizeof(snmpMsg_t));
	snmpMsg.radioIdx= radioIdx - 1;
	if ((socket_fd = send_snmp_event(SNMP_GET_WLAN_STATISTIC, &snmpMsg, sizeof(snmpMsg))) > 0)
	{
		memset(entry,0x0,sizeof(wlanStatistic_t));	
		rx_retcode = rx_snmp_event_loop(entry,sizeof(wlanStatistic_t),socket_fd);
	}
	
	return rx_retcode;
}

int
get_wlan_rxtx(wlanStatistic_t *entry){
	int socket_fd = -1, rx_retcode = -1;

	memset(&snmpMsg,0x0,sizeof(snmpMsg_t));
	if ((socket_fd = send_snmp_event(SNMP_GET_WLAN_TXRX, &snmpMsg, sizeof(snmpMsg))) > 0)
	{
		memset(entry,0x0,sizeof(wlanStatistic_t));	
		rx_retcode = rx_snmp_event_loop(entry,sizeof(wlanStatistic_t),socket_fd);
	}
	
	return rx_retcode;
}





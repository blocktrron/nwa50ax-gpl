/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include "wireless.h"
#include "wireless_dot11.h"
#include "../zld_oid.h"
#include "../zld/zld_lib.h"
#include "zld-spec.h"
#include "wireless_hal.h"

u_char         *
WlanStatistics_read(struct variable * vp, oid * name, size_t * length,
               int exact, size_t * var_len, WriteMethod ** write_method)
{
	int NEED_INDEX = 1;
	oid newname[MAX_OID_LEN] = {0};
	static U64 long64_return;
	int chipIndex, result;
	int plen=(int)vp->namelen;	// prefixlen
	wlanStatistic_t entry;	
	int WIRELESS_DEV_SUPPORT;

	*write_method = 0;

	WIRELESS_DEV_SUPPORT = zykit_get_current_model_slotnum();

	memcpy((char *)newname, (char *)vp->name, (int)vp->namelen * sizeof(oid));
	for (chipIndex = 1; chipIndex <= WIRELESS_DEV_SUPPORT; chipIndex++)
	{
		if (get_wlan_statistic(chipIndex, &entry) <= 0)
			continue;

		newname[plen] = (oid)(chipIndex);
		result = snmp_oid_compare(name, *length, newname, (int)vp->namelen + NEED_INDEX);
		if ((exact && (result == 0)) || (!exact && (result < 0)) ){
			break;
		}
	}
	
	if ((result >= 0) && (chipIndex > WIRELESS_DEV_SUPPORT)){
		return NULL;
	}
	
	memcpy((char *)name, (char *)newname, ((int)vp->namelen + NEED_INDEX) * sizeof(oid));
	*length = vp->namelen + NEED_INDEX;
	*var_len = sizeof(long64_return);

	switch (vp->magic)
	{
		case DOT11_FAILED_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.FailedCount >> 32);
			long64_return.low = (unsigned long)(entry.FailedCount & 0xffffffff);
			return (u_char *) & long64_return;
		}
		
		case DOT11_RETRY_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.RetryCount >> 32);
			long64_return.low = (unsigned long)(entry.RetryCount & 0xffffffff);
			return (u_char *) & long64_return;
		}

		case DOT11_ACK_FAILURE_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.ACKFailureCount >> 32);
			long64_return.low = (unsigned long)(entry.ACKFailureCount & 0xffffffff);
			return (u_char *) & long64_return;
		}

		case DOT11_RECEIVED_FRAME_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.ReceivedFragmentCount >> 32);
			long64_return.low = (unsigned long)(entry.ReceivedFragmentCount & 0xffffffff);
			return (u_char *) & long64_return;
		}

		case DOT11_TRANSMITTED_FRAME_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.TransmittedFrameCount >> 32);
			long64_return.low = (unsigned long)(entry.TransmittedFrameCount & 0xffffffff);
			return (u_char *) & long64_return;
		}

		case DOT11_RECEIVED_PKT_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.ReceivedPktCount >> 32);
			long64_return.low = (unsigned long)(entry.ReceivedPktCount & 0xffffffff);
			return (u_char *) & long64_return;
		}

		case DOT11_TRANSMITTED_PKT_COUNT:
		{
			*var_len = sizeof(long64_return);
			long64_return.high = (unsigned long)(entry.TransmittedPktCount >> 32);
			long64_return.low = (unsigned long)(entry.TransmittedPktCount & 0xffffffff);
			return (u_char *) & long64_return;
		}

		default:
			return NULL;
	}
	return NULL;
}

static oid	Wireless_variables_oid[] = {SYSTEM_MIB,ES_MGMT_OID,ES_WIRELESS_OID};

struct variable4 WlanStatistics_vars[] = {
	{DOT11_FAILED_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,1}},
	{DOT11_RETRY_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,2}},
	{DOT11_ACK_FAILURE_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,3}},
	{DOT11_RECEIVED_FRAME_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,4}},
	{DOT11_TRANSMITTED_FRAME_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,5}},
	{DOT11_RECEIVED_PKT_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,6}},
	{DOT11_TRANSMITTED_PKT_COUNT, ASN_COUNTER64, RONLY, WlanStatistics_read, 3, {3,1,7}}
};

void
init_wireless_dot11(void)
{
	REGISTER_MIB("WirelessStastistic", WlanStatistics_vars, variable4, Wireless_variables_oid);
}


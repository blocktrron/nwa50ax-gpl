/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#ifndef MIB_WIRELESS_AP_H
#define MIB_WIRELESS_AP_H


#define CHANNEL_2G		1
#define CHANNEL_5G		2

#define POWER_100		1
#define POWER_50		2
#define POWER_25		3
#define POWER_12		4

#define ON		1
#define OFF		2

#define DCS_PATH	"/va	r/zyxel/dcs.conf"

/*CLI*/
#define WIRELESS_RADIOS_PROFILE	"wlan-radio-profile"
#define DCS_ACTIVATE				"dcs activate"

/*XML*/
#define RADIO_PROFILE_BAND					"Band"
#define RADIO_PROFILE_2G_BAND				"2.4G"
#define RADIO_PROFILE_5G_BAND				"5G"
#define RADIO_PROFILE_CHANNEL_2G			"Channel"
#define RADIO_PROFILE_CHANNEL_5G			"Channel_5G"
#define RADIO_PROFILE_SUPPORT_SPEED_2G	"Support_Speed_2G"
#define RADIO_PROFILE_SUPPORT_SPEED_5G	"Support_Speed_5G"
#define RADIO_PROFILE_OUTPUT_POWER		"Output_power"
#define RADIO_PROFILE_CHANNEL_WIDTH		"Channel_width"
#define RADIO_PROFILE_COUNTRY_CODE		"Country_code"

#define DCS_GLOBAL_SETTING_ENTITY		"global_setting"
#define SCOPE_DCS						"network/dcs"
#define TYPE_DCS						"dcs_config_t"
#define DCS_ATRB_ACTIVATE				"activate"
#define DCS_XML_FILE					"/tmp/dcs.xml"

#define DOT11_XML_SCOPE				"network/interface/dot11"
#define DOT11_XML_TYPE					"dot11_t"
#define DOT11_LIST						"dot11"
#define RADIO_PROFILE_XML_SCOPE		"object/radioprofile"
#define TYPE_RADIO_PROFILE_LIST		"radio_profile_list"

#define RADIO_DB_FILE					"/tmp/radio_profile_db.xml"
#define DOT11_DB_FILE					"/tmp/wlan_slot_db.xml"

/*oid*/
#define CURRENT_CHANNEL				1
#define STATION_COUNT					2
#define WLAN_SUPPORTED_CHANNEL		3
#define WLAN_SUPPORTED_RATE			4
#define WLAN_MODE						5
#define WLAN_CHANNEL					6
#define WLAN_TX_POWER					7

#endif


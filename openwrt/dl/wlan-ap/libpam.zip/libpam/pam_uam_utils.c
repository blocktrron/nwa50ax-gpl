/* $Id: pam_uam_utils.c,v 1.7 2007/10/03 05:42:54 rogerho Exp $ */

/*
 * $Log: pam_uam_utils.c,v $
 * Revision 1.7  2007/10/03 05:42:54  rogerho
 * enhance log for SSL VPN
 *
 * Revision 1.6  2006/09/26 12:05:00  juyu
 * New enhancement Dial-in Management.
 *
 * Revision 1.5  2006/08/24 00:13:00  harry
 * Add get_destination_IP function for logging destination IP.
 *
 * Revision 1.4  2006/04/12 12:36:05  wilsonchen
 * fixed bug of //
 *
 * Revision 1.3  2006/04/12 08:43:21  wilsonchen
 * change for banner hiding
 *
 * Revision 1.2  2005/09/22 02:20:22  edward
 * include resolver header files
 *
 * Revision 1.1  2005/09/08 08:36:41  edward
 * initial release
 *
 */

#include <ctype.h>
#include <netdb.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <arpa/nameser.h>
#include <resolv.h>

#include <security/pam_modules.h>
#include <security/_pam_macros.h>
#include <security/_pam_types.h>

#include <security/pam_uam_utils.h>

/* BEGIN: copied from uam-1.0.0/misc.h */
#define NIPQUAD(addr) \
	((unsigned char *)&addr)[0], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[3]

void *uam_malloc(size_t size);

void uam_free(void *ptr);

char *uam_strdup(const char *s);

unsigned long uptime(void);

void *get_shm(key_t key);
void put_shm(void *addr);
int get_sem(key_t key);
void put_sem(key_t key);
/* END: of copied from uam-1.0.0/misc.h */


#include "uam.h"
#include "zylog.h"

#include <stdio.h>

static service_map_t service_map[] =
{
	{"login",		SERVICE_NAME_CONSOLE,	0,	SERVICE_TYPE_CONSOLE},
	{"login",		SERVICE_NAME_TELNET,	1,	SERVICE_TYPE_TELNET},
	{"ssh",			SERVICE_NAME_SSH,		1,	SERVICE_TYPE_SSH},
/*20060410 wilson added sshd*/
	{"sshd",		SERVICE_NAME_SSH,		1,	SERVICE_TYPE_SSH},
	{"weblogin",	SERVICE_NAME_HTTP_HTTPS,1,	SERVICE_TYPE_HTTP_HTTPS},
	{"ftp",			SERVICE_NAME_FTP,		1,	SERVICE_TYPE_FTP},
	{"dialin",		SERVICE_NAME_DIALIN,	0,	SERVICE_TYPE_DIALIN},
	{"xauth",		SERVICE_NAME_XAUTH,		0,  SERVICE_TYPE_XAUTH},
	{"captive_portal",	SERVICE_NAME_HTTP_HTTPS,1, SERVICE_TYPE_HTTP_HTTPS},
#if defined(AAA_WEB_PORTAL)
	{"captive_portal_1_1",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_2",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_3",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_4",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_5",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_6",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_7",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_1_8",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_1",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_2",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_3",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_4",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_5",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_6",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_7",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
	{"captive_portal_2_8",	SERVICE_NAME_CAPTIVE_PORTAL,1, SERVICE_TYPE_CAPTIVE_PORTAL},
#endif
};

static char *
map_service_name(char *name, u_int32_t ip, struct in6_addr *ip6, int *type)
{
	unsigned int i;
	for (i = 0; i < sizeof(service_map) / sizeof(service_map_t); i++) {
		service_map_t *map = &service_map[i];
		if (!strcmp(name, map->orig_name)
		    ||(!strcmp(map->orig_name, "xauth") && !strncmp(name, map->orig_name, 5))
		   ) {
#ifdef ZLDCONFIG_IPV6
			if (map->have_ip == 0){
				if(ip6) {
					if (IN6_IS_ADDR_UNSPECIFIED(ip6)) {
						*type = map->type;
						return map->tran_name;
					}
				} else if ( ip == INADDR_NONE ) {
					*type = map->type;
					return map->tran_name;
				}
			}
			if (map->have_ip){
				if (ip6) {
					if ( !IN6_IS_ADDR_UNSPECIFIED(ip6) ) {
						*type = map->type;
						return map->tran_name;
					}
				} else if (ip && (ip != INADDR_NONE)) {
					*type = map->type;
					return map->tran_name;
				}
			}
#else
			if (map->have_ip == 0 && ip == INADDR_NONE) {
				*type = map->type;
				return map->tran_name;
			}
			if (map->have_ip && ip && (ip != INADDR_NONE)) {
				*type = map->type;
				return map->tran_name;
			}
#endif
		}
	}
	*type = SERVICE_TYPE_UNKNOWN;
	return SERVICE_NAME_UNKNOWN;
}

/* utilities */
static int resolve_hostname(const char *hostname, u_int32_t *ip, struct in6_addr *ip6, int *af)
{
#ifdef ZLDCONFIG_IPV6
	union sockaddr_union *so;
	struct addrinfo hints, *ai, *ailist;
	int ret, count;
#else
	char ipbuf[INET_ADDRSTRLEN];
	struct hostent *he;
#endif

#ifdef ZLDCONFIG_IPV6
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;    /* Allow IPv4 or IPv6 */
	hints.ai_socktype = SOCK_DGRAM; /* Datagram socket */
	hints.ai_flags = 0;
	hints.ai_protocol = 0;          /* Any protocol */
	/* save error to host_error for later use */
	ret = getaddrinfo(hostname, NULL, &hints, &ailist);
	if (ret != 0)
		return ret;

	count = 0;
	for (ai = ailist; ai != NULL && count < 2; ai = ai->ai_next) {
		so = (union sockaddr_union *) ai->ai_addr;
		if (ai->ai_family == AF_INET6) {
			memcpy(ip6, &(so->sin6.sin6_addr), sizeof(struct in6_addr));
			count++;
			if ((ip6->s6_addr16[0] == 0) && (ip6->s6_addr16[1] == 0) && (ip6->s6_addr16[2] == 0) &&
				(ip6->s6_addr16[3] == 0) && (ip6->s6_addr16[4] == 0) && (ip6->s6_addr16[5] == 0xffff)) {
				// Convert IPv6 mapped IPv4 address back to IPv4 address (for proftpd case)
				*ip = ip6->s6_addr32[3];
				*af = AF_INET;
			}
			else
			*af = AF_INET6;
		} else if (ai->ai_family == AF_INET) {
			memcpy(ip,&so->sin.sin_addr,sizeof(struct in_addr));
		    count++;
			*af = AF_INET;
		}
	}
	freeaddrinfo(ailist);

	return count > 0 ? 0 : -1;
#else
	/* reset resolver context */
	res_init();
	he = gethostbyname(hostname);
	if (!he) {
		return -1;
	}

	while (*he->h_addr_list) {
		*ip = inet_addr(inet_ntop(he->h_addrtype, *he->h_addr_list++,
					ipbuf, sizeof(ipbuf)));
		return 0;
	}
	return -1;
#endif
}

#ifdef ZLDCONFIG_IPV6
int
get_destination_IP6(int service_type, struct in6_addr *dst_ip6) {
	int i = 0, flag = 0;
	pid_t ppid = 0;
	FILE *fp = NULL;
	char cmd[255], buffer[255];
	char pid_str[8], *tmp = NULL, *ptr = NULL;

	if(service_type == SERVICE_TYPE_FTP) {
		ppid = getpid();
	} else {
		ppid = getppid();
	}
	PAM_UAM_DEBUG("Parent PID is: %i.\n", ppid);
	snprintf(cmd, sizeof(cmd), "netstat -npW | grep %i", ppid);
	fp = popen(cmd, "r");

	if(fp == NULL) {
		memset(dst_ip6, '\0', sizeof(struct in6_addr));
		return -1;
	}

	/* Ensure that the entry is actually what we want. */
	while(fgets(buffer, sizeof(buffer), fp) != NULL) {
	PAM_UAM_DEBUG("The pipe content is %s.\n", buffer);
		snprintf(pid_str, sizeof(pid_str), "%d", ppid);
		if( (tmp = strstr(buffer, pid_str)) == NULL) {
			continue;
		} else {
			tmp += strlen(pid_str);
			if(!strncmp(tmp, "/", 1)) {
				flag = 1;
				break; /* Get the right entry */
			} else {
				continue;
			}
		}
	}

	if(flag) {
		/* Retrieve the destination IP. */
		tmp = strtok_r(buffer, " ", &ptr);
		for(i = 0; i < 3; i++)
			tmp = strtok_r(NULL, " ", &ptr);
		if(tmp != NULL) { /* get tmp with 'ip6:port' */
			memcpy(buffer, tmp, sizeof(buffer));
			ptr = strrchr(buffer, ':');
			if(ptr)
				*ptr = '\0';
		}
		inet_pton(AF_INET6, buffer, dst_ip6);
		PAM_UAM_DEBUG("Dst IP is %s\n", buffer);
	} else {
		PAM_UAM_DEBUG("Can not get destination IP.\n");
		memset(dst_ip6, '\0', sizeof(struct in6_addr));
	}
	pclose(fp);
	return 0;
}
#endif

int
get_destination_IP(int service_type, u_int32_t *dst_ip) {
	int i = 0, flag = 0;
	pid_t ppid = 0;
	FILE *fp = NULL;
	char cmd[255], buffer[255];
	char pid_str[8], *tmp = NULL, *ptr = NULL;
#if 1
	/* Because the popen function will cause captive portal poor efficiency
	 It only used in zylog and not shown in NCC, so we just initialize it to zero now */
	*dst_ip = 0;
#else
	if(service_type == SERVICE_TYPE_FTP) {
		ppid = getpid();
	} else {
		ppid = getppid();
	}
	PAM_UAM_DEBUG("Parent PID is: %i.\n", ppid);
	snprintf(cmd, sizeof(cmd), "netstat -np | grep %i", ppid);
	fp = popen(cmd, "r");

	if(fp == NULL) {
		*dst_ip = 0;
		return -1;
	}
	/* Ensure that the entry is actually what we want. */
	while(fgets(buffer, sizeof(buffer), fp) != NULL) {
	PAM_UAM_DEBUG("The pipe content is %s.\n", buffer);
		snprintf(pid_str, sizeof(pid_str), "%d", ppid);
		if( (tmp = strstr(buffer, pid_str)) == NULL) {
			continue;
		} else {
			tmp += strlen(pid_str);
			if(!strncmp(tmp, "/", 1)) {
				flag = 1;
				break; /* Get the right entry */
			} else {
				continue;
			}
		}
	}
	if(flag) {
		/* Retrieve the destination IP. */
		tmp = strtok_r(buffer, " ", &ptr);
		for(i = 0; i < 3; i++)
			tmp = strtok_r(NULL, " ", &ptr);
		if(tmp != NULL) {
			tmp = strtok_r(tmp, ":", &ptr);
		}

		*dst_ip = inet_addr(tmp);
		PAM_UAM_DEBUG("Dst IP is %u.%u.%u.%u\n", NIPQUAD(*dst_ip));
	} else {
		PAM_UAM_DEBUG("Can not get destination IP.\n");
		*dst_ip = 0;
	}
	pclose(fp);
#endif
	return 0;
}

void
pam_get_destination_IP(pam_handle_t *pamh, struct pam_info *info)
{
#ifdef ZLDCONFIG_IPV6
	char ip_buf[INET6_ADDRSTRLEN];
#endif
	int retval;
	char *dest_ip;

	retval = pam_get_item(pamh, PAM_DEST_IP, (const void **)&dest_ip);

#ifdef ZLDCONFIG_IPV6
	if ( info->flags & PAM_INFO_FLAG_USED_IPV6 ) {
		if (retval != PAM_SUCCESS || dest_ip == NULL) {
			get_destination_IP6(info->service_type, &info->dst_ip6);
		} else {
			inet_pton(AF_INET6, dest_ip, &info->dst_ip6);
		}
		inet_ntop(AF_INET6, &info->dst_ip6, ip_buf, INET6_ADDRSTRLEN);
		PAM_UAM_DEBUG("Get pam info6: username: %s host: %s(%s) service: %s:%d(%s) unique: %s\n",
						info->username, info->hostname, ip_buf,
						info->service, info->service_type, info->orig_service, info->unique);
	} else {
		if (retval != PAM_SUCCESS || dest_ip == NULL) {
			get_destination_IP(info->service_type, &info->dst_ip);
		} else {
			info->dst_ip = inet_addr(dest_ip);
		}
		PAM_UAM_DEBUG("Get pam info4: username: %s host: %s(%u.%u.%u.%u) service: %s:%d(%s) unique: %s\n",
						info->username, info->hostname, NIPQUAD(info->ip),
						info->service, info->service_type, info->orig_service, info->unique);
	}
#else
	if (retval != PAM_SUCCESS || dest_ip == NULL) {
		get_destination_IP(info->service_type, &info->dst_ip);
	} else {
		info->dst_ip = inet_addr(dest_ip);
	}

	PAM_UAM_DEBUG("Get pam info: username: %s host: %s(%u.%u.%u.%u) service: %s:%d(%s) unique: %s\n",
					info->username, info->hostname, NIPQUAD(info->ip),
					info->service, info->service_type, info->orig_service, info->unique);
#endif

}

/* If you want get dst_ip/dst_ip6 you need use pam_get_destination_IP() additionally */
int
pam_get_userinfo(pam_handle_t *pamh, struct pam_info *info)
{
    int retval;
	int *buf;
#ifdef ZLDCONFIG_IPV6
	int addr_family = AF_INET;
	char ip_buf[INET6_ADDRSTRLEN];
#endif

	/* according to pam_unix_auth.c implementation */
	retval = pam_get_user(pamh, &info->username, NULL);
    if (retval != PAM_SUCCESS ||
		info->username == NULL || !isalnum(*info->username)) {
		PAM_UAM_DEBUG("get user error: %s %s\n", info->username,
				pam_strerror(pamh, retval));
		/* note that username may be a null pointer but get a PAM_SUCCESS */
		return PAM_USER_UNKNOWN;
    }

	retval = pam_get_item(pamh, PAM_RHOST, (const void **) &info->hostname);
	if (retval != PAM_SUCCESS
		/* when login from console, the hostname is NULL */
		/* || info->hostname == NULL || *info->hostname == '\0'*/) {
		PAM_UAM_DEBUG("get hostname error: %s\n", pam_strerror(pamh, retval));
		return retval;
	}

	if (info->hostname && *info->hostname) {
		PAM_UAM_DEBUG("Resolve hostname: %s\n", info->hostname);
#ifdef ZLDCONFIG_IPV6
		/* retval > 0 , check addr_family AF_INET(2), AF_INET6(10) */
		retval = resolve_hostname((char *)info->hostname, &info->ip, &info->ip6, &addr_family);
		if (addr_family == AF_INET6) {
			info->flags |= PAM_INFO_FLAG_USED_IPV6;
			inet_ntop(AF_INET6, &info->ip6, ip_buf, INET6_ADDRSTRLEN);
			PAM_UAM_DEBUG("[Resolved]: %s, af:%d\n", ip_buf, addr_family);
		} else if (addr_family == AF_INET){
			PAM_UAM_DEBUG("[Resolved]: %u.%u.%u.%u, af:%d\n",  NIPQUAD(info->ip), addr_family );
		}
		if (retval < 0)
#else
		if (resolve_hostname(info->hostname, &info->ip, NULL, NULL) < 0)
#endif
		{
			PAM_UAM_DEBUG("Can't resolve hostname: %s!\n", info->hostname);
			return PAM_AUTHINFO_UNAVAIL;
		}
	} else {
		PAM_UAM_DEBUG("[No hostname!]\n");
#ifdef ZLDCONFIG_IPV6
		memset( &info->ip6, 0, sizeof(struct in6_addr)); /* FIXME, ?? TBD */
#endif
		info->ip = INADDR_NONE;
	}

	retval = pam_get_item(pamh, PAM_SERVICE, (const void **) &info->orig_service);
	if (retval != PAM_SUCCESS ||
		info->orig_service == NULL || *info->orig_service =='\0') {
		PAM_UAM_DEBUG("get service error: %s\n", pam_strerror(pamh, retval));
		return retval;
	}

	retval = pam_get_item(pamh, PAM_TTY, (const void **) &info->unique);
	if (retval != PAM_SUCCESS ||
		info->unique == NULL || *info->unique =='\0') {
		/* for some services (ftp), this could lead to failure */
		PAM_UAM_DEBUG("get unique error: %s set unique to empty string\n", pam_strerror(pamh, retval));
		info->unique = "";
		/* return retval; */
	}

	/* enhanced by Roger */
	retval = pam_get_item(pamh, PAM_ZYXEL_SSLVPN, (const void **) &buf);
	if (retval != PAM_SUCCESS) {
		/* for some services (ftp), this could lead to failure */
		PAM_UAM_DEBUG("get sslvpn error: %s set sslvpn to zero\n", pam_strerror(pamh, retval));
		info->sslvpn = 0;
		/* return retval; */
	} else {
		info->sslvpn = *buf;
	}

	/* enhanced by yvonne.cheng*/
	retval = pam_get_item(pamh, PAM_ZYXEL_AUTH_INFO, (const void **) &info->auth_info);
	if (retval != PAM_SUCCESS) {
		PAM_UAM_DEBUG("get auth_info error: %s\n", pam_strerror(pamh, retval));
		return retval;
	}

#if defined(ZLDCONFIG_QRCODE_AUTHENTICATOR)
	/* enhance by ShuPing.Yu */
	retval = pam_get_item(pamh, PAM_ZYXEL_QRCODE_AUTHENTICATOR, (const void **) &info->qrcode_authenticator);
	if(retval != PAM_SUCCESS) {
		PAM_UAM_DEBUG("get qrcode_authenticator error: %s\n", pam_strerror(pamh, retval));
		return retval;
	}
#endif

#if defined(AAA_WEB_PORTAL)
	/* Don't need to do error handling, it will return PAM_SUCCESS forever... */
	/* Just Cloud mode captive portal auth can get value */
	info->ssid_profile_name = NULL;
	info->sta_mac = NULL;
	pam_get_item(pamh, PAM_ZYXEL_PORTAL_SSID_PROFILE, (const void **) &info->ssid_profile_name);
	pam_get_item(pamh, PAM_ZYXEL_PORTAL_STA_MAC, (const void **) &info->sta_mac);
#endif

	/* service mapping */
#ifdef ZLDCONFIG_IPV6
	if ( info->flags & PAM_INFO_FLAG_USED_IPV6 )
		info->service = map_service_name((char *) info->orig_service, 0, &info->ip6, &info->service_type);
	else
#endif
		info->service = map_service_name((char *) info->orig_service, info->ip, NULL, &info->service_type);

	 /* get destination IP by Harry */
#ifdef ZLDCONFIG_IPV6
	if ( info->flags & PAM_INFO_FLAG_USED_IPV6 ) {
		retval = get_destination_IP6(info->service_type, &info->dst_ip6);
		inet_ntop(AF_INET6, &info->ip6, ip_buf, INET6_ADDRSTRLEN);
		PAM_UAM_DEBUG("Get pam info6: username: %s host: %s(%s) service: %s:%d(%s) unique: %s\n",
						info->username, info->hostname, ip_buf,
						info->service, info->service_type, info->orig_service, info->unique);
	} else {
		retval = get_destination_IP(info->service_type, &info->dst_ip);
		PAM_UAM_DEBUG("Get pam info4: username: %s host: %s(%u.%u.%u.%u) service: %s:%d(%s) unique: %s\n",
						info->username, info->hostname, NIPQUAD(info->ip),
						info->service, info->service_type, info->orig_service, info->unique);
	}
#else
	retval = get_destination_IP(info->service_type, &info->dst_ip);
	PAM_UAM_DEBUG("Get pam info: username: %s host: %s(%u.%u.%u.%u) service: %s:%d(%s) unique: %s\n",
					info->username, info->hostname, NIPQUAD(info->ip),
					info->service, info->service_type, info->orig_service, info->unique);
#endif

	return PAM_SUCCESS;
}

int
pam_get_user_role(pam_handle_t *pamh, struct pam_info *info)
{
	int retval;
	void *buf;

	retval = pam_get_item(pamh, PAM_ZYXEL_USER_ROLE, (const void **)&info->role);
	if( retval != PAM_SUCCESS) {
		PAM_UAM_DEBUG("Get item PAM_ZYXEL_USER_ROLE fail");
		return retval;
	}

	retval = pam_get_item(pamh, PAM_ZYXEL_LEASE_TIME, (const void **)&buf);
	if( retval	!= PAM_SUCCESS) {
		PAM_UAM_DEBUG("Get item PAM_ZYXEL_LEASE_TIME fail");
		return retval;
	}
	info->lease_time = *(int *) buf;

	retval = pam_get_item(pamh, PAM_ZYXEL_REAUTH_TIME, (const void **)&buf);
	if( retval	!= PAM_SUCCESS) {
		PAM_UAM_DEBUG("Get item PAM_ZYXEL_REAUTH_TIME fail");
		return retval;
	}
	info->reauth_time = *(int *) buf;

#ifdef ZLDCONFIG_WEBAUTH
	retval = pam_get_item(pamh, PAM_ZYXEL_DUE_TIME, (const void **)&buf);
	if( retval	!= PAM_SUCCESS) {
		PAM_UAM_DEBUG("Get item PAM_ZYXEL_DUE_TIME fail");
		return retval;
	}
	info->due_time = *(int *) buf;
#endif

	retval = pam_get_item(pamh, PAM_ZYXEL_DEFINED_USERNAME, (const void **)&info->define_username);
	if( retval	!= PAM_SUCCESS) {
		PAM_UAM_DEBUG("Get item PAM_ZYXEL_DEFINED_USERNAME fail");
		return retval;
	}

	retval = pam_get_item(pamh, PAM_ZYXEL_IDLE_TIMEOUT, (const void **)&buf);
	if ( retval != PAM_SUCCESS) {
		PAM_UAM_DEBUG("Get item PAM_ZYXEL_IDLE_TIMEOUT fail");
		return retval;
	}
	info->idle_timeout = *(int *) buf;

#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
	retval = pam_get_item(pamh, PAM_ZYXEL_RADIUS_PROFILE, (const void **)&info->profile_name);
	if ( retval != PAM_SUCCESS) {
		PAM_UAM_DEBUG("Can't get pam item[PAM_ZYXEL_RADIUS_PROFILE]\n");
		return retval;
	}
#if 0 /* controller code. because there is no aaa profile on AP, remove these code */
	else
	{
		if(info->profile_name)
		{

			PAM_UAM_DEBUG("get event.radius_profile_name: %s\n", info->profile_name);
#endif
			retval = pam_get_item(pamh, PAM_ZYXEL_SESSION_TIMEOUT, (const void **)&buf);
			if ( retval != PAM_SUCCESS) {
				PAM_UAM_DEBUG("Can't get pam item[PAM_ZYXEL_SESSION_TIMEOUT]\n");
				return retval;
			}
			info->session_timeout = *(int *) buf;
			PAM_UAM_DEBUG("get event.session_timeout: %x\n", info->session_timeout);
#if 0 /* controller code. because there is no aaa profile on AP, remove these code */
		}
	}
#endif
#endif
#ifdef AAA_WEB_PORTAL
	if(!strcmp(info->service, SERVICE_NAME_CAPTIVE_PORTAL)){
		retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_METHOD, (const void **)&info->method);
		if( retval != PAM_SUCCESS) {
			PAM_UAM_DEBUG("Get item PAM_ZYXEL_PORTAL_METHOD fail");
			return retval;
		}

		retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_SSID_NAME, (const void **)&info->ssid_name);
		if( retval != PAM_SUCCESS) {
			PAM_UAM_DEBUG("Get item PAM_ZYXEL_PORTAL_SSID_NAME fail");
			return retval;
		}

		retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_SSID_PROFILE, (const void **)&info->ssid_profile_name);
		if( retval != PAM_SUCCESS) {
			PAM_UAM_DEBUG("Get item PAM_ZYXEL_PORTAL_SSID_PROFILE fail");
			return retval;
		}

		retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_VAP_IF, (const void **)&info->ssid_vap_iface);
		if( retval != PAM_SUCCESS) {
			PAM_UAM_DEBUG("Get item PAM_ZYXEL_PORTAL_VAP_IF fail");
			return retval;
		}

		retval = pam_get_item(pamh, PAM_ZYXEL_PORTAL_STA_MAC, (const void **)&info->sta_mac);
		if( retval != PAM_SUCCESS) {
			PAM_UAM_DEBUG("Get item PAM_ZYXEL_PORTAL_STA_MAC fail");
			return retval;
		}
	}
#endif


	return PAM_SUCCESS;
}

int
valid_username(const char *username)
{
	while(1) {
		if (*username == '\0')
			break;
		if (!(isalnum(*username) || *username == '-' || *username == '_'))
			return 0;
		username++;
	}
	return 1;
}

/*
 * pam_auth.c -- PAM authentication
 *
 * $Id$
 *
 */

#include "pam_private.h"
#include "pam_prelude.h"

#include <stdio.h>
#include <stdlib.h>

#include "zld-spec.h"
#ifdef ZLDCONFIG_LINUX_PAM_MODIFICATION
#include <unistd.h>
#define inline
#include <security/pam_uam_utils.h>
#include <netinet/in.h>
#include "zylog.h"
#ifndef HOST_NAME_MAX
#define HOST_NAME_MAX 256
#endif
#endif /* ZLDCONFIG_LINUX_PAM_MODIFICATION */

#define PAM_FAIL_ZYLOG(msg,arg...)	zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM, \
										pinfo.ip, 0, pinfo.dst_ip, 0, note, \
										msg, ##arg)
#ifdef ZLDCONFIG_IPV6
#define PAM_FAIL_ZYLOG6(msg,arg...)	zylog6(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM, \
										&(pinfo.ip6), 0, &(pinfo.dst_ip6), 0, note, \
										msg, ##arg)
#endif
int is_cloud;
int pam_authenticate(pam_handle_t *pamh, int flags)
{
    int retval;
    D(("pam_authenticate called"));

    IF_NO_PAMH("pam_authenticate", pamh, PAM_SYSTEM_ERR);

#ifdef ZLDCONFIG_LINUX_PAM_MODIFICATION
    char hostname[HOST_NAME_MAX];
    if (gethostname(hostname, sizeof(hostname)) != 0) {
        strcpy(hostname, "device");
    }
#endif /* ZLDCONFIG_LINUX_PAM_MODIFICATION */

    if (__PAM_FROM_MODULE(pamh)) {
	D(("called from module!?"));
	return PAM_SYSTEM_ERR;
    }

    if (pamh->former.choice == PAM_NOT_STACKED) {
	_pam_sanitize(pamh);
	_pam_start_timer(pamh);    /* we try to make the time for a failure
				      independent of the time it takes to
				      fail */
    }

    retval = _pam_dispatch(pamh, flags, PAM_AUTHENTICATE);

    if (retval != PAM_INCOMPLETE) {
	_pam_sanitize(pamh);
	_pam_await_timer(pamh, retval);   /* if unsuccessful then wait now */
	D(("pam_authenticate exit"));
    } else {
	D(("will resume when ready"));
    }

#ifdef ZLDCONFIG_LINUX_PAM_MODIFICATION
    if (retval != PAM_SUCCESS) {
	char note[32];
	struct pam_info pinfo;

	if (pam_get_userinfo(pamh, &pinfo) != PAM_SUCCESS) {
	    PAM_UAM_DEBUG("%s","Can't get user information!\n");
	    goto out;
	}

	pam_get_destination_IP(pamh, &pinfo);

	if (pinfo.username && valid_username(pinfo.username))
	    snprintf(note, sizeof(note), "Account: %s", pinfo.username);
	else
	    strcpy(note, "");

#ifdef ZLDCONFIG_IPV6
	if (!(pinfo.flags & PAM_INFO_FLAG_USED_IPV6)) {
	    if (pinfo.ip == INADDR_NONE)
		pinfo.ip = 0;
	    if (pinfo.dst_ip == INADDR_NONE)
		pinfo.dst_ip = 0;
	}
#else /* ZLDCONFIG_IPV6 */
	if (pinfo.ip == INADDR_NONE)
	    pinfo.ip = 0;
	if (pinfo.dst_ip == INADDR_NONE)
	    pinfo.dst_ip = 0;
#endif /* ZLDCONFIG_IPV6 */

	if(strcmp(pinfo.username, "debug") == 0){
	/* Someone using "debug" account try to hack!! */
		switch(retval)
		{
			case PAM_TO_RAD_TIMEOUT:
#ifdef AAA_WEB_PORTAL
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG6("Account: %s from station: %s has failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
							hostname, pinfo.service);
					}

				}
				else {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
							hostname, pinfo.service);
					}
				}
#else /* ZLDCONFIG_IPV6 */
				if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
					PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
						pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
				}
				else {
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
						hostname, pinfo.service);
				}
#endif /* ZLDCONFIG_IPV6 */
#else /* AAA_WEB_PORTAL */
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
						hostname, pinfo.service);
				}
				else{
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
						hostname, pinfo.service);
				}
#else /* ZLDCONFIG_IPV6 */
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout. (someone try to hack!!)",
						hostname, pinfo.service);
#endif /* ZLDCONFIG_IPV6 */
#endif /* AAA_WEB_PORTAL */
				break;
			default:	// general error or user name / password error
#ifdef AAA_WEB_PORTAL
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG6("Account: %s from station: %s has failed login attempt to %s from %s (someone try to hack!!)",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s (someone try to hack!!)",
							hostname, pinfo.service);
					}
				}
				else {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s (someone try to hack!!)",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (someone try to hack!!)",
							hostname, pinfo.service);
					}
				}
#else /* ZLDCONFIG_IPV6 */
				if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
					PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s (someone try to hack!!)",
						pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
				}
				else {
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (someone try to hack!!)",
						hostname, pinfo.service);
				}
#endif /* ZLDCONFIG_IPV6 */
#else /* AAA_WEB_PORTAL */
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s (someone try to hack!!)",
						hostname, pinfo.service);
				}
				else{
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (someone try to hack!!)",
						hostname, pinfo.service);
				}
#else /* ZLDCONFIG_IPV6 */
				PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (someone try to hack!!)",
					hostname, pinfo.service);
#endif /* ZLDCONFIG_IPV6 */
#endif /* AAA_WEB_PORTAL */
		}
	} else {
		switch(retval)
		{
			case PAM_TO_RAD_TIMEOUT:
#ifdef AAA_WEB_PORTAL
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG6("Account: %s from station: %s has failed login attempt to %s from %s due to radius request timeout.",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s due to radius request timeout.",
							hostname, pinfo.service);
					}

				}
				else {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s due to radius request timeout.",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout.",
							hostname, pinfo.service);
					}
				}
#else /* ZLDCONFIG_IPV6 */
				if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
					PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s due to radius request timeout.",
						pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
				}
				else {
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout.",
						hostname, pinfo.service);
				}
#endif /* ZLDCONFIG_IPV6 */
#else /* AAA_WEB_PORTAL */
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s due to radius request timeout.",
						hostname, pinfo.service);
				}
				else{
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout.",
						hostname, pinfo.service);
				}
#else /* ZLDCONFIG_IPV6 */
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s due to radius request timeout.",
						hostname, pinfo.service);
#endif /* ZLDCONFIG_IPV6 */
#endif /* AAA_WEB_PORTAL */
				break;
			default:	// general error or user name / password error
#ifdef AAA_WEB_PORTAL
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG6("Account: %s from station: %s has failed login attempt to %s from %s (incorrect password or inexistent username)",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s (incorrect password or inexistent username)",
							hostname, pinfo.service);
					}
				}
				else {
					if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
						PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s (incorrect password or inexistent username)",
							pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
					}
					else {
						PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (incorrect password or inexistent username)",
							hostname, pinfo.service);
					}
				}
#else /* ZLDCONFIG_IPV6 */
				if(pinfo.sta_mac && pinfo.username && valid_username(pinfo.username)) {
					PAM_FAIL_ZYLOG("Account: %s from station: %s has failed login attempt to %s from %s (incorrect password or inexistent username)",
						pinfo.username, pinfo.sta_mac, hostname, pinfo.service);
				}
				else {
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (incorrect password or inexistent username)",
						hostname, pinfo.service);
				}
#endif /* ZLDCONFIG_IPV6 */
#else /* AAA_WEB_PORTAL */
#ifdef ZLDCONFIG_IPV6
				if (pinfo.flags & PAM_INFO_FLAG_USED_IPV6) {
					PAM_FAIL_ZYLOG6("Failed login attempt to %s from %s (incorrect password or inexistent username)",
						hostname, pinfo.service);
				}
				else{
					PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (incorrect password or inexistent username)",
						hostname, pinfo.service);
				}
#else /* ZLDCONFIG_IPV6 */
				PAM_FAIL_ZYLOG("Failed login attempt to %s from %s (incorrect password or inexistent username)",
					hostname, pinfo.service);
#endif /* ZLDCONFIG_IPV6 */
#endif /* AAA_WEB_PORTAL */
		}
	}
}
out:
#endif /* ZLDCONFIG_LINUX_PAM_MODIFICATION */

#ifdef PRELUDE
    prelude_send_alert(pamh, retval);
#endif

    return retval;
}

int pam_setcred(pam_handle_t *pamh, int flags)
{
    int retval;

    D(("pam_setcred called"));

    IF_NO_PAMH("pam_setcred", pamh, PAM_SYSTEM_ERR);

    if (__PAM_FROM_MODULE(pamh)) {
	D(("called from module!?"));
	return PAM_SYSTEM_ERR;
    }

    if (! flags) {
	flags = PAM_ESTABLISH_CRED;
    }

    retval = _pam_dispatch(pamh, flags, PAM_SETCRED);

    D(("pam_setcred exit"));

    return retval;
}

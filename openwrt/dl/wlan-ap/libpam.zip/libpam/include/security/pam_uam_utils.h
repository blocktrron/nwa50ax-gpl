#ifndef _SECURITY_PAM_UAM_UTILS_H
#define _SECURITY_PAM_UAM_UTILS_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PAM_INFO_FLAG_USED_IPV6         (1 << 0)

#ifndef PAM_UAM_DEBUG
#define PAM_UAM_DEBUG(fmt, args...) \
do { \
    zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_DEBUG, ZYLOG_FAC_UAM, \
             0, 0, 0, 0, "User", "%s: " fmt, __FUNCTION__, ##args); \
} while(0)
#endif

#ifndef PAM_UAM_ALERT
#define PAM_UAM_ALERT(fmt, args...) \
do { \
    zylog(ZYLOG_SRC_UAM, ZYLOG_PRI_ALERT, ZYLOG_FAC_UAM, \
             0, 0, 0, 0, "User", "%s: " fmt, __FUNCTION__, ##args); \
} while(0)
#endif

/* internal service name map */
typedef struct __service_map_t
{
	char *orig_name;
	char *tran_name;
	int have_ip;
	int type;
} service_map_t;

#ifdef ZLDCONFIG_IPV6
union sockaddr_union  {
	struct sockaddr sa;
	struct sockaddr_in sin;
	struct sockaddr_in6 sin6;
};
#endif

/* Get PAM parameters */
struct pam_info {
	const char *username;
	const char *hostname;
	const char *service;
	const char *orig_service;
	const char *unique;
	const char *role;
	const char *define_username;
	int lease_time;
	int reauth_time;
#ifdef ZLDCONFIG_WEBAUTH
	int due_time;
#endif
	int idle_timeout;

#if defined(ZLDCONFIG_QRCODE_AUTHENTICATOR)
	const char *qrcode_authenticator;
#endif

#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
	int session_timeout;
	const char *profile_name;
#endif

#ifdef ZLDCONFIG_IPV6
	struct in6_addr ip6;
	struct in6_addr dst_ip6;
#endif
	u_int32_t ip;
	u_int32_t dst_ip;
	int service_type;
	/* enhanced by Roger */
	int sslvpn;
	/* enhanced by Neil */
	int flags;
	struct zyuser_auth_info *auth_info;
#if defined(AAA_WEB_PORTAL)
	char *method; /* none, click-througn, sign-on*/
	char *ssid_name;
	char *ssid_profile_name;
	char *ssid_vap_iface;
	char *sta_mac;
#endif
};

static char *map_service_name(char *name, u_int32_t ip, struct in6_addr *ip6, int *type);

static int resolve_hostname(const char *hostname, u_int32_t *ip, struct in6_addr *ip6, int *af);

#ifdef ZLDCONFIG_IPV6
extern int get_destination_IP6(int service_type, struct in6_addr *dst_ip6);
#endif

extern int get_destination_IP(int service_type, u_int32_t *dst_ip);

extern void pam_get_destination_IP(pam_handle_t *pamh, struct pam_info *info);

extern int pam_get_userinfo(pam_handle_t *pamh, struct pam_info *info);

extern int pam_get_user_role(pam_handle_t *pamh, struct pam_info *info);

extern int valid_username(const char *username);
#endif /* SECURITY_PAM_UAM_UTILS_H */


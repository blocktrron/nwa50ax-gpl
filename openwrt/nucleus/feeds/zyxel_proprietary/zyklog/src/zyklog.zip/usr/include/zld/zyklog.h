#ifndef ZYKLOG_H
#define ZYKLOG_H

#include <linux/version.h>

#ifdef __KERNEL__
#include <linux/ipv6.h>
#include <linux/inet.h>
#else
#include <netinet/in.h>
#endif

#ifdef __KERNEL__
#define ZYLOG_PRI_EMERG		0	    /* system is unusable */
#define ZYLOG_PRI_ALERT		1	    /* action must be taken immediately */
#define ZYLOG_PRI_CRIT		2	    /* critical conditions */
#define ZYLOG_PRI_ERR		3	    /* error conditions */
#define ZYLOG_PRI_WARNING	4	    /* warning conditions */
#define ZYLOG_PRI_NOTICE	5	    /* normal but significant condition */
#define ZYLOG_PRI_INFO		6	    /* informational */
#define ZYLOG_PRI_DEBUG		7	    /* debug-level messages */

/* Zylog netlink message type */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
enum {
    ZYLOG_NL_U_BASE = 16,
    ZYLOG_NL_U_MSG,
    ZYLOG_NL_U_PID,
    ZYLOG_NL_U_MAX,
};
#else /* LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) */
#define ZYLOG_NL_U_MSG	1
#define ZYLOG_NL_U_PID	2
#endif

#endif

#define ZYKLOG_MAX_MESSAGE_LEN (128) /* ZYLOG_MAX_MESSAGE_LEN */

#define ZYLOG_FLAGS_LOOKUP_USER			(1 << 0)
#define ZYLOG_FLAGS_NO_SUPPRESSION		(1 << 1)
#define ZYLOG_FLAGS_IPV6_ENABLE			(1 << 2)
#define ZYLOG_FLAGS_CLEAR_HOSTNAME		(1 << 3)
#define ZYLOG_FLAGS_PRINTK_MSG			(1 << 4)
#define ZYLOG_FLAGS_SEND_TO_AC			(1 << 5)

struct zyklog_inf_t {
	struct in6_addr src_ip6;
	struct in6_addr dst_ip6;
	unsigned int	src_ip;
	unsigned int	dst_ip;
	unsigned int	src_port;
	unsigned int	dst_port;
	int	msg_len;
	int flags;
	char	buffer[0];
};

#ifdef __KERNEL__
extern int zylogd_rdy; 
//extern struct sock *nl_sk;
//extern u32 pid;
extern spinlock_t zyklog_lock;
#ifdef CONFIG_IPV6
extern int zyklog6(char *fac, int pri, struct in6_addr *srcip, unsigned int srcport, struct in6_addr *dstip, unsigned int dstport, const char *fmt, ...);
extern int zyklog_alert6(char *fac, int pri, struct in6_addr *srcip, unsigned int srcport, struct in6_addr *dstip, unsigned int dstport, char *fmt, ...);
#endif
extern int zyklog(char *fac, int pri, unsigned int srcip, unsigned int srcport, unsigned int dstip, unsigned int dstport, const char *fmt, ...);
extern int zyklog2AC(char *fac, int pri, unsigned int srcip, unsigned int srcport, unsigned int dstip, unsigned int dstport, const char *fmt, ...);
extern int zyklog_valist(char *fac, int pri, unsigned int srcip, unsigned int srcport, unsigned int dstip, unsigned int dstport, const char *fmt, va_list va);
extern int zyklog_alert(char *fac, int pri, unsigned int srcip, unsigned int srcport, unsigned int dstip, unsigned int dstport, char *fmt, ...);
extern int zyklog_printk(const char *fmt, ...);
#endif
//extern int __zyklog(const char *fmt, ...);

// Neil
#if 0
#define zyklog(fac, pri, srcip, srcport, dstip, dstport, fmt, args...) do { \
	typeof(srcip) _srcip = srcip; \
	typeof(dstip) _dstip = dstip; \
	__zyklog("<%d> fac=\"%s\" src=\"%u.%u.%u.%u:%d\" dst=\"%u.%u.%u.%u:%d\" " #fmt "\n", \
			pri, fac, NIPQUAD((_srcip)), srcport, NIPQUAD((_dstip)), dstport, ##args); \
} while (0)

#define zyklog_alert(fac, pri, srcip, srcport, dstip, dstport, fmt, args...) do { \
	typeof(srcip) _srcip = srcip; \
	typeof(dstip) _dstip = dstip; \
	__zyklog("<%d>*fac=\"%s\" src=\"%u.%u.%u.%u:%d\" dst=\"%u.%u.%u.%u:%d\" " #fmt "\n", \
			pri, fac, NIPQUAD((_srcip)), srcport, NIPQUAD((_dstip)), dstport, ##args); \
} while (0)
#endif

#endif /* ZYKLOG_H */

#ifndef RAW_TABLE_H_
#define RAW_TABLE_H_

#define MD5_LEN 16
#ifdef DEBUG
#define dbg_printf(format, args...) printf("[%s:%d] "format, __FILE__, __LINE__, ##args)
#else
#define dbg_printf(args...)
#endif

enum types
{
	TYPE_CERT = 0,
	TYPE_KEY,
	TYPE_CA,
	TYPE_MAX
};

enum ret_no
{
	RET_SUCCESS = 0,
	RET_CERT_SUCCESS,
	RET_POPEN_FAIL,
	RET_MKTMP_FAIL,
	RET_CERT_FAIL,
	RET_SAVE_FAIL,
	RET_MD5_FAIL,
};

struct raw_info
{
	enum types type;
	unsigned int data_len;
	unsigned char md5[MD5_LEN];
};

struct raw_entry
{
	struct raw_info info;
	unsigned char *val;
};

int verify_type(unsigned int type);
int verify_md5(struct raw_entry *entry);
int restore_raw_table(struct raw_entry table[], int count, char *mtd);
int store_raw_table(struct raw_entry table[], int count, char *mtd);
int store_raw_data(char *buf, int len, enum types type, char *mtd);
int store_raw_file(char *filename, enum types type, char *mtd);
char *restore_raw_file(enum types type, char *mtd); /* strdup() */

#endif

/*
 * This file nust sync between AC and WTP
 */
 
#ifndef __SCAN_MANAGER_IPC_H__
#define __SCAN_MANAGER_IPC_H__

#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ipc.h>
#include <sys/shm.h>


#define SCAN_AGENT_PID_FILE_PATH "/var/run/scan_agent.pid"
#define DCS_2G_PID_FILE_PATH "/var/run/dcs-1.pid"
#define DCS_5G_PID_FILE_PATH "/var/run/dcs-2.pid"
#define APMODE_RAPD_PID_FILE_PATH "/var/run/wlan_apmode_rapd.pid"

#define MAX_RADIO         2        
#define MAX_NEIGHBOR_SLOT 512

#ifndef MAX_FREQUENCIES
#define MAX_FREQUENCIES  32
#endif
#ifndef IFHWADDRLEN
#define IFHWADDRLEN 6
#endif

/* 
  * predefined value for signal ipc in scan agent (int type -32 bits)
  * Bit 0 - 23  : defined scanning parameter (bitmap settings) or debug configration
  * Bit 24 -27 : defined which application trigger scan
  * Bit 28 -31 : defined which request 
*/

/* define request id */
enum SCAN_AGENT_SCAN_REQ {
    DBG_CONFIG = 0x1,         // request to set debug configuration
    SCAN_REQUEST = 0x2      // request to scan  
};

/* define process id */
enum SCAN_AGENT_SCAN_PROCESSID {
	OTHERS =				0x0,   // others
	DCS_2G =				0x1,   // DCS 2G 
	DCS_5G =				0x2,   // DCS 5G 
	APMODE_RAPD =		0x3,   // RAPD 
	CAPWAP =				0x4,    // CAPWAP
	MAXPROCESS =		0x5
};

/*  define debug configration */
enum SCAN_AGENT_DEBUG_CONFIG {
    	DEBUG_LEVEL_ERROR =						0x1,
	DEBUG_LEVEL_WARNING =				       0x2,
	DEBUG_LEVEL_INFO =	     			              0x3,
	DEBUG_LEVEL_DEBUG =    				       0x4,
	DEBUG_PRINT_FILE =				              0x10,
	DEBUG_PRINT_CONSOLE =		                      0x20,
};

/* define scan parameter */
enum SCAN_AGENT_SCAN_MODE {
	BAND_24_GHZ =						0x1,           // scan 2.4G
	BAND_5_GHZ =						0x2,           // scan 5G
	FORCE_SCAN =						0x4,           // force scan
	OFFCHAN_SCAN =                                    0x8,           // off-channel scan. ignore the scan result in the home channel
};

#define SCAN_AGENT_GET_REQUEST_ID(val) (((val) & 0xf0000000) >> 28)
#define SCAN_AGENT_GET_PROCESS_ID(val) (((val) & 0x0f000000) >> 24)
#define SCAN_AGENT_GET_SCAN_BAND(val) (((val) & 0x00030000) >> 16)
#define SCAN_AGENT_GET_OFFCHAN_SCAN(val) (((val) & 0x00080000) >> 19)
#define SCAN_AGENT_GET_SCAN_TIME(val) ((val) & 0x0000ffff)
#define SCAN_AGENT_GET_DEBUG_LEVEL(val) (((val) & 0x0f0000) >> 16)
#define SCAN_AGENT_GET_PRINT_LEVEL(val) (((val) & 0xf00000) >> 16)

#define SCAN_AGENT_SET_REQUEST(req, req_id, process_id , mode, scan_time) do { \
        (req) =  (((req_id & 0xf) << 28) |((process_id & 0xf) << 24)  | ((mode & 0xff) << 16) | (scan_time & 0xffff) );        \
     } while (0)

enum {
    REASON_SUCCESS = 0x0,
    REASON_IFDOWN = 0x1,   // interface is down
    REASON_PARAMERROR = 0x2,     // set parameter fail
    REASON_WDSSTA = 0x3,              //  scan is not needed by wds sta status
    REASON_SCANFAIL = 0x4,
    REASON_GETRESULTFAIL = 0x5,
    REASON_RADIOINCAC = 0x6,     // radio in cac
    REASON_GETAVAILCHFAIL = 0x7,
    REASON_MALLOCFAIL = 0x8,
    REASON_INVALIDARGS = 0x9,
    REASON_CFG80211CMDFAIL = 0xa,
    REASON_DAEDOM_INIT = 0xb,
    REASON_GETSLOTNUMFAIL = 0xc,
};

#define SCAN_AGENT_GET_REASON_CODE(val) ((val) & 0xffff)
#define SCAN_AGENT_GET_COMPLETE_SCANBAND(val)  (((val) & 0xffff0000) >> 16)
#define SCAN_AGENT_SET_NOTIFY_INFO(info, complete_band, reasoncode) do { \
        (info) =  (((complete_band & 0xffff) << 16) | reasoncode);        \
     } while (0)

struct scan_channel_info {
    int ieee_chan;
    int chan_load;
    int noisefloor;
};

struct shm_radio_header {
    char scansuccess[2];				 /* uint: 0-1		  2 byte */
    char used[2];                        /* uint: 0-1         2 byte */
    char valid[2];                       /* uint: 0-1         2 byte */
    char timestamp[11];                  /* uint: 0-UINT_MAX 10 byte */
    unsigned char radiomac[IFHWADDRLEN];
    char txpower[3];                     /* uint: 0-99        2 byte */
    char neighborcount[4];               /* uint: 0-100       3 byte */
    char slotnum[2];
    int scanband;        
    int reasoncode ;                       /* reason */
    struct scan_channel_info chan_info[MAX_FREQUENCIES];
};

#define SET_RADIO_SCANSUCCESS(_s, s)   sprintf(_s, "%d", s)
#define SET_RADIO_USED(_u, u)          sprintf(_u, "%d", u)
#define SET_RADIO_VALID(_v, v)         sprintf(_v, "%d", v)
#define SET_RADIO_TIMESTAMP(_t, t)     sprintf(_t, "%u", (unsigned int)t)
#define SET_RADIO_TXPOWER(_p, p)       sprintf(_p, "%d", p)
#define SET_RADIO_NEIGHBORCOUNT(_n, n) sprintf(_n, "%d", n)
#define SET_RADIO_SLOTNUMBER(_n, n) sprintf(_n, "%d", n)

#define RADIO_NEIGHBORCOUNT_INC(_n)    sprintf(_n, "%d", atoi(_n)+1)

#define GET_RADIO_SCANSUCCESS(_s)    atoi(_s)
#define GET_RADIO_USED(_u)           atoi(_u)
#define GET_RADIO_VALID(_v)          atoi(_v)
#define GET_RADIO_TIMESTAMP(_t)      atol(_t)
#define GET_RADIO_TXPOWER(_p)        atoi(_p)
#define GET_RADIO_NEIGHBORCOUNT(_n)  atoi(_n)
#define GET_RADIO_SLOTNUMBER(_n)  atoi(_n)

#define IS_RADIO_SCANSUCCESS(_s)     GET_RADIO_SCANSUCCESS(_s)
#define IS_RADIO_USED(_u)            GET_RADIO_USED(_u)
#define IS_RADIO_VALID(_v)           GET_RADIO_VALID(_v)

#define IW_ESSID_MAX_SIZE 32 /* copy from wireless.h */
struct shm_radio_neighbor_entry {
	char          essid[IW_ESSID_MAX_SIZE + 1];
	unsigned char bssid[IFHWADDRLEN];
	unsigned char channel[4];          /* uint: 0~999     3 byte */
	unsigned char rssi[4];             /* uint: -99~999      3 byte */
	unsigned char band_mode;
	unsigned char security;
};

#define SET_NEIGHBOR_CHANNEL(_c, c)       sprintf(_c, "%d", c)
#define SET_NEIGHBOR_RSSI(_r, r)          sprintf(_r, "%d", r)

#define GET_NEIGHBOR_CHANNEL(_c)          atoi(_c)
#define GET_NEIGHBOR_RSSI(_r)             atoi(_r)

static inline int get_radio_slot_max_size(void)
{
	return (sizeof(struct shm_radio_header) + (sizeof(struct shm_radio_neighbor_entry) * MAX_NEIGHBOR_SLOT));
}
static inline struct shm_radio_header *next_radio(struct shm_radio_header *radio)
{
	return (struct shm_radio_header *)((char *)radio + get_radio_slot_max_size());
}

static inline struct shm_radio_neighbor_entry *get_neighbor_head(struct shm_radio_header *radio)
{
	return (struct shm_radio_neighbor_entry *)((char *)radio + sizeof(struct shm_radio_header));
}

static inline struct shm_radio_neighbor_entry *next_neighbor(struct shm_radio_neighbor_entry * neighbor)
{
	return (struct shm_radio_neighbor_entry *)((char *)neighbor + sizeof(struct shm_radio_neighbor_entry));
}

static inline struct shm_radio_neighbor_entry *get_neighbor_tail(struct shm_radio_header *radio)
{
    int count = GET_RADIO_NEIGHBORCOUNT(radio->neighborcount);

    return (struct shm_radio_neighbor_entry *)((char *)radio + (sizeof(struct shm_radio_header) + 
        (sizeof(struct shm_radio_neighbor_entry)*count)));
}

/* scan share memory API */
key_t scan_shm_gen_key(void);
void *scan_shm_create_rw(int *shmid, key_t key);
void *scan_shm_join_ronly(key_t key);
int scan_shm_stat(key_t key, int *shmid, struct shmid_ds *shmds);
int scan_shm_destroy(int shmid);

char *getscanreasonstr(int reasoncode, char *str, int len);
char *getbandmodestr(int mode, char *str, int len);
char *getsecmodestr(int mode, char *str, int len);

void dump_channel_info(struct shm_radio_header *radio);
void dump_scan_result(struct shm_radio_header *radio);
/* get scan result by slot number */
struct shm_radio_header *get_scan_result_by_slotnum(struct shm_radio_header *shm, int num);

#endif /* __SCAN_MANAGER_IPC_H__ */

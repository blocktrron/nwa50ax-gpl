#ifndef LIVE_CMD_H_
#define LIVE_CMD_H_

#define LIVE_TOOL_CLIENT_SOCK_FILE "/tmp/live_tool_client.sock"
#define LIVE_TOOL_SERVER_SOCK_FILE "/tmp/live_tool_server.sock"

typedef enum
{
	LIVE_PING = 0,
	LIVE_TRACERT,
#ifndef ZLDCONFIG_NEBULA_AP_SUPPORT
	LIVE_NSLOOKUP,
#endif
	LIVE_DEBUG,
	LIVE_TYPE_MAX
} LiveType;

struct ping_priv
{
	int count;
	int timeout;
	int interval;
};

struct tracert_priv
{
	int wait;
	int ttl;
};

typedef struct live_cmd
{
	LiveType type;
	enum {
		LIVE_SET = 0,
		LIVE_GET,
	} op;
	union {
		struct ping_priv ping;
		struct tracert_priv tracert;
	} /*priv*/;
	char target[1000]; /* FIXME */
} LiveCmd;

#endif

/* $Id: zysh_io.h,v 1.21 2008/05/26 06:51:53 juwu Exp $ */

/*
   $Log: zysh_io.h,v $
   Revision 1.21  2008/05/26 06:51:53  juwu
   improve performance

   Revision 1.20  2008/03/10 08:01:48  juwu
   add zyio_container_collect() series functions

   Revision 1.19  2008/03/04 09:48:36  juwu
   add zyio_regain_next()

   Revision 1.18  2005/12/05 04:15:10  juwu
   add new function: zyio_retrieve_all2()

   Revision 1.17  2005/12/01 07:44:48  juwu
   add new func: zyio_getlen()

   Revision 1.16  2005/10/07 07:10:08  juwu
   add zyio_decrease_entity_attr()/zyio_increase_entity_attr()

   Revision 1.15  2005/06/27 09:23:52  rogerho
   *** empty log message ***

   Revision 1.14  2005/03/25 05:34:57  juwu
   add zyio_compare_name()

   Revision 1.13  2005/03/16 09:26:04  mjyu
   add vi commands, which make tab be 4 spaces

   Revision 1.12  2005/01/18 10:39:56  juwu
   support scope export function

   Revision 1.11  2005/01/13 04:46:34  juwu
   add zyio_change_container_element

   Revision 1.10  2004/05/19 05:08:46  juwu
   add clifile structure member for supporting CLI config

   Revision 1.9  2004/04/01 06:58:44  juwu
   add comments

   Revision 1.8  2004/02/26 06:51:17  juwu
   add zyio_define2()

   Revision 1.7  2004/02/20 02:50:43  juwu
   add length-aware version

   Revision 1.6  2004/02/13 05:39:48  juwu
   add features

   Revision 1.5  2004/02/10 02:23:58  juwu
   *** empty log message ***

   Revision 1.4  2004/01/14 10:43:10  juwu
   add more file support. add session support

   Revision 1.3  2004/01/07 08:36:49  juwu
   add zyio_name()

   Revision 1.2  2003/12/18 10:21:37  juwu
   *** empty log message ***

   Revision 1.1.1.1  2003/12/15 08:45:17  juwu
   initial release

*/

#ifndef _ZYSH_IO_H
#define _ZYSH_IO_H

#include <limits.h>
#include <libxml/parser.h>
#include <stdio.h>


#ifndef __cplusplus
typedef int bool;
#define true	1
#define false	0
#endif

#ifndef TRUE
#define TRUE	1
#endif
#ifndef FALSE
#define FALSE	0
#endif

typedef struct {
/* CLI programmers NEVER touch */
	char		clifile[PATH_MAX];	/* zysh_io don't save it acturally */
	char		filename[PATH_MAX];
	xmlDocPtr	doc;

/* CLI programmers MAY read and MUST NOT change */
	int		semId;
	char		product[32];
	char		model[32];
	char		version[32];
} confCTX_t;

typedef xmlNodePtr	zyio_entity;

/* one buffer of two buffer */
#define _ZYIO_ENTS_MEMALLOC_ONE	0
#define _ZYIO_ENTS_MEMALLOC_TWO	1

typedef struct {
	int		size;
	int		capacity;
	zyio_entity	*set;
	int		_mem_alloc;
} zyio_entities_t;

typedef zyio_entities_t *	zyio_entities;

typedef xmlNodePtr	zyio_checkpoint;

typedef struct {
/* CLI Programmer MUST NOT touch */
#if 0
	int	_class;				/* table, group, or list */
#endif
	char	_classname[16];			/* "table", "group", or "list" */
	void*	_container;			/* the lower layer container (i.e. XML) */
	int	_readonly;			/* is readonly */
	confCTX_t	*_conf;
	char	_scope[64];
	char	_usertype[64];
} zyio_iterator_struct;

typedef zyio_iterator_struct* zyio_iterator;

typedef struct {
	int		size;
	zyio_iterator	*set;
} zyio_iterators_t;

typedef zyio_iterators_t * zyio_iterators;

#define	GET_ITERATOR_UNIQUENESS(iterator)	(iterator->_container)

/* ===== create container(conf, scope, name, type) */

#define ZYIO_CONTAINER_CREATE(container)		\
	zyio_iterator zyio_create_##container(confCTX_t *conf, char *scope, char *type, char *name)

#define ZYIO_CONTAINER_DISPOSE(container)		\
	bool zyio_dispose_##container(confCTX_t *conf, char *scope, char *type, char *name)

#define ZYIO_CONTAINER_OPEN(container)			\
	zyio_iterator zyio_open_##container(confCTX_t *conf, char *scope, char *type, char *name)

#define ZYIO_CONTAINER_CLOSE(container)			\
	bool zyio_close_##container(zyio_iterator iterator)

#define ZYIO_CONTAINER_COLLECT(container)			\
	zyio_iterators zyio_collect_##container(confCTX_t *conf, char *scope, char *type)

#define DECLARE_ZYIO_CONTAINER(container)		\
	ZYIO_CONTAINER_CREATE(container);		\
	ZYIO_CONTAINER_DISPOSE(container);		\
	ZYIO_CONTAINER_OPEN(container);			\
	ZYIO_CONTAINER_CLOSE(container);		\
	ZYIO_CONTAINER_COLLECT(container);

#define	ZYIO_CONTAINER_TYPE_TABLE	0
#define	ZYIO_CONTAINER_TYPE_LIST	1
#define	ZYIO_CONTAINER_TYPE_GROUP	2

/* ===== function declarations ... */

DECLARE_ZYIO_CONTAINER(table);						/* cli_ds.c */
DECLARE_ZYIO_CONTAINER(list);
DECLARE_ZYIO_CONTAINER(group);

void zyio_free_iterators(zyio_iterators foo);
bool zyio_remove(zyio_iterator iterator, char *name);
bool zyio_join(zyio_iterator iterator, char *name, int is_entity);
bool zyio_insert(zyio_iterator iterator, char *name, unsigned int position);
bool zyio_append(zyio_iterator iterator, char *name);
bool zyio_delete(zyio_iterator iterator, unsigned int idx);
int zyio_size(zyio_iterator iterator);
int zyio_real_size(zyio_iterator iterator);	/* not recommanded */
int zyio_check_loop(zyio_iterator iterator);	/* not recommanded */
zyio_entities zyio_retrieve_all(zyio_iterator iterator);
zyio_entities zyio_retrieve_all2(zyio_iterator iterator);	/* this version does not check loop! */
zyio_entities zyio_list_entities(confCTX_t *conf, char *scope, char *type);	/* not recommanded */
zyio_entity zyio_retrieve_index(zyio_iterator iterator, unsigned int idx);
zyio_entity zyio_retrieve_entity(confCTX_t *conf, char *scope, char *type, char *name);
int zyio_entity_count(confCTX_t *conf, char *scope, char *type);
int zyio_regain_next(zyio_iterator iterator, void **__ptr, char *namebuf, int buflen);
int zyio_regain_index(zyio_iterator iterator, unsigned int position, char *name);
int zyio_regain_index2(zyio_iterator iterator, unsigned int position, char *name, int length);
bool zyio_setattr_entity(zyio_entity entity, char *name, char *value);	/* for control purpose , don't use to save data */
bool zyio_unsetattr_entity(zyio_entity entity, char *name);
bool zyio_setattr_container(zyio_iterator iterator, char *name, char *value);
bool zyio_unsetattr_container(zyio_iterator iterator, char *name);
bool zyio_getattr_entity(zyio_entity entity, char *name, char *value);
bool zyio_getattr_entity2(zyio_entity entity, char *name, char *value, int length);
bool zyio_getattr_container(zyio_iterator iterator, char *name, char *value);
bool zyio_getattr_container2(zyio_iterator iterator, char *name, char *value, int length);
bool zyio_change_container_element(zyio_iterator iterator, char *oldname, char *newname);
bool zyio_decrease_entity_attr(zyio_entity entity, char *attribute, unsigned long *value);
bool zyio_increase_entity_attr(zyio_entity entity, char *attribute, unsigned long *value);

int zyio_get_version(confCTX_t *conf);					/* version.c */

zyio_entities zyio_alloc_entities(int count);				/* entity.c */
bool zyio_find_entities(zyio_iterator iterator, char *name);
void zyio_free_entities(zyio_entities foo);
bool zyio_desrtoy_entities(zyio_entities foo);
bool zyio_getlen(zyio_entity entity, char *name, int *length);
bool zyio_get(zyio_entity entity, char *name, char *value);
bool zyio_get2(zyio_entity entity, char *name, char *value, int length);
bool zyio_set(zyio_entity entity, char *name, char *value);
bool zyio_unset(zyio_entity entity, char *name);
bool zyio_define(confCTX_t *conf, char *scope, char *type, char *name);
bool zyio_undefine(confCTX_t *conf, char *scope, char *type, char *name);
bool zyio_name(zyio_entity entity, char *namebuf);
bool zyio_name2(zyio_entity entity, char *namebuf, int length);
bool zyio_compare_name(zyio_entity entity, char *name);
zyio_entity zyio_define2(confCTX_t *conf, char *scope, char *type, char *name);

confCTX_t* zyio_open_config(char *filename, int flag);			/* open.c */
int zyio_rename_config(char *filename1, char *filename2);
int zyio_save_config(confCTX_t *conf);
int zyio_save_as(confCTX_t *conf, char *filename);
int zyio_copy_config(char *filename1, char *filename2);
int zyio_remove_config(char *filename);
int zyio_close_config(confCTX_t *conf);
void zyio_initialize(void);
confCTX_t* zyio_restore(void *serialized, char *filename);		/* for session control */
int zyio_dump(confCTX_t *conf, char *filename);
zyio_checkpoint zyio_create_checkpoint(confCTX_t *conf, char *scope);	/* for error handling */
void zyio_release_checkpoint(zyio_checkpoint checkpoint);
bool zyio_rollback_checkpoint(confCTX_t *conf, char *scope, zyio_checkpoint checkpoint);
confCTX_t* zyio_restore_scope(char *fullpath);				/* for exporting scope to other programs */
bool zyio_backup_scope(confCTX_t *conf, char *scope, char *fullpath);


/* ===== debug ... */
#define DEBUG_ZYIO

#ifdef DEBUG_ZYIO
#define ZYIO_DEBUG(args...)	fprintf(stderr, ##args)
#else
#define ZYIO_DEBUG(args...)
#endif

#define ZYIO_LOG(args...)	fprintf(stderr, ##args)

#define ZYIO_TRACE(args...)	fprintf(stdout, ##args)

/* ===== useful macro */

#define CONF_LOCKED(conf)	(conf->semId < 0)

#endif
/* vi:set sw=4 ts=4: */

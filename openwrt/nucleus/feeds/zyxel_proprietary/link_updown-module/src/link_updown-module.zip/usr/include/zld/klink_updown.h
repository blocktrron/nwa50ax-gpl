#ifndef __KLINK_UPDOWN_H__
#define __KLINK_UPDOWN_H__

#include "zld-spec.h"

/****** SWITCH PORTS ******/
#ifndef MAX_PORTS
#define MAX_PORTS   8
#endif

#ifndef MIN_PORTS_IN_GROUP
#define MIN_PORTS_IN_GROUP  1
#endif

#if MAX_PORTS < MIN_PORTS_IN_GROUP
#error MAX_PORTS must >= MIN_PORTS_IN_GROUP
#endif

#if MAX_PORTS % MIN_PORTS_IN_GROUP != 0
#define MAX_GROUPS  ((MAX_PORTS / MIN_PORTS_IN_GROUP) + 1)
#else
#define MAX_GROUPS  (MAX_PORTS / MIN_PORTS_IN_GROUP)
#endif

#if MAX_PORTS % 8 != 0
#define BITMAP_COUNT    (MAX_PORTS / 8 + 1)
#else
#define BITMAP_COUNT    (MAX_PORTS / 8)
#endif

#define BITMAP_SET_PORT(bitmap, port)   (bitmap[port / 8] |= (0x80 >> (port % 8)))
#define BITMAP_ISSET_PORT(bitmap, port) ((bitmap[port / 8] & (0x80 >> (port % 8))) != 0)
#define BITMAP_UNSET_PORT(bitmap, port) (bitmap[port / 8] &= ~(0x80 >> (port % 8)))

/****** NETLINK ******/
#define LINK_UPDOWN_MCAST_GROUP 0xFFFF

typedef enum {
	PORT_GROUPING_INIT_DONE = 0,
	LINK_CHANGE,
	WDS_CHANGE,
	PSTA_CHANGE,
	ETHER_RECOVER
} link_updown_cmd;

typedef struct {
	unsigned char	link_status[BITMAP_COUNT];
	unsigned char	link_control_map[BITMAP_COUNT];
} link_cntl;

typedef struct {
	int command;
	union {
		link_cntl lc;
	} payload;
} link_updown_msg;

int lkud_notify_userspace(link_updown_msg *msg);

#endif

#ifndef RADIUS_TO_RUM_H
#define RADIUS_TO_RUM_H
#include "user_profile.h" /* for auth_module_enum */
#include "zld-spec.h"

#define UAM_EXT_GROUP_LEN		(ZLDSYSPARM_UAM_USER_ROLES_PER_EXT_GROUP_USER)*(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define UAM_USERNAME_LEN		(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define MAC_ADDRESS_LENGTH	 	6
#define GA_BINDING_TOKEN_LEN	128

#define USER_ZYLOG(fmt, arg...) zylog(ZYLOG_SRC_UAM, \
				ZYLOG_PRI_DEBUG, \
				ZYLOG_FAC_UAM, \
				0,0,0,0, "USER", fmt, ##arg)

#define RUM_PATH "/usr/sbin/rumd"

typedef struct radius_user_s {
	long messge_type;
	char username[UAM_USERNAME_LEN];
	char auth_method[UAM_EXT_GROUP_LEN];
	unsigned char mac[MAC_ADDRESS_LENGTH];
	u_int32_t ip;
	enum auth_module_enum authtype; /* defined in user_profile.h */
#ifdef AAA_8021X_CLOUD_AUTHENTICATION
	int expired;
#endif
	int ga_acct_status;
	char ga_binding_token[GA_BINDING_TOKEN_LEN];
} radius_user_t;

#endif

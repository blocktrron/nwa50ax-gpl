#ifndef RUM_H
#define RUM_H

/* for struct in_addr */
#include <netinet/in.h>
/* for auth_module_enum */
#include "user_profile.h"
/* for UAM_*_LEN, MAC_ADDRSSS_LENGTH */
#include "radius_to_rum.h"

typedef struct freeradius_log_s {
	char username[UAM_USERNAME_LEN];
	char auth_method[UAM_EXT_GROUP_LEN];
	unsigned char mac[MAC_ADDRESS_LENGTH];
	u_int32_t ip;
	enum auth_module_enum authtype; /* defined in user_profile.h */
	unsigned long uptime;
#ifdef AAA_8021X_CLOUD_AUTHENTICATION
	int expire;
#endif
	int ga_acct_status;
	char ga_binding_token[GA_BINDING_TOKEN_LEN];
	char wiface[20];
	int updated_type;
	struct freeradius_log_s *next_ptr;
	struct freeradius_log_s *pre_ptr;
} freeradius_log_t;

#define WIRELESS_HAL_RUM_SOCKET "/tmp/wireless-hal_to_rum.sock"

struct staInfo {
	enum {
		DISASSOC = 0,
		ASSOC
	} associate;
	struct in_addr client_ip;
	unsigned char mac[MAC_ADDRESS_LENGTH];
	char interface[20];
	int vid;
};
#endif

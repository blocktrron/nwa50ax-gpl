#ifndef __DCS_IPC_H__
#define __DCS_IPC_H__
enum {
	DCS_BY_ZYSH_DCS_NOW		=	1,	/* for ZYSH use (DCS now)*/
	DCS_BY_SCHEDULE_DCS		=	2,	/* for SCHEDULE DCS use */
	DCS_BY_WH_DCS_NOW		=	3,	/* for WIRELESS HEALTH use */
	DCS_BY_WH_DRIVER_ISSUE	=	4,	/* for WIRELESS HEALTH use */
};
#endif

#ifndef _ZY_PKI_H
#define _ZY_PKI_H

#define MAX_NAME_LEN	1024
#define NAME_LEN	128
#define SUBJECT_LEN	512

/*
 * default validation perion of self-signed certificate, 3 year
 */
#define YEAR				(365*24*60*60)
#define CERT_VALID_TIME		(3*YEAR)

/*
 * My Certificates path & Trusted Certificates path
 * if U want to modify it, you should also modify "zysh\cmd\include\xml_ipsec_conf.h"
 */
#define CERTPATH	"/etc/zyxel/ftp/cert/"
#define TRUSTED		"trusted/"

#define UPLOAD_PATH	"/tmp/"

#define NA		"N/A"
#define REQ		".req"
#define CRT		".crt"
#define P12		".p12"
#define PRV		".prv"
#define PEM_STRING "pem"
#define DER_STRING "der"
#define OPENSSL_INPUT_X509_DER "openssl x509 -inform DER -in"
#define OPENSSL_INPUT_X509_PEM "openssl x509 -inform PEM -in"
#define OPENSSL_INPUT_REQ_DER "openssl req -inform DER -in"
#define OPENSSL_VERIFY_BY_FILE "openssl verify -CAfile"
#define OPENSSL_POSTFIX_PEM_OUT "-outform pem -out"
#define OPENSSL_POSTFIX_DER_OUT "-outform der -out"
#define OPENSSL_INPUT_P12 "openssl pkcs12 -nodes -in"

#if defined(ZLDSYSPARM_IPSEC_VPN_QS_VER) && (ZLDSYSPARM_IPSEC_VPN_QS_VER == 44)
#define ZY_X509_OID_SERVER_AUTH		"1.3.6.1.5.5.7.3.1"
#define ZY_X509_OID_CLIENT_AUTH		"1.3.6.1.5.5.7.3.2"
#define ZY_X509_OID_IKE_INTERMEDIATE	"1.3.6.1.5.5.8.2.2" 

#define ZY_X509_STR_SERVER_AUTH		"ServerAuthentication"
#define ZY_X509_STR_CLIENT_AUTH		"ClientAuthentication"
#define ZY_X509_STR_IKE_INTERMEDIATE	"iKEIntermediate"
#endif /* defined(ZLDSYSPARM_IPSEC_VPN_QS_VER) && (ZLDSYSPARM_IPSEC_VPN_QS_VER == 44) */
//#define STRING_OR_NA(x)	((x) ? x: "N/A")
#define STRING_OR_NA(x)	((x) ? x: "none")

/*
 * Certificate Headers, For CA_BIN to verify if the file is valid certificate file. 
 */
#define PUBKEY_HEADER "-----BEGIN PUBLIC KEY-----\n"
#define REQ_HEADER "-----BEGIN CERTIFICATE REQUEST-----\n"
#define PEM_HEADER "-----BEGIN CERTIFICATE-----\n"

enum {
	LOCAL, REMOTE, UPLOAD
};

enum {
	TEXT, PEM
};

enum {
	REQ_N, SELF_N, CERT_N
};

#define REQ_STRING	"REQ"
#define SELF_STRING	"SELF"
#define CERT_STRING	"CERT"

enum {
	CN_IP, CN_EMAIL, CN_DNS
};

enum {
	ZY_RSA, ZY_DSA
};

enum {
	X509BIN, X509PEM, PKCS7, PKCS10, PKCS12
};

typedef struct {
	char name[NAME_LEN];	
	
	unsigned int common_name_type;
	char common_name[NAME_LEN];
	
	char org_unit[NAME_LEN];
	char org[NAME_LEN];
	char lct_name[NAME_LEN];
	char stat_name[NAME_LEN];
	char country[NAME_LEN];
	char usr_def[NAME_LEN];
	
	unsigned int key_type;
	unsigned int key_size;
#if defined(ZLDSYSPARM_IPSEC_VPN_QS_VER) && (ZLDSYSPARM_IPSEC_VPN_QS_VER == 44)
	char extend_key[NAME_LEN];
#endif /* defined(ZLDSYSPARM_IPSEC_VPN_QS_VER) && (ZLDSYSPARM_IPSEC_VPN_QS_VER == 44) */
} zyCertReq;

enum {
	X509_VALID, X509_BEFORE_VALIDATION, X509_AFTER_VALIDATION
};

typedef struct {
	char name[NAME_LEN];	
	
	unsigned int type;
	unsigned int version;
	
	char* serial;
	char* subject;
	char* issuer;
	char* sig_alg;
	char* valid_from;
	char* valid_to;
	char* key_alg;
	char san_type[NAME_LEN];
	char* subject_alt_name;
	char* key_usage;
#if defined(ZLDSYSPARM_IPSEC_VPN_QS_VER) && (ZLDSYSPARM_IPSEC_VPN_QS_VER == 44)
	char* ext_key_usage;
#endif /* defined(ZLDSYSPARM_IPSEC_VPN_QS_VER) && (ZLDSYSPARM_IPSEC_VPN_QS_VER == 44) */
	char* basic_constraint;
	char* cdp;
	char* auth_info_access;
	char* md5_finger;
	char* sha1_finger;
	
	unsigned int status;
} zyCert;

/*
 * In:certreq, type SSH_X509_PKIX_CERT|SSH_X509_PKCS_10, filename
 * Out:save the certificate in filename
 * generate a certificate, could be x.509 certificate or pkcs#10
 */
int genCertToFile(zyCertReq* certreq, int type, char* filename);

/*
 * In:filename, type=SSH_X509_PKIX_CERT|SSH_X509_PKCS_10 
 * Out:cert
 * parse the specified certificate and store the x.509 fields in "zyCert* cert" 
 * "zyCert* cert" should be freed with "free_zyCert(zyCert* cert)"
 */

/*
 * In:category, filename, type=SSH_X509_PKIX_CERT|SSH_X509_PKCS_10 
 * Out:cert
 * parse the specified certificate and store the x.509 fields in "zyCert* cert" 
 * "zyCert* cert" should be freed with "free_zyCert(zyCert* cert)"
 */ 
int dumpCertFile(int category, char* filename, int type, zyCert* cert);
int show_cert(int category, int format, char *filename, int raw);
int show_cert_summary(int category, int raw);

/*
 * In:integory, filename, type=SSH_X509_PKIX_CERT|SSH_X509_PKCS_10 
 * Out:buf
 * parse the specified certificate and transform it into PEM 
 * "*buf" should be freed with "ssh_xfree(*buf)"
 */
int get_file_pem(int category, char* filename, int type, char** buf);

/*
 * In: filename, password
 * Out: certificate, privatekey, type
 */
int import_cert(int category, char* name, char* password, int* type);

/*
 * In: caategory, p7File
 * Out: certificate
 */
int parse_pkcs7(int category, char* p7File); 

/*
 * In:certFile ,password
 * Out: pkcs#12 file
 */
int gen_pkcs12(char* certFile, char* password, int export); 

/*
 * In:p12File, password
 * Out: certificate and private key file
 */
int parse_pkcs12(char* p12File, char* password); 


/*
 * free the memory of zyCert*
 */
void free_zyCert(zyCert* cert);

/* find certificate path from leaf to root
 * In:cert_file (certificate name), ldapserver ("name:passwd@195.20.116.67:389"), timeout_in_secs
 */
int find_cert_path(int category, char *cert_file, char *ldapserver, unsigned int timeout_in_secs, int raw);

int get_root(char *cert_file, char *ldap);

int 
scep(	char* publickeyfile,	/* public key file */
	char* privatekeyfile, 	/* private key file 	-P file:xxxx */
	char* cafile, 		/* ca certificate file	-C ca.cer */
	char* password, 	/* password for scep	-p ssh */
	char* subject, 		/* certificate subject	-s C=TW,CN=test */
	char* scepUrl);		/* http://pki.ssh.com:8080/scep/ */

int 
cmp(	char* publickeyfile,	/* public key file */
	char* privatekeyfile, 	/* private key file 	-P file:xxxx */
	char* cafile, 		/* ca certificate file	-C ca.cer */
	char* num,		/* reference number 			*/
	char* password, 	/* password for cmp	-p 62154:ssh 		*/
	char* subject, 		/* certificate subject	-s C=TW,CN=test */
	char* cmpUrl);		/* http://pki.ssh.com:8080/scep/ */


int
pam_xauth_check(char *xauth_pam, char *name, char *passwd);

int
export_cert(int category, char *name, char *type, char *password);

#endif


#ifndef __DIAGNOSED_CLOUD_H__
#define __DIAGNOSED_CLOUD_H__

#ifdef ZLDCONFIG_PLATFORM_MIPS_ATHEROS_AR9344
#define CATE_SIZE_LIMIT		4096
#else
#define CATE_SIZE_LIMIT		51200
#endif
#define USB_STORAGE			0
#define SYS_BIN_TAR_OFF		1
#define SYS_BIN_TAR_ON		0
#define DIAG_RETRY			3
#define DIAG_SLEEP			1

#define MAIN_SCRIPT					("/usr/local/zyxel-diaginfo/main_script")
#define DIAG_INFO_CANCEL_SCRIPT 	("/usr/local/zyxel-diaginfo/cancel_diag_info.sh")
#define PID_FILE					("/var/run/diagnosed.pid")
#define DIAG_EXEC					("/var/run/diagnosed.exec")

#ifdef ZLDCONFIG_CLOUD_MODE_SUPPORT
#define URL_LEN             256
#define AWSACCESSID_LEN 128
#define POLICY_LEN          512
#define SIGNATURE_LEN       128
#define KEY_LEN             256
#define FILENAME_LEN        128

struct _convey_debug_info
{
	int ttl;
	char url[URL_LEN];
	char field_awsid[AWSACCESSID_LEN];
	char field_policy[POLICY_LEN];
	char field_signature[SIGNATURE_LEN];
	char field_key[KEY_LEN];
	char field_file[FILENAME_LEN];
};

typedef struct _convey_debug_info convey_debug_info;
#endif

#endif

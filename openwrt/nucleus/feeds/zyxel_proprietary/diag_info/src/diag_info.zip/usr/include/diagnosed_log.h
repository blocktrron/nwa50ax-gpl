/******************************************************************************
 *
 *	Copyright (C) 2002-2005 ZyXEL Communications, Corp.
 *	All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 *
 *****************************************************************************/
 /* $Id: diagnosed_log.h,v 1.1.1.2 2006/07/31 08:44:58 bato.wang Exp $ */

/*
 * $Log: diagnosed_log.h,v $
 * Revision 1.1.1.2  2006/07/31 08:44:58  bato.wang
 * Add module diag_info-1.0.0
 *
 * Revision 1.1.1.1  2006/07/26 09:06:39  bato.wang
 * Import diagnostic module 
 *
 */

#define DIAGNOSED_ALERT(srcip, srcport, dstip, dstport, arg...)  \
                zylog(  ZYLOG_SRC_SYSTEM,                   \
                        ZYLOG_PRI_ALERT,                 \
                        ZYLOG_FAC_SYSTEM,                   \
                        0, 0, 0, 0, \
                        "Diagnostic Info Collector", ##arg)
#define DIAGNOSED_ALERT_(arg...)  \
                zylog(  ZYLOG_SRC_SYSTEM,                   \
                        ZYLOG_PRI_ALERT,                 \
                        ZYLOG_FAC_SYSTEM,                   \
                        0, 0, 0, 0, \
                        "Diagnostic Info Collector", ##arg)
#define DIAGNOSED_NOTICE_(arg...)  \
                zylog(  ZYLOG_SRC_SYSTEM,                   \
                        ZYLOG_PRI_NOTICE,                 \
                        ZYLOG_FAC_SYSTEM,                   \
                        0, 0, 0, 0, \
                        "Diagnostic Info Collector", ##arg)

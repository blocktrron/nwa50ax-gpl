/****************************************************************************/
/*
* Copyright (C) 2006-2018 Zyxel Communications, Corp.
* All Rights Reserved.
*
* Zyxel Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such Zyxel confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of Zyxel Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* Zyxel Communications, Corp.
*/
/****************************************************************************/
#ifndef _NEIGHBOR_COLLECTOR_IPC_H_
#define _NEIGHBOR_COLLECTOR_IPC_H_

#define DOMAIN_EVENT_CRONTAB 1
#define DOMAIN_EVENT_DEBUGLEVEL 2
#define DOMAIN_EVENT_WLANCHANGE 3
#define DOMAIN_EVENT_ROAMCHANGE 4
#define DOMAIN_EVENT_SHOWAPVAPDATA 5

#define NBC_SOCKFILE_SERVER "/tmp/nbc_srv.sock"
#define NBC_SOCKFILE_CLIENT "/tmp/nbc_cli.sock"

typedef struct domainSockMsg_s {
	uint16_t type;
	uint16_t length;
	char value[0];
}domainSockMsg_t;

int neighbor_collector_ipc_send_event_no_wait(uint16_t type, uint16_t len, char *value);

#endif /* _NEIGHBOR_COLLECTOR_IPC_H_ */

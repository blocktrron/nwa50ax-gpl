#ifndef _WIFI_NOTIFY_H_
#define _WIFI_NOTIFY_H_
#include <stdint.h>
#include <libubox/blobmsg_json.h>
#include <libubus.h>
#include "zyUMAC_nl80211.h"
#include "zyUMAC_types.h"


/* ubus event type */
#define UBUS_STA_JOIN                  "sta_join"
#define UBUS_STA_LEAVE                 "sta_leave"
#define UBUS_STA_AUTHORIZED            "sta_authorized"
#define UBUS_STA_DHCP_SNIFFER          "dhcp_sniffer"
#define UBUS_STA_UPLINK_CONNECTED      "zymesh_connected"
#define UBUS_STA_UPLINK_DISCONNECTED   "zymesh_disconnected"
#define UBUS_STA_IP                    "sta_ip"
#define UBUS_STA_ACTIVITY_CHANGE_IND   "sta_act_change"
#define UBUS_IF_CHANNEL                "channel_changed"
#define	UBUS_IF_SSID                   "ssid"
#define	UBUS_IF_SECURITY               "security"
#define	UBUS_IF_ROLE                   "wlan_mode"
#define	UBUS_IF_VAP_DELETE             "vap_delete"
#define	UBUS_IF_VAP_CREATE             "vap_create"
#define UBUS_COM_BCNRPT                "bcn_report"
#define UBUS_COM_NEIGHBOR_REQ          "neighbor_req"
#define UBUS_COM_MONITOR_PROBE         "probe_mon"
#define UBUS_COM_BSTM_RESP             "bstm_resp"
#define UBUS_COM_DFS_CAC_EXPIRED       "dfs_cac_expired"
#define UBUS_COM_DFS_RADAR_DETECT      "dfs_radar_detect"
#define UBUS_COM_DFS_NOL_TIMEOUT       "dfs_nol_timeout"
#define UBUS_COM_SMESH_INFO            "smesh_info"
#define UBUS_COM_SMESH_WBS_FOUND       "smesh_wds_found"
#define UBUS_WIFIMGR_DEBUG             "wifimgr_dbg"


/* blobmsg policy */
enum {
	STAINFO_JOIN_CMD,
	STAINFO_LEAVE_CMD,
	STAINFO_AUTHORIZED_CMD,
	STAINFO_DHCP_SNIFFER_CMD,
	STAINFO_UPLINK_CONNECTED_CMD,
	STAINFO_UPLINK_DISCONNECTED_CMD,
	STAINFO_IP_CMD,
	STAINFO_ACTIVITY_CHANGE_IND_CMD,
	INTERFACE_CHANNEL_CMD,
	INTERFACE_SSID_CMD,
	INTERFACE_SECURITY_CMD,
	INTERFACE_ROLE_CMD,
	INTERFACE_VAP_DELETE_CMD,
	INTERFACE_VAP_CREATE_CMD,    
	COMMON_BCNRPT_CMD,
	COMMON_NEIGHBOR_REQ_CMD, 
	COMMON_MONITOR_PROBE_CMD,
	COMMON_BSTM_RESP_CMD,
	COMMON_DFS_CAC_EXPIRED_CMD, 
	COMMON_DFS_RADAR_DETECT_CMD,
	COMMON_DFS_NOL_TIMEOUT_CMD,
	COMMON_SMESH_INFO_CMD,
	COMMON_SMESH_WBS_FOUND_CMD,
	WIFIMGR_DEBUG_CMD,
	__UBUS_NOTIFY_MAX,
};

const static struct blobmsg_policy wifimgr_notify_policy[__UBUS_NOTIFY_MAX] = {
	[STAINFO_JOIN_CMD] = { .name = UBUS_STA_JOIN, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_LEAVE_CMD] = { .name = UBUS_STA_LEAVE, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_AUTHORIZED_CMD] = { .name = UBUS_STA_AUTHORIZED, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_DHCP_SNIFFER_CMD] = { .name = UBUS_STA_DHCP_SNIFFER, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_UPLINK_CONNECTED_CMD] = { .name = UBUS_STA_UPLINK_CONNECTED, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_UPLINK_DISCONNECTED_CMD] = { .name = UBUS_STA_UPLINK_DISCONNECTED, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_IP_CMD] = { .name = UBUS_STA_IP, .type = BLOBMSG_TYPE_UNSPEC },
 	[STAINFO_ACTIVITY_CHANGE_IND_CMD] = { .name = UBUS_STA_ACTIVITY_CHANGE_IND, .type = BLOBMSG_TYPE_UNSPEC },
 	[INTERFACE_CHANNEL_CMD] = { .name = UBUS_IF_CHANNEL, .type = BLOBMSG_TYPE_UNSPEC },
 	[INTERFACE_SSID_CMD] = { .name = UBUS_IF_SSID, .type = BLOBMSG_TYPE_UNSPEC },
 	[INTERFACE_SECURITY_CMD] = { .name = UBUS_IF_SECURITY, .type = BLOBMSG_TYPE_UNSPEC },
 	[INTERFACE_ROLE_CMD] = { .name = UBUS_IF_ROLE, .type = BLOBMSG_TYPE_UNSPEC },
 	[INTERFACE_VAP_DELETE_CMD] = { .name = UBUS_IF_VAP_DELETE, .type = BLOBMSG_TYPE_UNSPEC },
 	[INTERFACE_VAP_CREATE_CMD] = { .name = UBUS_IF_VAP_CREATE, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_BCNRPT_CMD] = { .name = UBUS_COM_BCNRPT, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_NEIGHBOR_REQ_CMD] = { .name = UBUS_COM_NEIGHBOR_REQ, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_MONITOR_PROBE_CMD] = { .name = UBUS_COM_MONITOR_PROBE, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_BSTM_RESP_CMD] = { .name = UBUS_COM_BSTM_RESP, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_DFS_CAC_EXPIRED_CMD] = { .name = UBUS_COM_DFS_CAC_EXPIRED, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_DFS_RADAR_DETECT_CMD] = { .name = UBUS_COM_DFS_RADAR_DETECT, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_DFS_NOL_TIMEOUT_CMD] = { .name = UBUS_COM_DFS_NOL_TIMEOUT, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_SMESH_INFO_CMD] = { .name = UBUS_COM_SMESH_INFO, .type = BLOBMSG_TYPE_UNSPEC },
 	[COMMON_SMESH_WBS_FOUND_CMD] = { .name = UBUS_COM_SMESH_WBS_FOUND, .type = BLOBMSG_TYPE_UNSPEC }, 
 	[WIFIMGR_DEBUG_CMD] = { .name = UBUS_WIFIMGR_DEBUG, .type = BLOBMSG_TYPE_INT32 }, 
};

#endif  /* _WIFI_NOTIFY_H_ */

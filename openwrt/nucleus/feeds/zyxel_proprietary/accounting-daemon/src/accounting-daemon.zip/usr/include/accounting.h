/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 

#include <netinet/in.h>	
#include <pthread.h>
#include "linked-list.h"
#include "zld-spec.h"

#ifndef _ACCOUNTING_H
#define _ACCOUNTING_H

#define INTERIM_QUEUE	1
#define REQUEST_QUEUE	2
#define FAIL_QUEUE		3

#define ACCOUNTINGD_PATH "/usr/sbin/accountingd"
#define ACCTD_PID_FILE	"/var/run/accountingd.pid"
#define ACCTD_DEBUG_PATH	"/usr/sbin/acct_debug"
#define ACCTD_DEBUG_FILE "/tmp/accountingd_db"
#define NEBULA_AP_IP_FILE	"/tmp/nebula_ap_ip"

#define ACCT_PROJECT_ID ('a' + 'c' + 't')
#if defined(ZLDCONFIG_NEBULA_PORTAL_ACCOUNTING_SUPPORT)
#define ACCT_PROJECT_PORTAL_ID ('a' + 'c' + 't' + 'p')
#endif

#define PRIMARY 			1
#define SECONDARY		2

#define	OK				0
#define 	FAIL			-1

#define	RETRY			1
#define	NON_RETRY		0

#define IP_ADDRESS_HASH_SIZE		1024
#define BUFFER_SIZE      1024

#define ACCOUNTING_STATUS_NONE	0
#define ACCOUNTING_STATUS_ON		1
#define ACCOUNTING_STATUS_OFF		2

#define	ACCOUNTING_EVENT_CONFIG_MODIFY				1
#define	ACCOUNTING_EVENT_CONFIG_REMOVE				2
#define	ACCOUNTING_EVENT_AC_IP_CHANGE				3
#define	ACCOUNTING_EVENT_INIT						4
#define	ACCOUNTING_EVENT_ZYSH_EXIT					5
#define	ACCOUNTING_EVENT_MODIFY_FOR_PORTAL			6
#define ACCOUNTING_EVENT_AC_SHARED_SECRET_KEY_CHANGE		7

#define ACCOUNTING_EVENT_DEBUG_OFF					100
#define ACCOUNTING_EVENT_DEBUG_ON					101
#define ACCOUNTING_EVENT_DEBUG_PRINT_TO_FILE		102

#define AUTH_VECTOR_LEN			16
#define AUTH_HDR_LEN				20
#define PROFILE_NAME_LEN			64
#define HOST_NAME_LEN				64
#define MAX_NAS_IDENTIFIER_LEN	64
#define MAX_PASSWORD_LEN	64

#define PRIMARY_FAIL_TRY_BACKUP		1
#define PRIMARY_FAIL_NO_BACKUP		2
#define BACKUP_FAIL						3

#define	FOR_1X					0
#define	FOR_PORTAL				1

#ifndef FREE
#define FREE(ptr) { \
	if (ptr != NULL) { \
		free(ptr); \
		ptr = NULL; \
	} \
};
#endif

#if defined(ZLDCONFIG_SOCIAL_WIFI)
struct list_head sta_info_queue_header;
#endif

typedef void (*scheduler_func)(struct list_head *);

typedef struct attribute_s {
  uint8_t attribute;
  uint8_t length;
  unsigned char data[128];
} attribute_t;

typedef struct vendor_s {
  uint8_t vendor;
  uint8_t length;
  unsigned char data[128];
} vendor_t;

typedef struct pw_auth_hdr {
	u_char		code;
	uint8_t		id;
	u_short		length;
	u_char		vector[AUTH_VECTOR_LEN];
	u_char		data[1024];
} AUTH_HDR;

struct scheduler_event_register {
	struct list_head register_event;
	time_t register_time;
	scheduler_func handler;
	struct list_head *header;
};

typedef struct radius_accounting_server {
	struct in_addr acct_ip;
	char hostname[HOST_NAME_LEN];
	int acct_port;
	char secret[MAX_PASSWORD_LEN+1];
} radius_server;

struct accounting_radius {
	int acc_interim;
	char interface[PROFILE_NAME_LEN];
	//char *profile_name;

	/* primary server */
	radius_server *primary_server;
	/* backup server */
	radius_server *backup_server;

	struct in_addr nas_ip;
	char nas_id[128];
	int retry_count;
	int time_out;

	struct list_head user_node_header;
	struct list_head total_radius_server;
	unsigned char acct_status;  /*accounting-on success: 1, accounting-on fail: 0*/
	int on_off_count;
};

typedef struct conn_s {
        uint64_t rx;
        uint64_t tx;
} conn_t;

struct user_node_info {
	time_t login_time;
	char user_name[64];
	struct in_addr user_ip;
	char user_mac[18];
	int uam_logout_cause;
	unsigned int session_id;
	char called_station_id[128];
};

struct user_accounting_info {
	struct user_node_info *user;
	 	
	unsigned short queue_type;
	
	struct accounting_radius *acct_radius;

	AUTH_HDR *request;
	int retry_count;
	unsigned char server; /*primary server or backup server */
	time_t time_out;
	time_t report_time;

	/* Receive from radiusd */
	int acc_interim;
	char auth_module[32];
#ifdef ZLDCONFIG_RADIUS_ATTR_SUPPORT
        char nas_ip_info[64];
        char nas_id_info[128];
#endif
	unsigned char acc_class[128];
	int class_length;

	conn_t	conn_tx_rx_status;
};

struct accounting_node {
	struct list_head queue;
	struct list_head address_sorting_list;
	struct list_head radius_profile_list;
	struct user_accounting_info *self;
};

struct interim_queue {
	struct list_head total_interim_queue;
	int interim;
	struct list_head interim_queue_header;
};

#if defined(ZLDCONFIG_NEBULA_PORTAL_ACCOUNTING_SUPPORT)
struct user_entry {
	char sta_mac[18];
	char username[64];
	char ssid_name[PROFILE_NAME_LEN];
	char ssid_profile_name[PROFILE_NAME_LEN];
	struct list_head user_list;
};
#endif
struct hash_table {
	struct list_head head;
};

struct zysh_ac_ip_change {
	char old_ac_ip[HOST_NAME_LEN];
	char new_ac_ip[HOST_NAME_LEN];
};

struct zysh_config_event {
	char interface[PROFILE_NAME_LEN];

	char hostname[HOST_NAME_LEN];
	int port;
		
	char backup_hostname[HOST_NAME_LEN];
	int backup_port;

	char secret[MAX_PASSWORD_LEN+1];
	char backup_secret[MAX_PASSWORD_LEN+1];
	
	//char profile_name[PROFILE_NAME_LEN];
	//int retry_count;
	//int time_out;

	/* Only for portal accounting */
	struct in_addr nas_ip;
	char nas_id[MAX_NAS_IDENTIFIER_LEN+1];
	int acct_interim;
};

struct zysh_remove_event {
	//char profile_name[PROFILE_NAME_LEN];
	char interface[PROFILE_NAME_LEN];
};

struct zysh_exit_event {
	unsigned char status;
};

typedef struct accounting_event_s{
	int event_id;
	union {
		struct zysh_ac_ip_change ip_change_event;
		struct zysh_config_event radius_profile;
		struct zysh_remove_event remove_profile;
		struct zysh_exit_event exit_event;
	} u;
} accounting_event_t;

#if defined(ZLDCONFIG_NEBULA_PORTAL_ACCOUNTING_SUPPORT)
typedef struct accounting_portal_event_s{
	int event_id;
	struct zysh_config_event for_portal_profile[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP];
} portal_event_t;
#endif

#if defined(ZLDCONFIG_SOCIAL_WIFI)
struct sta_info_s{
	struct list_head sta_info_queue;
	char sta_ip[32];
	char sta_mac[18];
	char ap_mac[18];
	uint64_t tx;
	uint64_t rx;
};
#endif

typedef struct termination_cause_s {
	int uam_event;
	int acct_termination_cause;
	char *reason;
}termination_cause_t;

typedef struct acct_status_type_s {
	uint32_t acct_status_id;
	char *acct_status_string;
}acct_status_type_t;

typedef struct accounting_msg_t {
	char user_name[64];
	char calling_station_id[20];
	char called_station_id[128];
	char interface[PROFILE_NAME_LEN];
	char auth_module[32];
	int interim_interval;
#ifdef ZLDCONFIG_RADIUS_ATTR_SUPPORT
        char nas_ip_acct[32];
        char nas_id_acct[128];
#endif
	unsigned char attr_class[128];
        int class_length;
} accounting_msg_t;

#define ACCOUNTING_RECV_RADIUS_FILE "/tmp/accounting_recv_radius.sock"

int getInterfaceIdx(char *if_name, int *radioIdx, int *wlanIdx);
int accounting_stop_by_mac(char *mac, int type, conn_t *status);
void change_mac_format(char *sta_mac,char *calling_station_id);
int hash_func(char *mac);
struct accounting_radius *search_radius_by_interface (char *interface, int type);
struct accounting_node *add_new_node(struct accounting_msg_t *event, struct accounting_radius *radius, int type);
int insert_node_to_queue(struct accounting_node *node, unsigned short queue_type);

#endif

#ifndef __APMODE_RAPD_IPC_H__
#define __APMODE_RAPD_IPC_H__

#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <net/if.h>
#include <sys/ipc.h>

#define APMODE_RAPD_BUF_LEN 128

/* rogue rule bitmap definition */
#define RAPD_WEAK_SEC_BIT	0x1
#define RAPD_HIDDEN_SSID_BIT	0x2
#define RAPD_SSID_KEYWORD_BIT	0x4

/* domain socket file */
#define APMODE_RAPD_EVENT_SOCK	"/tmp/apmode_rapd.sock"
#define APMODE_RAPD_TOOL_SOCK	"/tmp/apmode_rapd_tool.sock"
#define APMODE_DETECTION_SSIDKEYWORD_FILE_PATH  "/tmp/rogue_rule_ssidkeywrd"

enum {
	RAPD_EVENT_CLASSFICATION_RULE_CHANGE		= 0,
	RAPD_EVENT_ROGUE_FRIENDLY_AP_MODIFY		= 1,
	RAPD_EVENT_GET_DBGLVL						= 2, 
	RAPD_EVENT_SET_DBGLVL						= 3, 
	RAPD_EVENT_SAVE_TO_FILE						= 4,
	RAPD_DETECT_NOW								= 5,
	RAPD_DETECT_ACTIVATE							= 6,
	RAPD_EVENT_DETECT_INTERVAL_CHANGE			= 7,
	RAPD_EVENT_CONFIG_CHANGE					= 8,  /* this event for, 1. apply another config, 2. hybird mode change */
};

enum {
	RAPD_ROGUEAP_ADD		= 0,
	RAPD_ROGUEAP_RM		= 1,
	RAPD_FRIENDLYAP_ADD	= 2,
	RAPD_FRIENDLYAP_RM	= 3,
};

struct apmode_rapd_rf_ap_change {
	char tmpfile[APMODE_RAPD_BUF_LEN];
};

struct apmode_rapd_ipc_msg {
	int   eventCode;
	union {
		int                dbglvl;
		int                s2f;
		int			rogue_rule_bitmap;
		int			activate_state;
		int 			detect_interval;
		struct apmode_rapd_rf_ap_change rf_ap_change;
	} u;
};

ssize_t rapdIpcSendEventNoWait(void *send_msg);
ssize_t rapdIpcSendEventWaitAndGet(void *send_msg, void *recv_msg);
#endif /* __APMODE_RAPD_IPC_H__ */

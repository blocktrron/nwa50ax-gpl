/*
 * Copyright (C) 2016 ZyXEL Communications, Corp.
 * All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 */

#ifndef ZLD_SYSINFO_H
#define ZLD_SYSINFO_H

#include <stdint.h>

typedef struct cpu_info_s {
	float user;
	float nice;
	float system;
	float idle;
	float iowait;
	float irq;
	float softirq;
	float steal;
} cpu_info_t;

typedef struct mem_info_s {
	unsigned long mem_total;
	long mem_available;
} mem_info_t;

extern int get_cpuusage(int core_num, uint32_t sec, cpu_info_t *cpu_info);
extern int get_memusage(mem_info_t *mem_info);

#endif

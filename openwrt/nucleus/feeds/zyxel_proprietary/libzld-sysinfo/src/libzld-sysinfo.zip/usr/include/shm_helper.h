/*
 * Copyright (C) 2016 ZyXEL Communications, Corp.
 * All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 */

#ifndef SHM_HELPER_H
#define SHM_HELPER_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

#define sem_up(semid)	sem_operation(semid, 1)
#define sem_down(semid)	sem_operation(semid, -1)

extern int sem_operation(int semid, short count);
extern void *shm_connect(char *pathname, int prod_id);
extern void shm_disconnect(void *buf);
extern int sem_connect(char *pathname, int prod_id, int create);
extern void sem_disconnect(int semid);

#endif

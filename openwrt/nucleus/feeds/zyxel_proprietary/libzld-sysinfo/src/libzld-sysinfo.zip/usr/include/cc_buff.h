#ifndef _CC_BUFF_H
#define _CC_BUFF_H

#include <stdint.h>
#include <zld-spec.h>
#define MAX_CORE_NUM ZLDSYSPARM_CPU_CORE_NUM
#define CCD_BIN "/usr/sbin/ccd"
#define CPUUSAGE_BUFFER_SIZE	(5 * 60) /* 5 minutes */
typedef struct cpuusage_s {
	uint64_t user[CPUUSAGE_BUFFER_SIZE];
	uint64_t nice[CPUUSAGE_BUFFER_SIZE];
	uint64_t system[CPUUSAGE_BUFFER_SIZE];
	uint64_t idle[CPUUSAGE_BUFFER_SIZE];
	uint64_t iowait[CPUUSAGE_BUFFER_SIZE];
	uint64_t irq[CPUUSAGE_BUFFER_SIZE];
	uint64_t softirq[CPUUSAGE_BUFFER_SIZE];
	uint64_t steal[CPUUSAGE_BUFFER_SIZE];
	unsigned int ptr;
	unsigned int data_num;
} cpuusage_t;

typedef struct cc_buff_s {
        cpuusage_t cpuusage[MAX_CORE_NUM];
} cc_buff_t;

#endif

#ifndef _ZYKIT_H_
#define _ZYKIT_H_

#include <netinet/in.h>

int zykit_mrd_get_pure_countrycode(void);
int zykit_mrd_get_countrycode(void);
char *zykit_mrd_get_countryname(int type);
int zykit_mrd_get_etheraddr(unsigned char *macaddr);
int zykit_mrd_get_serial_no(char *serial);
int zykit_mrd_get_modelid(uint8_t *id);
int zykit_mrd_get_productname(char *name, int format);
#ifdef ZLDCONFIG_MFGCONFIG_SUPPORT
int zykit_mrd_get_manufacture_flag(char *id);
#endif

int zykit_mrd_get_hardware(char *name);
int zykit_get_iface_hwaddr(char *iface, char *macaddr);
int zykit_get_iface_addr(char *iface, struct in_addr *addr);
int zykit_get_iface_broadaddr(char *iface, struct in_addr *addr);
int zykit_get_iface_netmask(char *iface, struct in_addr *addr);
int zykit_get_current_model_portnum(void);
int zykit_get_slotnum(uint8_t *id);
int zykit_get_slotnumbyname(char* name,int *maxslotnum);
int zykit_get_namebyid(uint8_t *id, char *name);
int zykit_get_idbyname(char *name, uint8_t *id);
int zykit_get_firmwareid_bymodelid(char *fid, uint8_t *mid);
int zykit_get_firmwareid(char *fid);
int zykit_get_current_model_slotnum(void);
int zykit_get_current_slot_band_mode(uint8_t slot);
int zykit_get_current_model_name(char *name, int format);
int zykit_get_product_line_name(char *name);
int zykit_get_product_zone_name(char *name);
int zykit_get_product_family_name(char *name);
int zykit_update_disk_firmwareid(void);
int zykit_get_fwversionbyid(char* fwversion, uint8_t* mid);
uint32_t zykit_get_model_capability(void);
int zykit_check_model_max_capability_bandmode(char * arg);
int zykit_check_model_max_capability_chwidth(char * arg);
int zykit_get_capa_placement(void);
int zykit_get_capa_wireless_bridge(void);
int zykit_get_capa_maps(void);
#ifdef ZLDCONFIG_WLAN_SMART_ANTENNA_SUPPORT
int zykit_get_capa_smartant_slot1(void);
int zykit_get_capa_smartant_slot2(void);
#endif
int zykit_get_capa_fcc_dfs_support(void);
int zykit_get_port_type(int port);
#ifndef _GLOBAL_HAL_H_
enum {
	WHOPMODE_UNKNOWN = 0,
	WHOPMODE_STANDALONE,
	WHOPMODE_CONTROLLER,
	WHOPMODE_MANAGED,
	WHOPMODE_BEFORE_FIRMWARE_UPDATE,
	WHOPMODE_CLOUD,
	WHOPMODE_MAX,
};
#endif

extern const char hybrid_wmesg[];

int zykit_wlan_get_hybridmode(void);
int zykit_wlan_get_hybridname(char *buff);
int zykit_wlan_set_hybridmode(int value);
int zykit_wlan_match_hybridname(char *buff);
int zykit_get_slot1_chainmask(uint8_t *id);
int zykit_get_slot2_chainmask(uint8_t *id);
int zykit_get_current_slot1_chainmask(void);
int zykit_get_current_slot2_chainmask(void);

#if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI)
int zykit_get_pd_type(void);
int zykit_get_pd_class(void);
int zykit_get_requested_power(void);
#endif /*  #if defined(ZLDCONFIG_LLDP_POWER_VIA_MDI) */

#endif /* _ZYKIT_H_ */

#ifndef _SYSTEM_STATUS_H
#define _SYSTEM_STATUS_H

#define VALUE_BUFFER_LEN    8
#define STR_BUFFER_LEN 64
#define SYS_STATUS "SYSTEM STATUS"

int send_system_status_to_vrpt(void);
int send_device_info_to_vrpt(void);
#endif

#ifndef _CAL_IFACE_STATISTICS_H
#define _CAL_IFACE_STATISTICS_H

#include "iface_generic.h"

#ifdef ZLDCONFIG_WLAN_WPA3_SUPPORT
#define GENERIC_TIMER_WLAN_MAX_AP (ZLDSYSPARM_WLAN_MAX_AP+ZLDSYSPARM_WLAN_MAX_OWE)
#else
#define GENERIC_TIMER_WLAN_MAX_AP ZLDSYSPARM_WLAN_MAX_AP
#endif

/* (eth + vlan + bridge + aux */
#define MAX_ALL_IFACE_NUM 	ZLDSYSPARM_ETH_IFACE_MAX_NUM + \
                           	ZLDSYSPARM_VLAN_IFACE_MAX_NUM + \
                           	ZLDSYSPARM_BRIDGE_IFACE_MAX_NUM + 1 + \
                            (ZLDSYSPARM_WLAN_MAX_SLOT*GENERIC_TIMER_WLAN_MAX_AP)

#define INVAILD_IFACE_NUM -1

#define PORT_STATUS_COUNT_PERIOD 90

/* active flag */
enum {
	ENABLE,
	DISABLE
};

/* use in local */
typedef struct interface_rx_tx_bytes {
	char ifacename[MAX_IFACE_NAME_LEN];
	unsigned long rx_bytes_current;
	unsigned long tx_bytes_current;
	unsigned long rx_bytes_pre;
	unsigned long tx_bytes_pre;
}iface_rx_tx_bytes_t;

/* use in local */
typedef struct port_rx_tx_bytes {
	int port_num;
	unsigned int rx_bytes_current;
	unsigned int tx_bytes_current;
	unsigned int rx_bytes_pre;
	unsigned int tx_bytes_pre;
}port_rx_tx_bytes_t;

/* use in share memery */
typedef struct interface_rx_tx_bytes_ps {
	int iface_num;/* iface number: eth0 number is 0, vlan10 number is 10, default is -1 */
	unsigned long rx_bytes_per_sec;
	unsigned long tx_bytes_per_sec;
}iface_rx_tx_bytes_ps_t;

/* use in share memery */
typedef struct interface_rx_tx_ps_info {
	iface_rx_tx_bytes_ps_t port[ZLDSYSPARM_PHY_PORT_MAX_NUM];	
	iface_rx_tx_bytes_ps_t eth[ZLDSYSPARM_ETH_IFACE_MAX_NUM];
	iface_rx_tx_bytes_ps_t vlan[ZLDSYSPARM_VLAN_IFACE_MAX_NUM];
	iface_rx_tx_bytes_ps_t bridge[ZLDSYSPARM_BRIDGE_IFACE_MAX_NUM];
#ifdef ZLDCONFIG_WLAN_ENABLE
	iface_rx_tx_bytes_ps_t ap[ZLDSYSPARM_WLAN_MAX_SLOT * GENERIC_TIMER_WLAN_MAX_AP];
#endif
	char active_port_calculate;
}iface_rx_tx_ps_info_t;

int cal_iface_statistic(void);
int init_cal_iface_statistic(void);
#endif

/******************************************************************************
 *
 *      Copyright (C) 2002-2005 ZyXEL Communications, Corp.
 *      All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 *
 *****************************************************************************/
/* $Id: generic_timer.h,v 1.6 2008/02/18 05:18:17 saxont Exp $ */
/*
   $Log: generic_timer.h,v $
   Revision 1.6  2008/02/18 05:18:17  saxont
   fix generic_timer daemon takes lots memory

   Revision 1.5  2008/02/15 13:05:02  saxont
   fix entry error

   Revision 1.4  2007/10/24 05:50:18  saxont
   add vrpt log for system status and device info

   Revision 1.3  2007/01/15 00:09:46  saxont
   fix log file may too big

   Revision 1.2  2006/09/13 04:58:58  saxont
   interface statistics calculate move to generic_timer

   Revision 1.1.1.1  2006/04/25 01:55:27  saxont
   create generic_timer and generic_timer api

*/
/* rm command */
#define RM_BIN			"/bin/rm"

/* command buf */
#define STRBUF 400

/* debug print */
#define DPRINT( format, args... ) 											\
		do {																\
			int pid = 0;													\
			int ppid = 0 ;													\
			FILE *fp = NULL;												\
			char strbuf[STRBUF];											\
			pid = getpid();													\
			ppid = getppid();												\
			sprintf( strbuf, "/tmp/generic_timer_%d", pid);					\
			if( ( fp = fopen( strbuf, "a+" ) ) ) {							\
				fprintf( fp,"pid:%d, ppid:%d\n", pid, ppid );				\
				fprintf( fp, "%s:%s:%d:", __FILE__, __func__, __LINE__ );	\
				fprintf( fp, format, ##args );								\
				fclose( fp );												\
				fp = NULL;													\
			}																\
		}while(0);/* end DPRINT */

/* define generic_timer_path */
#define GENERIC_TIMER_FULL_PATH "/usr/sbin/generic_timer"
/* define cal_iface_statistic ftok key string */
#define CALCULATE_IFACE_BYTE_PER_SECOND "/usr/lib/libgeneric_timer.so"

/* define last entry */
#define GENERIC_TIMER_LAST_ENTRY "NULL"

/* define event binary full path */
#define INTERFACE_STATISTICS_PATH "/bin/zysh -p 200 -e \"_interface send statistics log\" &"
#define SEND_SYSTEM_STATUS "/usr/sbin/send_system_info_to_vrpt sys_status"
#define SEND_DEVICE_INFO "/usr/sbin/send_system_info_to_vrpt device_info"
#define GENERIC_TIMER_EMPTY_PATH "NULL"

/* event id */
enum {
	GENERIC_TIMER_INTERFACE_STATISTICS_ID,
	GENERIC_TIMER_IFACE_BYTES_PER_SECOND_ID,
	GENERIC_TIMER_SEND_SYSTEM_STATUS_VRPT_ID,
	GENERIC_TIMER_SEND_DEVICE_INFO_VRPT_ID,
	/* don't move last entry */	
	GENERIC_TIMER_LAST_ENTRY_ID
};

/* return code of  sendIntervalToGenericTimer */
enum {
	IPCS_OK,
	KEY_FAIL,
	MSGID_FAIL,
	MSGSND_FAIL
};

/* mtype */
enum {
	NONE,
	CAHNGE_TIMER_ENTRY,
	ADD_TIMER_ENTRY,
	DEL_TIMER_ENTRY
};

/* action id */
enum {
	UNKNOWN_ACTION,
	BINARY_CODE,
	POINT_OF_API
};

/* struct event */
typedef struct zy_time_event_handle {
	/* event id */
	int event_id;
	/* action id */
	int action_id;
	/* full path of binary code*/
	char *event_binary_path;
	/* point to action function */
	int (*action)(void);
	/* point to initial function */
	int (*initial)(void);	
	/* interval time */
	int event_interval;
	/* time count */
	unsigned long event_time_count;
} zy_time_event_handle_t;

typedef struct generic_timer_msgbuf {
         long  mtype;
         zy_time_event_handle_t mtext;
} generic_timer_msgbuf_t;

/* send interval to generic_timer */
int sendIntervalToGenericTimer( zy_time_event_handle_t *zy_event_handle );

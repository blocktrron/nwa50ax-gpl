/****************************************************************************/
/*
* Copyright (C) 2000-2012 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
#ifndef __INFO_TRANSFER_H__
#define __INFO_TRANSFER_H__


/*=======================defined timer id parameter start=======================*/
//this id only for one handler function, range:1~50  renaming
#define LLDP_TIMER 1
#define HARDWARE_TIMER 2

/*=======================defined timer id parameter end=======================*/


/*=======================defined event id parameter start=======================*/
//this id only for one handler function, range:1~50
#define HARDWARE_EVENT          1
#define COMMON_LOG_EVENT        2

/*=======================defined event id parameter end=======================*/


/*=======================defined common parameter=======================*/
#define	OK				0
#define	FAIL			1
#define JSON_NAME_LEN	32
#define INFO_LEN		64
#define RETRY_COUNT		3
#define MAC_LEN			6
#define MAX_LEN			1024
#define INFO_EVENT_HOOK_MAX	50
#define EMPTY_STR	""
/*=======================defined socket parameter=======================*/
#define NETLINK_PROC_TO_APP_GROUP		0xFFFF
#define FORWARD_TO_AC_WTP_STATUS_SOCKET_ZYSH	"/tmp/forward-to-ac-wtp-status-socket-zysh.sock"
#define WTP_STATE_CHG	"wtp_state_chg"
#define DATA_SIZE	strlen(WTP_STATE_CHG)
#define AP_INTERFACE	"br0"

#define COMMON_LOG_TRIGGER	"common_log_trigger"
/*=======================defined debug parameter=======================*/
enum{
	MSG_STATUS = 1,
	MSG_WARNING,
	MSG_ERROR,
	MSG_DEBUG,
	MSG_DEBUG_ALL
};

/*=======================defined json parameter=======================*/
typedef char *(*get_info_func)(int i);

enum{
	LEVEL_0=0,
	LEVEL_1,
	LEVEL_2,
	LEVEL_3,
	LEVEL_MAX
};

enum{
	VALUE_STR=0,
	VALUE_INT,
	VALUE_BL,
	VALUE_NO
};

typedef struct json_info_s {
        int level; 
        char name[JSON_NAME_LEN];
        get_info_func func;
        int type;
        char parent[JSON_NAME_LEN];
}json_info_t;

/*=======================defined link-list marco=======================*/
#define InfoLIST_CNT(head)			(head.count)

typedef pthread_mutex_t InfoLock_t;
#define InfoLOCK_GET(_LOCK)	(pthread_mutex_lock(& _LOCK))
#define InfoLOCK_PUT(_LOCK)	(pthread_mutex_unlock(& _LOCK))

#define InfoQLIST_FOREACH(head, entry, field)	\
	for (entry = head.listHead;					\
		entry != NULL;						\
		entry = entry->field.next)

#define InfoQLIST_INSERT(head, entry, field)	do {\
		if (((entry->field.next) = head.listHead) != NULL)		\
			(head.listHead)->field.prev = &(entry->field.next); \
		head.listHead = entry;								\
		entry->field.prev = &(head.listHead);				\
		head.count++;									\
	} while (0)

#define InfoLIST_INSERT(head,entry,field)	do{\
			entry->field.next = NULL;				\
			if (head.listHead == NULL) head.listHead = entry;\
			else	 head.listTail->field.next = entry; \
			head.listTail = entry; head.count++;		\
}while(0)

#define InfoLIST_REMOVE(head,entry,field)	do{\
				entry = head.listHead;					\
				if (entry) {							\
					head.listHead = entry->field.next;\
					entry->field.next = NULL;			\
					head.count--;					\
				}									\
}while(0)

#define InfoQLIST_HEAD(entryType)		\
	struct {									\
		struct entryType *listHead; 		\
		int32_t count,wm;							\
		void *priv; 						\
	}

#define InfoQLIST_REMOVE(head,entry, field)	do {\
	if ((entry->field.next) != NULL)							\
		(entry->field.next)->field.prev = entry->field.prev;	\
	*(entry->field.prev) = (entry->field.next);					\
	head.count--;										\
	if(!head.count)										\
		head.listHead = NULL;							\
} while (0)

#define InfoQLIST_INIT(head,watermark)	do{\
		head.listHead = NULL;					\
		head.count = 0; 					\
		head.wm = watermark;				\
		head.priv = NULL;						\
	}while(0)

#define InfoQLIST_CNT(head)			(head.count)

#define InfoLIST_INIT(head,watermark)		do{\
	head.listHead = head.listTail = NULL;\
	head.count = 0;						\
	head.wm = watermark;				\
	head.priv = NULL;						\
}while(0)

#define InfoLIST_ENTRY(entryType)		\
struct {								\
	struct entryType *next;			\
}

#define InfoQLIST_ENTRY(entryType)		\
struct {									\
	struct entryType *next;				\
	struct entryType **prev;				\
}

#define InfoLIST_HEAD(entryType)		\
struct {								\
	struct entryType *listHead,*listTail;	\
	int32_t count,wm;						\
	void *priv;						\
}

#define INFO_MALLOC_CHECK(name, size, errProc, errRet)	{name = malloc(size);\
															if(!(name)){ \
																{errProc;} \
																{errRet;} \
															}\
														}

#define INFO_MEM_FREE(name)	{if(name)\
									{\
										free(name);\
										name=NULL;\
									}\
								}

/*=======================defined timer parameter=======================*/
//typedef void (*Info_cb_timer_func)(int id);

typedef void (*info_cb_timer_func)(int id);

typedef struct Info_Timer_Register_s
{
	InfoQLIST_HEAD(Info_Timer_Register_Entry_s) InfoTimerRegisterList;
} Info_Timer_Register_t;

typedef struct Info_Timer_Register_Entry_s
{
	InfoQLIST_ENTRY(Info_Timer_Register_Entry_s) next;
	info_cb_timer_func pFunc;
	int32_t iType;
	int32_t iTime;
	int32_t iTimeCounter;
} Info_Timer_Register_Entry_t;

typedef struct Info_Timer_Exec_Func_Entry_s
{
	InfoLIST_ENTRY(Info_Timer_Exec_Func_Entry_s) next;
	info_cb_timer_func pFunc;
	int32_t iType;
} Info_Timer_Exec_Func_Entry_t;

typedef struct Info_Timer_Exec_Func_s
{
	InfoLIST_HEAD(Info_Timer_Exec_Func_Entry_s) InfoTimerExecFuncList;
} Info_Timer_Exec_Func_t;

int32_t InfoTimerRegisterAct(info_cb_timer_func InfoTimerFuncPtr, int32_t iType, int32_t iTime);
int32_t InfoTimerUnRegister(int32_t iType);

#define ATTACH_INFO_TIMER_FUNC(callbackfunc, Type, time)\
	InfoTimerRegisterAct(callbackfunc, Type, time);
#define DEATTACH_INFO_TIMER_FUNC(Type)\
	InfoTimerUnRegister(Type);

/*=======================defined event parameter=======================*/
//typedef void (*Info_cb_event_func)(char *data, int id);

typedef void (*info_cb_event_func)(int id, char *data, size_t data_len);

typedef struct Info_Event_Register_s
{
	InfoQLIST_HEAD(Info_Event_Register_Entry_s) InfoEventRegisterList;
} Info_Event_Register_t;

typedef struct Info_Event_Register_Entry_s
{
	InfoQLIST_ENTRY(Info_Event_Register_Entry_s) next;
	info_cb_event_func pFunc;
	int32_t iType;
	char string[INFO_LEN];
} Info_Event_Register_Entry_t;

typedef struct Info_Event_Exec_Func_Entry_s
{
	InfoLIST_ENTRY(Info_Event_Exec_Func_Entry_s) next;
	info_cb_event_func pFunc;
	int32_t iType;
	char string[INFO_LEN];
} Info_Event_Exec_Func_Entry_t;

typedef struct Info_Event_Exec_Func_s
{
	InfoLIST_HEAD(Info_Event_Exec_Func_Entry_s) InfoEventExecFuncList;
} Info_Event_Exec_Func_t;

int32_t InfoEventRegisterAct(info_cb_event_func InfoEventFuncPtr, int32_t iType, char *string);
int32_t InfoEventUnRegister(int32_t iType);

#define ATTACH_INFO_EVENT_FUNC(callbackfunc, Type, string)\
	InfoEventRegisterAct(callbackfunc, Type, string);
#define DEATTACH_INFO_EVENT_FUNC(Type)\
	InfoEventUnRegister(Type);

/*=======================defined register init parameter=======================*/
typedef int (*initcall_t) (void);

extern initcall_t __start_init_ptrs, __stop_init_ptrs;

#define __initcall(fn) \
        initcall_t __initcall_##fn __init_call = fn
#define __init_call \
        __attribute__ ((unused,__section__ ("init_ptrs")))
#define register_init(x) \
        __initcall(x)

static inline void
do_initcalls(void)
{
	initcall_t *call_p;
	call_p = &__start_init_ptrs;
	do {
		(*call_p)(); 
		++call_p;
	} while (call_p < &__stop_init_ptrs);
}

/*=======================defined common function=======================*/
char *getAPMacAddr(int index);
void conform_char(char *src, int skip_space);
void zyxel_json_single_group(json_info_t tbl[], int num, char *src);
int send_info_to_ac(char *binary,char *event, char *src, int skip_space);

extern void info_dbg(int level, const char *fmt, ...);

#endif

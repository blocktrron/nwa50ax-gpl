/******************************************************************************
 *
 *  Copyright (C) 2011-2012 ZyXEL Communications, Corp.  
 *  All rights reserved.
 *
 *****************************************************************************/

#ifndef _LIBBMM_H_
#define _LIBBMM_H_

#ifndef DBG_SYSLOG
#define DBG_SYSLOG
#ifdef DBG_SYSLOG_ON
#define dbg_syslog(format, args...) \
	do { \
		syslog(LOG_DEBUG, "%s:%d:"format,__FILE__,__LINE__,## args); \
	} while ( 0 )
#else
#define dbg_syslog(format, args...)
#endif
#endif/*DBG_SYSLOG*/

#ifndef TRUE
#define TRUE	 (1==1)
#endif

#ifndef FALSE
#define FALSE 	 (!TRUE)
#endif

#include <sys/types.h>
#include <stdint.h>
#include "MRD.h"

#define BMM_STORAGE_MTD 		1
#define BMM_STORAGE_EEPROM 		2
#define BMM_STORAGE_EMMC		3
#define BMM_STORAGE_FILE		4

#define BMM_FLAG_SEEK_END 			0x01  /* offset start form head other from the end */
#define BMM_FLAG_COMBINE_MASK 		0x0E
#define BMM_FLAG_COMBINE_BM			0x02
#define BMM_FLAG_COMBINE_MRD		0x04
#define BMM_FLAG_COMBINE_MYZYXEL	0x08
#define BMM_FLAG_DYNAMIC_ADJUST		0x10  /* auto adjustment for size, partition  */
#define BMM_FLAG_LOCK				0x20
#define BMM_OPT_BACKUP_MRD_MYZYXEL 0x1

#define BMM_FILE_BM 		1
#define BMM_FILE_MRD 		2
#define BMM_FILE_MYZYXEL 	3
#define BMM_FILE_END		-1

#ifndef ZLDSYSPARM_MYZYXEL_SIZE
#define ZLDSYSPARM_MYZYXEL_SIZE 512
#endif

#define BMM_PARTITION_LEN 32
#define BMM_NAME_LEN 32

#define PROC_MTD_PATH	"/proc/mtd"
#define KERNEL_NAME	"kernel"

struct zld_bmm_info_s;

struct zld_bmm_op_s {
	int (*adjust_bmm_info)( struct zld_bmm_info_s *bmm_p);
	char * (*get_bm_image)(  struct zld_bmm_info_s *bmm_p );
	int (*update_bm_image)( struct zld_bmm_info_s *bmm_p, char *image, off_t size, uint32_t option );
	char * (*get_mrd_image)(  struct zld_bmm_info_s *bmm_p );
	int (*update_mrd_image)( struct zld_bmm_info_s *bmm_p, char *image, off_t size );
	char * (*get_myzyxel_image)(  struct zld_bmm_info_s *bmm_p);
	int (*update_myzyxel_image)( struct zld_bmm_info_s *bmm_p, char *image, off_t size );
};


struct zld_bmm_info_s {
	int file_type; 
	int storage;
	unsigned int address; /* EEPROM: eeprom address, block: start block number mtd: unused */
	long offset; 
	off_t size; /* 0 mean the complete partition size */
	unsigned int flags;
	char name[BMM_NAME_LEN];		/* should the same define in /proc/mtd */
	char partition[BMM_PARTITION_LEN]; /* "" will re-caculate according to /proc/mtd */
	struct zld_bmm_op_s *op;
};

extern struct zld_bmm_info_s zld_bmm_tbl[];
extern int replace_mtd_dev_by_name ( char *name, char *mtd ) ;
extern char *get_bm_image( off_t *size );
extern int  update_bm_image ( char *image , off_t size, uint32_t option );
extern char *get_mrd_image( off_t *size );
extern int  update_mrd_image ( char *image , off_t size );
extern char *get_myzyxel_image( off_t *size );
extern int  update_myzyxel_image ( char *image , off_t size );
extern int cp_rom2proc_mrd(void);
extern int set_mrd_proc( MRD *mrd );
extern int get_bmm_partition ( char *partion, short bmm_file ) ;
extern void disp_bmm_info ( struct zld_bmm_info_s *bmm_p );

#ifdef ZLDCONFIG_BMM_MTD
extern int mtd_erase ( int fd, uint32_t offset, uint32_t len, int lock );
extern uint32_t get_mtd_size_by_fd ( int fd );
extern uint8_t get_mtd_type_by_fd ( int fd );
extern uint32_t get_mtd_erasesize_by_fd ( int fd );
extern uint32_t get_mtd_size_by_name ( char *mtd );
#endif
#ifdef ZLDSYSPARM_BMM_EMMC
extern uint64_t get_emmc_size_by_name ( char *emmc );
#endif
#ifdef ZLDSYSPARM_BMM_FILE
uint64_t get_file_size_by_name ( char *file );
#endif


extern int bmm_write_bm( char *bm_file );

#endif

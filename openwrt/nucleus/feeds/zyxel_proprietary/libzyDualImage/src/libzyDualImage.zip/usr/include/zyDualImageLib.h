#include <zylog.h>
#include <stdint.h>
#include "zld-spec.h"

#define FEATUREBIT_OFFSET_OF_DUALIMAGE 	10
#define PROC_KERNEL_CMDLINE	"/proc/cmdline"

/*Support Dual Image*/
#define NUMOFIMAGE					2

#define DUALIMAGE_BOOTIMAGE  		0xfe
#define DUALIMAGE_UPGRADEIMAGE 		0xff

#define DUALIMAGE_IMGSTATE_MASK 	0xc
#define DUALIMAGE_IMGLOG_MASK 		0x2
#define BOOTIMAGE_IMAGE_MASK 		0x1


#define KERNEL_CMD_BOOTIMG_STR		"bootImage="
#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
#define IMAGE_UPGRADE_STATUS		"/etc/zyxel/ftp/tmp/"
#define SEND_UPGRADE_LOG		"/db/etc_writable/sendUpgradeLog"
#define UPGRADE_STATUS_FILE		"/etc/zyxel/ftp/tmp/upgradeStatus"
#else
#define IMAGE_UPGRADE_STATUS		"/etc/zyxel/ftp/keep/"
#define SEND_UPGRADE_LOG		"/etc/zyxel/ftp/keep/sendUpgradeLog"
#define UPGRADE_STATUS_FILE		"/etc/zyxel/ftp/diaglog/upgradeStatus"
#endif

#define DUALIMAGE_FW_UPGRADE_STATUS		"Last Firmware Upgrade Status"
#define DUALIMAGE_FW_UPGRADE_TIMESTAMP		"Last Firmware Upgrade Timestamp"

#define BOOTCONFIG_AGE_FAIL		0x0
#define BOOTCONFIG_AGE_NEW		0xFFFFFFFF

#define posOfStartbit(b,n,m) \
({ int def = b; \
int len=0; \
n=0;	\
m=0;	\
while (def) { \
        if(def & 1 ) {break;} \
        n ++; \
        def = def >> 1; \
};  \
while (def) { \
        if((def & 1) ==0) {break;} \
        len ++; \
        def = def >> 1; \
};  \
m = (1 << len) - 1; \
})

typedef enum{				
	DUALIMAGE_NUM_IMAGE,		
	DUALIMAGE_NUM_BOOTIMAGE,
	DUALIMAGE_NUM_UPGRADEIMAGE
}zyDualImageNum;

typedef enum{				
	DUALIMAGE_STATE_NONE=0,		
	DUALIMAGE_STATE_NEW_IMAGE,		
	DUALIMAGE_STATE_SUCCESS_IMAGE,	
	DUALIMAGE_STATE_FAIL_IMAGE
}zyDualImageState;		

struct ImageInfo
{
	zyDualImageState state;
	int log;	
	uint32_t age;
};
	
struct dualImageInfo
{
	int bootImage;
	int upgradeImage;
	struct ImageInfo image[NUMOFIMAGE];
};

/*MRD process API*/
int cp_rom2workingbuffer(char *MRDROM);
int save_workingbuffer2rom(char *MRDROM);

/*Dual Image process API*/
int dumpDualImageInfo(struct dualImageInfo *dualIMAGE);
void writeDualImageInfo(struct dualImageInfo dualIMAGE);


int getCurrentImageNum(void);

/*Set API*/
void setBootImageNum(struct dualImageInfo *dualIMAGE, int ImageNum);
void setUpgradeImageNum(struct dualImageInfo *dualIMAGE, int ImageNum);

void setImageState(struct dualImageInfo *dualIMAGE,int image, zyDualImageState stat);
void setImageLog(int image);

/*Get API*/
int getBootImageNum(struct dualImageInfo *dualIMAGE);
int getUpgradeImageNum(struct dualImageInfo *dualIMAGE);
int getImageState(struct dualImageInfo *dualIMAGE,int image);
int getImageLog(void);

/*LogCheck*/
void checkImageLog(void);

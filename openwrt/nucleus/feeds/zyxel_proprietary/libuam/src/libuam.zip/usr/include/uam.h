/* $Id: uam.h,v 1.31 2007/11/21 11:55:51 edward Exp $ */

/*
 * $Log: uam.h,v $
 * Revision 1.31  2007/11/21 11:55:51  edward
 * support threading for uam request
 *
 * Revision 1.29.2.1  2007/10/03 06:07:54  rogerho
 * enhance log for SSL VPN
 *
 * Revision 1.29  2007/03/13 07:37:15  juwu
 * support SSLVPN lease time update
 *
 * Revision 1.28  2007/02/13 07:20:05  alexlee
 * no message
 *
 * Revision 1.27  2007/01/04 07:01:38  rogerho
 * *** empty log message ***
 *
 * Revision 1.26  2006/09/27 08:03:55  rogerho
 * Merge uam with SSL VPN feature
 *
 * Revision 1.25  2006/09/26 12:05:00  juyu
 * New enhancement Dial-in Management.
 *
 * Revision 1.24  2006/09/05 06:57:47  rogerho
 * move UAM_UNIQUE_LEN and UAM_USERNAME_LEN  to zld-spec.h
 *
 * Revision 1.23  2006/08/24 00:11:16  harry
 * Add destination ip entry in user_info.
 *
 * Revision 1.22  2006/02/09 09:15:04  edward
 * enlarge the size of auth token
 *
 * Revision 1.21  2005/11/15 05:51:01  edward
 * show failed login reason for web login
 *
 * Revision 1.20  2005/09/12 08:12:18  edward
 * allow more people share the same account
 *
 * Revision 1.19  2005/09/08 08:38:25  edward
 * alter some generic codes for other pam modules
 *
 * Revision 1.18  2005/08/23 07:37:27  edward
 * adjust length of unique
 *
 * Revision 1.17  2005/08/18 08:29:01  edward
 * support update lease automation
 *
 * Revision 1.16  2005/08/17 08:17:48  edward
 * support user idle detection
 *
 * Revision 1.15  2005/08/10 01:17:05  edward
 * update definition/wording
 *
 * Revision 1.14  2005/08/08 12:47:39  edward
 * support external virtual users
 *
 * Revision 1.13  2005/07/29 05:24:29  edward
 * make wording more readable
 *
 * Revision 1.12  2005/07/28 10:41:46  edward
 * add user login uniqueness support and change definition wording
 *
 * Revision 1.11  2005/07/28 01:58:25  edward
 * add user lock support
 *
 * Revision 1.10  2005/07/13 00:51:34  edward
 * add debug option and fix bugs of userdb handling
 *
 * Revision 1.9  2005/05/06 07:09:37  edward
 * add notify function to uam library
 *
 * Revision 1.8  2005/04/19 09:53:55  edward
 * support login privilege matrix
 *
 * Revision 1.7  2005/03/30 09:54:25  edward
 * split uam library out: add uamlog.h
 *
 * Revision 1.6  2005/03/15 06:07:27  edward
 * add user log support
 *
 * Revision 1.5  2005/03/03 00:59:02  edward
 * add user attribute for an uam notify event
 *
 * Revision 1.4  2005/02/15 05:02:19  edward
 * add idle timeout definition for backward compatibility
 *
 * Revision 1.3  2005/02/04 07:12:28  edward
 * add user profile and multi-login support
 *
 * Revision 1.2  2004/12/24 06:28:31  edward
 * update event name
 *
 * Revision 1.1.1.1  2004/12/23 06:28:24  edward
 * initial release
 *
 */

#ifndef _UAM_H_
#define _UAM_H_

#include <stdint.h>
#include <sys/types.h>
#include <pthread.h>
#include <netinet/in.h>

#include "linked-list.h"
#include "zld-spec.h"

#define UAM_MAX_USERS		ZLDSYSPARM_CON_USER_MAX_NUM
#define PRODUCT_LINE_NAME_LEN		32
/* UAM_REAUTH_TIME in minutes */
#define UAM_REAUTH_TIME     (8*60) /* 8 hours */
/* UAM_REAUTH_TIME in minutes */
#define UAM_LEASE_TIME      (30)   /* 30 minutes */

#ifdef ZLDCONFIG_USERGROUP_EXTERNAL_USER_ENHANCEMENT
/* for USER_TYPE_LEN */
#define USER_TYPE_LEN 16 
#endif

//#define UAM_SHM_DB 
#ifdef UAM_SHM_DB
#include "avl.h"
#endif

#define	UAM_LOGOUT_DEFER_TIME			"/tmp/logout_defer_time.txt"
#define	UAM_DEFAULT_LOGOUT_DEFER_TIME	5
#ifdef AAA_WEB_PORTAL
#define QUERY_PATH		"/tmp/query-socket"
#define FREE_RADIUS 			1
#define UAM_LOGIN 				2
#define UAM_LOGOUT							3
#define CLOUD_QUERY_ADDRESS 				4
#define USER_LOGIN_FAIL 			5	
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
#define EMAIL_VERIFICATION_DPPSK_ASSOC			6
#define GOOGLE_AUTHENTICATOR_1X_ASSOC				7
#define GOOGLE_AUTHENTICATOR_1X_BINDING				8
#define GOOGLE_AUTHENTICATOR_1X_AUTH				9
#endif
#endif

#ifdef AAA_WEB_PORTAL
/* notify CC or not */
#define NOTIFY_CC			1
#define DO_NOT_NOTIFY_CC	2

/* local user or foreign user */
#define LOCAL_AUTHENTICATED_USER 		1
#define FOREIGN_AUTHENTICATED_USER 	2
#endif

/* open for user-aware applications */
#define UAM_SERVICE_LEN		32
#define UAM_USERNAME_LEN	(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define UAM_PASSWORD_LEN	(ZLDSYSPARM_UAM_PASSWORD_LEN)
#define UAM_UNIQUE_LEN		(ZLDSYSPARM_UAM_UNIQUE_LEN)
#ifdef ZLDCONFIG_WEBAUTH
#define IN_USER_DEFAULT_DUE_BASE	"12:00"
#endif
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
#define UAM_PROFILE_NAME_LEN	128
#endif
#ifdef AAA_WEB_PORTAL
#define UAM_EXT_GROUP_LEN		(ZLDSYSPARM_UAM_USER_ROLES_PER_EXT_GROUP_USER)*(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define MAC_ADDRESS_LENGTH	 	6
#define ACCOUNT_TYPE_LENGTH	 	32
#define CLOUD_AUTH_ERR_MSG_LEN	1024
#define VLAN_ID_LEN			6
#define FQDN_NAME_LEN 256
#define UAM_PROFILE_NAME_LEN_64		64
#define UAM_PORTAL_IP_ADDR_LEN		16
#define UAM_PORTAL_SSID_LEN			64
#define UAM_PORTAL_METHOD_LEN		32
#define UAM_PORTAL_VAP_IF_LEN			16
#define UAM_PORTAL_MAC_STR_LEN		32
#define UAM_PORTAL_AUTH_TIME_LEN	16
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
#define UAM_PORTAL_LOCALE_STR_LEN	16
#define UAM_PORTAL_GENDER_STR_LEN       16
#define UAM_PORTAL_AGE_STR_LEN		16
#endif
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
#define GA_CLIENT_ADDR_STR_LEN		16
#define GA_VERIFICATION_STR_LEN	9
#endif
#define GA_BINDING_TOKEN_STR_LEN		128
#endif

#define strncpy_0( dst, src, len ) \
{\
	int __len__ = (len); \
	char *__dst__ = (dst); \
	strncpy((__dst__), (src), (__len__));\
	*((char *)(__dst__)+((__len__)-1)) = '\0';\
};

struct uam_handle
{
	int fd;

#define UAM_MODE_QUERY		0
#define UAM_MODE_LISTEN		1
	u_int8_t mode;
};

/* events */
enum event_number {
	/* exported event */
	UAM_EVENT_USER_LOGIN = 1,
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT	
	UAM_EVENT_USER_SOCIAL_LOGIN_STAGE1,
	UAM_EVENT_USER_SOCIAL_LOGIN_STAGE2,
#endif	
	UAM_EVENT_USER_LOGOUT,
	UAM_EVENT_USER_LOGOUT2,			/* Extra event for logout, this event will include sub_event for logout reason */
	UAM_EVENT_USER_REAUTH_TIMEOUT,
	UAM_EVENT_USER_LEASE_TIMEOUT,
	UAM_EVENT_USER_IDLE_TIMEOUT,
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
	UAM_EVENT_USER_SESSION_TIMEOUT,
#endif
#ifdef AAA_WEB_PORTAL
	UAM_EVENT_FOREIGN_USER_LOGOUT,
#endif	
	UAM_EVENT_QUERY_RESULT,
	UAM_EVENT_USER_TRAFFIC,
	UAM_EVENT_TUNNEL_UP,			/* tunnel is established for internal notify */
	UAM_EVENT_TUNNEL_DOWN,			/* tunnel is disconnected for internal notify */
	UAM_EVENT_USER_TUNNEL_UP,		/* tunnel is established for external notify */
	UAM_EVENT_USER_TUNNEL_DOWN,		/* tunnel is disconnected for external notify */

	UAM_EVENT_WEB_USER_LOGOUT,		/* Extra event for web user logout, in order to fix user logout problem in EXT-group user.*/
	UAM_EVENT_USER_FORCE_LOGOUT,		/* Extra event for force logout, admin user can force logout common user */

	/* update event */
	UAM_EVENT_UPDATE_LEASE_TIME,
	UAM_EVENT_UPDATE_IDLE_TIME,
	UAM_EVENT_UPDATE_REAUTH_TIME,
#ifdef AAA_WEB_PORTAL
	UAM_EVENT_UPDATE_ROAMING_STA_IP,
#endif
#ifdef ZLDCONFIG_WEBAUTH
	UAM_EVENT_UPDATE_DUE_TIME,
	UAM_EVENT_UPDATE_SYSTEM_TIME,
	UAM_EVENT_LOGOUT_DUE_USER,
#endif
	
	/* internal events */	
	UAM_EVENT_USER_ALIVE,
	UAM_EVENT_APP_QUERY_NAME,
	UAM_EVENT_APP_QUERY_FROM,
	UAM_EVENT_APP_QUERY_FROM_FIRST,
	UAM_EVENT_APP_QUERY_ALL,
	UAM_EVENT_APP_QUERY_TOTAL_USER_NUM,
	UAM_EVENT_APP_LISTEN,
	UAM_EVENT_APP_CLOSE,
	UAM_EVENT_TIMER_SECOND,
	UAM_EVENT_TIMER_10SECONDS,
	UAM_EVENT_CONFIG_CHANGE,
	/* special events for specific GUI operation. NOT dispatchable */
	UAM_EVENT_USER_LOGOUT_REVOCABLE,	/* logout will be deferred and revocable */
	UAM_EVENT_USER_LOGOUT_REVOKE,		/* revoke previous revocable logout */
#if defined(ZLDCONFIG_NAC)
	UAM_EVENT_UPDATE_AUTHENTICATION_POLICY_INDEX,
	UAM_EVENT_UPDATE_AUTHENTICATION_POLICY_EPS_CHK,
#endif
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
	UAM_EVENT_UPDATE_ACCOUNTING_STATUS,
	UAM_EVENT_RENAME_RADIUS_PROFILE_NAME,
#endif
	UAM_EVENT_LIMIT,
};

#define UAM_EVENT_FLAG_SKIP_USER_LOGOUT		(1 << 1) /* When this flag is on, uam will ignore UAM_EVENT_USER_LOGOUT.*/
#define UAM_EVENT_FLAG_USED_IPV6_ADDR		(1 << 2)

#ifdef ZLDCONFIG_USERGROUP_EXTERNAL_USER_ENHANCEMENT
#define UAM_EVENT_FLAG_USER_NUM			(1 << 3)
#define UAM_EVENT_FLAG_LOGIN_LOCAL		(1 << 4)
#define UAM_EVENT_FLAG_LOGIN_EXT_USER		(1 << 5)
#define UAM_EVENT_FLAG_LOGIN_EXT_GROUP		(1 << 6)
#define UAM_EVENT_FLAG_LOGIN_DEFAULT_EXT_USER	(1 << 7)
#define UAM_EVENT_FLAG_REFRESH_TIME_LIST	(1 << 8)

#define UAM_EVENT_FLAG_EXT_USERS	\
	(UAM_EVENT_FLAG_LOGIN_EXT_USER | UAM_EVENT_FLAG_LOGIN_EXT_GROUP | UAM_EVENT_FLAG_LOGIN_DEFAULT_EXT_USER)
#endif
#ifdef AAA_WEB_PORTAL
#define UAM_EVENT_FLAG_USER_LOGOUT_MATCH_MAC_SSIDPROFILE	(1 << 9)
#define UAM_EVENT_FLAG_RUM									(1 << 10)
#define UAM_EVENT_FLAG_8021x_logout							(1 << 11)
#define UAM_EVENT_FLAG_USER_LOGOUT_MATCH_SSIDPROFILE		(1 << 12)
#define UAM_EVENT_FLAG_USER_LOGOUT_MATCH_MAC				(1 << 13)
#endif
struct uam_event
{
	int event;
	int count;
	int sub_event;
	/* field to identify a user */
	char service[UAM_SERVICE_LEN];
	char username[UAM_USERNAME_LEN];
	char real_username[UAM_USERNAME_LEN];
	char define_name[UAM_USERNAME_LEN];   /* the username to get access, visibility... */
	char unique[UAM_UNIQUE_LEN + 1];
	u_int32_t ip;
	u_int32_t dst_ip;
	u_int32_t tunnel_ip;	/* for SSLVPN and L2TP */

#if defined(ZLDCONFIG_QRCODE_AUTHENTICATOR)
	char qrcode_authenticator[UAM_USERNAME_LEN];
#endif
#if defined(ZLDCONFIG_NAC)
	int authentication_policy_idx;
	int authentication_policy_eps_chk;
#endif
#define UAM_USER_ATTRIBUTE_MANAGEMENT	(1 << 0)
#define UAM_USER_ATTRIBUTE_ACCESS		(1 << 1)
	unsigned char attribute;
	unsigned char type;

	/* field to update */
	union {
		unsigned int lease_time;
		unsigned int reauth_time; 
#ifdef ZLDCONFIG_WEBAUTH
		unsigned int due_time; 
#endif
	} update;
#ifdef ZLDCONFIG_IPV6
	struct in6_addr ip6;
	struct in6_addr dst_ip6;
	struct in6_addr tunnel_ip6;
#endif
	unsigned int event_flag;

	int default_lease_time;  /* the lease_time decided by login */
	int default_reauth_time; /* the reauth_time decided by login */
	unsigned int match_flag;
#ifdef ZLDCONFIG_WEBAUTH
	unsigned int default_due_time; 
#endif	
	unsigned int idle_timeout;
	int idle_timeout_form_acct_flag;
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
	unsigned int session_timeout;
	char radius_profile_name[UAM_PROFILE_NAME_LEN];
	char old_radius_profile_name[UAM_PROFILE_NAME_LEN];
	int accounting_status;
#endif
#ifdef AAA_WEB_PORTAL
	int notify_cc; /* local or foreign station */
	char method[UAM_PORTAL_METHOD_LEN]; /* none, click-through, sign-on, email-verification-dppsk, google-authenticator-1x */
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
	char locale[UAM_PORTAL_LOCALE_STR_LEN];
	char gender[UAM_PORTAL_GENDER_STR_LEN];
	char age[UAM_PORTAL_AGE_STR_LEN];
#endif
	char auth_time[UAM_PORTAL_AUTH_TIME_LEN];
	char ssid_name[UAM_PORTAL_SSID_LEN]; 
	char ssid_profile_name[UAM_PROFILE_NAME_LEN_64];
 	char ssid_vap_iface[UAM_PORTAL_VAP_IF_LEN];
	char sta_mac[UAM_PORTAL_MAC_STR_LEN];
	int usr_from; /* local user or foreign user*/
	int ga_acct_status; /* 0:disable, 1:unbinding, 2:binding, 3:whitelist */
	char ga_binding_token[GA_BINDING_TOKEN_STR_LEN];
#endif
};

#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
struct notify_info
{
	int notify_cc; /* local or foreign station */
	char method[UAM_PORTAL_METHOD_LEN]; /* none, click-through, sign-on, email-verification-dppsk, google-authenticator-1x */
	char locale[UAM_PORTAL_LOCALE_STR_LEN];
	char gender[UAM_PORTAL_GENDER_STR_LEN];
	char age[UAM_PORTAL_AGE_STR_LEN];
	char ssid_name[UAM_PORTAL_SSID_LEN]; 
	char ssid_profile_name[UAM_PROFILE_NAME_LEN_64];
 	char ssid_vap_iface[UAM_PORTAL_VAP_IF_LEN];
	char sta_mac[UAM_PORTAL_MAC_STR_LEN];
	int usr_from; /* local user or foreign user*/
};
#endif

/* x, y are uam_event, need to be synced with userdb_handle_logout()! */
#define UAM_EVENT_LOGOUT_MATCHED(x, y)	\
		((x.ip == y.ip) && \
		 strcmp(x.unique, y.unique) == 0 && \
		 strcmp(x.service, y.service) == 0 && \
		 strcmp(x.username, y.username) == 0)

#define UAM_HANDLE_FLAG_USING_QUERY2		(1 << 0)
#define UAM_HANDLE_FLAG_QUERY_FIRST			(1 << 1)
#define UAM_HANDLE_FLAG_IPV6_ADDR			(1 << 2)

struct uam_request
{
#define UAM_QUERY_NAME		1
#define UAM_QUERY_FROM		2
#define UAM_QUERY_FROM_FIRST	3

#define UAM_QUERY_ALL		4
#define UAM_LISTEN		5
#define UAM_QUERY_TOTAL_USER_NUM           6
	int method;

	union {
		char username[UAM_USERNAME_LEN];
#ifdef ZLDCONFIG_IPV6
		struct in6_addr ip6;
#endif
		u_int32_t ip;
	} u;
	unsigned int req_flags;
};

struct uam_response
{
#define UAM_RESPONSE_SUCCESS	0
#define UAM_RESPONSE_FAIL		1
	int code;
};

struct user_info
{
	char service[UAM_SERVICE_LEN];
	char username[UAM_USERNAME_LEN];			/* login username */
	char virtual_username[UAM_USERNAME_LEN];	/* the username for ACL rules */
	char unique[UAM_UNIQUE_LEN + 1];
#ifdef ZLDCONFIG_USERGROUP_EXTERNAL_USER_ENHANCEMENT
	char user_type[USER_TYPE_LEN];
#endif
#ifdef ZLDCONFIG_IPV6
	struct in6_addr ip6;
	struct in6_addr dst_ip6;
	struct in6_addr tunnel_ip6;
#endif
	u_int32_t ip;
	u_int32_t dst_ip;
	u_int32_t tunnel_ip;	/* for SSLVPN and L2TP */

	/* seconds since boot */
	unsigned long login_time;
	unsigned long lease_time;
	unsigned long reauth_time;
	unsigned long idle_time;

#if defined(ZLDCONFIG_QRCODE_AUTHENTICATOR)
	char qrcode_authenticator[UAM_USERNAME_LEN];
#endif

#ifdef ZLDCONFIG_WEBAUTH
	/* seconds since 1970/1/1 00:00:00 UTC */
	unsigned long due_time;
#endif

	int idle_timeout_form_acct_flag;
	unsigned int idle_timeout;

	/* user profile field*/
	unsigned int lease_minute;
	unsigned int reauth_minute;
	unsigned int access;
	unsigned int visibility;

	unsigned char attribute;
	unsigned char type;
#if defined(ZLDCONFIG_NAC)
	int authentication_policy_idx;
	int authentication_policy_eps_chk;
#endif
	unsigned int usr_flags;

#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
	unsigned long session_timeout;
	char radius_profile_name[UAM_PROFILE_NAME_LEN];
	int accounting_status;
#endif
#ifdef AAA_WEB_PORTAL
	char method[UAM_PORTAL_METHOD_LEN]; /* none, click-through, sign-on, email-verification-dppsk, google-authenticator-1x */
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
	char locale[UAM_PORTAL_LOCALE_STR_LEN];
	char gender[UAM_PORTAL_GENDER_STR_LEN];
	char age[UAM_PORTAL_AGE_STR_LEN];
#endif
	char auth_time[UAM_PORTAL_AUTH_TIME_LEN];
	char ssid_name[UAM_PORTAL_SSID_LEN]; 
	char ssid_profile_name[UAM_PROFILE_NAME_LEN_64]; 
 	char ssid_vap_iface[UAM_PORTAL_VAP_IF_LEN]; 
	char sta_mac[UAM_PORTAL_MAC_STR_LEN];
	int usr_from;
	int ga_acct_status;
	char ga_binding_token[GA_BINDING_TOKEN_STR_LEN];
#endif
};

#ifdef UAM_SHM_DB

struct user_cache_info {
	int flags;
	struct user_info *uinfo;
};

/* user database */
struct user_list {
	struct list_head use_list;

	/* maintain the number of users that have the the same name or ip */
	int same_name_users;
	int same_ip_users;
#ifdef ZLDCONFIG_IPV6
	int same_ip6_users;
#endif
	/* list used for the same name or ip */
	struct list_head same_name_list;
	struct list_head same_ip_list;
#ifdef ZLDCONFIG_IPV6
	struct list_head same_ip6_list;
#endif
	/* list used to maintain timeout */
	struct list_head reauth_list;
	struct list_head lease_list;
	struct list_head idle_list;
#ifdef ZLDCONFIG_WEBAUTH
	struct list_head due_list;
#endif
	/* the user information storage */
	struct user_info *uinfo;
};

struct avl_node_pool_list {
	struct list_head pool_list;
	struct avl_node avl_node;
};

struct avl_table_pool_list {
	int used;
	struct avl_table avl_table;
};

#define USERDB_SHM_BASE_ADDR 0x70000000

/* user database in share memory structure */
struct user_shm_db{
	void	*userdb_shmaddr;
	struct user_info userdb_uinfo[UAM_MAX_USERS];
	struct user_list userdb_ulist[UAM_MAX_USERS];

	struct avl_table *avl_username_tree;
	struct avl_table *avl_ip_tree;

	struct list_head userdb_use_list;
	struct list_head userdb_unuse_list;

	/* used for AVL allocate */
	struct avl_table_pool_list avl_table_mem_pool[2]; /* only two avl tree in uam */
	struct avl_node_pool_list avl_node_mem_pool[UAM_MAX_USERS];
	/* avl node pool use/unuse list */
	struct list_head avl_node_use_list;
	struct list_head avl_node_unuse_list;
};
#endif /* ifdef UAM_SHM_DB */

typedef struct uam_user_info_s {
	char    service[UAM_SERVICE_LEN];
	char    username[UAM_USERNAME_LEN];
	char    virtual_username[UAM_USERNAME_LEN];
	char    unique[UAM_UNIQUE_LEN + 1];
	u_int32_t ip;
	u_int32_t dst_ip;
	unsigned char type;
	unsigned long login_time;
#ifdef ZLDCONFIG_IPV6
	struct  in6_addr ip6;
	int     flags;
#endif
	struct uam_user_info_s  *next;
} uam_user_info_t;

uam_user_info_t *uam_get_user_info(char *username, char *service, char *unique);

void uam_put_user_info(uam_user_info_t *userInfo);

struct uam_handle *uam_create_handle(u_int32_t flags);

int uam_set_mode(struct uam_handle *h, u_int8_t mode);

int uam_send_query(struct uam_handle *h, struct uam_request *request);

int uam_read_event(struct uam_handle *h, struct uam_event *event,
					int timeout);

int uam_read_data(struct uam_handle *h, struct uam_event *event,
					struct user_info *info);

int uam_destroy_handle(struct uam_handle *h);

void uam_perror(const char *s);

char *uam_errstr(void);

char *uam_strerror_v(char *errString, size_t errStringSize);

/* utilities */
#ifdef ZLDCONFIG_AAA_FREERADIUS_UAM
int __uam_notify(struct uam_event *event, struct uam_response *response);
#endif
int uam_find_ssl_vpn_user(void); /* Add for SSL VPN user */

#ifdef ZLDCONFIG_IPV6
int uam_find_first_match6(struct user_info *info, const char *service, char *username, struct in6_addr *ip6, char *unique);
int uam_find_first_match_by_ip6(struct user_info *info, struct in6_addr *ip6);
int uam_notify_login6(char *s, char *u, struct in6_addr *ip6, char *q);
int uam_notify_logout6(char *s, char *u, struct in6_addr *ip6, char *q);
int uam_notify_logout_revocable6(char *s, char *u, struct in6_addr *ip6, char *q);
int uam_notify_logout_revoke6(char *s, char *u, struct in6_addr *ip6, char *q);
int uam_notify_update_lease6(char *s, char *u, struct in6_addr *ip6, char *q, int l);
int uam_notify_update_idle6(struct in6_addr *ip6);
int uam_notify_update_reauth6(char *s, char *u, struct in6_addr *ip6, char *q, int r);
int uam_notify_bind_tunnel_ip6(char *s, char *u, struct in6_addr *ip6, char *q, struct in6_addr *tunnel_ip6);
int uam_notify_unbind_tunnel_ip6(char *s, char *u, struct in6_addr *ip6, char *q);
#ifdef ZLDCONFIG_WEBAUTH
int uam_notify_update_due6(char *s, char *u, struct in6_addr *ip6, char *q, int d);
#endif
#endif

int uam_find_first_match(struct user_info *info, const char *service, char *username, u_int32_t ip, char *unique);
#ifdef ZLDCONFIG_IPV6
int uam_find_first_match_double_service6(struct user_info *info, char *service1, char *service2, char *username, struct in6_addr *ip6, char *unique);
#endif
int uam_find_first_match_double_service(struct user_info *info, char *service1, char *service2, char *username, u_int32_t ip, char *unique);
int uam_find_first_match_unique(struct user_info *info, char *service, char *username, u_int32_t ip, char *unique);
int uam_find_first_match_by_ip(struct user_info *info, u_int32_t ip);
int uam_notify_login(char *s, char *u, u_int32_t ip, char *q);
int uam_notify_logout(char *s, char *u, u_int32_t ip, char *q);
int uam_notify_logout_revocable(char *s, char *u, u_int32_t ip, char *q);
int uam_notify_logout_revoke(char *s, char *u, u_int32_t ip, char *q);
int uam_notify_update_lease(char *s, char *u, u_int32_t ip, char *q, int l);
int uam_notify_update_idle(u_int32_t ip);
int uam_notify_update_reauth(char *s, char *u, u_int32_t ip, char *q, int r);
int uam_notify_bind_tunnel_ip(char *s, char *u, u_int32_t ip, char *q, u_int32_t tunnel_ip);
int uam_notify_unbind_tunnel_ip(char *s, char *u, u_int32_t ip, char *q);

#if defined(ZLDCONFIG_NAC)
int uam_notify_update_authentication_policy_idx(char *s, char *u, u_int32_t ip, char *q, int idx);
int uam_notify_update_authentication_policy_eps_chk(char *s, char *u, u_int32_t ip, char *q, int checked);
int uam_notify_update_ssl_vpn_user(char *s, char *u, u_int32_t ip, char *q);
#endif
#ifdef ZLDCONFIG_AAA_RADIUS_ACCT
int uam_notify_update_accounting_status(char *s, char *u, u_int32_t ip, char *q, int status);
int uam_notify_rename_radius_profile_name(char *new_name, char *old_name);
#endif

/* internal use */
extern int userdb_query_by_name(char *username, struct user_info *uinfo_array[]);
#ifdef ZLDCONFIG_IPV6
extern int userdb_query_by_ip6(struct in6_addr *ip6, struct user_info *uinfo_array[]);
#endif
extern int userdb_query_by_ip(u_int32_t ip, struct user_info *uinfo_array[]);
extern int userdb_query_all(struct user_info *uinfo_array[]);

extern pthread_mutex_t userdb_lock;
int uam_bind_unix_address(char *unaddr);

/* for address mapping */
#define ADDR_NAME_CONSOLE		0xffffffff

/* for service mapping */
#define SERVICE_NAME_CONSOLE		"console"
#define SERVICE_NAME_TELNET			"telnet"
#define SERVICE_NAME_SSH			"ssh"
#define SERVICE_NAME_HTTP_HTTPS		"http/https"
#define SERVICE_NAME_FTP			"ftp"
#define SERVICE_NAME_DIALIN			"dialin"
#define SERVICE_NAME_UNKNOWN		"unknown"
#define SERVICE_NAME_DOT1X		"802.1x"
#define SERVICE_NAME_XAUTH 		"xauth"
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
#define SERVICE_NAME_SOCIAL_LOGIN_FB    "social login fb"
#endif  
#ifdef ZLDCONFIG_FB_WIFI
#define SERVICE_NAME_FB_WIFI_LOGIN	"fb wi-fi login"
#endif
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
#define SERVICE_NAME_GOOGLE_AUTHENTICATOR	"google authenticator"
#define SERVICE_NAME_EMAIL_VERIFICATION		"email verification"
#endif
#define SERVICE_NAME_MAC_AUTH		"mac-auth"
#ifdef AAA_WEB_PORTAL
//#define CAPTIVE_PORTAL_NO_DASH_STR	"captive portal"
#define SERVICE_NAME_CAPTIVE_PORTAL	"captive portal"
#define CAPTIVE_PORTAL_DASH_STR	"captive-portal"
#endif
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
#define AUTH_METHOD_CAPTIVE_PORTAL_SOCIAL_LOGIN_FB             "sns-facebook"
#define AUTH_METHOD_CAPTIVE_PORTAL_SOCIAL_LOGIN_GOOGLE_PLUS    "sns-google-plus" 
#endif
#ifdef ZLDCONFIG_FB_WIFI
#define AUTH_METHOD_CAPTIVE_PORTAL_FB_WIFI_LOGIN		"fb-wifi-login"
#endif
/* for login privilege matrix */
#define SERVICE_TYPE_CONSOLE     0
#define SERVICE_TYPE_TELNET      1
#define SERVICE_TYPE_SSH         2
#define SERVICE_TYPE_HTTP_HTTPS  3
#define SERVICE_TYPE_FTP         4
#define SERVICE_TYPE_DIALIN      5
#define SERVICE_TYPE_UNKNOWN     6
#ifdef AAA_WEB_PORTAL
#define SERVICE_TYPE_CAPTIVE_PORTAL	7
#endif
#define SERVICE_TYPE_XAUTH       8

#define UAM_ADDRESS_NOTIFY			"/dev/user-notify"
#define UAM_ADDRESS_REQUEST			"/dev/user-request"
#define UAM_ADDRESS_REQUEST2			"/dev/user-request2"
#define UAM_ADDRESS_ALIVE			990

#define UAM_PID_FILE				"/var/run/uamd.pid"

#define UAM_MAX_SOCKET		128

struct uam_socket
{
	struct list_head list;

#define UAM_SOCKTYPE_NOTIFY		1
#define UAM_SOCKTYPE_REQUEST	2
	char type;
	int fd;
};

struct uam_deferred_logout
{
	struct list_head list;

	unsigned long event_time;
	struct uam_event event;
};

#ifdef AAA_WEB_PORTAL
struct uam_notify_parameters
{
	char service[UAM_SERVICE_LEN];
	char username[UAM_USERNAME_LEN];
	char unique[UAM_UNIQUE_LEN + 1];
	char sta_mac[UAM_PORTAL_MAC_STR_LEN];
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
	char locale[UAM_PORTAL_LOCALE_STR_LEN];
	char gender[UAM_PORTAL_GENDER_STR_LEN];
	char age[UAM_PORTAL_AGE_STR_LEN];
#endif
	char auth_time[UAM_PORTAL_AUTH_TIME_LEN];
	char method[UAM_PORTAL_METHOD_LEN];
	char ssid_name[UAM_PORTAL_SSID_LEN];
	char ssid_profile_name[UAM_PROFILE_NAME_LEN_64];
	u_int32_t ip;
	int notify_cc; /* local or foreign station */
	int usr_from; /* local user or foreign user*/
	int event_type;
	union {
		unsigned int lease_time;
		unsigned int reauth_time; 
	} update;
	unsigned int event_flag;
};
#endif

/* support user locking */
#define USER_LOCK_IPC_KEY	0x11111111

#define DEFAULT_ATTEMPT_COUNT	5
#define DEFAULT_LOCKOUT_PERIOD	30
#define MAX_LOCKOUT_RECORD	1024
#define MAX_ATTEMPT_RECORD	1024

struct lockout_record {
	uint32_t ip;
#ifdef ZLDCONFIG_IPV6
	struct in6_addr ip6;
#endif
	unsigned long time;
	char username[UAM_USERNAME_LEN];
	char inuse;
};

struct attempt_record {
	uint32_t ip;
#ifdef ZLDCONFIG_IPV6
	struct in6_addr ip6;
#endif
	unsigned long time;
	unsigned short count;
	char inuse;
};

struct user_lock {
	char enable;
	char attempt_count;		/* per minute */
	unsigned int lockout_period;	/* in minute */
	struct lockout_record lockout_rec[MAX_LOCKOUT_RECORD];
	struct attempt_record attempt_rec[MAX_ATTEMPT_RECORD];
};

/* user login uniqueness enforcer */
#define USER_CONFIG_IPC_KEY	0x11111112
#define USER_DB_SHM_KEY	(USER_CONFIG_IPC_KEY+1)
#define USER_DB_SEM_KEY	(USER_CONFIG_IPC_KEY+2)

#define DEFAULT_MAX_ADMIN_LOGON_COUNT		1
#define DEFAULT_MAX_ACCESS_LOGON_COUNT		1

#define DEFAULT_MAX_IDLE_MINUTE				3
struct user_config {
	char enforce_admin_logon_count:1,
		 enforce_access_logon_count:1,
		 browser_close_with_logout:1;
	unsigned int max_admin_logon_count;
	unsigned int max_access_logon_count;	
	
	/* idle timeout detection for users and guests */
	char enable_idle_detection;
	unsigned int max_idle_minute;

	/* allow user update lease time automatically */
	char enable_auto_lease_update;
};

#ifdef AAA_WEB_PORTAL
#define CLOUD_EPOCH_LEN				16
/* for share memory with user profile */
typedef struct user_info_s {
	int messge_type;
	char username[UAM_USERNAME_LEN];
	char password[UAM_EXT_GROUP_LEN];
	char ssid_name[UAM_PORTAL_SSID_LEN];
	char ssid_profile_name[UAM_PROFILE_NAME_LEN_64];
	char account_type[ACCOUNT_TYPE_LENGTH];
	unsigned char MAC[MAC_ADDRESS_LENGTH];
	char message[CLOUD_AUTH_ERR_MSG_LEN];
	int authtype;
	/*for debugging*/
	char cc_address[FQDN_NAME_LEN];
	char user_expired[CLOUD_EPOCH_LEN];
	char user_epoch[CLOUD_EPOCH_LEN]; /* for cache */
	long httpStatusCode;
	char vlan_id[VLAN_ID_LEN];
	time_t assoc_time;
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
	char client_addr[GA_CLIENT_ADDR_STR_LEN];
	char verification_code[GA_VERIFICATION_STR_LEN];
	char sta_mac[UAM_PORTAL_MAC_STR_LEN];
	char ap_mac[UAM_PORTAL_MAC_STR_LEN];
#endif
	int ga_acct_status;
	char ga_binding_token[GA_BINDING_TOKEN_STR_LEN];
} user_info_t;

/* string len */
#define CLOUD_EPOCH_LEN				16
#define MAX_CLOUD_USERNAME_LEN			(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define MAX_CLOUD_PASSWORD_LEN			(ZLDSYSPARM_UAM_PASSWORD_LEN)
#define VLAN_ID_LEN				6
#define BITMAP_LEN				8

typedef struct user_s {
	int flag;
	char username[MAX_CLOUD_USERNAME_LEN];
	char password[MAX_CLOUD_PASSWORD_LEN];
	char user_expired[CLOUD_EPOCH_LEN];
	char user_epoch[CLOUD_EPOCH_LEN]; /* for cache */
	long httpStatusCode;
	char vlan_id[VLAN_ID_LEN];
	char bitmap[BITMAP_LEN];
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
	int ga_status;
#endif
	int ga_acct_status;
	char ga_binding_token[GA_BINDING_TOKEN_STR_LEN];
} user_t;
#endif

/* for pam uam failed code */
enum __pam_uam_errno {
	PAM_UAM_SUCCESS = 0,
	PAM_UAM_ERR_GET_AUTHINFO,
	PAM_UAM_ERR_ADDRESS_LOCKOUT,
	PAM_UAM_ERR_RETRIEVE_USER_PROFILE,
	PAM_UAM_ERR_VERIFY_USER,
	PAM_UAM_ERR_VALIDATE_USER,
	PAM_UAM_ERR_NOTIFY_LOGIN,
	PAM_UAM_ERR_MAX,
};

#ifdef AAA_WEB_PORTAL
enum ga_acct_status_code{
	GA_ACCOUNT_DISABLE = 0,
	GA_ACCOUNT_BINDING,
	GA_ACCOUNT_UNBINDING,
	GA_ACCOUNT_WHITELIST
};
#endif
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
/* for google authenticator auth failed code */
enum ga_error{
	GA_INVALID_VERIFICATION_CODE = 0,
	GA_STOPPED_BY_ACCT_BLOCKED,
	GA_BINDING_FAIL,
	GA_ACCEPTED
};
#endif

#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

/* remove this before release */
#undef UAM_TESTING

#endif


#ifdef ZLDCONFIG_IPV6
int uam_notify_web_logout6(char *s, char *u, struct in6_addr *ip6, char *q);
#endif

#ifdef AAA_WEB_PORTAL
int uam_notify_update_roaming_sta_ip(char *s, char *u, u_int32_t ip, char *mac, char *ssid_profile_name, char *q);

int uam_notify_web_auth_foreign_logout(char *s, char *u, char *mac, char *s_n, char *s_p, int n_c, char *q, int l, int type, int usr_from,  int lease, int reauth, int flags );

int uam_notify_web_auth_foreign_login(char *s, char *u, char *mac, char *s_n, char *s_p,int n_c, char *q,int l, int type, int usr_from, int lease, int reauth, int flags );

int uam_notify_common(int notify_event_number, struct uam_notify_parameters *UNparas);

int uam_find_first_match_web_auth_service(struct user_info *info, char *service, char *username, char *sta_mac, char *ssidprofile, char *unique);

int uam_find_total_user_number(void);

#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
int uam_find_first_match_unique(struct user_info *info, char *service, char *username, u_int32_t ip, char *unique);
#endif
#endif

int userdb_query_total_user_num(void);

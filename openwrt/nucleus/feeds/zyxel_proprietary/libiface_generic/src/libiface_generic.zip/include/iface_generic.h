#ifndef _IFACE_GENERIC_H
#define _IFACE_GENERIC_H
#include <stdint.h>
#include <stddef.h>

#include "zld/k_ifacename_change.h"
#include "zld/k_ifacename_list.h"
#include "switchdev-abi.h"

#ifndef VAR_ZYSH
#define VAR_ZYSH "/var/zyxel/zysh"
#endif

#define FILENAMESIZE 128
#define STRZISE 256
#define ADDR_LEN 16

#define PPP_STRING INTERNAL_PPP_IFACENAME
#define BR_STRING INTERNAL_BRD_IFACENAME

#define ETH_STRING INTERNAL_ETH_IFACENAME
#define ETH_BASE_STRING "eth_base"
#define VIR_STRING INTERNAL_VIR_IFACENAME
#define VLAN_STRING INTERNAL_VLAN_IFACENAME
#define AP_STRING INTERNAL_AP_IFACENAME

#define ETH_CHAR strlen(ETH_STRING) //"eth"
#define VLAN_CHAR strlen(VLAN_STRING) //"vlan"
#define BR_CHAR strlen(BR_STRING) //"br"
#define PPP_CHAR strlen(PPP_STRING) //"ppp"
#define AP_CHAR strlen(AP_STRING) //"wlan-
#define PPPOE_TYPE "pppoe"
#define PPTP_TYPE "pptp"
#define IFACE_GENERIC_DEBUG 0 /*debug flag*/

#define IFACE_ETH_TYPE_PREFIX "eth"
#define IFACE_GE_TYPE_PREFIX "ge"
#define IFACE_PPP_TYPE_PREFIX "ppp"
#define IFACE_VLAN_TYPE_PREFIX "vlan"
#define IFACE_LAN_TYPE_PREFIX "lan"
#define IFACE_WLAN_TYPE_PREFIX "wlan-"
#define IFACE_BRIDGE_TYPE_PREFIX "br"
#define IFACE_TUNNEL_TYPE_PREFIX "tunnel"

#define IFACE_SHM_GET_FAIL (-1)
#define IFACE_VLAN_NAME_MAX_NUM		4094 /* Maximum VLAN name number (e.g. vlan0 to vlanN) */

enum {
	NON_HIDDEN,
	HIDDEN
};

enum {
	UNKNOWN_IFACE,
	ETH_IFACE,
	VLAN_IFACE,
	BRD_IFACE,
	VIR_IFACE,
	VIR_VLAN_IFACE,
	VIR_ETH_IFACE,
	VIR_BRD_IFACE,
	PPP_IFACE,
	AP_IFACE,
	STA_IFACE,
	DHA_MGMT_IFACE
};

int interface_name_update_iface_property(char *internal_name, uint32_t property);
int interface_get_info_by_internal_iface(char *internal_iface, struct _interface_info *iface_info);
int interface_get_info_by_ud_iface(char *user_define_name, struct _interface_info *iface_info, char *internal_iface, int iface_len);
int interface_name_update_list(char *internal_name,char *user_define_name, uint32_t type);
int interface_name_check_udiface_duplicate(char *internal_name, char *user_define_name);
uint32_t interface_get_system_ppp_info(char *ud_iface_name);
int check_interface_name_configured(char *iface_name);
void interface_debug_show_interface_shm(void);
int interface_get_property_by_internal_iface(char *internal_iface, struct _if_property_info *info);

int eth_to_user_define (char *iface, char *ud_iface);
int user_define_to_eth (char *ud_iface, char *iface);
int user_define_to_eth_and_get_type (char *ud_iface, char *iface, size_t iface_len, struct _interface_info *iface_info);
int interface_name_check_udiface_in_list(char *user_define_name, struct _interface_info *iface_info, char *internal_iface);
int query_interface_link_status(char *iface);
int check_ppp_connected(char *ppp_dev);
int find_bridge_with_base_interface(char *iface, char *brx, int *change);
int identify_vir_interface_type(char *iface);
int identify_interface_hidden(char *iface);
int identify_interface_type(char *iface);
int real_exist_interface(char *buf);//find is 1, no find is 0
int reset_ifacename_list(void);
enum {
	IFACE_PORT_LINK_DOWN,
	IFACE_PORT_LINK_UP,
	INTERFACE_DOWN_OR_NOT_EXIST,
	IFACE_AP_IFACE_DOWN,
	IFACE_AP_IFACE_UP
};


#ifndef ZLD_DBG_CONSOLE
#define ZLD_DBG_CONSOLE(args...)	\
{ \
	FILE *console_fp; \
	console_fp = fopen("/dev/console", "w"); \
	if (console_fp) {\
		fprintf(console_fp, ##args); \
		fclose(console_fp); \
	} \
}
#endif

/* libiface_generic2 */
int find_cpu_port_idx(int sw_type, int sw_idx);
char *get_uplinkport (void);
int get_switch_type_by_port ( int port );
char *get_portname_by_front_idx(int front_idx);
int get_port_idx_by_name ( char *name );
char *get_eth_base_by_name ( char *name );
int get_front_idx_by_port ( int port );
int get_port_table(zld_port_cfg_t *cfg_tbl_p);
int get_port_ext_table(zld_port_cfg_t *cfg_tbl_p);
zld_port_cfg_t *get_port_table_ptr ( void );
zld_port_cfg_t *get_port_ext_table_ptr ( void );
int get_switch_summary(zld_sw_summary_t *summary);
int is_port_belongto_uplink (char *name);
int is_switch_exist (void);
short get_iface_status(char *iface);
int get_sw_idx_by_port (int port);

#define ZYERR_SWITCH_IS_NOT_FOUND1 (-100)

#define OPEN_SWITCH_DEV(fd,sw_num)						\
	do{													\
		char dev_path[20];								\
		sprintf(dev_path,"/dev/switch%d",sw_num);		\
		fd	= open(dev_path,O_RDWR);					\
		if ( fd < 0 )									\
		{												\
			return ZYERR_SWITCH_IS_NOT_FOUND1;			\
		}												\
	}while(0);

#define CLOSE_SWITCH_DEV(fd) 	\
	do{							\
		close(fd);				\
	}while(0);


#endif

#ifndef _IFNAME_SHARE_MEM_H_
#define _IFNAME_SHARE_MEM_H_

#define IFACELIB_PATH  	"/usr/lib/libiface_generic.so"
#define IF_NAME_SHM_KEY_CHAR		'N' 
#define IF_NAME_SEM_KEY_CHAR		'n'
#define IF_PROPERTY_SHM_KEY_CHAR	'R'
#define IF_PROPERTY_SEM_KEY_CHAR	'r'
/* config.c BEGIN */
extern size_t count_if_property_num;
extern size_t count_if_name_num;
/* config.c END */

#define IF_PROPERTY_NUM			count_if_property_num
#define IF_PROPERTY_SHM_SIZE	(sizeof(struct _share_header)+(IF_PROPERTY_NUM*sizeof(struct interface_property_map)))

/* cellular and aux still need name mapping.  */
#define IF_NAME_NUM				count_if_name_num
#define IF_NAME_SHM_SIZE		(sizeof(struct _share_header)+(IF_NAME_NUM*sizeof(struct interface_map)))

union semun {
	int val;
	struct semid_ds *buf;
	ushort * array;
};

struct _iface_shm_info {
	char 	*begin;
	int     shmid, semid;
};

struct _share_header {
	size_t count;
};

int init_ifacename_mapping(struct _iface_shm_info *ifname, struct _iface_shm_info *ifproperty);
void iface_semaphore_p(int sem);
void iface_semaphore_v(int sem);
void IFACE_DPRINT(char *format);

#endif

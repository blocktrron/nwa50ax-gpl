#ifndef NC_WD_H_
#define NC_WD_H_
#include <zld-spec.h>

#define APPLY_SYS_DEFAULT		112
#define WATCH_NC 				113
#define APPLY_CLOUD_DEFAULT_IFACE	114
#define CLOUD_CERT_EXPIRED	116

#define BACKUP_CONFIG 	"/tmp/if-test.backup"
#define READY_TO_BACKUP	"/tmp/if-test.backup.ready"

#define STARTUP_CONFIG "/etc/zyxel/ftp/conf/startup-config.conf"
#define LASTGOOD_CONFIG "/etc/zyxel/ftp/conf/lastgood.conf"
#ifdef ZLDCONFIG_MD5_SUPPORT
#define LASTGOOD_CONFIG_MD5 "/etc/zyxel/ftp/conf/lastgood.conf.md5"
#endif

#define RESET_CONFIG_RMSITE		"remove-site"
#define RESET_CONFIG_UNREGISTER	"unregister"
#define RESET_CONFIG_REGISTER		"register"

#endif

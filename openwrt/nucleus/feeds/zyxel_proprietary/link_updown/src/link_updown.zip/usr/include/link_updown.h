#define MAX_PORTS ZLDSYSPARM_PHY_PORT_MAX_NUM

#include <zld/klink_updown.h>

/* the port grouping is represented in binary format */

#define NOTIFY_SYSTEM	"/usr/sbin/notify_system"
//----------by saxon-------------
#define ZYSH_BIN	"/bin/zysh"
//-------------------------------

#define LINK_UPDOWN_FTOK_PATH "/usr/sbin/link_updown" /* bala */

//----------by harry--------------
enum Trap_Type {
    TRAP_LINK_UP = 0,
    TRAP_LINK_DOWN
};
//-------------------------------

typedef struct {
	unsigned char member_bitmap[BITMAP_COUNT];
	unsigned char link_status[BITMAP_COUNT];
} port_group_t;

#define LINK_UPDOWN_SOCKET	"/tmp/link-updown-socket"

#ifndef __KERNEL__
/* used for user-space only */

#define LINK_IS_DOWN	0
#define LINK_IS_UP	1

#endif

/* specifically define for wlan */
#define WLAN_FLAG_FILE		"/tmp/wlan_flag"

#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
#define MAX_SLOT ZLDSYSPARM_WLAN_MAX_SLOT
#if defined(ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER)
#define DOT11_STR_WDS_IFACE_PREFIX	"wlds-"
#define DOT11_STR_PAP_IFACE_PREFIX	"wlpap-"
#else
#define DOT11_STR_WDS_IFACE_PREFIX	"wds-"
#endif
#define WDS_STA_INF_INDEX 10
#endif

#if defined(ZLDCONFIG_ZYMESH_SUPPORT) || defined(ZLDCONFIG_SMART_MESH_SUPPORT)
#define DOT11_STR_PSTA_IFACE_PREFIX	"psta-"
#define PSTA_INF_INDEX 12
#endif


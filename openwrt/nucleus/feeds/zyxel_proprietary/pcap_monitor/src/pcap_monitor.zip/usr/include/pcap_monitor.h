#include <errno.h>
#include <stdint.h>
#define PCAP_MAX_IFACE_NUMBER 10
#define PCAP_MAX_ARG_LEN 64	
#define PCAP_MAX_PID_LEN	8
#define PCAP_KBYTE	1024
#define PCAP_MBYTE	(1024*1024)
#define PCAP_DEFAULT_FILE_SIZE 10
#define PCAP_MAX_DIR_SIZE	ZLDSYSPARM_PACKET_CAPTURE_MAX_DIR_SIZE
#define PCAP_MBYTE	(1024*1024)
#define PCAP_TCPDUMP_MB	1000000
#define PCAP_DEFAULT_SPLIT_SIZE 2000
#define PCAP_DEFAULT_RING_BUFFER 0
#define PCAP_DEFAULT_STORAGE 0
#define PCAP_DEFAULT_SNAPLEN 1500
#define PCAP_MAX_OPERATION_STORE_SIZE 3 
#define PCAP_IGNORE_FILE_NAME_LEN 2
#define PCAP_TCP_STR "tcp"
#define PCAP_UDP_STR "udp"
#define PCAP_ANY_STR "any"
#define PCAP_EXT_TYPE_STR "ext-type"
#define PCAP_HOST_STR "HOST"
#define PCAP_DATA_STR "data"
#define PCAP_DEFAULT_FILE_SUFFIX "-packet-capture"

#define PCAP_TCPDUMP_BIN  "/usr/sbin/tcpdump -n -i"
#define PCAP_RM_BIN "/bin/rm -f"
#define PCAP_MV_BIN "/bin/mv"
#define PCAP_MKDIR_BIN "/bin/mkdir -p"
#define PCAP_PCAP_MONITOR_PID_FILE_PATH "/tmp/pcap_monitor.pid"
#define PCAP_TCPDUMP_CMD_FILE	"/tmp/tcpdump_cmds"
#define PCAP_TCPDUMP_CRITERIA_ARG_FILE "/tmp/tcpdump_args"
#define PCAP_TCPDUMP_PID_FILE_PATH "/tmp/tcpdump_pids"
#define PCAP_PACKET_TRACE_FILE_PATH	"/etc/zyxel/ftp/packet_trace"
#define PCAP_PACKET_TRACE_FILE_PATH_TMP	"/tmp/etc/zyxel/ftp/packet_trace"
#define PCAP_PCAP_MONITOR_DEBUG_FILE "/tmp/pcap_monitor_debug"
#define PCAP_END_OF_LINE "\n"
#define PCAP_END_OF_CHAR '\0'

#define PCAP_MAX_DEBUG_FILE_SIZE 1000000
#define PCAP_PCAP_MONITOR_SLEEP_TIME	19000
#define SIG_PCAP_DEBUG_ON 59
#define SIG_PCAP_DEBUG_OFF 60
#define PCAP_MAX_PCAP_MONITOR_ARG_NUM 2
#define PCAP_MAX_BUF_LEN 256 

#undef PCAP_TURN_ON_DEBUG
//#define PCAP_TURN_ON_DEBUG 1
#define PACKET_CAPTURE_DEBUG_FLAG 1
#ifdef PACKET_CAPTURE_DEBUG_FLAG
	#define PKT_CAP_DEBUG(fmt, args...)	zylog(ZYLOG_SRC_SYSTEM, ZYLOG_PRI_DEBUG, ZYLOG_FAC_SYSTEM, 0,0,0,0, "", fmt, ##args)
#else
	#define PKT_CAP_DEBUG(args...)
#endif

#ifdef ZLDCONFIG_WIRELESS_CAPTURE_SUPPORT
#define PCAP_WIRELESS_CAPTURE_FLAG			"/tmp/wrieless_packet_capture_flag"
/* Use wireless_24G to capture 24G wireless packet on CLI. */
#define PCAP_WIRELESS_CAPTURE_INTERFACE_1	"wireless_24G"
/* Use wireless_5G to capture 5G wireless packet on CLI. */
#define PCAP_WIRELESS_CAPTURE_INTERFACE_2	"wireless_5G"
#endif

#define PKT_CAP_LOG_ALERT(fmt, args...) zylog(ZYLOG_SRC_SYSTEM, ZYLOG_PRI_ALERT, ZYLOG_FAC_SYSTEM, 0,0,0,0, "", fmt, ##args)
/*=====================================*/

#define PCAP_DEBUG(format, args...) do { \
			if ( pcap_debug_flag == PCAP_DEBUG_ON){ \
				fprintf(pcap_debug_fp, "%s-%s-%d:", __FILE__, __func__, __LINE__); \
				fprintf(pcap_debug_fp, format, ##args); \
				fflush(pcap_debug_fp); \
			} \
		}while(0)

enum pcap_enum_work_status{
	PCAP_NO_WORK,
	PCAP_NEED_WORK,
	PCAP_MAX
};

enum pcap_enum_debug_status{
	PCAP_DEBUG_ON,
	PCAP_DEBUG_OFF,
	PCAP_DEBUG_MAX
};


#ifdef ZLDCONFIG_WIRELESS_CAPTURE_SUPPORT
/* Turn on monitor mode */
static inline int32_t
__exec_monitor_mode_on(int radio)
{
	int32_t ret = 0;
	char cmd[PCAP_MAX_BUF_LEN] = "";

	if(radio == 1) {
#ifdef ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER
		system("/usr/sbin/wl -i wlan-1-1 monitor 3");
		system("/usr/sbin/wl -i wlan-1-1 cap_probe 1");
		system("/usr/sbin/wl -i wlan-1-1 cap_beacon 1");
		sprintf(cmd, "/sbin/ifconfig %s up", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
#endif

#ifdef ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER
#if (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
		sprintf(cmd, "/usr/bin/iw phy phy1 interface add %s type monitor", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
		sprintf(cmd, "/usr/bin/iwconfig %s essid zyxel24g-mon", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
		sprintf(cmd, "/usr/bin/ifconfig %s up", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
#endif
#endif
	} else if(radio == 2) {
#ifdef ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER
		system("/usr/sbin/wl -i wlan-2-1 monitor 3");
		system("/usr/sbin/wl -i wlan-2-1 cap_probe 1");
		system("/usr/sbin/wl -i wlan-2-1 cap_beacon 1");
		sprintf(cmd, "/sbin/ifconfig %s up", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
#endif

#ifdef ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER
#if (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
		sprintf(cmd, "/usr/bin/iw phy phy0 interface add %s type monitor", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
		sprintf(cmd, "/usr/bin/iwconfig %s essid zyxel5g-mon", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
		sprintf(cmd, "/usr/bin/ifconfig %s up", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
#endif
#endif
	}

out:
	return ret;
}

/* Turn off monitor mode */
static inline int32_t
__exec_monitor_mode_off(int radio)
{
	int32_t ret = 0;
	char cmd[PCAP_MAX_BUF_LEN] = "";

	if(radio == 1) {
#ifdef ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER
		/* Turn off radio1 monitor mode */
		system("/usr/sbin/wl -i wlan-1-1 monitor 0 > /dev/null 2>&1");
		system("/usr/sbin/wl -i wlan-1-1 cap_probe 0 > /dev/null 2>&1");
		system("/usr/sbin/wl -i wlan-1-1 cap_beacon 0 > /dev/null 2>&1");
		sprintf(cmd, "/sbin/ifconfig %s down > /dev/null 2>&1", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
#endif

#ifdef ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER
#if (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
		/* Turn off radio1 monitor mode */
		sprintf(cmd, "/usr/bin/ifconfig %s down > /dev/null 2>&1", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
		sprintf(cmd, "/usr/bin/iw dev %s del > /dev/null 2>&1", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_1);
		ret = system(cmd);
#endif
#endif
	} else {
#ifdef ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER
		/* Turn off radio2 monitor mode */
		system("/usr/sbin/wl -i wlan-2-1 monitor 0 > /dev/null 2>&1");
		system("/usr/sbin/wl -i wlan-2-1 cap_probe 0 > /dev/null 2>&1");
		system("/usr/sbin/wl -i wlan-2-1 cap_beacon 0 > /dev/null 2>&1");
		sprintf(cmd, "/sbin/ifconfig %s down > /dev/null 2>&1", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
#endif

#ifdef ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER
#if (ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
		/* Turn off radio2 monitor mode */
		sprintf(cmd, "/usr/bin/ifconfig %s down > /dev/null 2>&1", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
		sprintf(cmd, "/usr/bin/iw dev %s del > /dev/null 2>&1", ZLDSYSPARM_WIRELESS_CAPTURE_INTERFACE_2);
		ret = system(cmd);
#endif
#endif
	}

out:
	return ret;
}
#endif
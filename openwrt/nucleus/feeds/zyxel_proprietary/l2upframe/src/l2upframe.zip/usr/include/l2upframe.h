#include <linux/version.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0))
#define NF_HOOK_FN(FN_NAME, HOOKNUM, OPS, SKB, UNUSED, OUT, OKFN) \
static unsigned int FN_NAME(void *priv, \
                            struct sk_buff *SKB, \
                            const struct nf_hook_state *state)
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 13, 0))
#define NF_HOOK_FN(FN_NAME, HOOKNUM, OPS, SKB, UNUSED, OUT, OKFN) \
static unsigned int FN_NAME(const struct nf_hook_ops *OPS, \
                            struct sk_buff *SKB, \
                            const struct net_device *UNUSED, \
                            const struct net_device *OUT, \
                            int (*OKFN)(struct sk_buff *))
#else
#define NF_HOOK_FN(FN_NAME, HOOKNUM, OPS, SKB, UNUSED, OUT, OKFN) \
static unsigned int FN_NAME(unsigned int HOOKNUM, \
                            struct sk_buff *SKB, \
                            const struct net_device *UNUSED, \
                            const struct net_device *OUT, \
                            int (*OKFN)(struct sk_buff *))
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0))
#define NF_HOOK_FN_ASSIGN(fn, p, h, i) \
        {                                               \
                .hook = fn,                             \
                .pf = p,                        \
                .hooknum = h,   \
                .priority = i,  \
        }
#else
#define NF_HOOK_FN_ASSIGN(fn, p, h, i) \
        {                                               \
                .hook = fn,                             \
                .owner = THIS_MODULE,                   \
                .pf = p,                        \
                .hooknum = h,   \
                .priority = i,  \
        }
#endif


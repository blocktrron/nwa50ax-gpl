#ifndef _USER_PROFILE_H_
#define _USER_PROFILE_H_

#include <stdint.h>

#include "zld-spec.h"
#ifndef ZLDSYSPARM_UAM_USER_ROLES_PER_EXT_GROUP_USER
#define ZLDSYSPARM_UAM_USER_ROLES_PER_EXT_GROUP_USER 32
#endif
#ifdef AAA_WEB_PORTAL
#define IN_USER_NAME_LEN 	(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define IN_USER_PASSWORD_LEN 	(ZLDSYSPARM_UAM_PASSWORD_LEN)
#else
#define IN_USER_NAME_LEN	32
#define IN_USER_PASSWORD_LEN 	128
#endif
#define TYPE_LEN	12
#define DESC_LEN 1024
#define MAX_USER_NUM	1024
#define UAM_GROUP_IDENTIFIER_LEN		512*(ZLDSYSPARM_UAM_USER_ROLES_PER_EXT_GROUP_USER)

#ifdef AAA_WEB_PORTAL
#define USER_PROFILE_NAME_LEN	64
#define STR_BUF_LEN	512
#endif

#define EXT_GROUP_INFO_FILE                     "/tmp/ext_group_info.conf"

#define SHMKEY_PAM_PATH	"/lib/security/pam_auth_admin.so"
#define SEM_PATH	"/lib/security/pam_unix.so"
#define PERMS_PAM 0666

#define GROUP_BACKUP_FILE	"/tmp/template_group.xml"
#define USER_BAKCUP_FILE	"/tmp/template_user.xml"

/* If you want to add new user type, please update the table and user_profile.c( sync with def_user_profile[]) */
enum user_type_enum {
	ADMIN_TYPE	=0,
	USER_TYPE,
	GUEST_TYPE,
	EXT_TYPE,
	LIMIT_TYPE,
	EXT_GROUP_TYPE,
#ifdef ZLDCONFIG_DYNAMIC_GUEST_ACCOUNT
	GUEST_MANAGER_TYPE,
	DYNAMIC_GUEST_TYPE,
#endif
#ifdef ZLDCONFIG_AAA_MAC_AUTH_MAC_ROLE
	MAC_ADDRESS_TYPE,
#endif
#ifdef ZLDCONFIG_USERGROUP_EXTERNAL_USER_ENHANCEMENT
	DEFAULT_EXT_TYPE,
#endif
	MAX_USER_TYPE
};

/* xml entity name for count */
#define ADMIN_NUM_COUNT "admin_users"
#define USER_NUM_COUNT "local_users"
#define EXT_USER_NUM_COUNT "ext_local_users"
#define MAC_USER_NUM_COUNT	"mac_users"

#define NONE_TYPE	-1

#define LDAP_TIMEOUT	5
#ifdef ZLDSYSPARM_MAX_AUTH_ENTRY
	#define MAX_AUTH_ENTRY	ZLDSYSPARM_MAX_AUTH_ENTRY
	#define MAX_USER_ENTRY	ZLDSYSPARM_MAX_AUTH_ENTRY
#else
#define MAX_AUTH_ENTRY	50
#define MAX_USER_ENTRY 50
#endif

#define LOCAL_AUTH	1
#define RADIUS_AUTH	2
#define LDAP_AUTH	3
#define AD_AUTH		4

#define ADMIN_PRIV	120
#define LIMIT_PRIV	100
#define USER_PRIV	80
#define	EXT_PRIV	80
#define GUEST_PRIV	50

#define IN_USER_DEFAULT_ADMIN	1
#define IN_USER_DEFAULT_ACCESS	1
#define IN_USER_DEFAULT_NO_ADMIN	0
#define IN_USER_DEFAULT_NO_ACCESS	0

/* support external database users */
#define DEFAULT_LDAP_USERS      "ldap-users"
#define DEFAULT_RADIUS_USERS    "radius-users"
#define DEFAULT_AD_USERS    	"ad-users"
#define DEFAULT_MAC_ADDRESS_USERS	"mac-users"

#ifdef ZLDCONFIG_WEBAUTH
#define DUE_TIME_LEN	8
#define DUE_TIME_MAGIC_CHAR 'D'
#endif

/* cgi flow controller */
#define APACHE_PAHT	"/usr/local/apache/bin/httpd"

#ifdef ZLDSYSPARM_MAX_AUTH_ENTRY
	#define MAX_SIMULTANEOUS_LOGIN	ZLDSYSPARM_MAX_AUTH_ENTRY
#else
	#define MAX_SIMULTANEOUS_LOGIN	100
#endif

typedef struct cfc_shared_mem_s {
	int simultaneous_login;
} cfc_shared_mem_t;

/*
 * default setting add by alexlee
 * below SETTING_* defind just for XML which used by user default setting
 */
#define SETTING_LIST				"global_setting_list"
#define SETTING_TYPE				"in_user_setting"
#define SETTING_NAME_ADMIN			"def_set_admin"
#define SETTING_NAME_USER			"def_set_user"
#define SETTING_NAME_GUEST			"def_set_guest"
#define SETTING_NAME_LADMIN			"def_set_ladmin" /* limited admin */
#define SETTING_NAME_EXTU			"def_set_ext_user"
#define SETTING_NAME_EXTGU			"def_set_ext_group_user"
#define SETTING_NAME_GMANAGER		"def_set_guest_manager"
#define SETTING_NAME_DYGUEST		"def_set_dynamic_guest"
#define SETTING_NAME_MAC_ADDRESS	"def_set_mac_address"

#define IN_USER_DEFAULT_LEASE_BASE	1440
#define IN_USER_DEFAULT_REAUTH_BASE	1440
#define IN_USER_DEFAULT_DUE_BASE	1440

#define HAVE_PASSWORD	1
#define NO_HAVE_PASSWORD	0

struct default_user_profile {
	char *type_name;
	char *type_name_for_log;
	char *xml_entity_name;
	int access;
	int visibility;
	int remote_admin;
	int remote_access;
	int def_lease;
	int def_reauth;
	unsigned long def_due;
	char *xml_num_count;
	int max_num;
	int password;
};

#define MAX_LOCAL_USER		ZLDSYSPARM_LOCAL_USER_MAX_NUM
#define MAX_ADMIN_USER		ZLDSYSPARM_ADMIN_USER_MAX_NUM
#ifndef ZLDSYSPARM_EXT_USER_MAX_NUM
#define MAX_EXT_USER		ZLDSYSPARM_LOCAL_USER_MAX_NUM
#else
#define MAX_EXT_USER		ZLDSYSPARM_EXT_USER_MAX_NUM
#endif
#define MAX_MAC_USER		ZLDSYSPARM_MAC_ADDRESS_MAX_NUM


typedef struct user_profile_s {
	char username[IN_USER_NAME_LEN];
	char virtual_username[IN_USER_NAME_LEN];
	int type;
	int access;
	int visibility;
	int lease_time;
	int reauth_time;
#ifdef ZLDCONFIG_WEBAUTH
	unsigned long due_time;
#endif
	int remote_admin;
	int remote_access;
	int refCnt;
	unsigned char flag;
} user_profile_t;

#ifdef AAA_WEB_PORTAL
typedef struct portal_profile_s {
	char profilename[STR_BUF_LEN];
	char method[STR_BUF_LEN]; /* open, click-through or sign-on*/
	char auth_type[STR_BUF_LEN]; /*ZyXEL cloud authentication, My-Radiuse*/
	char portal_type[STR_BUF_LEN]; /* internal or external*/
	uint32_t lease_time;
	//bool update_info;
	//uint16_t defSet; /* default or manual, 1: default, 0: manual */
	uint32_t reauth_time;
	//uint32_t manual_lease;
	//uint32_t manual_reauth;
} portal_profile_t;
#endif

typedef struct user_role_s {
	char *username;
	char *user_role;
	char define_name[IN_USER_NAME_LEN];
	int type;
	int lease_time;
	int reauth_time;
#ifdef ZLDCONFIG_WEBAUTH
	char due_time[DUE_TIME_LEN];
#endif
	unsigned char flag;
#ifdef AAA_8021X_CLOUD_AUTHENTICATION
	int user_expired;
	int http_code;
#endif
} user_role_t;

enum {
	FLAG_RETRIEVE_LDAP	= 1<<0,
	FLAG_IGNORE_CASE	= 1<<1,
	FLAG_EXT_REAUTH_TIME	= 1<<2,
	FLAG_EXT_LEASE_TIME	= 1<<3,
};

#define FLAG_EXT_CTL_TIMEOUT	(FLAG_EXT_REAUTH_TIME | FLAG_EXT_LEASE_TIME)

#define SETUP_MATCH_FLAG(f, a) 	(*f) = (a&PAM_AUTH_IGNORE_CASE)?(FLAG_RETRIEVE_LDAP|FLAG_IGNORE_CASE):(FLAG_RETRIEVE_LDAP)


struct zyuser_match_info
{
	char type;
	unsigned char flag;
};

enum auth_module_enum {
	AUTH_MODULE_LOCAL = 1,
	AUTH_MODULE_RADIUS,
	AUTH_MODULE_LDAP,
	AUTH_MODULE_AD,
	MAX_AUTH_MODULE
};

/* export function */
int check_username_local(char *username, int type);
int match_default_external_user(char *username, int auth_module);
int get_type_from_local(char *username);
int get_info_from_local(user_profile_t *user_p, const char *username, int type);
int get_external_group_user(user_role_t *user_p, char *group_identifier, int auth_module_idx);
int check_admin_related_type(int type);
int get_user_privilege_by_type(user_profile_t *user_privilege, char *type);
int get_user_privilege_by_type_id(user_profile_t *user_privilege, int type);
int user_have_password(char *type);
int get_xml_name_for_count(char *token, int *count, char *xml_name);
int get_xml_name_for_count_by_id(int type, int *count, char *xml_num_count);
int get_xml_entity_name(char *type, char *xml_entity_name);
int get_xml_entity_name_by_id(int type, char *xml_entity_name);
char *get_type_string(int type);
char *get_type_str_for_log(int type);
int get_user_type_from_ldap(char *token);
int get_user_type_from_radius(char *token);
int get_user_type_from_passwd(char *token);
int get_user_role(user_role_t *role, char *group_identifier, int auth_module_idx, int auth_module);
#ifdef ZLDCONFIG_WEBAUTH
void get_due_time(char *buf, unsigned long *due_time);
void get_reauth_data(char *buf, int *reauth_time, unsigned long *due_time);
#endif
#ifdef AAA_WEB_PORTAL
int get_captive_info_from_local(portal_profile_t *portal_info, const char *portal_name);
#endif
#endif


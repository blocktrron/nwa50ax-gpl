#ifndef __ZYUMAC_DFS_PVT_H__
#define __ZYUMAC_DFS_PVT_H__

#define MAX_CHAN_NUM 100

typedef struct _chan_ctrl {
	int dcs_manual_chan[MAX_CHAN_NUM];
	int dcs_manual_chan_num;
	int dfs_nol[MAX_CHAN_NUM];
	int dfs_nol_num;
} zyUMAC_chan_ctrl_t;

#endif /* __ZYUMAC_DFS_PVT_H__ */

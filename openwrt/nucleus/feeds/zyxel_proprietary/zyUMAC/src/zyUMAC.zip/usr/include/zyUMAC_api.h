#ifndef __zyUMAC_API_HEAD__
#define __zyUMAC_API_HEAD__

#define ACFG_PAD_TO_ZY_REASON      0xACF0

int zyUMAC_init(void);
void zyUMAC_exit(void);

typedef int (*zyUMAC_events_monitor_fn_t)(int event);
struct zyUMAC_events_block {
	struct list_head list;
	zyUMAC_events_monitor_fn_t cb;
};

enum zyUMAC_events_led_state 
{
	ZYUMAC_LED_ST_IDLE = 0,		/**< Idle (normal operation) */
	ZYUMAC_LED_ST_CAC_START, /**< CAC start  */
	ZYUMAC_LED_ST_CAC_STOP,  /**< CAC stop  */
	ZYUMAC_LED_ST_CLIENT_JOIN, /**< client join  */
	ZYUMAC_LED_ST_CLIENT_LEAVE,  /**< client leave  */
	OSP_LED_ST_LAST	/**< (table sentinel) */
};

int zyUMAC_events_monitor_register(struct zyUMAC_events_block *n);
int zyUMAC_events_monitor_unregister(struct zyUMAC_events_block *n);
extern void zyUMAC_events_monitor_callback(int event);
extern int zyUMAC_vap_free_sta(const struct net_device *ndev, unsigned char *mac);

#endif

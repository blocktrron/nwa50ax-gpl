#ifndef __zyUMAC_NL80211_H__
#define __zyUMAC_NL80211_H__

#include <linux/wireless.h>

/* max GENL_NAMSIZ (16) bytes: */
#define ZYXEL_UMAC_GENL_FAM_NAME "zyUMAC"

/* max GENL_NAMSIZ (16) bytes: */
#define ZYXEL_UMAC_GENL_MC_GRP_NAME    "zyUMAC-mcast-grp"
#define zyUMAC_MCGRP_MLME_NAME           "mlme"
#define zyUMAC_MCGRP_STA_INFO_NAME       "sta-info"
#define ZYXEL_UMAC_GENL_VERSION 1

#define IEEE80211_SSID_LEN 32

enum {
	zyUMAC_E_UNSPEC,
	zyUMAC_E_ECHO,
	zyUMAC_E_DOS,
	zyUMAC_E_TXPOWER_CHANGED,
	zyUMAC_E_TRAFFIC_REPORT,
	zyUMAC_E_MLME_FAIL,
	zyUMAC_E_ACCESS_FAIL,
	zyUMAC_E_STA_JOIN, /* Association/Reassociation */
	zyUMAC_E_STA_LEAVE,  /* Disassociation */
	zyUMAC_E_STA_AUTHORIZED, /* STA Authorized */
	zyUMAC_E_STA_DHCP_SNIFFER, /* For DHCP sniffer */
	zyUMAC_E_STA_UPLINK_CONNECTED, /* For ZyMesh, When VAP(station mode) connected to up link send notify ZyMesh app */
	zyUMAC_E_STA_UPLINK_DISCONNECTED, /* For ZyMesh, When VAP(station mode) disconnected to up link send notify ZyMesh app */
	zyUMAC_E_STA_IP, /* mac + extra ip */
	zyUMAC_E_STA_ACTIVITY_CHANGE_IND, /* sta activity change event*/
	zyUMAC_E_IF_CHANNEL, /* Channel */
	zyUMAC_E_IF_SSID, /* SSID */
	zyUMAC_E_IF_SECURITY, /* security mode */
	zyUMAC_E_IF_ROLE, /* wlan mode */
	zyUMAC_E_IF_VAP_DELETE, /* VAP delete */
	zyUMAC_E_IF_VAP_CREATE, /* VAP create */
	zyUMAC_E_COM_BCNRPT, /* beacon report */
	zyUMAC_E_COM_NEIGHBOR_REQ, /* neighbor request */
	zyUMAC_E_COM_MONITOR_PROBE, /* listen to Probe */
	zyUMAC_E_COM_BSTM_RESP, /* BSS Transition Management response */
	zyUMAC_E_COM_DFS_CAC_EXPIRED, /* CAC expired */
	zyUMAC_E_COM_DFS_RADAR_DETECT, /* Radar detected */
	zyUMAC_E_COM_DFS_NOL_TIMEOUT, /* non-occupancy list timeout */
	zyUMAC_E_COM_SMESH_INFO, /* common info */
	zyUMAC_E_COM_SMESH_WBS_FOUND, /* Root AP found */
	zyUMAC_E_COM_ZYLOG,  /* send zylog msg */
	
	__zyUMAC_E_MAX
};

enum {
	zyUMAC_A_UNSPEC,
	zyUMAC_A_ECHO,
	zyUMAC_A_DOS,
	zyUMAC_A_TXPOWER_CHANGED,
	zyUMAC_A_TRAFFIC_REPORT,
	zyUMAC_A_MLME_FAIL,
	zyUMAC_A_ACCESS_FAIL,
	zyUMAC_A_STA_JOIN, /* Association/Reassociation */
	zyUMAC_A_STA_LEAVE, /* Disassociation */
	zyUMAC_A_STA_AUTHORIZED, /* STA Authorized */
	zyUMAC_A_STA_DHCP_SNIFFER, /* For DHCP sniffer */
	zyUMAC_A_STA_UPLINK_CONNECTED, /* For ZyMesh, When VAP(station mode) connected to up link send notify ZyMesh app */
	zyUMAC_A_STA_UPLINK_DISCONNECTED, /* For ZyMesh, When VAP(station mode) disconnected to up link send notify ZyMesh app */
	zyUMAC_A_STA_IP, /* mac + extra ip */
	zyUMAC_A_STA_ACTIVITY_CHANGE_IND, /* sta activity change event*/
	zyUMAC_A_IF_CHANNEL, /* Channel */
	zyUMAC_A_IF_SSID, /* SSID */
	zyUMAC_A_IF_SECURITY, /* security mode */
	zyUMAC_A_IF_ROLE, /* wlan mode */
	zyUMAC_A_IF_VAP_DELETE, /* VAP delete */
	zyUMAC_A_IF_VAP_CREATE, /* VAP create */
	zyUMAC_A_COM_BCNRPT, /* beacon report */
	zyUMAC_A_COM_NEIGHBOR_REQ, /* neighbor request */
	zyUMAC_A_COM_MONITOR_PROBE, /* listen to Probe */
	zyUMAC_A_COM_BSTM_RESP, /* BSS Transition Management response */
	zyUMAC_A_COM_DFS_CAC_EXPIRED, /* CAC expired */
	zyUMAC_A_COM_DFS_RADAR_DETECT, /* Radar detected */
	zyUMAC_A_COM_DFS_NOL_TIMEOUT, /* non-occupancy list timeout */
	zyUMAC_A_COM_SMESH_INFO, /* common info */
	zyUMAC_A_COM_SMESH_WBS_FOUND, /* Root AP found */
	zyUMAC_A_COM_ZYLOG,  /* send zylog msg */

	__zyUMAC_A_MAX,
};
#define zyUMAC_A_MAX (__zyUMAC_A_MAX - 1)

/* multicast groups */
enum zyUMAC_multicast_groups {
	zyUMAC_MCGRP_MLME,
	zyUMAC_MCGRP_STA_INFO
};

typedef struct _zyUMAC_nl_station_info {
	u_int16_t vid;
	u_int8_t macaddr[6];
	/* Set to 1 if this client supports BSS Transition Management */
	u_int8_t isBTMSupported : 1;
	/* Set to 1 if this client implements Radio Resource Manangement */
	u_int8_t isRRMSupported : 1;
	u_int8_t rssi;
	u_int8_t authorized;
	u_int8_t is_reassoc;
	u_int8_t auth_alg;
	u_int8_t ssid[32];
	u_int16_t event_code;		/* disassoc/deauth event code */
	u_int16_t reason_code;		/* disassoc/deauth reason code */
	char event_type[64];	/* disassoc/deauth event type */
	u_int8_t reassoc_ap[6];
	char security[32];	/*Client security mode*/
	u_int64_t tx_bytes;
	u_int64_t rx_bytes;
	u_int32_t ipaddr;
	u_int8_t activity; 
}	zyUMAC_nl_station_info_t; /* it's a copy of zyUMAC_wal_station_info_t */

typedef struct _zyUMAC_nl_interface_info {
	u_int8_t status;  /* 1: enable 0: disable */
	u_int8_t macaddr[6];
	char cause[64];
	u_int8_t channel;
	int8_t cw_extoffset; /* channel width extern channel offset */
	u_int8_t vht_ch_freq; /* 11ac 80MHz channel center frequency*/
	u_int8_t vht_ch_freq2; /* 11ax 160MHz channel center frequency*/
	u_int8_t ssid_len;
	u_int8_t ssid[32];
	u_int8_t security_len;
	u_int8_t security[32];
	u_int8_t wlan_role;
	u_int8_t is_zy1x;
} zyUMAC_nl_interface_info_t;

typedef struct _zyUMAC_nl_client_info {
	__u16 cap;
	__u8 macaddr[6];
	__u8 rssi;      /* The RSSI of the received probe request. */
} zyUMAC_nl_client_info;

#define zyUMAC_DHCP_MSG_MAX_LEN  600  /* MAC + IP + UDP + DHCP */
typedef struct _zyUMAC_nl_dhcp_sniffer {
	u_int8_t macaddr[6];
	unsigned int skb_len;
	unsigned char skb[zyUMAC_DHCP_MSG_MAX_LEN];
} zyUMAC_nl_dhcp_sniffer_t;

#define zyUMAC_ZYLOG_MAX_MESSAGE_LEN 512
#define zyUMAC_ZYLOG_MAX_NOTE_LEN 32
#define zyUMAC_ZYLOG_DEST_AP	1
#define zyUMAC_ZYLOG_DEST_APC	2
typedef struct _zyUMAC_nl_zylog {
	unsigned char msg[zyUMAC_ZYLOG_MAX_MESSAGE_LEN];
	unsigned char note[zyUMAC_ZYLOG_MAX_NOTE_LEN];
	u_int8_t source;
	u_int8_t facility;
	u_int8_t priority;
	u_int8_t dest;
} zyUMAC_nl_zylog_t;

typedef struct _zyUMAC_nl_bstm_resp {
	u_int8_t macaddr[6];          /* station mac */
	u_int8_t status;              /* status of the response to the request frame */
	u_int8_t termination_delay;   /* number of minutes that the STA requests the BSS to delay termination */
	u_int8_t target_bssid[6];     /* BSSID of the BSS that the STA transitions to */
} zyUMAC_nl_bstm_resp_t;

typedef struct _zyUMAC_nl_bcnrpt {
	u_int8_t bssid[6];
	u_int8_t rsni;
	u_int8_t rcpi;
	u_int8_t chnum;
	u_int8_t more;
} zyUMAC_nl_bcnrpt_t;

#define ZYUMAC_BSTEERING_RRM_NUM_BCNRPT_MAX 4
typedef struct _zyUMAC_nl_bcnrpt_ind {
	u_int8_t macaddr[6];          /* station mac */
	u_int8_t rpt_cnt;
	zyUMAC_nl_bcnrpt_t rpt[ZYUMAC_BSTEERING_RRM_NUM_BCNRPT_MAX];
} zyUMAC_nl_bcnrpt_ind_t;


typedef struct _zyUMAC_nl_neighbor_req {
	u_int8_t macaddr[6];  /* MAC address of the reporter station.*/
	u_int8_t dialogtoken;
	u_int8_t ssid[32];
	u_int8_t ssid_len;
} zyUMAC_nl_neighbor_req_t;

typedef struct _zyUMAC_nl_smesh_event_ind {
	u_int8_t rt_type;
	u_int8_t bssid[6];
	u_int8_t channel;
} zyUMAC_nl_smesh_event_ind_t;

typedef struct zyUMAC_event_msg {
	char ifname[IFNAMSIZ];
	unsigned short subtype;
	unsigned short len;
	union{
		zyUMAC_nl_station_info_t sta_info;
		zyUMAC_nl_interface_info_t vap_info;
		zyUMAC_nl_client_info client;
		zyUMAC_nl_dhcp_sniffer_t dhcp_sniffer;
		zyUMAC_nl_bstm_resp_t bstm_resp;
		zyUMAC_nl_zylog_t zylog;
		zyUMAC_nl_bcnrpt_ind_t beacon_report;
		zyUMAC_nl_neighbor_req_t neighbor_req;
		zyUMAC_nl_smesh_event_ind_t smesh_event_ind;
	}u;
} zyUMAC_event_msg_t;

#define IEEE80211_VHTCAP_MU_BFORMEE          0x00100000 /* B20 MU Beam Formee */

enum {
	ZYUMAC_IEEE80211_ELEMID_SSID             = 0,
	ZYUMAC_IEEE80211_ELEMID_RATES            = 1,
	ZYUMAC_IEEE80211_ELEMID_FHPARMS          = 2,
	ZYUMAC_IEEE80211_ELEMID_DSPARMS          = 3,
	ZYUMAC_IEEE80211_ELEMID_CFPARMS          = 4,
	ZYUMAC_IEEE80211_ELEMID_TIM              = 5,
	ZYUMAC_IEEE80211_ELEMID_IBSSPARMS        = 6,
	ZYUMAC_IEEE80211_ELEMID_COUNTRY          = 7,
	ZYUMAC_IEEE80211_ELEMID_REQINFO          = 10,
	ZYUMAC_IEEE80211_ELEMID_QBSS_LOAD        = 11,
	ZYUMAC_IEEE80211_ELEMID_TCLAS            = 14,
	ZYUMAC_IEEE80211_ELEMID_CHALLENGE        = 16,
	/* 17-31 reserved for challenge text extension */
	ZYUMAC_IEEE80211_ELEMID_PWRCNSTR         = 32,
	ZYUMAC_IEEE80211_ELEMID_PWRCAP           = 33,
	ZYUMAC_IEEE80211_ELEMID_TPCREQ           = 34,
	ZYUMAC_IEEE80211_ELEMID_TPCREP           = 35,
	ZYUMAC_IEEE80211_ELEMID_SUPPCHAN         = 36,
	ZYUMAC_IEEE80211_ELEMID_CHANSWITCHANN    = 37,
	ZYUMAC_IEEE80211_ELEMID_MEASREQ          = 38,
	ZYUMAC_IEEE80211_ELEMID_MEASREP          = 39,
	ZYUMAC_IEEE80211_ELEMID_QUIET            = 40,
	ZYUMAC_IEEE80211_ELEMID_IBSSDFS          = 41,
	ZYUMAC_IEEE80211_ELEMID_ERP              = 42,
	ZYUMAC_IEEE80211_ELEMID_TCLAS_PROCESS    = 44,
	ZYUMAC_IEEE80211_ELEMID_HTCAP_ANA        = 45,
	ZYUMAC_IEEE80211_ELEMID_RESERVED_47      = 47,
	ZYUMAC_IEEE80211_ELEMID_RSN              = 48,
	ZYUMAC_IEEE80211_ELEMID_XRATES           = 50,
	ZYUMAC_IEEE80211_ELEMID_AP_CHAN_RPT      = 51,
	ZYUMAC_IEEE80211_ELEMID_HTCAP_VENDOR     = 51,
	ZYUMAC_IEEE80211_ELEMID_HTINFO_VENDOR    = 52,
	ZYUMAC_IEEE80211_ELEMID_MOBILITY_DOMAIN  = 54,
	ZYUMAC_IEEE80211_ELEMID_FT               = 55,
	ZYUMAC_IEEE80211_ELEMID_TIMEOUT_INTERVAL = 56,
	ZYUMAC_IEEE80211_ELEMID_SUPP_OP_CLASS    = 59,
	ZYUMAC_IEEE80211_ELEMID_EXTCHANSWITCHANN = 60,
	ZYUMAC_IEEE80211_ELEMID_HTINFO_ANA       = 61,
	ZYUMAC_IEEE80211_ELEMID_SECCHANOFFSET    = 62,
	ZYUMAC_IEEE80211_ELEMID_WAPI             = 68,   /*IE for WAPI*/
	ZYUMAC_IEEE80211_ELEMID_TIME_ADVERTISEMENT = 69,
	ZYUMAC_IEEE80211_ELEMID_RRM              = 70,   /* Radio resource measurement */
	ZYUMAC_IEEE80211_ELEMID_MBSSID           = 71,   /* MBSSID element */
	ZYUMAC_IEEE80211_ELEMID_2040_COEXT       = 72,
	ZYUMAC_IEEE80211_ELEMID_2040_INTOL       = 73,
	ZYUMAC_IEEE80211_ELEMID_OBSS_SCAN        = 74,
	ZYUMAC_IEEE80211_ELEMID_MMIE             = 76,   /* 802.11w Management MIC IE */
	ZYUMAC_IEEE80211_ELEMID_MBSSID_NON_TRANS_CAP = 83, /* 802.11ax MBSS IE Non-transmitting VAP */
	ZYUMAC_IEEE80211_ELEMID_MBSSID_INDEX    = 85,    /* 8021.11ax MBSS IE BSSID Index */
	ZYUMAC_IEEE80211_ELEMID_FMS_DESCRIPTOR   = 86,   /* 802.11v FMS descriptor IE */
	ZYUMAC_IEEE80211_ELEMID_FMS_REQUEST      = 87,   /* 802.11v FMS request IE */
	ZYUMAC_IEEE80211_ELEMID_FMS_RESPONSE     = 88,   /* 802.11v FMS response IE */
	ZYUMAC_IEEE80211_ELEMID_BSSMAX_IDLE_PERIOD = 90, /* BSS MAX IDLE PERIOD */
	ZYUMAC_IEEE80211_ELEMID_TFS_REQUEST      = 91,
	ZYUMAC_IEEE80211_ELEMID_TFS_RESPONSE     = 92,
	ZYUMAC_IEEE80211_ELEMID_TIM_BCAST_REQUEST  = 94,
	ZYUMAC_IEEE80211_ELEMID_TIM_BCAST_RESPONSE = 95,
	ZYUMAC_IEEE80211_ELEMID_INTERWORKING     = 107,
	ZYUMAC_IEEE80211_ELEMID_QOS_MAP          = 110,
	ZYUMAC_IEEE80211_ELEMID_XCAPS            = 127,
	ZYUMAC_IEEE80211_ELEMID_RESERVED_133     = 133,
	ZYUMAC_IEEE80211_ELEMID_TPC              = 150,
	ZYUMAC_IEEE80211_ELEMID_CCKM             = 156,
	ZYUMAC_IEEE80211_ELEMID_VHTCAP           = 191,  /* VHT Capabilities */
	ZYUMAC_IEEE80211_ELEMID_VHTOP            = 192,  /* VHT Operation */
	ZYUMAC_IEEE80211_ELEMID_EXT_BSS_LOAD     = 193,  /* Extended BSS Load */
	ZYUMAC_IEEE80211_ELEMID_WIDE_BAND_CHAN_SWITCH = 194,  /* Wide Band Channel Switch */
	ZYUMAC_IEEE80211_ELEMID_VHT_TX_PWR_ENVLP = 195,  /* VHT Transmit Power Envelope */
	ZYUMAC_IEEE80211_ELEMID_CHAN_SWITCH_WRAP = 196,  /* Channel Switch Wrapper */
	ZYUMAC_IEEE80211_ELEMID_AID              = 197,  /* AID */
	ZYUMAC_IEEE80211_ELEMID_QUIET_CHANNEL    = 198,  /* Quiet Channel */
	ZYUMAC_IEEE80211_ELEMID_OP_MODE_NOTIFY   = 199,  /* Operating Mode Notification */
	ZYUMAC_IEEE80211_ELEMID_REDUCED_NBR_RPT  = 201,  /* Reduced Neighbor Report */
	ZYUMAC_IEEE80211_ELEMID_VENDOR           = 221,  /* vendor private */
	ZYUMAC_IEEE80211_ELEMID_EXTN             = 255,
};

/* Element ID extensions
 */
enum {
	ZYUMAC_IEEE80211_ELEMID_EXT_ESP_ELEMID_EXTENSION = 11,
	ZYUMAC_IEEE80211_ELEMID_EXT_MAX_CHAN_SWITCH_TIME = 34,
	ZYUMAC_IEEE80211_ELEMID_EXT_HECAP                = 35,
	ZYUMAC_IEEE80211_ELEMID_EXT_HEOP                 = 36,
	ZYUMAC_IEEE80211_ELEMID_EXT_SRP                  = 39,
	ZYUMAC_IEEE80211_ELEMID_EXT_BSSCOLOR_CHG         = 42,
};

/**
 * struct zyUMAC_ie_ssid_t : ssid IE
 * @ssid_id: SSID Element Id
 * @ssid_len: SSID IE Length
 * @ssid: ssid value
 */
typedef struct __zyUMAC_ie_ssid_t {
	uint8_t ssid_id;
	uint8_t ssid_len;
	uint8_t ssid[IEEE80211_SSID_LEN + 1];
} zyUMAC_ie_ssid_t;

/**
 * struct zyUMAC_htcap_cmn_ie_t: HT common IE info
 * @hc_cap: HT capabilities
 * @ampdu_param: ampdu params
 * @mcsset: supported MCS set
 * @extcap: extended HT capabilities
 * @txbf_cap: txbf capabilities
 * @antenna: antenna capabilities
 */
typedef struct __zyUMAC_htcap_cmn_ie_t {
	uint16_t hc_cap;
	uint8_t ampdu_param;
	uint8_t mcsset[16];
	uint16_t extcap;
	uint32_t txbf_cap;
	uint8_t antenna;
} zyUMAC_htcap_cmn_ie_t;

/**
 * struct zyUMAC_htcap_ie_t: HT Capability IE
 * @id: HT IE
 * @len: HT IE LEN
 * @ie: HT cap info
 */
typedef struct __zyUMAC_htcap_ie_t {
	uint8_t id;
	uint8_t len;
	zyUMAC_htcap_cmn_ie_t ie;
} zyUMAC_htcap_ie_t;

/**
 * struct zyUMAC_ie_vhtcaps - VHT capabilities
 * @elem_id: VHT caps IE
 * @elem_len: VHT caps IE len
 * @max_mpdu_len: MPDU length
 * @supported_channel_widthset: channel width set
 * @ldpc_coding: LDPC coding capability
 * @shortgi80: short GI 80 support
 * @shortgi160and80plus80: short Gi 160 & 80+80 support
 * @tx_stbc; Tx STBC cap
 * @tx_stbc: Rx STBC cap
 * @su_beam_former: SU beam former cap
 * @su_beam_formee: SU beam formee cap
 * @csnof_beamformer_antSup: Antenna support for beamforming
 * @num_soundingdim: Sound dimensions
 * @mu_beam_former: MU beam former cap
 * @mu_beam_formee: MU beam formee cap
 * @vht_txops: TXOP power save
 * @htc_vhtcap: HTC VHT capability
 * @max_ampdu_lenexp: AMPDU length
 * @vht_link_adapt: VHT link adapatation capable
 * @rx_antpattern: Rx Antenna pattern
 * @tx_antpattern: Tx Antenna pattern
 * @rx_mcs_map: RX MCS map
 * @rx_high_sup_data_rate : highest RX supported data rate
 * @tx_mcs_map: TX MCS map
 * @tx_sup_data_rate: highest TX supported data rate
 */
typedef struct __zyUMAC_ie_vhtcaps_t {
	uint8_t elem_id;
	uint8_t elem_len;
	uint32_t max_mpdu_len:2;
	uint32_t supported_channel_widthset:2;
	uint32_t ldpc_coding:1;
	uint32_t shortgi80:1;
	uint32_t shortgi160and80plus80:1;
	uint32_t tx_stbc:1;
	uint32_t rx_stbc:3;
	uint32_t su_beam_former:1;
	uint32_t su_beam_formee:1;
	uint32_t csnof_beamformer_antSup:3;
	uint32_t num_soundingdim:3;
	uint32_t mu_beam_former:1;
	uint32_t mu_beam_formee:1;
	uint32_t vht_txops:1;
	uint32_t htc_vhtcap:1;
	uint32_t max_ampdu_lenexp:3;
	uint32_t vht_link_adapt:2;
	uint32_t rx_antpattern:1;
	uint32_t tx_antpattern:1;
	uint32_t unused:2;
	uint16_t rx_mcs_map;
	uint16_t rx_high_sup_data_rate:13;
	uint16_t reserved2:3;
	uint16_t tx_mcs_map;
	uint16_t tx_sup_data_rate:13;
	uint16_t reserved3:3;
} zyUMAC_ie_vhtcaps_t;

/* struct ie list */
typedef struct __zyUMAC_ie_list_t {
	zyUMAC_ie_ssid_t ssid_ie;
	zyUMAC_htcap_ie_t htcap_ie;
	zyUMAC_ie_vhtcaps_t vhtcap_ie;

}zyUMAC_ie_list_t;

/**
 * zylog category for zyUMAC
 * 
 * We only define the value which we interested.
 * It will mapping to correct zylog category in user space.
 */
enum {
	ZYUMAC_ZYLOG_PRI_EMERG,
	ZYUMAC_ZYLOG_PRI_ALERT,
	ZYUMAC_ZYLOG_PRI_CRIT,
	ZYUMAC_ZYLOG_PRI_ERR,
	ZYUMAC_ZYLOG_PRI_WARNING,
	ZYUMAC_ZYLOG_PRI_NOTICE,
	ZYUMAC_ZYLOG_PRI_INFO,
	ZYUMAC_ZYLOG_PRI_DEBUG,
};
enum {
	ZYUMAC_ZYLOG_SRC_WLAN,
	ZYUMAC_ZYLOG_SRC_WLAN_STATION_INFO, 
	ZYUMAC_ZYLOG_SRC_DFS, 
	ZYUMAC_ZYLOG_SRC_STATION_INFO_COLLECTION,
};
enum {
	ZYUMAC_ZYLOG_FAC_WLAN, 
	ZYUMAC_ZYLOG_FAC_WLAN_STATION_INFO, 
	ZYUMAC_ZYLOG_FAC_DFS, 
	ZYUMAC_ZYLOG_FAC_SYSTEM, 
	ZYUMAC_ZYLOG_FAC_STATION_INFO_COLLECTION,
};

#endif /* __zyUMAC_NL80211_H__ */

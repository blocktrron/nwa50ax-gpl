#ifndef __ZYUMAC_DFS_H__
#define __ZYUMAC_DFS_H__

#include "zyUMAC_umac.h"

#if 0
enum {
	ZYUMAC_BW20 = 0,
	ZYUMAC_BW40,    
	ZYUMAC_BW80,
	ZYUMAC_BW8080,
	ZYUMAC_BW160,
};
#endif

/* ic_dfs_enhance */
enum {
	ZYUMAC_DFS_OFF = 0,
	ZYUMAC_DFS_RECOVER = 1,
	ZYUMAC_DFS_SILENCE = 2,
};

extern int zyUMAC_chan_valid(zyUMAC_scn_priv_t *zyUMAC_scn_priv, int chan, int enable_zylog);
extern int zyUMAC_dfs_select_channel(zyUMAC_scn_priv_t *zyUMAC_scn_priv, unsigned char cur_ch_list[], unsigned char new_ch_list[], 
int max_ch_num);
extern int zyUMAC_set_dcs_manual_chan(zyUMAC_scn_priv_t *zyUMAC_scn_priv, char *chan_buf);
extern int zyUMAC_get_dcs_manual_chan(zyUMAC_scn_priv_t *zyUMAC_scn_priv, char *chan_buf, int chan_buf_len);
extern int zyUMAC_radar_notify(zyUMAC_wal_wdev_t vap, int chan);
extern int zyUMAC_get_nol(zyUMAC_scn_priv_t *zyUMAC_scn_priv, char *chan_buf, int chan_buf_len);
extern int zyUMAC_nol_timeout(zyUMAC_wal_wdev_t vap, int chan);
extern int zyUMAC_reset_nol(zyUMAC_scn_priv_t *zyUMAC_scn_priv, int force);
extern int zyUMAC_sync_nol(zyUMAC_scn_priv_t *zyUMAC_scn_priv);
extern int zyUMAC_is_ch_switch_disabled(zyUMAC_scn_priv_t *zyUMAC_scn_priv);

#endif /* __ZYUMAC_DFS_H__ */

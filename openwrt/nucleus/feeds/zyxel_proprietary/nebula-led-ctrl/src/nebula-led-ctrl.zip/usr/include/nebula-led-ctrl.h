#ifndef NEBULA_LED_CTRL_H_
#define NEBULA_LED_CTRL_H_

typedef enum led_state
{
    NCC_CONNECTING = 0,
    NCC_OK_AP_UNREG,
    NCC_OK_AP_REG,
    NCC_CONNECTING_AP_REG,
} LED_STATE;

#define MAX_CMD_BUF_LEN      128         /* Max. cmd buf length */

#define NotifyNetconfLedState(led_state) {\
	char cmd_buf[MAX_CMD_BUF_LEN];\
	snprintf(cmd_buf,sizeof(cmd_buf),"/bin/zysh -p 200 -e \"_netconf led-state change %d\"", led_state);\
	system(cmd_buf); \
}

#endif /* LED_CTRL_H_ */

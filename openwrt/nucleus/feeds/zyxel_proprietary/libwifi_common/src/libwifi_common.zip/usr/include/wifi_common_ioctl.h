#ifndef __WIFI_COMMON_IOCTL_H__
#define __WIFI_COMMON_IOCTL_H__

#include <string.h>
#include <stdint.h>
#include <zyUMAC_ioctl.h>

/* channel width */
enum {
	CW_20            = 0,
	CW_40            = 1,
	CW_80            = 2,
	CW_160          = 3,
};

/* ret : 1 : radio is incac , 0 : radio is ready */
int radio_is_incac(const char *radio_ifname);

int get_active_chanlist(const char *radio_ifname, zyUMAC_active_chlist_t *buf);

int send_btm_req(const char *radio_ifname, zyUMAC_btm_req_params_t *buf);
int wifi_kickmac(char *vap_ifname, unsigned char *mac, unsigned short event_code, unsigned short reason);
void wifi_list_sta(char *vap_ifname);
int get_current_channel_width(const char *vap_ifname, int *cw);
int set_current_channel_width(const char *vap_ifname, int cw);
int get_current_band(const char *vap_ifname, int *band);
int get_current_channel(const char *vap_ifname, int *channel);
int get_radio_band_mode(const char *vap_ifname);
int get_channel_utilization(const char * vap_ifname);
int get_first_active_vap(int radioIndx,unsigned char * ifname);
int get_current_txpower(const char *vap_ifname, int *txpower);
#endif


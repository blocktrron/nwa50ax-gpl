#ifndef	_SIGNAL_WRAPPER_ 
#define _SIGNAL_WRAPPER_ 

#include <sys/types.h>
#include <signal.h>

#define ARG_SIZE 16
#define BUF_SIZE 64

enum EVENT_TYPE {	EVENT_NON=0,
					EVENT_SIGNAL,
					EVENT_RESTART_DAEMON,
					EVENT_TYPE_SIZE };

typedef struct{
	enum EVENT_TYPE event_type;
	union {
		struct{
			pid_t	pid;
			int	sig;
		}s; //struct for EVENT_SIGNAL
		char arg[ARG_SIZE][BUF_SIZE]; //array for EVENT_DESTART_DAEMON
	}data;
} sig_event_t, *sig_event_p;



#define UNIX_DOMAIN_SOCKET_PATH_SIGNAL_WRAPPER  "/tmp/_signal_wrapper_"
#define NAMED_PIPE_SIGNAL_WRAPPER_STATE "/tmp/_signal_wrapper_state_"


#endif

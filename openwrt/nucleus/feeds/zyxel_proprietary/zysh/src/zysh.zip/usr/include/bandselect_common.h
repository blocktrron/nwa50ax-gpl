/****************************************************************************/
/*
* Copyright (C) 2000-2018 Zyxel Communications, Corp.
* All Rights Reserved.
*
* Zyxel Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such Zyxel confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of Zyxel Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* Zyxel Communications, Corp.
*/
/****************************************************************************/

#ifndef _BANDSELECT_COMMON_H
#define _BANDSELECT_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <linked-list.h>
#include <event.h>
#include <time.h>
#include <zld-spec.h>
#include <stdint.h>

#ifndef IEEE80211_ADDR_LEN
#define IEEE80211_ADDR_LEN  6       /* size of 802.11 address */
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif


/**
 * @brief Type that denotes the Wi-Fi band.
 *
 * This type is only for use within the Load Balancing Daemon.
 */
typedef enum wlanif_band_e {
    wlanif_band_24g = 1,   // 2.4 GHz
    wlanif_band_5g = 2 ,    // 5 GHz
    wlanif_band_dual = 3 ,    // 2.4 GHz & 5 GHz
    wlanif_band_invalid,  ///< band is not known or is invalid
} wlanif_band_e;


static const char *BandString[] = {
    "",
    "2.4GHz",
    "5GHz",
    "Dual",
    "Invalid"
};

typedef enum debug_Level_t {
    DBGERR = (1<<0),         /* for serious errors only */
    DBGINFO = (1 << 1),        /* important information, including minor errors */
    DBGDEBUG = (1 << 2),       /* for typical debugging */
    DBGZYDEBUG = (1 << 3)         /* for zysh_bandselect debug */
}debug_Level;


/**
 * @brief Enumeration for sta finite state machine
 */
typedef enum StaFSMStatus_t {
    // STA is ready
    StaState_Ready = 1,
    // Steer STA 
    StaState_Steer =2,
    // Wait disassociation 
    StaState_WaitDisassoc = 3,
    // Disable Steering  
    StaState_Ignore = 4,
    // Active Steering until the timer expires
    StaState_Unfriendly =5,
    // Invalid state
    StaState_invalid = 6
} StaFSMStatus;

static const char *StaFSMStatusString[] = {
    "",
    "Ready",
    "Steer",
    "WaitDisassoc",
    "Ignore",
    "Unfriendly",
    "Invalid"
};

typedef enum StaStatus_t {
    STA_IDLE = 0,
    STA_BUSY = 1,
    STA_DISASSOC = 2,
    STA_INVALID
}StaStatus;

static const char *StaStatusString[] = {
    "idle",
    "busy",
    "Invalid"
};

typedef enum BandSelectEventType_t{
        BANDSELECT_SET_CONFIG,  // set config 
        BANDSELECT_GET_CONFIG,  // get config         
        BANDSELECT_GET_STANUM,
        BANDSELECT_GET_STAINFO,
        BANDSELECT_GET_STAINFO_END,
        BANDSELECT_SET_DBGLVL,
        BANDSELECT_SSID_SCHEDULE,
        BANDSELECT_INVALID
}BandSelectEventType;


#define BANDSELECT_SOCK_PATH		"/tmp/bandselect.sock"
#define BANDSELECT_SSID_MAX_LEN  37
#define BANDSELECT_SEC_MAX_LEN 37


#ifndef MAC2STR
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MACSTR "%02x:%02x:%02x:%02x:%02x:%02x"
#endif


#ifndef IFNAMSIZ
#define IFNAMSIZ		16
#endif

#ifdef ZLDCONFIG_WLAN_RSSI_THRESHOLD
typedef struct SignalThreshConfig_t
{
    uint8_t enable;
    int signal_threshold;
    int disassoc_threshold;
}SignalThreshConfig;
#endif

typedef struct BandSelectConfig_t
{
    uint8_t  bs_enable;
    uint8_t  balance_ratio;
    uint8_t  stop_threshold;
}BandSelectConfig;

typedef struct VapData_t {
    char ssid[BANDSELECT_SSID_MAX_LEN];
    char security[BANDSELECT_SEC_MAX_LEN];
    uint8_t     bssid[IEEE80211_ADDR_LEN];
    uint8_t     suggest_bssid[IEEE80211_ADDR_LEN];
    uint8_t  kv_enable;
    uint8_t bs_active ; // have the same ssid/security of the other radio & band select is enabled
    uint8_t ifaceUp;     // ssid-schedule changes vap status to up or down.
    BandSelectConfig bs_config;
}VapData;


typedef struct BandSelectConfigData_t {
    uint8_t radioIdx;
    uint8_t    active;   // 1:  radio & slot are active , 0: radio || slot is not active || monitor mode
    int     channel;
    int     txpower;
    int     dfscac;
#ifdef ZLDCONFIG_WLAN_WPA3_SUPPORT
    VapData   vap[ZLDSYSPARM_WLAN_MAX_AP+ZLDSYSPARM_WLAN_MAX_OWE];
#else
    VapData   vap[ZLDSYSPARM_WLAN_MAX_AP];
#endif
#ifdef ZLDCONFIG_WLAN_RSSI_THRESHOLD    
    SignalThreshConfig signal;
#endif
}BandSelectConfigData;


typedef struct BandSelectStaInfo_t
{
    char ifname[IFNAMSIZ];
    uint8_t     addr[IEEE80211_ADDR_LEN];
    int           status;    // idle / busy / disassoc
    int           capability;  // 2.4G / 5G / dual band
    StaFSMStatus fsmstatus;
    int isRRMSupported;
    int isBTMSupported;
    uint8_t fail_times;
    int remain_time;
}BandSelectStaInfo;

typedef struct BandSelectStaNum_t
{
    int  radioIdx;
    int  num;
}BandSelectStaNum;


typedef struct BandSelectDebugLVL_t
{
     int    level;
}BandSelectDebugLVL;

typedef struct BandSelectSsidSchedule_t
{
    char ifname[IFNAMSIZ];
    unsigned char active;
}BandSelectSsidSchedule;

typedef struct BandSelectConfigEvent_t
{
    BandSelectEventType event_type;
    union
    {
        BandSelectConfigData config;
        BandSelectStaNum stanum;
        BandSelectStaInfo   stainfo;
        BandSelectDebugLVL dbglvl;
        BandSelectSsidSchedule ssidschedule;
    }u;
}BandSelectConfigEvent;


#endif

#ifndef __ZYSH_LOADBALANCING_H__
#define __ZYSH_LOADBALANCING_H__

#include <stdint.h>

#define LB_XML_SCOPE			"network/load_balancing"
#define LB_XML_TYPE			"load_balancing_t"
#define LB_LIST			"load_balancing"


#define LB_STR_YES			"yes"
#define LB_STR_NO			"no"
#ifdef ZLDCONFIG_OVERLOADED_TXPOWER_ADJUST
#define TXPOW_ENABLE		"ENABLE"
#define TXPOW_DISABLE		"DISABLE"
#endif
typedef struct {
	uint8_t LI_Level[ZLDSYSPARM_WLAN_MAX_SLOT];
	uint16_t debug_level;	
} loadBalancing_status_t;

typedef struct {
	uint8_t radioIdx;
	uint16_t LI_level;
} loadBalancing_loading_t;

#define LB_SOCKET_MSG_LEN 32
#define LB_DOMAIN_SOCKET_PATH "/tmp/load_balancing_socket_event"

enum {
	ACTIVATE = 0,
	SET_KICKOUT = 1,
	SET_MODE = 2,
	SET_MAX_STA = 3,
	SET_TRAFFIC_LEVEL = 4,
	SET_ALPHA = 5,
	SET_BETA = 6,
	SET_SIGMA = 7,
	SET_TIMEOUT = 8,
	SET_LI_INTERVAL = 9,
	SET_KICK_INTERVAL = 10,
	SET_GROUP = 11
};

typedef struct {
	uint8_t code;
	uint8_t slot;
	char msg[LB_SOCKET_MSG_LEN];
} loadBalancing_domain_socket_data_t;

#define LI_LEVEL_UNNORMAL     4

#endif

/* $Id: libfirmware.h,v 1.1.1.1 2005/11/17 07:07:42 herenlin Exp $ */

/*
  $Log: libfirmware.h,v $
  Revision 1.1.1.1  2005/11/17 07:07:42  herenlin
  libfirmware - the library for ZLD firmware image related functions

*/

#ifndef _LIBFIRMWARE_H_
#define _LIBFIRMWARE_H_

#ifdef ZLDCONFIG_UPDATE_FW_OOM_WORKAROUND
#define UPDATE_FW_FTP 0
#define UPDATE_FW_GUI 1
#endif

#define FW_VERIFY_MSG_LEN   1024
#define ZLD_CURRENT_INFO_LEN 512
#define COMPATIBLE_PRODUCT_MODEL_NUM 5
#define COMPATIBLE_PRODUCT_MODEL_LEN 5

typedef enum {
	FW_VERIFY_OK,
	FW_NOT_COMPAT_IDS,
	FW_FILE_DAMAGED,
	FW_NOT_COMPAT_VERSION
} fw_verify_t;

enum {
	FSEXTRACT_NONE = -1,
	FSEXTRACT_COMPATIBLE_PRODUCT_MODEL,
	FSEXTRACT_FW_VERSION,
	FSEXTRACT_MAX
};

typedef struct zld_current_info_t
{
	unsigned char compatible_product_model[COMPATIBLE_PRODUCT_MODEL_NUM][COMPATIBLE_PRODUCT_MODEL_LEN];
	int fw_version_major;
	int fw_version_minor;
}zld_current_info;

#ifdef ZLDCONFIG_UPDATE_FW_OOM_WORKAROUND
int kill_process(int fw);
void proc_control(char *string, char *file);
#endif
int verify_rommrd_product_model(void);
int get_zld_current_info(char *zld_current_file, zld_current_info *zu_info, int is_recovery, int opt);
int is_product_model_compatible(unsigned char *ROMMRD_product_model,zld_current_info *zu_info);
int verify_firmware(char *file, char *verify_fw_msg);

#endif

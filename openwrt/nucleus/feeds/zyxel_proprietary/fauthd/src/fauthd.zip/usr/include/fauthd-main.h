/******************************************************************************
 *
 *  Copyright (C) 2002-2006 ZyXEL Communications, Corp.
 *  All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 *
 *****************************************************************************/
 /* $Id: fauthd-main.h,v 1.5 2006/03/08 02:24:42 peterwang Exp $ */

/*
 * $Log: fauthd-main.h,v $
 * Revision 1.5  2006/03/08 02:24:42  peterwang
 * *** empty log message ***
 *
 * Revision 1.4  2006/03/07 13:01:13  peterwang
 * add definition of FORCE_AUTH_REDIRECT_PORT_CHAIN
 *
 * Revision 1.3  2006/03/06 09:01:22  peterwang
 * add POLICY_APPEND and POLICY_INSERT to rule_op_s
 *
 * Revision 1.2  2006/02/06 10:16:55  peterwang
 * fix One Time schedule issue
 *
 * Revision 1.1.1.1  2006/01/24 00:47:40  peterwang
 * Force User Authentication Daemon Initial check in
 *
 */

#ifndef _FORCE_AUTH_MAIN_H
#define _FORCE_AUTH_MAIN_H

#include <linux/types.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "zld-spec.h"

#define	FAUTHD_PATH			"/usr/sbin/fauthd"
#define AP_IPTABLES_BIN			"/usr/sbin/iptables"

#ifdef AAA_8021X_CLOUD_AUTHENTICATION
#define DOT11_ATH_IWPRIV		"iwpriv"
#define DOT11_STR_IFACE_PREFIX		"wlan-" 
#define ARPHRD_ETHER	1
#endif

#define FORCE_AUTH_CHAIN				"FORCE_AUTH"
#define FORCE_AUTH_REDIRECT_CHAIN		"FORCE_AUTH_REDIRECT"
#define FORCE_AUTH_POLICY_CHAIN			"FORCE_AUTH_POLICY"
#define FORCE_AUTH_REDIRECT_HTTP_CHAIN	"FORCE_AUTH_REDIRECT_HTTP"
#define FORCE_AUTH_REDIRECT_HTTPS_CHAIN	"FORCE_AUTH_REDIRECT_HTTPS"
#define FORCE_AUTH_EXCEPTIONAL_CHAIN	"FORCE_AUTH_EXCEPTIONAL"
#define FORCE_AUTH_DEF_CHAIN			"FORCE_AUTH_DEF_RULE"

#define NAT_REDIRECT_TARGET		"REDIRECT"
#define VPN_REDIRECT_TARGET		"REDIRECT"
#define RETURN_TARGET			"RETURN"
#define FORWARD_CHAIN			"FORWARD"
#define ZYNAC_TABLE				"zynac"
#define FAUTH_PID_FILE_PATH          "/var/run/fauth.pid"
#ifdef AAA_WEB_PORTAL
#define	CAPTIVE_PORTAL_CLICK_TO_CONTINUE	"Click-to-continue"
#define	CAPTIVE_PORTAL_CLICKTHROUGH		"click-through"
#define	CAPTIVE_PORTAL_SIGN_ON			"sign-on"
#define	CAPTIVE_PORTAL_CC_DISPLAY_FORMAT	"Captive Portal"
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT 
#define SOCIAL_LOGIN_FACEBOOK_CC_DISPLAY_FORMAT         "Facebook"
#define SOCIAL_LOGIN_GOOGLE_PLUS_CC_DISPLAY_FORMAT      "Google+"
#define SOCIAL_LOGIN_ATTRIBUTE_UNACQUIRED   "N/A"
#endif
#ifdef ZLDCONFIG_FB_WIFI
#define FB_WIFI_LOGIN_CC_DISPLAY_FORMAT			"Facebook Wi-Fi"
#endif
#ifdef ZLDCONFIG_AAA_FREE_ACCESS_SUPPORT
#define CAPTIVE_PORTAL_FREE_ACCESS		"free-access"
#endif
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
#define CAPTIVE_PORTAL_GOOGLE_AUTHENTICATOR_1X			"google-authenticator-1x"
#define CAPTIVE_PORTAL_EMAIL_VERIFICATION_DPPSK		"email-verification-dppsk"
#endif
#define LOCAL_LOGIN_USER_TABLE			"local_login_user"
#define LOCAL_LOGOUT_USER_TABLE			"local_logout_user"
#define FOREIGN_LOGIN_USER_TABLE		"foreign_login_user"
#endif
#define OK			0
#define FAIL			-1
#define YES			OK
#define	NO			FAIL

#define BUF_LEN16		16
#define BUF_LEN32		32
#define BUF_LEN64		64
#define BUF_LEN128		128
#define BUF_LEN256		256
#define BUF_LEN512		512

#ifdef AAA_8021X_CLOUD_AUTHENTICATION
#define WLAN_SLOT_ONE	1	
#define WLAN_SLOT_TWO	2
#endif

#ifdef AAA_WEB_PORTAL
#define SSID_MAX_LENGTH	(33+1)
#define UAM_USERNAME_LEN	(ZLDSYSPARM_UAM_USER_NAME_LEN)
#define PROFILE_NAME_LEN			64
#define PORTAL_SSID_LEN			64
#define PORTAL_MAC_STR_LEN		32
#define UAM_PORTAL_IP_ADDR_LEN		16
#define PORTAL_AUTH_TYPE_LEN		32
#define PORTAL_METHOD_LEN			16
#define PORTAL_AUTH_TIME_LEN		16
#define PORTAL_LOGOUT_TIME_LEN		16
#define PORTAL_VAP_IFACE_LEN		16
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
#define PORTAL_LOCALE_LEN                       16
#define PORTAL_GENDER_LEN            16
#define PORTAL_AGE_LEN            16
#endif
#define UAM_MAX_USER_NUMBER	(ZLDSYSPARM_CON_USER_MAX_NUM - 10)
#define LOCAL_CASE	0
#define FOREIGN_CASE	1
#endif

#define SCHEDULE_CHECK_TIMER	60	/* sec */
#define NOTIFY_CC_TIMEOUT	5

static inline void system_cmd(char *fmt, ...)
{
	char buffer[BUF_LEN256];
	va_list args;

	if(fork()) {
		wait(NULL);
	} else {
		if(fork()) {
			_exit(0);
		} else {
			va_start(args, fmt);
			vsprintf(buffer, fmt, args);
			system(buffer);
			va_end(args);
			_exit(0);
		}
	}
}

#define NIPQUAD(addr) \
	((unsigned char *)&addr)[0], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[3]

static int fauth_week_dig[7] = {
        1,      /* SUN */
        2,      /* MON */
        4,      /* TUE */
        8,      /* WED */
        16,     /* THU */
        32,     /* FRI */
        64      /* SAT */
};

#define		SCHEDULE_ONCE		1
#define		SCHEDULE_RECURSIVE	2

typedef struct schedule_s {
	__u64 	sche_s;
        __u64 	sche_e;
        int 	sche_w;
        int 		type;
} schedule_t;

typedef enum rule_op_s {
	POLICY_DELETE = 1,
	POLICY_FLUSH,
	POLICY_UPDATE,
	POLICY_APPEND,
	POLICY_INSERT,
	PORTAL_CONF_SET,
	UPDATE_AP_ROLE
} rule_op_t;

typedef struct fauth_msg_s {
	long		mtype;
	int		policy_id;
	unsigned int	need_to_check;
	int		applied;
	rule_op_t	operation;
	schedule_t	sche_info;
	int slot;
	int vap;
} fauth_msg_t;

#ifdef AAA_WEB_PORTAL
typedef struct login_user_info_s
{
	char mac_addr[PORTAL_MAC_STR_LEN];
	char sta_ip[UAM_PORTAL_IP_ADDR_LEN];
	char username[UAM_USERNAME_LEN];
	char auth_time[PORTAL_AUTH_TIME_LEN];
	char logout_time[PORTAL_LOGOUT_TIME_LEN];
	char portal_method[PORTAL_METHOD_LEN];
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
	char locale[PORTAL_LOCALE_LEN];
	char gender[PORTAL_GENDER_LEN];
	char age[PORTAL_AGE_LEN];
#endif
	char ssid_name[PORTAL_SSID_LEN];
	char ssid_profile_name[PROFILE_NAME_LEN];
	char ssid_vap_iface[PORTAL_VAP_IFACE_LEN];
} login_user_info_t;
#endif


#define DBG_FILE_SIZE	(3 * 1024 * 1024)   /*3MB*/
#define DBG_FILE_NAME	"/tmp/fauthd.log"
#define DBG_FILE_FLAG	"/tmp/fauthd_flag"
#define CAPTIVE_PORTAL_SIMULATE_FLAG	"/tmp/cp_simulate"
#endif

/******************************************************************************
 *
 *  Copyright (C) 2002-2006 ZyXEL Communications, Corp.
 *  All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 *
 *****************************************************************************/
 /* $Id: fauth-redirect.h,v 1.2 2006/01/25 20:09:34 peterwang Exp $ */

/*
 * $Log: fauth-redirect.h,v $
 * Revision 1.2  2006/01/25 20:09:34  peterwang
 * add path definition for http config
 *
 * Revision 1.1.1.1  2006/01/24 00:47:40  peterwang
 * Force User Authentication Daemon Initial check in
 *
 */

#ifndef _FORCE_AUTH_REDIRECT_H
#define _FORCE_AUTH_REDIRECT_H

#define	FAUTH_REDIRECT_FLAG	"/tmp/__reply_302__"
#define FAUTH_HTTP_SERVER_CONF	"/tmp/__HTTP_SERVER_CONFIG"

#endif

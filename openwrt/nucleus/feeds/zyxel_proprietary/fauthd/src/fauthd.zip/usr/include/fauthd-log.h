/******************************************************************************
 *
 *  Copyright (C) 2002-2006 ZyXEL Communications, Corp.
 *  All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 *
 *****************************************************************************/
 /* $Id: fauthd-log.h,v 1.2 2006/01/25 02:40:12 peterwang Exp $ */

/*
 * $Log: fauthd-log.h,v $
 * Revision 1.2  2006/01/25 02:40:12  peterwang
 * add string define CONFIG_CHANGE
 *
 * Revision 1.1.1.1  2006/01/24 00:47:40  peterwang
 * Force User Authentication Daemon Initial check in
 *
 */
 
#ifndef _FORCE_AUTH_LOG_H
#define _FORCE_AUTH_LOG_H

#define	INTERNAL_ERROR	"INTERNAL ERROR"
#define	CONFIG_CHANGE	"CONFIG CHANGE"

#define FAUTH_LOG(pri,note,msg,arg...)  zylog(ZYLOG_SRC_FORCE_AUTH,\
					pri,\
					ZYLOG_FAC_FORCE_AUTH,\
					0,0,0,0,\
					note,\
					msg,\
					##arg)

#define NAC_LOG(pri,note,msg,arg...)  zylog(ZYLOG_SRC_AUTH_POLICY,\
					pri,\
					ZYLOG_FAC_AUTH_POLICY,\
					0,0,0,0,\
					note,\
					msg,\
					##arg)

#if 0
#define ZYLOG_PRI_EMERG		LOG_EMERG           /* system is unusable */
#define ZYLOG_PRI_ALERT		LOG_ALERT           /* action must be taken immediately */
#define ZYLOG_PRI_CRIT		LOG_CRIT            /* critical conditions */
#define ZYLOG_PRI_ERR		LOG_ERR             /* error conditions */
#define ZYLOG_PRI_WARNING	LOG_WARNING         /* warning conditions */
#define ZYLOG_PRI_NOTICE	LOG_NOTICE          /* normal but significant condition */
#define ZYLOG_PRI_INFO		LOG_INFO            /* informational */
#define ZYLOG_PRI_DEBUG		LOG_DEBUG           /* debug-level messages */
#endif

#endif

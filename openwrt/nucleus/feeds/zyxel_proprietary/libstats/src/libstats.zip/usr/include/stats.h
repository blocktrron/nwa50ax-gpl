#ifndef __STATS_H__
#define __STATS_H__

#include <stdint.h>
#include <sys/types.h>
#include "zyUMAC_stats.h"

#define RADIO_SIGNAL_SAMPLE_FILE	"radio_signal_sample"
#define RADIO_EXTERN_STATISTICS_FILE	"radio_extern_statistics"
#define RADIO_RATEPKT_STATISTICS_FILE	"radio_ratepkt_statistics"
#define RADIO_BASIC_STATISTICS_FILE	"radio_basic_statistics"
#define RADIO_MPDU_STATISTICS_FILE	"radio_mpdu_statistics"
#define STATION_STATISTICS_FILE		"station_statistics"
#define BACKHUAL_STATISTICS_FILE		"backhaul_statistics"

#define BSS_STATISTICS_FILE		"bss_statistics"
#define ASSOC_STATISTICS_FILE		"assoc_statistics"
#define CHANNEL_UTILIZATION_FILE	"channel_utilization"
#define BUSY_CYCLE_FILE			"busy_cycle"
#define TOTAL_CYCLE_FILE		"total_cycle"

//#define LIBSTATS_DEBUG 1
#define MAC_LEN        6

#define GET_ABSOLUTE_PATH(filepath, radio_id, filename)   \
    do{         \
        sprintf(filepath, "/proc/wifi%d/%s", radio_id, filename); \
    }while(0)

#define ARRAY_LENGTH(array)	\
		(sizeof(array) / sizeof((array)[0]))

#ifndef MACSTR
#define MACSTR      "%02X:%02X:%02X:%02X:%02X:%02X"
#define MAC2STR(a)  (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#endif

#if LIBSTATS_DEBUG
#define SLOG_DEBUG(fmt, args...)\
		printf("[%s:%d]DEBUG: " fmt"\n", __FUNCTION__, __LINE__, ##args)
#else
#define SLOG_DEBUG(fmt, args...)
#endif

typedef struct MIB_counter {
        u_int32_t dot11FailedCount;
        u_int32_t dot11RetryCount;
        u_int32_t dot11ACKFailureCount;
        u_int64_t dot11ReceivedFragmentCount;
        u_int32_t dot11TransmittedFrameCount;
        u_int32_t dot11FCSErrorCount;
} MIB_counter_t;

int get_Radio_Basic_Statistics(uint8_t radio,
			  RADIO_BASIC_STATS_T *stats);
int get_Bss_Statistics(uint8_t radio,
		  	BSS_STATS_T *stats,
			uint32_t size);
int get_Station_Statistics(uint8_t radio,
			    STATION_STATS_T *stats,
			    uint32_t size);
int get_Station_Statistics_by_mac(uint8_t radio,
			    char *mac,
			    STATION_STATS_T *stats);
int get_driver_counters(uint8_t radio,MIB_counter_t *mib_counter);
int get_Backhual_Station_Statistics(uint8_t radio,
			    BACKHUAL_STATS_T *bh_stats);
#endif

#include <linux/types.h>
#include <linux/if_ether.h>
#include "zld-spec.h"

#define CAPTIVE_PORTAL_DEV_NAME "CP_dev"
#define CAPTIVE_PORTAL_DEV "/dev/CP_dev"

#define CAPTIVE_PORTAL_IOCTL_SET	1
#define CAPTIVE_PORTAL_IOCTL_GET	2
#define WALLED_GARDEN_IOCTL_SET	3
#define WALLED_GARDEN_IOCTL_GET	4
#define BLOCK_HTTPS_IOCTL_SET		5
#ifdef ZLDCONFIG_WEB_PORTAL_LIMIT_SUPPORT
#define GATEWAY_IOCTL_SET		6
#define GATEWAY_IOCTL_GET		7
#endif
#define GATEKEEPER_IOCTL_SET	8
#define GATEKEEPER_IOCTL_GET	9
#define GATEKEEPER_IOCTL_SEARCH 10

#define IF_LEN		16
#define LOGOUT_IP_ADDRESS_LEN	16
#define DATA_LEN	128
#define MAX_DEFAULT_RULE_SIZE	36
#define SLOT_NUM		2


/* define mulitiple captive portal NCC behavior */
#define CLOUD_DISCONNECT_BEHAVIOR_OPEN 			1
#define CLOUD_DISCONNECT_BEHAVIOR_RESTRICTED	2

/* NCC connnection status */
#define CLOUD_CONNECTED 							1
#define CLOUD_DISCONNECTED						2

typedef struct def_rule_s{	
	char domain_name[DATA_LEN];
}def_rule_t;

typedef struct rule_s{
	struct rule_s *next;
	int is_cidr;
	struct in_addr ipaddr; 
	struct in_addr netmask; 	
	char domain_name[DATA_LEN];
}rule_t;

typedef struct walled_garden_table_s{
	char if_name[IF_LEN];
	int mark;
	int enable;
	rule_t *garden_list;
}walled_garden_table_t;

typedef enum{
	WALLED_GARDEN = 0,
	UPDATE_DEFAULT_RULE,
	UPDATE_RULE,
#ifdef ZLDCONFIG_COLLABORATIVE_DETECTION_RESPONSE
	CDR_UPDATE_URL,
#endif
	SHOW_TABLE,
	SHOW_DEFAULT_RULE,
}walled_garden_cmd;

typedef enum{
	OP_OFF = 0,
	OP_ON,
}walled_garden_on;

typedef struct rule_cmd_s{
	int is_cidr;
	struct in_addr ipaddr; 
	struct in_addr netmask; 	
	char domain_name[DATA_LEN];
}rule_cmd_t;

struct walled_garden_ioctl {
	int cmd;
	int iface; /* wlan1-1~wlan1-8=>1~8, wlan2-1~wlan2-8=>101~108 */
	int enable_value;
	int rule_number;
	rule_cmd_t list[24]; /* copy_from_user can copy only upto 4k(page size) */
};

typedef struct mac_rule_s{
	struct mac_rule_s *next; 
	unsigned char	mac_addr[ETH_ALEN];	
}mac_rule_t;

typedef struct gatekeeper_mac_table_s{
	char if_name[IF_LEN];
	int mark;
	mac_rule_t *mac_list;
}gatekeeper_mac_table_t;

typedef struct gatekeeper_ncc_behavior_s{
	char if_name[IF_LEN];
	int ncc_dis_behavior;
	int ncc_status;
}gatekeeper_ncc_behavior_t;

typedef struct owe_mapping_table_s{
	char if_name[IF_LEN];
	char owe_if_name[IF_LEN];
}owe_mapping_table_t;

#ifdef AAA_WEB_PORTAL
typedef enum{
	AUTH_METHOD_OPEN=0,
	AUTH_METHOD_CLICKTHROUGH,
	AUTH_METHOD_SIGN_ON_MYRADIUS,
	AUTH_METHOD_SIGN_ON_CLOUD,
#ifdef ZLDCONFIG_SOCIAL_LOGIN_SUPPORT
	AUTH_METHOD_SIGN_ON_SOCIAL_LOGIN,
#endif
#ifdef ZLDCONFIG_FB_WIFI
	AUTH_METHOD_SIGN_ON_FB_WIFI_LOGIN,
#endif
#ifdef ZLDCONFIG_WEB_PORTAL_LIMIT_SUPPORT
	AUTH_METHOD_LIMIT,
#endif
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
	AUTH_METHOD_EMAIL_VERIFICATION_DPPSK,
	AUTH_METHOD_GOOGLE_AUTHENTICATOR_1X,
#endif
}auth_method_t;
#endif

typedef struct ip_list_s{
	struct ip_list_s *next;
	__be32 daddr;
}ip_list_t;

typedef struct ipport_list_s{
	struct ipport_list_s *next;
	__be32 saddr;
	__be16 sport;
	__be32 daddr;
	__be16 dport;	
}ipport_list_t;

typedef struct captive_portal_table_s{
	int mark;
	__be16 http_port;
	__be16 https_port;
	int captive_portal;
	int wallgarden;
	int block_https;
	char logout_ip[LOGOUT_IP_ADDRESS_LEN];
	ipport_list_t *table_list;
	ip_list_t *wg_white_list;
	ip_list_t *sni_white_list;
}captive_portal_table_t;

typedef enum{
	ADD_WHITELIST_MAC = 0,
	DEL_WHITELIST_MAC,
	ADD_AUTH_MAC,
	DEL_AUTH_MAC,
	ADD_LOGIN_MAC,
	DEL_LOGIN_MAC,
	SHOW_WHITELIST_TABLE,
	SHOW_AUTH_MAC_TABLE,
	SHOW_LOGIN_MAC_TABLE,
	FLUSH_CAPTIVE_PORTAL_TABLE,
	ADD_NCC_BEHAVIOR,
	SHOW_NCC_STAUTS,
	ADD_MAPPING_OWE_VAP,
	SHOW_MAPPING_TABLES,
	FLUSH_MAPPING_OWE_VAP,
	SEARCH_WHITELIST_TABLE,
#ifdef ZLDCONFIG_COLLABORATIVE_DETECTION_RESPONSE
	SHOW_CDR_BLACK_LIST,
	SHOW_CDR_WHITE_LIST,
	ADD_CDR_BLACK_LIST_MAC,
	DEL_CDR_BLACK_LIST_MAC,
	ADD_CDR_WHITE_LIST_MAC,
	DEL_CDR_WHITE_LIST_MAC,
#endif
#ifdef ZLDCONFIG_MULTI_FACTOR_AUTHENTICATION_SUPPORT
	ADD_GA_WHITELIST_MAC,
	DEL_GA_WHITELIST_MAC,
	SHOW_GA_WHITELIST_TABLE,
	SEARCH_GA_WHITELIST_TABLE,
#endif
}gatekeeper_cmd;

typedef enum{
	CP_WALLED_GARDEN = 0,
	CAPTIVE_PORTAL_ENABLE,
	SHOW_STATUS,
	SHOW_WG_WHITE_LIST,
	SHOW_SNI_WHITE_LIST,
	BLOCK_HTTPS_ENABLE,
	FINDME_URL_ENABLE,
#ifdef ZLDCONFIG_COLLABORATIVE_DETECTION_RESPONSE
	CDR_ENABLE,
#endif
	LOGOUT_IP_NOTIFY,
}captive_portal_cmd;

struct captive_portal_set_ioctl {
    int cmd;
    int iface; /* wlan1-1~wlan1-8=>0~7, wlan2-1~wlan2-8=>8~15 */
    int enable; /* 0: off, 1: on */
	char logout_ip[LOGOUT_IP_ADDRESS_LEN];
};

#ifdef ZLDCONFIG_WEB_PORTAL_LIMIT_SUPPORT
struct gateway_ioctl {
	__be32 gateway;
};
#endif

typedef struct ip_cmd_s{
	struct in_addr ipaddr; 
}ip_cmd_t;

struct gatekeeper_set_ioctl {
    int cmd;
    int ncc_behavior;
    int ncc_status;
    char iface[IF_LEN];
    char owe_iface[IF_LEN];
    unsigned char mac[ETH_ALEN];
};

struct gatekeeper_get_ioctl {
    int cmd;
    int ncc_b;
    int ncc_s;	
    char iface[IF_LEN];
    char owe_iface[IF_LEN];
    int mac_number;
    mac_rule_t mac_list[512];
};

struct gatekeeper_search_ioctl {
	int cmd;
	char iface[IF_LEN];
	unsigned char mac[ETH_ALEN];
	int match_idx;
};

struct captive_portal_get_ioctl {
    int cmd;
    int iface; /* wlan1-1~wlan1-8=>0~7, wlan2-1~wlan2-8=>8~15 */
    int mark;
    int captive_portal; /* 0: off, 1: on */
    int wallgarden; /* 0: off, 1: on */
    int block_https; /* 0: off, 1: on */
    __be32 ap_addr; /* local ap address */
    int list_number;
    ip_cmd_t wg_white_list[36];
    ip_cmd_t sni_white_list[36];
};
	

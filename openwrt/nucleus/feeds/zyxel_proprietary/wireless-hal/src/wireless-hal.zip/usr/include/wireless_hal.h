#ifndef WIRELESS_HAL_H
#define WIRELESS_HAL_H
#include "zld-spec.h"
#include <stdio.h>
#include <string.h>	
#include "linked-list.h"
#include <pthread.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/wait.h>
#include <stdint.h>
#include <stdlib.h>
#include <zykit.h>
#if (ZLDSYSPARM_ATHEROS_DRIVER_VERSION==110)
#include <endian.h>
#if defined(__LITTLE_ENDIAN)
#define	_BYTE_ORDER	_LITTLE_ENDIAN
#elif defined(__BIG_ENDIAN)
#define	_BYTE_ORDER	_BIG_ENDIAN
#else
#error "Please fix asm/byteorder.h"
#endif
#include <sys/types.h>
#include <ieee80211_external.h>
#endif /* ZLDSYSPARM_ATHEROS_DRIVER_VERSION==110 */

typedef pthread_mutex_t halLock_t ;
#define HALLOCK_INIT(_LOCK)	(pthread_mutex_init(& _LOCK,NULL))
#define HALLOCK_GET(_LOCK)	(pthread_mutex_lock(& _LOCK))
#define HALLOCK_PUT(_LOCK)	(pthread_mutex_unlock(& _LOCK))
#define HALLOCK_END(_LOCK)	(pthread_mutex_destroy(& _LOCK))

#define SSID_MAX_LENGTH	(33+1)
#define SEC_MAX_LENGTH		(33+1)
#define EADDR_LEN	6
#define RATE_LEN	10
#ifndef IFNAMSIZ
#define IFNAMSIZ		16
#endif
#define SYSTEM_CMD_LEN	128

#ifdef ZLDCONFIG_WLAN_WPA3_SUPPORT
#define DRIVER_SEC_LEN	32
#endif
/*Because of enahnced-open transition mode have to cnvert ssidname, and it ssid length will exceed 32.
   So we add the display ssid name length for ssid name on monitor */
#define DISPLAY_SSID_LEN 64

#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
/* wlan band */
enum whal_band_e {
    whal_band_24g,
    whal_band_5g,
    whal_band_invalid,
    whal_band_dual,
} ;

#define CAP_MAX_LEN	16
#define MAXSTACAPNUM ZLDSYSPARM_WLAN_MAX_CLIENT
#define STACAP_DURATION  (10*60)
#define STACAP_BAND_MASK whal_band_dual
#define STACAP_HTVHT_MASK (0xf - whal_band_dual)
#define DOT11_HTCAP 45
#define DOT11_VHTCAP 191
extern unsigned int MaxStapCap;
extern unsigned int StaCapPeriod;
#endif

/*copy from ath_iw_handler.c , used for ioctl to get driver counter*/
#ifndef ATH_IOCTL_GETMACMIB
#define ATH_IOCTL_GETMACMIB	(SIOCIWFIRSTPRIV+31)
#endif

/*copy from ieee80211_ioctl.h , used to verify wlan opmode*/
#define IEEE80211_ZYXEL_CLONE_BSSID	0x0001		/* allocate unique mac/bssid */
#define IEEE80211_ZYXEL_CRUDE_WDS	0x0004	/*ZyXEL CRUDE WDS*/

#define WIRELESSHAL_EVENT_PATH		"/tmp/wirelesshalevent"
#define WIRELESSHAL_DEBUG_PATH		"/tmp/wirelesshaldebug"
#define DOT11_ATH_WLANCONFIG		"wlanconfig"
#ifdef ZLDCONFIG_OVERLOADED_TXPOWER_ADJUST
#define DOT11_ATH_IWLIST		"iwlist"
#endif
#define DOT11_ATH_IWPRIV		"iwpriv"
#define DOT11_STR_AP_IFACE_PREFIX	"wlan-"
#define WIRELESS_HAL_PID_FILE_PATH          "/var/run/wireless-hal.pid"
#define WIRELESS_PROC_FILE			"/proc/net/wireless"

enum driver_notify {
	DRIVER_NOTIFY_CHANNEL_CHANGE, 
	DRIVER_NOTIFY_STA_ASSO,
	DRIVER_NOTIFY_STA_DISASSO,
	DRIVER_NOTIFY_STA_AUTHFAIL
};

enum debug_event {
	DEBUG_EVENT_CHANNEL_CHANGE, 
	DEBUG_EVENT_STA_ASSO,
	DEBUG_EVENT_STA_DISASSO,
	DEBUG_EVENT_STA_AUTHFAIL,
	DEBUG_EVENT_STA_RUNTIME_INFO,
	DEBUG_EVENT_DBG_LEVEL,
	DEBUG_EVENT_RESET_ERROR_COUNTER,
	DEBUG_EVENT_SHOW_CHANNEL,
	DEBUG_EVENT_SHOW_STATION_NUMBER,
	DEBUG_EVENT_SHOW_STATION_ENTRY,
	DEBUG_EVENT_SHOW_STATION_ENTRY_END,
	DEBUG_EVENT_SHOW_WLAN_STASTISTIC,
	DEBUG_EVENT_SHOW_DBG_LEVEL,
	DEBUG_EVENT_SHOW_ERROR_COUNTER
#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
	,DEBUG_EVENT_WDS_RUNTIME_INFO
	,DEBUG_EVENT_SHOW_WDS_GLOBAL
	,DEBUG_EVENT_SHOW_WDS_NUMBER
	,DEBUG_EVENT_SHOW_WDS_ENTRY
	,DEBUG_EVENT_SHOW_WDS_ENTRY_END
	,DEBUG_EVENT_SHOW_WDS_MAC
	,DEBUG_EVENT_WDS_UPLINK_CONNECTED
	,DEBUG_EVENT_WDS_UPLINK_DISCONNECTED
	,DEBUG_EVENT_WSTA_SCAN_BUFFER_FULL
	,DEBUG_EVENT_WDS_DOWNLINK_AUTHORIZED
	,DEBUG_EVENT_WSTA_AUTH_SUCCESS
#if defined(ZLDCONFIG_ZYMESH_SUPPORT) || defined(ZLDCONFIG_SMART_MESH_SUPPORT)
    ,DEBUG_EVENT_WDS_UPLINK_PRE_SHARE_KEY_WRONG
	,DEBUG_EVENT_PSTA_UPLINK_CONNECTED
	,DEBUG_EVENT_PSTA_UPLINK_DISCONNECTED
	,DEBUG_EVENT_RECV_NETLINK_FAIL
	,DEBUG_EVENT_PSTA_SCAN_BUFFER_FULL
#endif
#endif
#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
	,DEBUG_EVENT_SET_MAX_STATION_CAP
	,DEBUG_EVENT_SHOW_MAX_STATION_CAP
	,DEBUG_EVENT_SET_STA_CAP_PERIOD
	,DEBUG_EVENT_SHOW_STA_CAP_PERIOD
	,DEBUG_EVENT_SHOW_STATION_CAP_NUMBER
	,DEBUG_EVENT_SHOW_STATION_CAP_ENTRY
	,DEBUG_EVENT_SHOW_STATION_CAP_END
#endif
	,DEBUG_EVENT_SEARCH_STATION_ENTRY_BY_STAIP
	,DEBUG_EVENT_SEARCH_STATION_ENTRY_BY_STAIP_NOT_FOUND
	,DEBUG_EVENT_SEARCH_STATION_ENTRY_BY_STAMAC
	,DEBUG_EVENT_SEARCH_STATION_ENTRY_BY_STAMAC_NOT_FOUND
};

enum snmp_event {
	SNMP_GET_CURRENT_CHANNEL, 
	SNMP_GET_WLAN_STATISTIC,
	SNMP_GET_STA_NUM,
	SNMP_GET_STA_ENTRY,
	SNMP_GET_WLAN_TXRX,
	SNMP_GET_STA_ENTRY_END
};

/*copied from ath_iw_handler.c*/
struct dot11_mib_mac_count {
	uint32_t dot11TransmittedFragmentCount;
	uint32_t dot11MulticastTransmittedFrameCount;
	uint32_t dot11FailedCount;
	uint32_t dot11RetryCount;
	uint32_t dot11MultipleRetryCount;
	uint32_t dot11FrameDuplicateCount;
	uint32_t dot11RTSSuccessCount;
	uint32_t dot11RTSFailureCount;
	uint32_t dot11ACKFailureCount;
	uint32_t dot11ReceivedFragmentCount;
	uint32_t dot11MulticastReceivedFrameCount;
	uint32_t dot11FCSErrorCount;
	uint32_t dot11TransmittedFrameCount;
	uint32_t dot11WEPUndecryptableCount;
	uint32_t dot11QosDiscardedFragmentCount;
	uint32_t dot11AssociatedStationCount;
	uint32_t dot11QosCFPollsReceivedCount;
	uint32_t dot11QosCFPollsUnusedCount;
	uint32_t dot11QosCFPollsUnusableCount;
};

/*copied from _ieee80211.h*/
enum whal_ieee80211_opmode {
	WHAL_IEEE80211_M_STA		= 1,	/* infrastructure station */
	WHAL_IEEE80211_M_IBSS 	= 0,	/* IBSS (adhoc) station */
	WHAL_IEEE80211_M_AHDEMO	= 3,	/* Old lucent compatible adhoc demo */
	WHAL_IEEE80211_M_HOSTAP	= 6,	/* Software Access Point */
	WHAL_IEEE80211_M_MONITOR	= 8,	/* Monitor mode */
	WHAL_IEEE80211_M_WDS		= 2	/* WDS link */
};

/* wlan role defined for wireless-hal */
enum wlan_role {
	ROLE_UNKNOWN	= 0,	/* default */
	ROLE_AP,	
	ROLE_WDS,	
	ROLE_MONITOR,	
	ROLE_STA
};

typedef struct raStaIdx_s{
	int radioIdx;
	int staIdx;
#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
	int wds_role;
#endif
} raStaIdx_t;

typedef struct snmpStaInfo_s{
	char ssid[SSID_MAX_LENGTH];
	char security[SEC_MAX_LENGTH];
	unsigned char MAC[EADDR_LEN];
	uint32_t ipv4;
	time_t assoTime;
	char txRate[RATE_LEN];
	char rxRate[RATE_LEN];
	int rssi;
	int authorized;
	int vapId;
#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
	char bandmode[CAP_MAX_LEN];
	int bandcap;
	char dot11_cap[CAP_MAX_LEN];
#endif
	char display_ssid[DISPLAY_SSID_LEN];
	int vid;
} snmpStaInfo_t;

typedef struct staInfo_s{
	struct list_head list;
	int radioId;
	int vapId;
	char ssid[SSID_MAX_LENGTH];
	char security[SEC_MAX_LENGTH];
	unsigned char MAC[EADDR_LEN];
	uint32_t ipv4;
	time_t assoTime;
/* RunTime data */
	char txRate[RATE_LEN];
	char rxRate[RATE_LEN];
	int rssi;
#if 0 /* for future enhancement */
	char htcap[RATE_LEN];
#endif	
#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
	int wds_role;
#endif
	int authorized;
	char ifname[IFNAMSIZ+1];
	int authentication;
	int vid;
#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
       char bandmode[CAP_MAX_LEN];
	int bandcap;
	char dot11_cap[CAP_MAX_LEN];
#endif
#ifdef ZLDCONFIG_WLAN_WPA3_SUPPORT
	char display_ssid[DISPLAY_SSID_LEN];
#endif
} staInfo_t;

typedef struct wlanStatistic_s{
	int64_t FailedCount;
	int64_t RetryCount;
 	int64_t ACKFailureCount;
	int64_t ReceivedFragmentCount;
	int64_t TransmittedFrameCount;
	int64_t ReceivedPktCount;
	int64_t TransmittedPktCount;
	unsigned long long  TransmittedByte;
	unsigned long long  ReceivedByte;
	unsigned long long  wlanTransmittedByte;
	unsigned long long  wlanReceivedByte;
	/* for WEB GUI */	
	int64_t FCSErrorCount;
	int     txpower;
	int     chUtil;
} wlanStatistic_t;

typedef union snmpMsg_s{
	int radioIdx;
	raStaIdx_t rStaIdx;
	int chann;
	wlanStatistic_t wlanCounter;
	int staNum;
	snmpStaInfo_t snmpStaInfo;
} snmpMsg_t;

typedef struct snmpEventMsg_s{
	pid_t pid;
	int code;
	snmpMsg_t msg;
} snmpEventMsg_t;

#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
#if defined(ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER)
#define DOT11_STR_WDS_IFACE_PREFIX	"wlds-"
#else
#define DOT11_STR_WDS_IFACE_PREFIX	"wds-"
#endif
#define WDS_AP_INDEX 8
#define WDS_STA_INDEX 9
#define WDS_NO_UPLINK 0
#define WDS_HAVE_UPLINK 1
#define AUTH_SUCCESS    1
#if defined(ZLDCONFIG_ZYMESH_SUPPORT) || defined(ZLDCONFIG_SMART_MESH_SUPPORT)
#define PSTA_INDEX 11
#endif
#define DOT11_ATH_IWCONFIG		"iwconfig"
#define LINK_UP 1
#define LINK_DOWN 0
#define LINK_UNKNOWN -65535
#define MAX_SLOT ZLDSYSPARM_WLAN_MAX_SLOT
extern int ETH_FLAG;
#if defined(ZLDCONFIG_ZYMESH_SUPPORT) || defined(ZLDCONFIG_SMART_MESH_SUPPORT)
extern int PSTA_UP;
#endif

#endif

enum role{
	ROLE_NONE=0
#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
	,WDS_ROLE_DL=1
	,WDS_ROLE_UL=2
#endif
#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
	,ROLE_CAP=4
#endif
};

typedef struct wlanInfo_s{
	int staNum[ZLDSYSPARM_WLAN_MAX_SLOT];
	struct list_head staList[ZLDSYSPARM_WLAN_MAX_SLOT];
	halLock_t staLock[ZLDSYSPARM_WLAN_MAX_SLOT];
	int channel[ZLDSYSPARM_WLAN_MAX_SLOT];
	int extoffset[ZLDSYSPARM_WLAN_MAX_SLOT];
	int vht_ch_freq[ZLDSYSPARM_WLAN_MAX_SLOT];
	int vht_ch_freq2[ZLDSYSPARM_WLAN_MAX_SLOT];
#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
	struct list_head stacap;
	halLock_t stacapLock;
	int stacapNum;
#endif
#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
	int wdsdlNum[ZLDSYSPARM_WLAN_MAX_SLOT];
	struct list_head wdsdlList[ZLDSYSPARM_WLAN_MAX_SLOT];
	halLock_t wdsdlLock[ZLDSYSPARM_WLAN_MAX_SLOT];
	int wdsulNum[ZLDSYSPARM_WLAN_MAX_SLOT];
	struct list_head wdsulList[ZLDSYSPARM_WLAN_MAX_SLOT];
	halLock_t wdsulLock[ZLDSYSPARM_WLAN_MAX_SLOT];
	char ssidInfo[ZLDSYSPARM_WLAN_MAX_SLOT][2*ZLDSYSPARM_WLAN_MAX_AP][SSID_MAX_LENGTH];
	char securityMode[ZLDSYSPARM_WLAN_MAX_SLOT][2*ZLDSYSPARM_WLAN_MAX_AP][SEC_MAX_LENGTH];
	int wlanRole[ZLDSYSPARM_WLAN_MAX_SLOT][2*ZLDSYSPARM_WLAN_MAX_AP];
	char wdsMac[ZLDSYSPARM_WLAN_MAX_SLOT][2][EADDR_LEN];
#if defined(ZLDCONFIG_RRM_SUPPORT)
	int zy1x[ZLDSYSPARM_WLAN_MAX_SLOT][2*ZLDSYSPARM_WLAN_MAX_AP];
#endif
#else
#ifdef ZLDCONFIG_WLAN_WPA3_SUPPORT
	char ssidInfo[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP*2][SSID_MAX_LENGTH];
	char securityMode[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP*2][SEC_MAX_LENGTH];
	int wlanRole[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP*2];	
#if defined(ZLDCONFIG_RRM_SUPPORT)
	int zy1x[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP*2];
#endif	
#else
	char ssidInfo[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP][SSID_MAX_LENGTH];
	char securityMode[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP][SEC_MAX_LENGTH];
	int wlanRole[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP];	
#if defined(ZLDCONFIG_RRM_SUPPORT)
	int zy1x[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP];
#endif
#endif
#endif
	char display_ssid[ZLDSYSPARM_WLAN_MAX_SLOT][ZLDSYSPARM_WLAN_MAX_AP*2][DISPLAY_SSID_LEN];
} wlanInfo_t;

#if 1 /* for debug use*/
typedef struct debugChann_s{
	int radioIdx;
	int channel;
} debugChann_t;

typedef struct debugSta_s{
	int radioIdx;
	char ssid[SSID_MAX_LENGTH];
	unsigned char MAC[EADDR_LEN];
	int vapIdx;
	uint32_t ipv4;
	int vid;
} debugSta_t;

typedef struct channInfo_s{
	int channel;
	int extoffset;
	int vht_ch_freq;
	int vht_ch_freq2;
	int ch_util;
} channInfo_t;

typedef struct errorCounter_s{
	/* domain socket related */
	int DMSoketAcceptError;
	int DMSoketSizeError;
	int DMSoketEventMsgTooLarge;
	int DMSoketWriteEventMsgError;
	/* SNMP event related */
	int SNMPWlnaSlotError;
	int SNMPEventTypeError;
	/* wireless counter related */
	int DriverSocketCreatError;
	int DriverIoctlFail;
	/* netlink socket related */
	int NLSoketMsgError;
	int NLSoketUnknowMsgSubtype;
	int NLSoketUnknowInfoSubtype;
	int NLSoketUnknowEventType;
	/* station info. related */
	int StaDuplicate;
	int StaDeleteFail;
	int StaNotFind;
} errorCounter_t;

typedef union debugMsg_s{
	int radioIdx;
	raStaIdx_t rStaIdx;	
	debugChann_t channInfo;
	debugSta_t staInfo;
	unsigned long dbg_level;
	snmpStaInfo_t snmpStaInfo;
	wlanStatistic_t wlanCounter;	
	errorCounter_t errorCount;
	int staNum;
	channInfo_t chann;
} debugMsg_t;

typedef struct debugEventMsg_s{
	pid_t pid;
	int code;
	debugMsg_t msg;
} debugEventMsg_t;
#endif


extern unsigned long WirelessHaldebugFlag;
extern int console_fd;
#define WIRELESS_HAL_DBG_STR_LEN			300

static inline void system_cmd(char *fmt, ...)
{
	char buffer[256];
	va_list args;

	if(fork()) {
		wait(NULL);
	} else {
		if(fork()) {
			_exit(0);
		} else {
			va_start(args, fmt);
			vsprintf(buffer, fmt, args);
			system(buffer);
			va_end(args);
			_exit(0);
		}
	}
}

#define hal_printf(format, args...) \
	do { \
		if( console_fd >= 0) \
		{\
			char *__dbg_buf; \
			__dbg_buf = (char *)GetDbgStr(); \
			snprintf(__dbg_buf,(size_t)WIRELESS_HAL_DBG_STR_LEN,(const char*)("%s:%d:"format"\n\r"),__FILE__,__LINE__,## args); \
			write(console_fd, __dbg_buf, strlen(__dbg_buf)); \
		}\
	} while ( 0 )


#define HAL_DEBUG_NLSOCKET		0x00000001
#define HAL_DEBUG_NLEVENT			0x00000002
#define HAL_DEBUG_DBGSOCKET		0x00000004
#define HAL_DEBUG_DBGEVENT		0x00000008
#define HAL_DEBUG_DMSOCKET		0x00000010
#define HAL_DEBUG_DMEVENT			0x00000020
#define HAL_DEBUG_ERROR			0x00000040
#define HAL_DEBUG_STA				0x00000080
#define HAL_DEBUG_STASTISTIC		0x00000100

#define HAL_DEBUG_ALL			0xffffffff


/*debug flags*/
#define HALprintNetLinkSocket	if (WirelessHaldebugFlag & HAL_DEBUG_NLSOCKET)	hal_printf
#define HALprintNetLinkEvent				if (WirelessHaldebugFlag & HAL_DEBUG_NLEVENT)		hal_printf
#define HALprintDebugSocket			if (WirelessHaldebugFlag & HAL_DEBUG_DBGSOCKET)		hal_printf
#define HALprintDebugEvent				if (WirelessHaldebugFlag & HAL_DEBUG_DBGEVENT)		hal_printf
#define HALprintDomainSocket			if (WirelessHaldebugFlag & HAL_DEBUG_DMSOCKET)		hal_printf
#define HALprintDomainEvent				if (WirelessHaldebugFlag & HAL_DEBUG_DMEVENT)		hal_printf
#define HALprintError				if (WirelessHaldebugFlag & HAL_DEBUG_ERROR)	hal_printf
#define HALprintSTA			if (WirelessHaldebugFlag & HAL_DEBUG_STA)		hal_printf
#define HALprintStastistic			if (WirelessHaldebugFlag & HAL_DEBUG_STA)		hal_printf
#define HALprintAll			if (WirelessHaldebugFlag & HAL_DEBUG_STASTISTIC)		hal_printf

int32_t wirelessHalEvtLoop(void* param);
int32_t wirelessDriverEvtLoop(void* param);
#ifdef ZLDCONFIG_UBUS_SUPPORT
int UbusEvtLoop(void);
#endif
int wirelessHalDebugLoop(void* param);
wlanInfo_t* wirelessHalGetWlanInfo(void);
errorCounter_t* wirelessHalGetErrorCounter(void);
void OpenDbgFd(void);
void CloseDbgFd(void);
void CloseEvtFd(void);
void CloseDbgEvtFd(void);
void setDebugLevel(unsigned long);
unsigned long GetDebugLevel(void);
char * GetDbgStr(void);
int initWirelessHal(void);
void resetErrorCounter(void);
void initStationInfo(int, wlanInfo_t *);
int initSocket (void);
staInfo_t *searchStaByIP(wlanInfo_t *, int , uint32_t, int );
staInfo_t *searchStaByMAC(wlanInfo_t *, int , unsigned char *, int );
staInfo_t *searchStaById(wlanInfo_t *, int , int , int );
#ifdef ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT
int32_t staInfoDel(wlanInfo_t *, int , int ,  unsigned char *, int );
staInfo_t *searchStaInList(wlanInfo_t *, int , char *, int );
void getstationinfo(wlanInfo_t *, int , int );
void staInfoPrintList(wlanInfo_t *, int );
void getWDSULRunTimeInfo(wlanInfo_t *, int , int );
void getWDSMac(wlanInfo_t *, int , int , snmpStaInfo_t *);
int set_eth0_port_disable(void);
int set_eth0_port_enable(void);
#else
staInfo_t *searchStaInList(wlanInfo_t *, int , char *);
int32_t staInfoDel(wlanInfo_t *, int , int, unsigned char *);
void getstationinfo(wlanInfo_t *, int);
void staInfoPrintList(wlanInfo_t *);
#endif
int32_t staInfoAdd(wlanInfo_t *, int , staInfo_t *, int);
#ifdef ZLDCONFIG_WLAN_CLIENT_INFO
int updateStaCap(wlanInfo_t *, unsigned char *, int , int , int);
int checkAssocStaCapchange(wlanInfo_t *, unsigned char *, int);
int hal_netlink_event_send(int, char *, int, const int, const size_t,
			   const void *);
int setstaCap_by_netlink(char *, unsigned char *, int );
void copyStaCapToSnmpStaCap(snmpStaInfo_t *,staInfo_t*);
void setMaxStapCap(unsigned int);
unsigned int GetMaxStapCap(void);
void setStaCapPeriod(unsigned int);
unsigned int GetStaCapPeriod(void);
#endif
void copyStaInfoToSnmpStaInfo(snmpStaInfo_t *,staInfo_t*);
int getInterfaceIdx(char *, int *, int *);
int getIfaceRxTxPkt( int , wlanStatistic_t * );
int getDriverCounter(int , wlanStatistic_t *);
int getIfaceTxPower(int , wlanStatistic_t *);
int getIfaceChUtil(int , wlanStatistic_t *);
int getWlanRole(int, int);
void resetWlanStatistic(wlanStatistic_t *);
void resetIfaceRxTx(wlanStatistic_t *);
void resetIfaceTxPower(wlanStatistic_t *ptr);
void resetIfaceChUtil(wlanStatistic_t *ptr);
int get_lan_rx_tx(wlanStatistic_t *ptr);
void reset_lan_rx_tx(wlanStatistic_t *ptr);
int wds_link_client_socket_send(int slot, int connection);
int psta_link_client_socket_send(int slot, int connection);
int wds_check_link(wlanInfo_t *wlanInformation);
int32_t uplinkInfoDel(wlanInfo_t *wlanInfo, int radioIdx, unsigned char *macAddr, int wds_role);

#endif /* WIRELESS_HAL_H */

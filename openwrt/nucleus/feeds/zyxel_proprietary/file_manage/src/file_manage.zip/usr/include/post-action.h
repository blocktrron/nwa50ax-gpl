#ifndef POST_ACTION_H
#define POST_ACTION_H

#define CLASSIFY_ASK 1
#define CLASSIFY_END 2
#define RUN_POST_ACTION 3
#define PROFTPD_PR_RESPONSE 4
#define POST_ACTION_FINISH 5
 
#define ETC "/etc"
#define ETC_ZYXEL "/etc/zyxel"
#define ETC_ZYXEL_FTP "/etc/zyxel/ftp"
#define TMP "/.tmp"
#define FTP_TMP_DIR "/etc/zyxel/ftp/.tmp"
#define FTOK_CLASSIFY_WO_CHROOT "/etc/zyxel/ftp/.classify"
#define FTOK_CLASSIFY_W_CHROOT "/.classify"
#define FTOK_PROFTPD_WO_CHROOT "/etc/zyxel/ftp/.proftpd"
#define FTOK_PROFTPD_W_CHROOT "/.proftpd"

#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
#define CLASSIFY  "/util/classify"
#define FTOK_DEVICE_HA_SYNC_WO_CHROOT "/etc/zyxel/ftp/.dha-sync"
#define FTOK_DEVICE_HA_SYNC_W_CHROOT "/.dha-sync"
#define FTP_DOT_TMP_MOUNTED_FILE	"/tmp/ftp_tmp_mounted"
#define FTP_TMP_DIR_RAMDISK "/dev/ram0"
#define ZLD_CURRENT "/etc/zyxel/ftp/Firmware"
#define FTP_ROOT_DIR "/db/etc/zyxel/ftp"
#else
#define FTP_ROOT_DIR "/etc/zyxel/ftp"
#endif

#define CP_BIN "/bin/cp"
#define DD_BIN "/bin/dd"
#define RM_BIN "/bin/rm"

struct apps_type
{
	char	*orig_path;
	char	*program;
	unsigned int  wdt_timeout;	//software watchdog timeout value ; unit:in seconds
	unsigned int  dir_quota;	//dir quota total filesize limit  ; unit:in kilo bytes
};

#define MSGMAX 8192

typedef struct {
	long mtype;	 /* message type, must be > 0 */
	char mtext[MSGMAX];	 /* message data */
} mbuf;

typedef struct {
	char orig_path[MSGMAX/8];
	char fake_path[MSGMAX/8];
	int  msgid_proftpd;
	int  pa_idx;
	int  pa_result;
}classify_buf;

typedef enum {
	POST_ACTION_OK,
	POST_ACTION_FAIL_UNKNOWN,
	POST_ACTION_FAIL_MEM_NOT_ENOUGH,
	POST_ACTION_FAIL_DISK_NOT_ENOUGH,
	POST_ACTION_FAIL_SIGNATURE_ERROR,
	POST_ACTION_FAIL_FILE_DAMAGED,
	POST_ACTION_FAIL_UPDATE_FAILED,
	POST_ACTION_FAIL_NOT_REGISTERED_FILE,
	POST_ACTION_FAIL_INVALID_FIRMWARE,
	POST_ACTION_FAIL_OVER_DIR_QUOTA,
	POST_ACTION_FAIL_OVER_SOFTWARE_WATCHDOG_TIMEOUT_VALUE,
	POST_ACTION_FAIL_UPLOAD_FILE_DISAPPEAR,
	POST_ACTION_FAIL_PRODUCT_MODEL_ID_CHANGED,
	POST_ACTION_FAIL_FIRMWARE_PRODUCT_MODEL_NOT_COMPATIBLE,
	POST_ACTION_FAIL_IDP_UPDATE,
/* 20060413 add by wilson for signature update checking */
	POST_ACTION_FAIL_EXTRACT,
	POST_ACTION_FAIL_SIGNATURE_CONTENT,
	POST_ACTION_FAIL_SIGNATURE_CONFIG, 
	POST_ACTION_FAIL_LAV_UPDATING,
	POST_ACTION_FAIL_INTERNAL_ERROR,
	POST_ACTION_FAIL_REMOVE_FILE,
	POST_ACTION_FAIL_REPLACE_FILE,
	POST_ACTION_FAIL_DIFF_SIG_TYPE,
	POST_ACTION_FAIL_INVALID_UPDATE, 
} pa_result_enum;

typedef struct {
	int pa_result;
	char *pa_result_string;
} post_action_result_table;

static post_action_result_table pa_rt[] = {
	{ POST_ACTION_OK,"Post action ok"},
	{ POST_ACTION_FAIL_UNKNOWN,"unknown reason"},
	{ POST_ACTION_FAIL_MEM_NOT_ENOUGH,"memory not enough"},
	{ POST_ACTION_FAIL_DISK_NOT_ENOUGH,"disk not enough"},  
	{ POST_ACTION_FAIL_SIGNATURE_ERROR,"signature error"},  
	{ POST_ACTION_FAIL_FILE_DAMAGED,"file damaged"},
	{ POST_ACTION_FAIL_UPDATE_FAILED,"update failed"},
	{ POST_ACTION_FAIL_NOT_REGISTERED_FILE,"not registered file"},
	{ POST_ACTION_FAIL_INVALID_FIRMWARE,"invalid firmware"},
	{ POST_ACTION_FAIL_OVER_DIR_QUOTA,"Over specified directory quota"},
	{ POST_ACTION_FAIL_OVER_SOFTWARE_WATCHDOG_TIMEOUT_VALUE,"Over software watchdog timeout value"},
	{ POST_ACTION_FAIL_UPLOAD_FILE_DISAPPEAR,"Upload file disappears!!Maybe multiple users are uploading the same file"},
	{ POST_ACTION_FAIL_PRODUCT_MODEL_ID_CHANGED,"Product Model is changed by someone"},
	{ POST_ACTION_FAIL_FIRMWARE_PRODUCT_MODEL_NOT_COMPATIBLE,"Firmware product model ids are all not compatible to this product"},
	{ POST_ACTION_FAIL_IDP_UPDATE, "IDP update is running! Skip IDP synchronizing!"},
/* 20060413 add by wilson for signature update checking */
	{ POST_ACTION_FAIL_EXTRACT,"Signature extract failed"},
	{ POST_ACTION_FAIL_SIGNATURE_CONTENT,"Invalid signature content"},
	{ POST_ACTION_FAIL_SIGNATURE_CONFIG,"Invalid IDP config file"},
	{ POST_ACTION_FAIL_LAV_UPDATING, "AV signature updating is already in progress"},
	{ POST_ACTION_FAIL_INTERNAL_ERROR, "System internal error. AV signature cannot be updated"},
	{ POST_ACTION_FAIL_REMOVE_FILE, "Removing original signatures has failed"},
	{ POST_ACTION_FAIL_REPLACE_FILE, "Replacing original signatures has failed"},
	{ POST_ACTION_FAIL_DIFF_SIG_TYPE, "Updated signature type is different with current one"},
	{ POST_ACTION_FAIL_INVALID_UPDATE, "Invalid update type"},
};

int pr_response_request(int msgid,const char *fmt, ...);
#endif

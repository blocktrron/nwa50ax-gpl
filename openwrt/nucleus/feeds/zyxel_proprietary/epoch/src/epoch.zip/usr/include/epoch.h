#ifndef	EPOCH_H_
#define EPOCH_H_

#include <stdio.h>
#include <sys/time.h>
#include <stdint.h>

void get_epoch(uint64_t *epoch);

#endif

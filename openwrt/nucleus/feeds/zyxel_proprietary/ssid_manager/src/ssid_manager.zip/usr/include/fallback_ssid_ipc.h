#ifndef _FALLBACK_SSID_IPC_H_
#define _FALLBACK_SSID_IPC_H_
#include <stdint.h>
#define EVENT_WLANCONFIG_CHANGE 1
#define EVENT_SSIDSTATUS_CONTROL 2
#define EVENT_CAPWAPSTATUS_CHANGE 3
#ifdef ZLDCONFIG_REMOTE_AP_CLIENT_SUPPORT
#define EVENT_IPSECSTATUS_CHANGE 4
#endif
#ifdef ZLDCONFIG_CAMPUS_AP_CLIENT_SUPPORT
#define EVENT_DFDISCOVERSTATUS_CHANGE 5
#endif

int fallback_ssid_ipc_send_event_no_wait(uint16_t type, uint16_t len, char *value);

#endif /* _FALLBACK_SSID_IPC_H_ */




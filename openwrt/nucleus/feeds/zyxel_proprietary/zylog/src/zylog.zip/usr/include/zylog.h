/* $Id: zylog.h,v 1.93 2008/06/06 05:45:54 ncheng Exp $ */

/*
 * $Log: zylog.h,v $
 * Revision 1.93  2008/06/06 05:45:54  ncheng
 * Zyklog enhancement - Phase II
 *
 * Revision 1.92  2008/05/29 12:09:47  stan.hung
 * log-statistic from kernel space to user space
 *
 * Revision 1.91  2008/05/29 00:52:11  juwu
 * *** empty log message ***
 *
 * Revision 1.90  2008/04/15 02:53:01  ncheng
 * DHCP enhancements - Add DHCP logs.
 *
 * Revision 1.89  2008/03/18 00:05:22  hchou
 * Add IP-MAC binding support.
 *
 * Revision 1.88  2008/01/24 14:02:48  alexlee
 * support cef format
 *
 * Revision 1.87  2007/10/31 06:25:25  saxont
 * fix 071030680
 *
 * Revision 1.86  2007/09/28 11:29:45  kl.chiang
 * Add cellular log category
 *
 * Revision 1.85  2007/07/24 04:44:01  hchou
 * Modified for transparent agent (TA) support.
 *
 * Revision 1.84  2007/07/10 11:13:22  kuoshou
 * modify for email-daily-report init version
 *
 * Revision 1.83  2007/06/01 08:47:13  bato.wang
 * Add Wlan
 *
 * Revision 1.82  2007/05/30 01:26:43  daniel.lin
 * Add anti-spam comment.
 *
 * Revision 1.81  2007/05/07 11:59:51  peterwang
 * Add KAV Support
 *
 * Revision 1.80  2007/04/18 11:06:33  peterwang
 * Remove WBL category
 *
 * Revision 1.79  2007/03/12 03:34:06  wilsonchen
 * For add ADP log category
 *
 * Revision 1.78  2006/09/26 12:36:49  juyu
 * New enhancement Dial-in Management.
 *
 * Revision 1.77  2006/09/25 00:54:34  hchou
 * Add CNM base agent support.
 *
 * Revision 1.76  2006/09/14 14:07:39  peterwang
 * Add for LAV
 *
 * Revision 1.75  2006/09/14 09:05:55  peterwang
 * Add support for LAV
 *
 * Revision 1.74  2006/09/05 04:17:21  rogerho
 * SSL VPN
 *
 * Revision 1.73  2006/08/24 01:19:52  daniel.lin
 * Use zld-spec.h to define centralize log related parameters.
 *
 * Revision 1.72  2006/07/27 03:30:39  peterwang
 * *** empty log message ***
 *
 * Revision 1.71  2006/07/27 01:41:43  peterwang
 * Remove zld-spec.h include
 *
 * Revision 1.70  2006/07/27 00:58:13  peterwang
 * Remove L2TP over IPSec compiler flag
 *
 * Revision 1.69  2006/07/26 23:49:31  peterwang
 * Add for L2TP over IPSec
 *
 * Revision 1.68  2006/07/14 06:41:27  shunchao
 * enhance VRPT log format to version 2.26 2.27 2.28 2.37 for IKE, traffic log
 *
 * Revision 1.67  2006/06/29 07:20:38  saxont
 * add interface_statistics
 *
 * Revision 1.66  2006/06/03 07:44:40  lachang
 * fix SPR060603179
 *
 * Revision 1.65  2006/05/29 06:35:20  lachang
 * do resource protectiong and modify the log of sending mail SPR060522312
 *
 * Revision 1.64  2006/05/22 06:07:27  lachang
 * modify mail_format
 *
 * Revision 1.63  2006/04/17 02:44:35  edward
 * obsolete category content-filter-forward
 *
 * Revision 1.62  2006/02/16 11:14:51  lachang
 * modify firewall VRPT format
 *
 * Revision 1.61  2006/02/16 06:16:47  eddieho
 * SHOW category was removed.
 *
 * Revision 1.60  2006/01/24 01:54:01  peterwang
 * add zylog definition for Force User Authentication
 *
 * Revision 1.59  2006/01/03 05:00:18  lachang
 * change the data type of log_num
 *
 * Revision 1.58  2005/12/06 08:52:42  lachang
 * fix GUI "sending-now" behavior
 *
 * Revision 1.57  2005/11/25 09:56:35  lachang
 * add semphore debug imformation
 *
 * Revision 1.55  2005/10/06 06:55:08  eddieho
 * ZYLOG_SRC_SHOW & ZYLOG_FAC_SHOW were added.
 *
 * Revision 1.54  2005/09/27 09:11:11  edward
 * make content filter forward logs another category
 *
 * Revision 1.53  2005/09/15 07:55:11  saxont
 * add port-grouping
 *
 * Revision 1.52  2005/09/07 14:41:56  kl.chiang
 * add dynamic route
 *
 * Revision 1.51  2005/09/07 13:25:12  saxont
 * add interface and account
 *
 * Revision 1.50  2005/09/07 06:29:44  lachang
 * add ZYLOG_MAILMAN_BIN
 *
 * Revision 1.49  2005/09/07 05:33:50  hwtseng
 * add PKI LOG
 *
 * Revision 1.48  2005/09/05 06:18:12  rogerho
 * add ZYLOG_SRC_NAT,ZYLOG_FAC_NAT
 *
 * Revision 1.47  2005/08/29 09:41:00  peterwang
 * add ZYLOG_SRC_DEVICE_HA
 *
 * Revision 1.46  2005/08/29 08:27:20  edward
 * support enable/disable log suppression
 *
 * Revision 1.45  2005/08/24 12:53:38  herenlin
 * modify for ftp file manage
 *
 * Revision 1.44  2005/08/23 08:35:24  lachang
 * add "log filter && log persistent"
 *
 * Revision 1.43  2005/08/23 01:35:35  edward
 * change console device to ttyS0
 *
 * Revision 1.42  2005/08/19 07:28:14  rogerho
 * add connectivity check facility and source
 *
 * Revision 1.41  2005/08/15 06:18:46  fannyk
 * replace command notation
 *
 * Revision 1.40  2005/08/15 06:17:23  fannyk
 * replace command notation.
 *
 * Revision 1.39  2005/08/09 07:02:09  lachang
 * omit mail server && syslog server config ordering
 *
 * Revision 1.38  2005/08/08 09:00:53  fannyk
 * add ZYLOG_SRC_SYSTEM/ZYLOG_FAC_SYSTEM for ntp update
 *
 * Revision 1.37  2005/08/01 12:55:58  eddieho
 * ZYLOG_SRC_POLICY_ROUTE & ZYLOG_FAC_POLICY_ROUTE were added.
 *
 * Revision 1.36  2005/07/27 12:40:41  shunchao
 * log the built-in service access denied
 *
 * Revision 1.35  2005/07/26 03:17:58  lachang
 * add "mail size limit"
 *
 * Revision 1.34  2005/07/14 02:11:43  lachang
 * add csum
 *
 * Revision 1.33  2005/07/05 08:52:05  lachang
 * zylog-enhancement
 *
 */

#ifndef _ZYLOG_H
#define _ZYLOG_H

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <time.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <syslog.h>
#include <netinet/in.h>

#include <regex.h>

#include <sys/socket.h>
#include <asm/types.h>
#include <zld/netlink_extern.h>
#include <linux/version.h>

#include "zld-spec.h"
#include "zld/k_ifacename_change.h"

/* log system parameters */
#define ZYLOG_MAIL_SIZE				1048576
#define ZYLOG_SYSTEM_LOG_NUM		ZLDSYSPARM_EVENT_LOG_ENTRY_MAX_NUM
#define ZYLOG_DEBUG_LOG_NUM			ZLDSYSPARM_DEBUG_LOG_ENTRY_MAX_NUM

#define ZYLOG_USBSTORAGE_BUF_LEN	4096
#define ZYLOG_MAX_SINGLE_MSG_LEN	1024
#define ZYLOG_MAX_MESSAGE_LEN		1024
#define ZYLOG_MAX_NOTE_LEN			32
#ifdef AAA_WEB_PORTAL
#define ZYLOG_MAX_USERNAME_LEN		(ZLDSYSPARM_UAM_USER_NAME_LEN)
#else
#define ZYLOG_MAX_USERNAME_LEN		32
#endif
#define ZYLOG_MAIL_NUM				ZLDSYSPARM_LOG_EMAIL_SERVER_SUPPORT
#define ZYLOG_REMOTE_SERVER_NUM		ZLDSYSPARM_LOG_SYSLOG_SERVER_SUPPORT

#define ZYLOG_SYSTEM_SUPPRESS_INTERVAL	10
#define ZYLOG_DEBUG_SUPPRESS_INTERVAL	10
#define ZYLOG_MAIL_CONSOLIDATION_INTERVAL	2

#define ZYLOG_MAX_CONSOLIDATION_COUNT	255
#define ZYLOG_MAX_MSMTP_COUNT 100	/* maximum msmtp process */

#define ZYLOG_REMOTE_SERVER_FIFO_NAME	"/tmp/zylog_fifo"	/* default name for syslog-ng fifo */
#define ZYLOG_CONSOLE_DEVICE			"/dev/ttyS0"
#define ZYLOGD_PID_FILE					"/var/run/zylogd.pid"

#define ZYLOG_MAIL_TEMP_DIR				"/tmp/"
#define ZYLOG_MAIL_EVENT_FILE			"event"
#define ZYLOG_MAIL_ALERT_FILE			"alert"

#define ZYLOG_MSMTP_BIN					"/usr/sbin/msmtp"
#define ZYLOG_MSMTP_RC					"/etc/msmtprc"
#define ZYLOG_MSMTP_TIMEOUT				10

#define ZYLOG_FLAGS_LOOKUP_USER			(1 << 0)
#define ZYLOG_FLAGS_NO_SUPPRESSION		(1 << 1)
#define ZYLOG_FLAGS_IPV6_ENABLE			(1 << 2)
#define ZYLOG_FLAGS_CLEAR_HOSTNAME		(1 << 3)
#define ZYLOG_FLAGS_PRINTK_MSG			(1 << 4)
#define ZYLOG_FLAGS_SEND_TO_AC			(1 << 5)

/*Protocol name string */
#define ZYLOG_PROTONAME_TCP   "tcp"
#define ZYLOG_PROTONAME_UDP   "udp"
#define ZYLOG_PROTONAME_ICMP  "icmp"
#define ZYLOG_PROTONAME_OTHER "others"

/* priority */
#define ZYLOG_PRI_EMERG		LOG_EMERG           /* system is unusable */
#define ZYLOG_PRI_ALERT		LOG_ALERT           /* action must be taken immediately */
#define ZYLOG_PRI_CRIT		LOG_CRIT            /* critical conditions */
#define ZYLOG_PRI_ERR		LOG_ERR             /* error conditions */
#define ZYLOG_PRI_WARNING	LOG_WARNING         /* warning conditions */
#define ZYLOG_PRI_NOTICE	LOG_NOTICE          /* normal but significant condition */
#define ZYLOG_PRI_INFO		LOG_INFO            /* informational */
#define ZYLOG_PRI_DEBUG		LOG_DEBUG           /* debug-level messages */

#define ZYLOG_EVENT_LOG_LEVEL			ZYLOG_PRI_INFO
#define ZYLOG_DEBUG_LOG_LEVEL			ZYLOG_PRI_DEBUG
#define ZYLOG_ALERT_LEVEL				ZYLOG_PRI_CRIT

#define ZYLOG_CONSOLE_LEVEL				ZYLOG_PRI_EMERG

/* keys */
#define ZYLOG_LOCK_KEY		0x12340001
#define ZYLOG_BUFFER_KEY	0x12340002
#define ZYLOG_LOCK_STATISTIC_SEM_KEY	0x12340003
#define ZYLOG_LOCK_STATISTIC_SHM_KEY	0x12340004
#define ZYLOG_USLOCK_KEY		0x12340005
/* for debugging */
#ifdef ENABLE_ZYLOG_DEBUG
#define ZYLOG_DEBUG(fmt, args...)	fprintf(stderr, "%s %s: " fmt, __FILE__, __FUNCTION__, ##args)
#else
#define ZYLOG_DEBUG(fmt, args...)
#endif

/* for log persistence */
#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
#define BACK "/etc_writable/backup"
#define BACK_DEBUG "/etc_writable/backup1"
#define BACK_JSON "/etc_writable/backup_json"
#else
#define BACK "/etc/zyxel/ftp/diaglog/backup"
#define BACK_DEBUG "/etc/zyxel/ftp/diaglog/backup1"
#define BACK_JSON "/etc/zyxel/ftp/diaglog/backup_json"
#endif
/* 20090825 vincent added for WTP Logs */
#if (defined(ZLDCONFIG_CAPWAP_AC_WTP_LOGS_SUPPORT) || defined(ZLDCONFIG_CAPWAP_WTP_WTP_LOGS_SUPPORT))
#define WTP_LOG_SYS "/tmp/wtpLogs_sys"
#define WTP_LOG_DEBUG "/tmp/wtpLogs_debug"
#define WTP_LOG_SYS_INFO "/tmp/wtpLogs_sys_info.txt"
#define WTP_LOG_DEBUG_INFO "/tmp/wtpLogs_debug_info.txt"
#define JSON_FORMAT "json"
#endif
#define ZYLOG_MAX_COVERT_MESSAGE_LEN        ZYLOG_MAX_MESSAGE_LEN+50

/* Zylog netlink message type */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
enum {
	ZYLOG_NL_U_BASE = 16,
	ZYLOG_NL_U_MSG,
	ZYLOG_NL_U_PID,
	ZYLOG_NL_U_MAX,
};
#else
#define ZYLOG_NL_U_MSG		1
#define ZYLOG_NL_U_PID		2
#endif
#define ZYLOG_NL		28

#define MAX_PAYLOAD		512

#define MAX_PROTO_NAME_LEN  16
/* structures */
struct zylog_buffer {
	int     shmid;
	void    *addr;
	key_t   key;
};

/* log sources */
enum zylog_sources {
	ZYLOG_SRC_DEFAULT = 0,	/* Don't touch */
        
	ZYLOG_SRC_CONTENT_FILTER,
	ZYLOG_SRC_FORWARD_WEB_SITES,
	ZYLOG_SRC_BLOCKED_WEB_SITES,
	ZYLOG_SRC_WARNING_WEB_SITES,
	ZYLOG_SRC_UAM,
	ZYLOG_SRC_MYZYXEL_DOT_COM,
	ZYLOG_SRC_ZYSH,
	ZYLOG_SRC_IDP,
	ZYLOG_SRC_AS,
	ZYLOG_SRC_TRAFFIC,
	ZYLOG_SRC_FILE_MANAGE,
	ZYLOG_SRC_APP_PATROL,
	ZYLOG_SRC_BWM,
	ZYLOG_SRC_IKE,
	ZYLOG_SRC_IPSEC,
	ZYLOG_SRC_FIREWALL,
	ZYLOG_SRC_SESSIONS_LIMIT,
	ZYLOG_SRC_AV,
	ZYLOG_SRC_POLICY_ROUTE,
	ZYLOG_SRC_BUILTIN_SERVICE,
	ZYLOG_SRC_SYSTEM,
	ZYLOG_SRC_SYSTEM_MONITORING, /* vrpt use */
	ZYLOG_SRC_CONNECTIVITY_CHECK,
	ZYLOG_SRC_DEVICE_HA,
	ZYLOG_SRC_ROUTING_PROTOCOL,
	ZYLOG_SRC_NAT,
	ZYLOG_SRC_PKI,
	ZYLOG_SRC_INTERFACE,
	ZYLOG_SRC_INTERFACE_STATISTICS, /* vrpt use */
	ZYLOG_SRC_ISP_ACCOUNT,
	ZYLOG_SRC_PORT_GROUPING,
	ZYLOG_SRC_FORCE_AUTH,
	ZYLOG_SRC_L2TP,
/* #if defined(ZLDCONFIG_SSLVPN_INTOTO_BASIC) || defined(ZLDCONFIG_SSLVPN_INTOTO_FULL) */
	ZYLOG_SRC_SSL_VPN, 
/* #endif */
	ZYLOG_SRC_DIALIN,
	ZYLOG_SRC_LAV,
	ZYLOG_SRC_CNM,
	ZYLOG_SRC_ADP,
	ZYLOG_SRC_WLAN,
	ZYLOG_SRC_CELLULAR,
	ZYLOG_SRC_DAILY_REPORT,
	ZYLOG_SRC_IPMAC_BINDING,
	ZYLOG_SRC_DHCP,
	ZYLOG_SRC_EPS,
	ZYLOG_SRC_AUTH_POLICY,
	ZYLOG_SRC_CAPWAP,		/*for CAPWAP module*/
/* #if defined(ZLDCONFIG_WLAN_MON_MODE_SERVER_SUPPORT) || defined(ZLDCONFIG_WLAN_MON_MODE_CLIENT_SUPPORT) */
	ZYLOG_SRC_WLAN_MON,
/* #endif */
/* #if defined(ZLDCONFIG_WLAN_RAD_AC_SUPPORT) || defined(ZLDCONFIG_WLAN_RAD_WTP_SUPPORT) */
	ZYLOG_SRC_WLAN_ROGUEAP,
/* #endif */
/* #ifdef ZLDCONFIG_WLAN_FRAME_CAPTURE_SERVER_SUPPORT */
	ZYLOG_SRC_WLAN_FRAME_CAPTURE,
/* #endif */
/* #if defined(ZLDCONFIG_WLAN_DCS_AC_SUPPORT) || defined(ZLDCONFIG_WLAN_DCS_WTP_SUPPORT) */
	ZYLOG_SRC_WLAN_DCS,
/* #endif */
	ZYLOG_SRC_INBOUND_LOAD_BALANCING,
	ZYLOG_SRC_LOAD_BALANCING,
	ZYLOG_SRC_WLAN_BAND_SELECT,
/* #ifdef ZLDCONFIG_USB_STORAGE_APP */
	ZYLOG_SRC_USB_STORAGE,
	ZYLOG_SRC_CAPWAP_DATA_FORWARD,	
	ZYLOG_SRC_DYNAMIC_GUEST_ACCOUNT,
	ZYLOG_SRC_FREERADIUS,
	/* #if defined(ZLDCONFIG_RTLS_SUPPORT) */
	ZYLOG_SRC_RTLS,
	ZYLOG_SRC_WLAN_STATION_INFO,		/* Station information */
	ZYLOG_SRC_FORWARD_CLEAR_MAILS, /* 10 */
	ZYLOG_SRC_WEB_AUTH,
/* #if defined(ZLDCONFIG_WLAN_AUTO_HEALING_AC_SUPPORT) */
    ZYLOG_SRC_WLAN_AUTO_HEALING,
	ZYLOG_SRC_WLAN_ZYMESH,
/* #endif */
    ZYLOG_SRC_ZON,
    ZYLOG_SRC_DFS,
/* #if defined(ZLDCONFIG_CLOUD_WTP_IMAGE_UPDATING_AC_SUPPORT) */
	ZYLOG_SRC_AP_FIRMWARE,
/* #endif */
/* #if defined(ZLDCONFIG_BLE_SUPPORT) */
    ZYLOG_SRC_BLE,
/* #endif */
/* #ifdef ZLDCONFIG_ZYLOG_DROPPED_COUNT */
	ZYLOG_SRC_DROPPED_COUNT,
/* #endif */	
/* #ifdef AAA_WEB_PORTAL */
	ZYLOG_SRC_CLOUD_AUTH,
/* #endif */
/* #if defined(ZLDCONFIG_SMART_MESH_SUPPORT) */
	ZYLOG_SRC_WLAN_SMART_MESH,
/* #endif */
/* #if defined(ZLDCONFIG_WLAN_STATION_INFO_COLLECTION) */
	ZYLOG_SRC_STATION_INFO_COLLECTION,
/* #endif */
	ZYLOG_SRC_STA_ROAMING,
/* #if defined(ZLDCONFIG_WIRELESS_HEALTH_SUPPORT) */
        ZYLOG_SRC_WIRELESS_HEALTH,
/* #endif */	
/* #if defined(ZLDCONFIG_SSID_NAT_SUPPORT) || defined(ZLDCONFIG_ETHERNET_NAT_SUPPORT) */
	ZYLOG_SRC_SESSION,
/* #endif */
/* #if defined(ZLDCONFIG_COLLABORATIVE_DETECTION_RESPONSE) */
	ZYLOG_SRC_CDR,
/* #endif */
/* #if defined(ZLDCONFIG_CAMPUS_AP_CLIENT_SUPPORT) */
	ZYLOG_SRC_TUNNEL,
/* #endif */
	ZYLOG_SRC_LIMIT,		/* Don't touch */
};


/* log facility */
enum zylog_facilities {
	ZYLOG_FAC_DEFAULT = 0,	/* Don't touch */

	ZYLOG_FAC_CONTENT_FILTER,
	ZYLOG_FAC_FORWARD_WEB_SITES,
	ZYLOG_FAC_BLOCKED_WEB_SITES,
	ZYLOG_FAC_WARNING_WEB_SITES,
	ZYLOG_FAC_UAM,
	ZYLOG_FAC_MYZYXEL_DOT_COM,
	ZYLOG_FAC_ZYSH,
	ZYLOG_FAC_IDP,
	ZYLOG_FAC_AS,
	ZYLOG_FAC_TRAFFIC,
	ZYLOG_FAC_FILE_MANAGE,
	ZYLOG_FAC_APP_PATROL,
	ZYLOG_FAC_BWM,
	ZYLOG_FAC_IKE,
	ZYLOG_FAC_IPSEC,
	ZYLOG_FAC_FIREWALL,
	ZYLOG_FAC_SESSIONS_LIMIT,
	ZYLOG_FAC_AV,
	ZYLOG_FAC_POLICY_ROUTE,
	ZYLOG_FAC_BUILTIN_SERVICE,
	ZYLOG_FAC_SYSTEM,
	ZYLOG_FAC_SYSTEM_MONITORING, /* vrpt use */
	ZYLOG_FAC_CONNECTIVITY_CHECK,
	ZYLOG_FAC_DEVICE_HA,
	ZYLOG_FAC_ROUTING_PROTOCOL,
	ZYLOG_FAC_NAT,
	ZYLOG_FAC_PKI,
	ZYLOG_FAC_INTERFACE,
	ZYLOG_FAC_INTERFACE_STATISTICS, /* vrpt use */
	ZYLOG_FAC_ISP_ACCOUNT,
	ZYLOG_FAC_PORT_GROUPING,
	ZYLOG_FAC_FORCE_AUTH,
	ZYLOG_FAC_L2TP,
/* #if defined(ZLDCONFIG_SSLVPN_INTOTO_BASIC) || defined(ZLDCONFIG_SSLVPN_INTOTO_FULL) */
	ZYLOG_FAC_SSL_VPN, 
/* #endif */
	ZYLOG_FAC_DIALIN,
	ZYLOG_FAC_LAV,
	ZYLOG_FAC_CNM,
	ZYLOG_FAC_ADP,
	ZYLOG_FAC_WLAN,
	ZYLOG_FAC_CELLULAR,
	ZYLOG_FAC_DAILY_REPORT,
	ZYLOG_FAC_IPMAC_BINDING,
	ZYLOG_FAC_DHCP,
	ZYLOG_FAC_EPS,
	ZYLOG_FAC_AUTH_POLICY,
	ZYLOG_FAC_CAPWAP,		/*for CAPWAP module*/	
/* #if defined(ZLDCONFIG_WLAN_MON_MODE_SERVER_SUPPORT) || defined(ZLDCONFIG_WLAN_MON_MODE_CLIENT_SUPPORT) */
	ZYLOG_FAC_WLAN_MON,
/* #endif */
/* #if defined(ZLDCONFIG_WLAN_RAD_AC_SUPPORT) || defined(ZLDCONFIG_WLAN_RAD_WTP_SUPPORT) */
	ZYLOG_FAC_WLAN_ROGUEAP,
/* #endif */
/* #ifdef ZLDCONFIG_WLAN_FRAME_CAPTURE_SERVER_SUPPORT */
	ZYLOG_FAC_WLAN_FRAME_CAPTURE,
/* #endif */
/* #if defined(ZLDCONFIG_WLAN_DCS_AC_SUPPORT) || defined(ZLDCONFIG_WLAN_DCS_WTP_SUPPORT) */
	ZYLOG_FAC_WLAN_DCS,
/* #endif */
	ZYLOG_FAC_INBOUND_LOAD_BALANCING,
	ZYLOG_FAC_LOAD_BALANCING,
	ZYLOG_FAC_WLAN_BAND_SELECT,
	ZYLOG_FAC_USB_STORAGE,
	ZYLOG_FAC_CAPWAP_DATA_FORWARD,
	ZYLOG_FAC_DYNAMIC_GUEST_ACCOUNT,
	ZYLOG_FAC_FREERADIUS,
/* #if defined(ZLDCONFIG_RTLS_SUPPORT)*/
	ZYLOG_FAC_RTLS,
	ZYLOG_FAC_WLAN_STATION_INFO,		/* Station information */
	ZYLOG_FAC_FORWARD_CLEAR_MAILS,
	ZYLOG_FAC_WEB_AUTH,
/* #if defined(ZLDCONFIG_WLAN_AUTO_HEALING_AC_SUPPORT) */
    ZYLOG_FAC_WLAN_AUTO_HEALING,
	ZYLOG_FAC_WLAN_ZYMESH,
/* #endif */
    ZYLOG_FAC_ZON,
    ZYLOG_FAC_DFS,
/* #if defined(ZLDCONFIG_CLOUD_WTP_IMAGE_UPDATING_AC_SUPPORT) */
	ZYLOG_FAC_AP_FIRMWARE,
/* #endif */
/* #if defined(ZLDCONFIG_BLE_SUPPORT) */
    ZYLOG_FAC_BLE,
/* #endif */
/* #ifdef ZLDCONFIG_ZYLOG_DROPPED_COUNT */	
	ZYLOG_FAC_DROPPED_COUNT,
/* #endif */	   
/* #ifdef AAA_WEB_PORTAL */
	ZYLOG_FAC_CLOUD_AUTH,
/* #endif */
/* #if defined(ZLDCONFIG_SMART_MESH_SUPPORT) */
	ZYLOG_FAC_WLAN_SMART_MESH,
/* #endif */
/* #if defined(ZLDCONFIG_WLAN_STATION_INFO_COLLECTION) */
	ZYLOG_FAC_STATION_INFO_COLLECTION,
/* #endif */
	ZYLOG_FAC_STA_ROAMING,
/* #if defined(ZLDCONFIG_WIRELESS_HEALTH_SUPPORT) */
        ZYLOG_FAC_WIRELESS_HEALTH,
/* #endif */	
/* #if defined(ZLDCONFIG_SSID_NAT_SUPPORT) || defined(ZLDCONFIG_ETHERNET_NAT_SUPPORT) */
	ZYLOG_FAC_SESSION,
/* #endif */
/* #if defined(ZLDCONFIG_COLLABORATIVE_DETECTION_RESPONSE) */
	ZYLOG_FAC_CDR,
/* #endif */
/* #if defined(ZLDCONFIG_CAMPUS_AP_CLIENT_SUPPORT) */
	ZYLOG_FAC_TUNNEL,
/* #endif */
	ZYLOG_FAC_LIMIT,		/* Don't touch */
};

/* define zylog error number */
enum {
	ZYLOG_ESYSERROR = 1,
	ZYLOG_EEXIST,
	ZYLOG_EIDRM,
	ZYLOG_EINTR,

	/* return value */	
	ZYLOG_EGETSEM,
	ZYLOG_EGETRING,
	ZYLOG_EATTRING,
	ZYLOG_ELOCK,
};


/* lock structure */
struct zylog_lock {
	int     semid;
	key_t   key;
};

struct traffic_log {
	uint32_t duration;
	uint32_t sent;
	uint32_t received;
	char dir[98];
	uint16_t proto;
	char proto_name[16];
	char client_mac[20];
};

struct idp_log {
	char class[32];
	char act[16];
	uint32_t sid;
	char ob[16];
	char ob_mac[16];
};

struct firewall_log {
	char class[32];
	char ob[16];
	char ob_mac[16];
	char dir[66];
	uint16_t proto;
	char proto_name[16];
};

typedef struct zylog_extfield_s {
	char *srciface;
	char *dstiface;
	char *proto_name;
} zylog_extfield_t;

struct zylog_usbstorage_buf {
	char buf[ZYLOG_USBSTORAGE_BUF_LEN];
	int dataLen;
	int msgCnt;
	int flushThreshold;
};
/* ZLD centralized log structures */
struct zylog_entry {
	/* fields to judge duplicated log  */
	struct in6_addr srcip6, dstip6;
	uint32_t srcip, dstip;
	uint16_t sport, dport;

	char message[ZYLOG_MAX_MESSAGE_LEN];
	char note[ZYLOG_MAX_NOTE_LEN];
	char username[ZYLOG_MAX_USERNAME_LEN];
	char srciface[MAX_IFACE_NAME_LEN];
	char dstiface[MAX_IFACE_NAME_LEN];
	char proto_name[MAX_PROTO_NAME_LEN];

	union {
		struct traffic_log traffic;
		struct idp_log idp;
		struct firewall_log firewall;
	} u;
	
	/* don't change it */
	uint8_t source;
	uint8_t facility;
	uint8_t priority;
	uint8_t __padding;	/* necessary for log consolidation */

	/* varied parts */
	time_t timestamp;
	struct timeval tv;
	unsigned short count;
#if 0
	int need_mail:ZYLOG_MAIL_NUM,	/* reserve ZYLOG_MAIL_NUM bits */
		 force_alert:1,
		 debug:1,
		 no_suppress:1;
#else
	int need_mail;
	int force_alert;
	int debug;
	int no_suppress;
#endif
	int flags;			/* Additional flag for IPv6 reference */
	uint32_t csum;
};

enum config_type {
	CONFIG_TYPE_SYSTEM,
	CONFIG_TYPE_MAIL,
	CONFIG_TYPE_CONSOLE,
	CONFIG_TYPE_REMOTE_SERVER,
	CONFIG_TYPE_MISC,
/* 20090825 vincent added for WTP Logs */
#ifdef ZLDCONFIG_CAPWAP_AC_WTP_LOGS_SUPPORT
	CONFIG_TYPE_WTP_SYSTEM,
	CONFIG_TYPE_WTP_MAIL,
	CONFIG_TYPE_WTP_CONSOLE,
	CONFIG_TYPE_WTP_REMOTE_SERVER,
	CONFIG_TYPE_WTP_MISC,
#endif
	CONFIG_TYPE_USB_STORAGE,
	CONFIG_TYPE_MAX,
};

enum config_item {
	/* common items */
	CONFIG_ITEM_ALL,
	CONFIG_ITEM_ACTIVE,
	CONFIG_ITEM_ENABLE,
	CONFIG_ITEM_LOGGING_CATEGORY,

	/* specified items */
	CONFIG_ITEM_SERVER,
	CONFIG_ITEM_PORT,
	CONFIG_ITEM_SUBJECT,
	CONFIG_ITEM_SENDER,
	CONFIG_ITEM_LOG_RECEIVER,
	CONFIG_ITEM_ALERT_RECEIVER,
	CONFIG_ITEM_AUTH_ACTIVE,
	CONFIG_ITEM_AUTH_ENABLE,
	CONFIG_ITEM_AUTH_NAME_PASSWORD,
	CONFIG_ITEM_SCHEDULE,
	CONFIG_ITEM_FORMAT,
	CONFIG_ITEM_FACILITY,
	CONFIG_ITEM_ENABLE_SYSTEM_SUPPRESS,
	CONFIG_ITEM_SYSTEM_SUPPRESS_INTERVAL,
	CONFIG_ITEM_ENABLE_DEBUG_SUPPRESS,
	CONFIG_ITEM_DEBUG_SUPPRESS_INTERVAL,
	CONFIG_ITEM_MAIL_CONSOLIDATION_INTERVAL,
	CONFIG_ITEM_TLS_ENABLE,
	CONFIG_ITEM_TLS_TYPE,
	CONFIG_ITEM_SYSTEM_NAME,
	CONFIG_ITEM_DATE_TIME,
};

/* definition for zylog mail */
#define ZYLOG_MAILMAN_BIN 	"/usr/sbin/zylog_mailman"
#define MAIL_WHEN_FULL		0
#define MAIL_HOURLY			1
#define MAIL_DAILY			2
#define MAIL_WEEKLY			3
#define MAIL_PORT			25

#define BIT_MAIL_LOG		1
#define BIT_MAIL_ALERT		2

#define MAIL_PROCESS_COUNT 0
#define MAIL_SIZE 1

struct zylog_mail {
	char active;
	char enable;
	
	char server[64];
	int	 port;
	char subject[64];
	int bAppendSystemName;
    int bAppendDateTime;
	
	char sender[128];
	char log_receiver[128];
	char alert_receiver[128];

	char auth_active;
	char auth_enable;
	char auth_name[32];
	char auth_password[32];

	char schedule;
	char day, hour, minute;
	
	char logging_category[ZYLOG_SRC_LIMIT];
	char tls_enable; 
	char tls_type[10];
};

/* definition for system buffer and remote server */
#define DISABLE_LOG			0
#define ENABLE_LOG			1
#define ENABLE_DEBUG_LOG		2
#define ENABLE_ALERT_LOG		3

#define REMOTE_SERVER_FORMAT_VRPT	0
#define REMOTE_SERVER_FORMAT_CEF	1

enum remote_server_facility {
	REMOTE_SERVER_FACILITY_LOCAL1 = 17,
	REMOTE_SERVER_FACILITY_LOCAL2,
	REMOTE_SERVER_FACILITY_LOCAL3,
	REMOTE_SERVER_FACILITY_LOCAL4,
	REMOTE_SERVER_FACILITY_LOCAL5,
	REMOTE_SERVER_FACILITY_LOCAL6,
	REMOTE_SERVER_FACILITY_LOCAL7
};

struct zylog_remote_server {
	char active;
	char enable;

	char server[64];
	
	char format;
	char facility;

	char logging_category[ZYLOG_SRC_LIMIT];
};

struct zylog_usb_storage{
	char logging_category[ZYLOG_SRC_LIMIT];
        char enable;
};

struct zylog_system {
	char logging_category[ZYLOG_SRC_LIMIT];
};

struct zylog_console {
	char active;
	char logging_category[ZYLOG_SRC_LIMIT];
};

/* 20090825 vincent added for WTP Logs */
#ifdef ZLDCONFIG_CAPWAP_AC_WTP_LOGS_SUPPORT
struct zylog_wtp_mail {	
	char logging_category[ZYLOG_SRC_LIMIT];
};
struct zylog_wtp_remote_server {	
	char logging_category[ZYLOG_SRC_LIMIT];
};
struct zylog_wtp_system {
	char logging_category[ZYLOG_SRC_LIMIT];
};
struct zylog_wtp_console {	
	char logging_category[ZYLOG_SRC_LIMIT];
};
#endif

struct zylog_config {
	struct zylog_system system;
	struct zylog_console console;
	struct zylog_mail mail[ZYLOG_MAIL_NUM];
	struct zylog_remote_server server[ZYLOG_REMOTE_SERVER_NUM];

/* 20090825 vincent added for WTP Logs */
#ifdef ZLDCONFIG_CAPWAP_AC_WTP_LOGS_SUPPORT
	struct zylog_wtp_system wtp_system;
	struct zylog_wtp_console wtp_console;
	struct zylog_wtp_mail wtp_mail[ZYLOG_MAIL_NUM];
	struct zylog_wtp_remote_server wtp_server[ZYLOG_REMOTE_SERVER_NUM];
#endif
	
	int enable_system_suppress;
	uint32_t system_suppress_interval;
	int enable_debug_suppress;
	uint32_t debug_suppress_interval;
	uint32_t mail_consolidation_interval;
};

#define LOG_TYPE_SYSTEM			0
#define LOG_TYPE_DEBUG			1
/* for log persistence */
#define LOG_TYPE_SYSTEM_LAST	2
#define LOG_TYPE_DEBUG_LAST 	3
/* 20080825 vincent added for WTP Logs */
#ifdef ZLDCONFIG_CAPWAP_AC_WTP_LOGS_SUPPORT
#define LOG_TYPE_SYSTEM_WTP_LOG	 	4
#define LOG_TYPE_DEBUG_WTP_LOG	 	5
#endif

struct zylog_centralized_log {
	struct zylog_entry system_entry[ZYLOG_SYSTEM_LOG_NUM];
	struct zylog_entry debug_entry[ZYLOG_DEBUG_LOG_NUM];
	uint64_t system_entry_num;
	uint64_t debug_entry_num;
	unsigned long mail_sequence[ZYLOG_MAIL_NUM];
	unsigned long mail_size;
	unsigned long mail_process_count;
	int event_mail_count;
	int alert_mail_count;
	
	struct zylog_config config;
	pid_t pid;
	char cmdline[64];
	int fail_count;	
	int fail_pid;
#ifdef ZLDCONFIG_ZYLOG_DROPPED_COUNT
	uint64_t old_system_entry_num;
#endif	
	char json_msg[ZYLOG_SYSTEM_LOG_NUM][ZYLOG_MAX_MESSAGE_LEN];
};

struct zylog_identifier {
	char *zysh_name;
	char *category_name;
	char *gui_category_name;
	char *pattern;
	
	uint8_t source;
	uint8_t facility;

	regex_t re;
};

/*for log statistic*/
#define COUNTER_ON 1
#define COUNTER_OFF 0
struct log_statistic {
	int shmid; /*share memory id*/
	int semid; /*semaphore id*/
};
/*for log-statistic sotre record
ZYLOG_SRC_LIMIT: means max category number
*/
struct log_statistic_entry {
	uint64_t count[ZYLOG_SRC_LIMIT];
	int counter_button;
};
extern struct zylog_identifier zylog_id[];
/* 20090825 vincent added for WTP Logs */
#if (defined(ZLDCONFIG_CAPWAP_AC_WTP_LOGS_SUPPORT) || defined(ZLDCONFIG_CAPWAP_WTP_WTP_LOGS_SUPPORT))
extern struct zylog_identifier zylog_wtp_id[];
#endif
extern int zylog_errno;

/* Extern netlink socket index */
extern int sock_fd;

/* exported functions */
#ifdef ZLDCONFIG_IPV6
extern int zylog6(uint8_t src, uint8_t pri, uint8_t fac,
	   	struct in6_addr *srcip6, u_int16_t srcport, struct in6_addr *dstip6,u_int16_t dstport, 
		char *note, const char *fmt, ...) __attribute__((format(printf, 9, 10)));

extern int32_t zylog_extension6(uint8_t src, uint8_t pri, uint8_t fac, 
			struct in6_addr *srcip6, u_int16_t srcport, struct in6_addr *dstip6, u_int16_t dstport, 
			char *note, zylog_extfield_t *extfield, const char *fmt, ...) __attribute__((format(printf, 10, 11)));
#endif
extern int zylog(int8_t src, int8_t pri, int8_t fac,
	   	u_int32_t srcip, u_int16_t srcport, u_int32_t dstip,u_int16_t dstport, 
		char *note, const char *fmt, ...) __attribute__((format(printf, 9, 10)));
int
zylog_json(int8_t src, int8_t pri, int8_t fac, u_int32_t srcip, u_int16_t srcport,
      u_int32_t dstip, u_int16_t dstport,
	  char *note, char* json_msg, const char *fmt, ...) __attribute__((format(printf, 10,11)));

extern int32_t zylog_extension(int8_t src, int8_t pri, int8_t fac, 
			u_int32_t srcip, u_int16_t srcport, u_int32_t dstip, u_int16_t dstport, 
			char *note, zylog_extfield_t *extfield, const char *fmt, ...) __attribute__((format(printf, 10, 11)));
extern int zylog_valist(uint8_t src, uint8_t pri, uint8_t fac,
	   	u_int32_t srcip, u_int16_t srcport, u_int32_t dstip,u_int16_t dstport, 
		char *note, const char *fmt, va_list va);

extern int zylog2(struct zylog_entry *entry, int flags);

extern int zylog_clear_log(char log_type);
extern uint64_t zylog_get_current_num(char log_type);
extern uint64_t zylog_get_current_num_file(char log_type);
extern int zylog_get_entry(char log_type, uint64_t current, 
		uint64_t offset, struct zylog_entry *entry, char* json_buf);

extern int zylog_get_entry_file(char log_type, uint64_t total, 
		uint64_t which, struct zylog_entry *entry, char* json_buf);
		
extern int zylog_mail_event(int which, int send_all);
extern int zylog_mail_clear_event_bit(int which);

extern int zylog_set_config(int type, int which, int item, void *args);
extern int zylog_get_config(int type, int which, int item, void *args);
extern int zylog_call_lock(void);
extern int zylog_call_unlock(void );


extern int zylog_init(void);
extern int zylog_exit(void);
extern int zylog_print_debug(void);
extern int zylog_reset(void);
extern int save_log(char flag);
extern int zylog_mail_inc(int type, unsigned long amount);
extern int zylog_mail_dec(int type, unsigned long amount);

/* internal functions */
extern int zylog_create_buffer(struct zylog_buffer *buffer, 
		key_t key, unsigned int size);
extern int zylog_init_buffer(struct zylog_buffer *buffer, key_t key);
extern int zylog_attach_buffer(struct zylog_buffer *buffer);
extern int zylog_detach_buffer(struct zylog_buffer *buffer);
extern int zylog_remove_buffer(struct zylog_buffer *buffer);
extern int zylog_create_lock(struct zylog_lock *lock, key_t key, int val);
extern int zylog_init_lock(struct zylog_lock *lock, key_t key);
extern int zylog_get_lock_val(struct zylog_lock *lock);
extern int zylog_set_lock_val(struct zylog_lock *lock, int val);
extern int zylog_dolock(struct zylog_lock *lock);
extern int zylog_unlock(struct zylog_lock *lock);
extern int zylog_notify_lock(struct zylog_lock *lock);
extern int zylog_remove_lock(struct zylog_lock *lock);
extern char* zylog_transfer_category(int source);
extern char* zylog_transfer_severity(int priority);
extern void init_zylog_identifier(void);
extern void fini_zylog_identifier(void);
extern struct zylog_identifier *zylog_getid_by_pattern(char *pattern);
extern struct zylog_identifier *zylog_getid_by_source (int source);
extern int log_counter_create_semaphore(key_t key);
extern struct log_statistic_entry *log_counter_create_shm(int *ret_shmid,key_t key,unsigned int size);
extern void log_counter_semaphore_dolock(int sem);
extern void log_counter_semaphore_unlock(int sem);

#ifdef ZLDCONFIG_INFO_TRANSFER_WTP_SUPPORT
#define FORWARD_TO_AC_WTP_STATUS_SOCKET_ZYSH   "/tmp/forward-to-ac-wtp-status-socket-zysh.sock"
#define COMMON_LOG_TRIGGER                     "common_log_trigger"
#define COMMON_LOG_MAX_LEN                     1024
#define COMMON_LOG_MSG_LEN                     512
#define COMMON_LOG_INFO_LEN                    64

typedef struct common_log_entry_s {
        unsigned char source;
        unsigned char priority;
        unsigned char facility;

        unsigned int srcip, dstip;
        unsigned short sport, dport;
}common_log_entry_t;

extern int
zylog_send_WTPlog2AC(uint8_t src, uint8_t pri, uint8_t fac, u_int32_t srcip, u_int16_t srcport,
      u_int32_t dstip, u_int16_t dstport, char *note, const char *fmt, ...);
#endif

#endif

/* vi:set sw=4 ts=4: */

#ifndef __STAINFO_H__
#define __STAINFO_H__

#include <stdint.h>
#include <sys/types.h>

#define PROC_PATH	"/proc"
#define STAINFO_FILE	"sta_info"
#define NODE_COUNT_FILE	"node_count"
#define FILE_PATH	128

#define MAC_LEN		6
#define LEN_8		8
#define LEN_16		16
#define LEN_128		128
#define LEN_256		256
#define LEN_1024	1024

#define MAX_VAP_NUM	16

#define LIBSTAINFO_DEBUG 1

#define GET_ABSOLUTE_PATH(filepath, vap_name, filename)   \
    do{         \
        sprintf(filepath, "/proc/%s/%s", vap_name, filename); \
    }while(0)

#define ARRAY_LENGTH(array)	\
		(sizeof(array) / sizeof((array)[0]))

#ifndef MACSTR
#define MACSTR      "%02X:%02X:%02X:%02X:%02X:%02X"
#define MAC2STR(a)  (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#endif

#if LIBSTAINFO_DEBUG
#define SLOG_DEBUG(fmt, args...)\
		printf("[%s:%d]DEBUG: " fmt"\n", __FUNCTION__, __LINE__, ##args)
#endif

typedef struct sta_entry {
	uint8_t mac[MAC_LEN];
	unsigned int aid;
	unsigned int channel;
	unsigned int bandwidth;
	unsigned int txrate;
	unsigned int rxrate;
	int rssi;
	unsigned int idle;
	unsigned int vid;
	unsigned long long tx_bytes;
	unsigned long long rx_bytes;
	char cap[LEN_16];
	char ip_addr[LEN_16];
	unsigned int is_support11k;
	unsigned int is_support11v;
	unsigned int is_support11r;
} sta_entry_t;

typedef struct sta_table {
	unsigned int count;
	sta_entry_t entry[LEN_256];
} sta_table_t;

int get_list_sta_by_vap(char *vap, sta_table_t* table);
int get_list_sta_by_mac(char *vap, char * mac, sta_entry_t* entry);
int get_Sta_count_by_vap(char *vap);
int get_Sta_count_by_radio(char *radio);

#endif /* __STAINFO_H__ */

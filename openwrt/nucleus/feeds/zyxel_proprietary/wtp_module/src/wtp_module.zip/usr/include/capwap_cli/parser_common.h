#ifndef PARSER_COMMON_H_
#define PARSER_COMMON_H_

#include "parser_module.h"

#define CONN_RETRY_COUNT 3

struct parser_opt
{
	char *key;
	int event_type;
	enum {
		ARG,
		NO_ARG,
	} value_type;
};

int add_tlv(char *dst, int type, int len, char *value);
int __init_sock(get_addr_func __get_addr, enum parser_role role);
void __close_sock(get_addr_func __get_addr, int fd, enum parser_role role);
int handle_tlv(char *data, int size, type_func *func_table, char *result);
int __comm_server(get_addr_func __get_addr, int fd, char *msg, int msg_len, char *result);
int __gen_cmd(get_addr_func __get_addr, parser_func __parser, int client_fd, char *msg, va_list ap);
int __parser(struct parser_opt opts[], int argc, char **argv, char *result, void (*help_func)(void));

#endif

#ifndef WLAN_H_
#define WLAN_H_

#include <stdint.h>
#include <netinet/in.h>
#include <linux/if.h>
#include "linked-list.h"
#include "capwap_val.h"
#include "sta.h"

#define STA_STATISTIC_TABLE_PREFIX  "STA_STATISTIC"
#define STA_STATISTIC_SLOT_KEY_PREFIX   "SLOT"
#define MESH_STA_STATISTIC_TABLE_PREFIX  "MESH_STA_STATISTIC"


#define TABLE_PREFIX	"WLAN"
#define KEY_PREFIX		"SLOT"

#define STA_ASSOC               1
#define STA_DISASSOC            2
#define STA_IP_ADDR             3
#define STA_INTERFACE_SSID      4
#define STA_AUTHORIZED          5

typedef struct capwapWlanStatis_s{
	unsigned char index;
	unsigned char activate;
	uint32_t txFragCnt;
	uint32_t multicatstTxCnt;
	uint32_t failCnt;
	uint32_t retryCnt;		
	uint32_t multiRetryCnt;
	uint32_t frameDuplicateCnt;
	uint32_t rtsSuccessCnt;
	uint32_t rtsFailureCnt;
	uint32_t ackFailureCnt;
	uint32_t rxFragCnt;
	uint32_t multicastRxCnt;
	uint32_t fcsErrCnt;
	uint32_t txFrameCnt;
	uint32_t rxFrameCnt;	
	uint32_t decryptionErrCnt;
	uint32_t discardQosFrameCnt;
	uint32_t assocStationCnt;
	uint32_t qosCfPollsRecCnt;
	uint32_t qosCfPollsUnusedCnt;
	uint32_t qosCfPollsUnusablCnt;
	uint32_t txBytesPerSec;		/* new request at ZLD */
	uint32_t rxBytesPerSec;	/* new request at ZLD */
	/* --- for auto healing --- */
	uint32_t txPower;
	/* --- for zwo --- */
    uint32_t rx_err_rate;
    uint32_t tx_err_rate;
	/* --- for dcs channel --- */
	unsigned char dcsChann;
	int8_t extOffset;
	uint8_t vht_ch_freq;
	uint8_t vht_ch_freq2;
	/* --- txrx byte counter --- */
	unsigned long long txBytes;
	unsigned long long rxBytes;
	/* --- channel utilization --- */
	uint32_t chUtil;
#ifdef WIRELESS_HEALTH_SUPPORT
	uint32_t retryRate;
	uint32_t alertCount;
	uint32_t actionThreshold;
	uint32_t recoveryThreshold;
#endif
}capwapWlanStatis_t;

typedef void (*action_func)(int fd, void *data);

typedef enum
{
	WLAN_STATISTIC = 0,
	STA_STATISTIC,
}ACTION_TYPE;

typedef struct staInfo_s {
#define STAINFO_UPDATE  (1U<<0)
    uint32_t flags; /* keep first */
    uint32_t timeStamp;
    int32_t needUpdate;

    /* dot11-related */
    unsigned char macAddr[6];
    struct in_addr ipAddr;  /* added by sophia, for captive portal & free-radius */
    int32_t wlanIndex;
    int32_t vid;            /* added for Data Tunnel Feature */
    int32_t radioId;        /* added by sophia , added for Data Tunnel Feature */
    unsigned char wlanIfName[IFNAMSIZ+1];   /*added by sophia , use if name at Linux platform*/
    time_t assoTime;
    int32_t disassoReasonCode;   /* added for Disassociation Reason Code */
    char *wlan_tmp;

    int32_t ssidProfileId;
    int32_t secProfileId;
    char ssidProfileName[CAPWAP_MAX_PROFILE_NAME_LEN];
    char ssid[CAPWAP_SSID_MAX_LENGTH];
    char secProfileName[CAPWAP_MAX_PROFILE_NAME_LEN];
    char security[CAPWAP_MAX_PROFILE_NAME_LEN];

    int32_t sigRSSI;
    char txRate[RATE_LEN+1];
    char rxRate[RATE_LEN+1];
    int32_t authentication; /* added to record if the sta need to do authentication */
    int32_t channel;
    unsigned long long tx;
    unsigned long long rx;
    char event_type[RRM_EVENT_TYPE_LEN];
#if CAPWAP_WTP_CLIENT_INFO
    char bandcap[STACAP_MAXLEN+1];
	char dot11Features[STACAP_MAXLEN];
#endif
    int32_t auth_alg;
    int32_t reassoc;
    unsigned char reassoc_ap[6];
    char display_ssid[DISPLAY_SSID_LEN];
#ifdef WIRELESS_HEALTH_SUPPORT
    uint32_t retryRate;
    uint32_t alertCount;
    uint32_t actionThreshold;
    uint32_t recoveryThreshold;
#endif
} staInfo_t;

void rrm_sta_notify(struct sta_module_msg *sta_msg);
void retrieve_wlan_stat(int radioId, capwapWlanStatis_t *ptr);
int retrieve_sta_statistic_stat(char *mac_str, staInfo_t *entry, int mesh, char *iface);
void getWtpMac(char *str);
void netlink_evt_attach(void *data, void *sub_info);
void system_sleep(void);
#endif

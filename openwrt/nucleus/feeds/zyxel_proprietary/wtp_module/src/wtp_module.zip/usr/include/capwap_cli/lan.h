#ifndef LAN_H_
#define LAN_H_

#include <sys/socket.h>
#include <linux/if.h>

#include "capwap_val.h"

#define LAN_TABLE_PREFIX	"LAN"
#define LAN_KEY_PREFIX		"PORT"

typedef struct wtpGePort_s {
	char ifacename[IFNAMSIZ+1];
	char status[32];
	int tx_packets;
	int rx_packets;
	int tx_bcast;
	int rx_bcast;
	int tx_colls;
	int tx_bytes;
	int rx_bytes;
	char up_time[32];
	int pvid;
} wtpGePort_t;

void retrieve_lan_stat(wtpGePort_t ge_info[]);
void retrieve_lan_rx_tx(unsigned long long *rx_bytes, unsigned long long *tx_bytes);
void system_sleep(void);

#endif


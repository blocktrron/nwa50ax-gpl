#ifndef RRM_COMMON_H_
#define RRM_COMMON_H_

#include <stdint.h>

#define COMMON_TABLE "COMMON_TABLE"
#define COLLECT_CLOUD_MODE_INTERVAL 50
#define COLLECT_NORMAL_INTERVAL 50

#define WTP_IDX		"WTP_IDX"
#define LOCAL_IP	"LOCAL_ADDR"
#define REMOTE_IP	"AC_IP_ADDR"
#define RAP_LOCAL_IP	"RAP_LOCAL_IP"
#define RAP_REMOTE_IP	"RAP_REMOTE_IP"
#define DISCOVER_IP	"DISCOVER_IP"

void init_title(int argc, char *argv[], char *envp[], char *name);
void set_title(const char *fmt, ...);

void mac2str(char *mac, char *str);
void str2mac(char* str, char* mac);
int isMac(char *str);
int32_t capwapUtlGetIfMAC(char *ifName,char *mac);
void rrm_get_common_mac(char *mac_str, int len);

void *run(int argc, char *argv[], char *envp[], void *arg);

#endif


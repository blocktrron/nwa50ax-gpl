#ifndef STA_H_
#define STA_H_
#include <netinet/in.h>

enum reg_type
{
	STA_ASSO,
	STA_DISASSO,
	STA_IP,
	NETOPEER_ONLINE,
	NETOPEER_OFFLINE,
	NETOPEER_CLAIM,
	NETOPEER_DECLAIM,
	STA_REG_TYPE_MAX,
};

enum sta_module_op
{
	STA_MODULE_NOTIFY,
	STA_MODULE_REG,
};

/* map to struct capwap_sta_info in hostapd-0.5.11/capwap_event.h */
#ifndef HOSTAPD_MAX_SSID_LEN
#define HOSTAPD_MAX_SSID_LEN 32
#endif
#define RRM_SSID_LEM	HOSTAPD_MAX_SSID_LEN

enum hapd_sta_status {
	HAPD_STA_NULLFUNC   = 0,
	HAPD_STA_ASSOC      = 1,
	HAPD_STA_DISASSOC   = 2,
	HAPD_STA_AUTH		= 3,
	HAPD_STA_DEAUTH     = 4,
	HAPD_STA_NEW		= 5,
	HAPD_STA_DELETE     = 6
};

#ifndef EADDR_LEN
#define EADDR_LEN	6
#endif

#ifndef IFNAMSIZ
#define IFNAMSIZ	16
#endif

#define RRM_EVENT_TYPE_LEN	64
#define RRM_CHANNEL_LEN		32
#define DRIVER_SEC_LEN 32
#define DISPLAY_SSID_LEN 64

struct rrm_sta_info
{
	char mac[EADDR_LEN];
	char iface[IFNAMSIZ + 1];
	char ssid[RRM_SSID_LEM + 1];
	struct in_addr ipAddr;
	int vid;
	int reason_code;
	int authentication;
	enum hapd_sta_status status;
	enum reg_type type;
	char event_type[RRM_EVENT_TYPE_LEN];
	int auth_alg;
	int reassoc;
	char reassoc_ap[EADDR_LEN];
	char security[DRIVER_SEC_LEN];
	char display_ssid[DISPLAY_SSID_LEN];
	int rssi;
	int channel;
};

struct sta_module_msg
{
	enum sta_module_op op;
	union
	{
		struct rrm_sta_info info;
		enum reg_type type;
	};
};

typedef void (proc_func)(struct sta_module_msg *, void *);
typedef void (con_func)(char *, int);

typedef struct reg_type_s{
	proc_func *sub_cb;
}reg_type_t;

/* subscribe info */
typedef struct sub_info_s{
	char mac_str[32];
	reg_type_t reg_type[STA_REG_TYPE_MAX];
	con_func *con_cb;
	con_func *dis_con_cb;
	/* libevent */
	void *event_base;
	void *ev;
}sub_info_t;

void subscribe_dispatch(sub_info_t *sub_info);
int sta_lib_notify(struct sta_module_msg *sta_msg);
void sta_lib_get_ch(char *ch, enum reg_type type);
void sta_lib_check_ch(char *mac);
void sta_lib_set_ch(char *ap_mac);
void sub_info_init(sub_info_t *sub_info);
#endif


/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Enable build-broadcom */
/* #undef BUILD_BROADCOM */

/* Enable campus-ap-client */
/* #undef CAMPUS_AP_CLIENT */

/* Enable data-forward */
/* #undef CAPWAP_DATA_TUNNEL_ENABLE */

/* Enable new-openssl */
/* #undef CAPWAP_NEW_OPENSSL */

/* Run on Linux */
/* #undef CAPWAP_PLATFORM_OS_LINUX */

/* Run on ZyXEL */
#define CAPWAP_PLATFORM_OS_ZLD 1

/* Enable remote debug */
#define CAPWAP_REMOTE_DEBUG 1

/* Enable capwap */
/* #undef CAPWAP_SUPPORT */

/* Enable transporter */
#define CAPWAP_TRANSPORTER 1

/* Enable client-info */
#define CAPWAP_WTP_CLIENT_INFO 1

/* Enable fallback */
#define CAPWAP_WTP_FALLBACK 1

/* Enable update-multimethod */
#define CAPWAP_WTP_IMAGE_UPGRADE_MUTI_METHODS 1

/* Enable len-control */
/* #undef CAPWAP_WTP_LED_CONTROL_SUPPORT */

/* Enable standalone-disc */
#define CAPWAP_WTP_STANDALONE_AC_DISCOVERY 1

/* Enable status-notify */
#define CAPWAP_WTP_STATUS_NOTIFY_SUPPORT 1

/* Enable zwo-support */
#define CAPWAP_WTP_ZWO_SUPPORT 1

/* Enable cloud-mode */
#define CLOUD_MODE_SUPPORT 1

/* Enable collaborative-detection-response */
/* #undef COLLABORATIVE_DETECTION_RESPONSE */

/* Enable db */
#define DB_SUPPORT 1

/* Enable dhcp-option82 */
/* #undef DHCP_OPTION82 */

/* Enable self examine */
/* #undef ENABLE_UNIT_TEST */

/* Enable wtp-log module */
/* #undef ENABLE_WTP_LOG */

/* With etc-writeable-zyxel-cfg-dir path */
#define ETC_WRITEABLE_ZYXEL_CFG_DIR "/etc/zyxel/ftp/nebula"

/* Enable factory-default */
#define FACTORY_DEFAULT 1

/* Define to 1 if you have the <arpa/inet.h> header file. */
#define HAVE_ARPA_INET_H 1

/* Define to 1 if you have the <arpa/nameser.h> header file. */
#define HAVE_ARPA_NAMESER_H 1

/* Define to 1 if you have the declaration of `CLOCK_MONOTONIC_RAW', and to 0
   if you don't. */
#define HAVE_DECL_CLOCK_MONOTONIC_RAW 1

/* Define to 1 if you have the declaration of `cygwin_conv_path', and to 0 if
   you don't. */
/* #undef HAVE_DECL_CYGWIN_CONV_PATH */

/* Define to 1 if you have the declaration of `strerror_r', and to 0 if you
   don't. */
#define HAVE_DECL_STRERROR_R 1

/* Define if you have the GNU dld library. */
/* #undef HAVE_DLD */

/* Define to 1 if you have the `dlerror' function. */
#define HAVE_DLERROR 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the `dup2' function. */
#define HAVE_DUP2 1

/* Define if you have the _dyld_func_lookup function. */
/* #undef HAVE_DYLD */

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the `fork' function. */
#define HAVE_FORK 1

/* Define to 1 if you have the `gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if you have the `inet_ntoa' function. */
#define HAVE_INET_NTOA 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `bmm' library (-lbmm). */
#define HAVE_LIBBMM 1

/* Define if you have the libdl library or equivalent. */
#define HAVE_LIBDL 1

/* Define if libdlloader will be built on this platform */
#define HAVE_LIBDLLOADER 1

/* Define to 1 if you have the `event' library (-levent). */
#define HAVE_LIBEVENT 1

/* Define to 1 if you have the `hiredis' library (-lhiredis). */
#define HAVE_LIBHIREDIS 1

/* Define to 1 if you have the `mtd' library (-lmtd). */
/* #undef HAVE_LIBMTD */

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the `localtime_r' function. */
#define HAVE_LOCALTIME_R 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the `memmove' function. */
#define HAVE_MEMMOVE 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the <netdb.h> header file. */
#define HAVE_NETDB_H 1

/* Define to 1 if you have the <netinet/in.h> header file. */
#define HAVE_NETINET_IN_H 1

/* Define to 1 if you have the <resolv.h> header file. */
#define HAVE_RESOLV_H 1

/* Define to 1 if you have the `select' function. */
#define HAVE_SELECT 1

/* Define if you have the shl_load function. */
/* #undef HAVE_SHL_LOAD */

/* Define to 1 if you have the `socket' function. */
#define HAVE_SOCKET 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the `strerror' function. */
#define HAVE_STRERROR 1

/* Define to 1 if you have the `strerror_r' function. */
#define HAVE_STRERROR_R 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strstr' function. */
#define HAVE_STRSTR 1

/* Define to 1 if you have the `strtol' function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the `strtoul' function. */
#define HAVE_STRTOUL 1

/* Define to 1 if you have the <syslog.h> header file. */
#define HAVE_SYSLOG_H 1

/* Define to 1 if you have the <sys/file.h> header file. */
#define HAVE_SYS_FILE_H 1

/* Define to 1 if you have the <sys/ioctl.h> header file. */
#define HAVE_SYS_IOCTL_H 1

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/socket.h> header file. */
#define HAVE_SYS_SOCKET_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/vfs.h> header file. */
#define HAVE_SYS_VFS_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `vfork' function. */
#define HAVE_VFORK 1

/* Define to 1 if you have the <vfork.h> header file. */
/* #undef HAVE_VFORK_H */

/* Define to 1 if `fork' works. */
#define HAVE_WORKING_FORK 1

/* Define to 1 if `vfork' works. */
#define HAVE_WORKING_VFORK 1

/* Enable load-balancing-group */
#define LOAD_BALANCING_GROUP_SUPPORT 1

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Enable override-full-power */
/* #undef OVERRIDE_FULL_POWER_SUPPORT */

/* Name of package */
#define PACKAGE "wtp_module"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "chunting.wu@zyxel.com.tw"

/* Define to the full name of this package. */
#define PACKAGE_NAME "wtp_module"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "wtp_module 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "wtp_module"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Enable pcap-monitor-mode */
/* #undef PCAP_MONITOR_WTP_SUPPORT */

/* Enable remote-ap-client */
/* #undef REMOTE_AP_CLIENT */

/* Enable remote-capture */
#define REMOTE_CAPTURE_SUPPORT 1

/* Enable rrm optimize */
/* #undef RRM_OPTIMIZE */

/* Enable rrm */
#define RRM_SUPPORT 1

/* Enable selectable-antenna */
/* #undef SELECTABLE_ANTENNA_SUPPORT */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to 1 if strerror_r returns char *. */
/* #undef STRERROR_R_CHAR_P */

/* Version number of package */
#define VERSION "1.0"

/* Enable WHAL */
/* #undef WHAL */

/* Enable wireless-health-support */
/* #undef WIRELESS_HEALTH_SUPPORT */

/* Enable wireless-storm-control */
/* #undef WIRELESS_STORM_CONTROL */

/* With wlan-max-ap num */
/* #undef WLAN_MAX_AP */

/* With wlan-max-owe num */
#define WLAN_MAX_OWE 3

/* With wlan-max-slot num */
/* #undef WLAN_MAX_SLOT */

/* Enable wpa3-support */
#define WLAN_WPA3_SUPPORT 1

/* Enable ZyMesh */
/* #undef ZYMESH */

/* Define for Solaris 2.5.1 so the uint32_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT32_T */

/* Define for Solaris 2.5.1 so the uint64_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT64_T */

/* Define for Solaris 2.5.1 so the uint8_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT8_T */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to the type of a signed integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int16_t */

/* Define to the type of a signed integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int32_t */

/* Define to the type of a signed integer type of width exactly 8 bits if such
   a type exists and the standard includes do not define it. */
/* #undef int8_t */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef mode_t */

/* Define to `long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef pid_t */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Define to the type of an unsigned integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint16_t */

/* Define to the type of an unsigned integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint32_t */

/* Define to the type of an unsigned integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint64_t */

/* Define to the type of an unsigned integer type of width exactly 8 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint8_t */

/* Define as `fork' if `vfork' does not work. */
/* #undef vfork */

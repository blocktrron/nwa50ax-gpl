#ifndef PARSER_MODULE_H_
#define PARSER_MODULE_H_

#include "zld-spec.h"

#define PARSER_ADDR_LEN 100
#define MAX_BUF_LEN 10240
#define STA_BUF_LEN    ZLDSYSPARM_WLAN_MAX_CLIENT*ZLDSYSPARM_WLAN_MAX_SLOT

enum parser_role
{
	PARSER_CLI,
	PARSER_SRV,
};

struct result_tlv
{
	int t;
	int l;
	char v[0];
};

typedef int (*type_func)(char *data, int len, char *result);
typedef int (*get_id_func)(void);
typedef int (*parser_func)(int argc, char **argv, char *result);
typedef void (*get_addr_func)(unsigned int role, char *addr);
typedef void *(*init_sock_func)(unsigned int role);
typedef int (*handle_tlv_func)(char *data, int size, type_func *func_table, char *result);
typedef int (*comm_server_func)(void *fd, char *msg, int msg_len, char *result);
typedef void (*close_sock_func)(void *fd, unsigned int role);
typedef int (*gen_cmd_func)(void * client_fd, char *msg, ...);

struct parser_module
{
	void *handle;
	/* Public interface */
	get_id_func get_id;
	parser_func parser;
	get_addr_func get_addr;
	init_sock_func init_sock;
	handle_tlv_func handle_tlv;
	comm_server_func comm_server;
	close_sock_func close_sock;
	gen_cmd_func gen_cmd;
};

struct parser_module *parser_open(char *name);
void parser_close(struct parser_module *module);

#endif


#ifndef WLAN_ZLD_H_
#define WLAN_ZLD_H_

int getInterfaceIdx(char *if_name, int *radioIdx, int *wlanIdx);

#endif

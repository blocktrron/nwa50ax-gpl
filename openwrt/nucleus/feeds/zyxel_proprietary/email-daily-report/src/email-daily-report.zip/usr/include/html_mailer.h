#ifndef _HTML_MAILER_H_
#define _HTML_MAILER_H_

#include "zld-spec.h"
#define STR_TMP_DIR_DAILY_REPORT	"/tmp/daily-report"
#define STR_TMP_ZYSHCONFIG	STR_TMP_DIR_DAILY_REPORT"/zyshConfig.dat"

#define STR_USR_SBIN_MSMTP	"/usr/sbin/msmtp"
#define STR_TMP_MSMTP_CONF  STR_TMP_DIR_DAILY_REPORT"/msmtp.conf"
#define STR_TMP_OUTMIME     STR_TMP_DIR_DAILY_REPORT"/outmine.final"
#define STR_TMP_SENDRESULT_LOG     STR_TMP_DIR_DAILY_REPORT"/sendresult.log"

#define STR_TMP_PERIODICAL_SYSINFO	STR_TMP_DIR_DAILY_REPORT"/periodicalSysInfo.csv"
#define STR_TMP_PERIODICAL_SYSINFO_ERR	STR_TMP_DIR_DAILY_REPORT"/periodicalSysInfo.err"
#ifdef ZLDCONFIG_CAPWAP_DAILY_REPORT 
#define STR_TMP_PERIODICAL_STATION     STR_TMP_DIR_DAILY_REPORT"/periodicalStation.csv"
#define STR_TMP_PERIODICAL_WTPTX     STR_TMP_DIR_DAILY_REPORT"/periodicalWTPTx.csv"
#define STR_TMP_PERIODICAL_WTPRX     STR_TMP_DIR_DAILY_REPORT"/periodicalWTPRx.csv"
#endif
#define STR_TMP_PERIODICAL_PORTINFO_PREFIX   STR_TMP_DIR_DAILY_REPORT"/periodicalPort"
#define STR_TMP_PNG_DATASOURCE  STR_TMP_DIR_DAILY_REPORT"/pngDataSource.csv"
    
#define STR_USR_BIN_HTML_MAILER	    "/usr/bin/html_mailer"
#define STR_USR_BIN_PERIIDICALLY	"/usr/bin/periodically"
#define STR_USR_BIN_GDUTIL      	"/usr/bin/gdutil"
#define STR_USR_BIN_RESET_CSV   	"/usr/bin/reset_csv"

#define STR_TMP_MAILBODY_HTM	STR_TMP_DIR_DAILY_REPORT"/mailbody.htm"

#define STR_ETC_HTML_HEAD_TEMPLATE "/etc/tmp/html-head.template"
#define STR_ETC_LOGO_GIF "/etc/tmp/logo.gif"
#define STR_ETC_BACK_TOP_GIF "/etc/tmp/i_top.gif"

/* add the buffer size to be larger than zysh contrains */

/* define the big-enough length for each configuration fields, compliant with CLI */
#define CLI_HOST_ADDRESS_LEN	256
#define CLI_EMAIL_ADDRESS_LEN	84
#define CLI_USERNAME_LEN	68
#define CLI_PASSWORD_LEN	64
#define CLI_SUBJECT_LEN	64
#define CLI_TLS_LEN   10

struct ZyshConfig_st {
	int bActivate;
	char strHostAddress[CLI_HOST_ADDRESS_LEN];
    char strMailFrom[CLI_EMAIL_ADDRESS_LEN];
    char strMailTo_1[CLI_EMAIL_ADDRESS_LEN];
    char strMailTo_2[CLI_EMAIL_ADDRESS_LEN];
    char strMailTo_3[CLI_EMAIL_ADDRESS_LEN];
    char strMailTo_4[CLI_EMAIL_ADDRESS_LEN];
    char strMailTo_5[CLI_EMAIL_ADDRESS_LEN];
    int bSmtpAuthOn;
    char strUsername[CLI_USERNAME_LEN];
    char strPassword[CLI_PASSWORD_LEN];
    char strSubject[CLI_SUBJECT_LEN];
    int bAppendSystemName;
    int bAppendDateTime;
	int bCpuUsage;
	int bMemUsage;
#ifdef ZLDCONFIG_TRAFFIC_STATISTICS_CONN_PWLAN_WORKAROUND
	int bSessionUsage;
#endif
	int bPortUsage;
#ifdef ZLDCONFIG_CAPWAP_DAILY_REPORT 	
	int bStationCount;
	int bWTPTx;
	int bWTPRx;
	int bAPsta;
	int bAPTraffic;
#endif
	int bAvReport;
	int bAsReport;
	int bIdpReport;
#ifdef ZLDCONFIG_TRAFFIC_STATISTICS_CONN_PWLAN_WORKAROUND
	int bTrafficReport;
#endif
	int intScheduleHour;
	int intScheduleMinute;
	int bResetCounter;
	int intHostPort;
	int bTLSOn;
	char strTLS[CLI_TLS_LEN];
};

void writeConfig(struct ZyshConfig_st *pZyConfig);
struct ZyshConfig_st *readConfigFile(void);

#include "zylog.h"
#define _ZYLOG(pri,note,msg,arg...)  zylog(ZYLOG_SRC_DAILY_REPORT, \
                                                        pri, \
                                                        ZYLOG_FAC_DAILY_REPORT, \
                                                        0,0,0,0, \
                                                        note, \
                                                        msg, \
                                                        ##arg)

enum eTargetPng {
    eTargetPngCpu = 0,
    eTargetPngMemory,
    eTargetPngSession,
    eTargetPngPort,
    eTargetPngStation,
    eTargetPngWTPTx,
    eTargetPngWTPRx,
    eTargetPngSTACount,
    eTargetPngWLANtraffic
};

#define STR_CPU_DASHED_USAGE    "cpu-usage"
#define STR_MEM_DASHED_USAGE    "mem-usage"
#define STR_SESSION_DASHED_USAGE "session-usage"
#define STR_PORT_DASHED_USAGE    "port-usage"
#ifdef ZLDCONFIG_CAPWAP_DAILY_REPORT 
#define STR_STATION_DASHED_USAGE    "station-count"
#define STR_WTPTX_DASHED_USAGE    "wtp-tx"
#define STR_WTPRX_DASHED_USAGE    "wtp-rx"
#endif

#define STR_IDP_DASHED_REPORT    "idp-report"
#define STR_AV_DASHED_REPORT    "av-report"
#define STR_AS_DASHED_REPORT    "as-report"
#define STR_TRAFFIC_DASHED_REPORT    "traffic-report"

#endif


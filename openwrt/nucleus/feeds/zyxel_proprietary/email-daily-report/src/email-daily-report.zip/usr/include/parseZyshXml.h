#ifndef _PARSEXEL_H_
#define _PARSE_XML_H_

#include <string.h>
#include <errno.h>

#define STR_ZYSHXMLOUT	"/tmp/zyshXmlOut.xml"

typedef void (*HANDLE);

HANDLE parseZyshXmlOutput(char *strZyshCmd); /* sample strZyshCmd = "show system uptime|xml" */
void closeZyshResultHandle(HANDLE hResult);

char *lookup(HANDLE hResult, char *strKeyword,  char *outbuf, size_t outbufLen);
/* 1) case-insensitive,2) will return the first match value, 3) substring matching, 4) for both LIST and TABLE format*/

char *lookupWithIndex(HANDLE hResult, int num, char *strKeyword,  char *outbuf, size_t outbufLen);

int sizeofZyshResultHandle(HANDLE hResult);

HANDLE parseDoc(char *docname);
void showAllEntries(HANDLE hResult);

#define STR_PARSEZYSHXML_LOGNAME    "/tmp/parseZyshXml.log"

//extern int errno;
extern int gParseZyshXml_DBGEnable;

#ifdef ENABLE_DAILY_DEBUG
#define DBG(format, args...) \
    do { \
        FILE *fpDbg = NULL; \
        if( (fpDbg = fopen(STR_PARSEZYSHXML_LOGNAME, "a+")) ) { \
            fprintf(fpDbg, "%s-%s()-%d:", __FILE__, __func__, __LINE__); \
            fprintf(fpDbg, format, ##args); \
            fclose(fpDbg); \
        } \
        else { \
            fprintf(stderr, "Fail to fopen %s !! error: %s\n",STR_PARSEZYSHXML_LOGNAME, strerror(errno)); \
        } \
	} while(0)
#else
#define DBG(format, args...)
#endif

#ifdef ENABLE_DAILY_DEBUG
#define CLEAR_DBGLOG() \
    do { \
        FILE *fpDbg = NULL; \
        if( (fpDbg = fopen(STR_PARSEZYSHXML_LOGNAME, "w+")) ) { \
            fclose(fpDbg); \
        } \
        else { \
            fprintf(stderr, "Fail to fopen %s !! error: %s\n",STR_PARSEZYSHXML_LOGNAME, strerror(errno)); \
        } \
    } while(0)
#else
#define CLEAR_DBGLOG()
#endif

#endif

#ifndef _ZYLOG_WRAPPER_H
#define _ZYLOG_WRAPPER_H

extern int zylog_msgsnd(int src, int pri, int fac, 
						u_int32_t srcip, u_int16_t srcport,
						u_int32_t dstip, u_int16_t dstport,
						char *note, const char *fmt, ...);

#ifdef ZLDCONFIG_INFO_TRANSFER_WTP_SUPPORT
extern int
zylog_msgsnd2AC(uint8_t src, uint8_t pri, uint8_t fac, u_int32_t srcip, u_int16_t srcport,
      u_int32_t dstip, u_int16_t dstport, char *note, const char *fmt, ...);
#endif /* ZLDCONFIG_INFO_TRANSFER_WTP_SUPPORT */

#endif /* !_ZYLOG_WRAPPER_H */

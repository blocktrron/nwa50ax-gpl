/****************************************************************************/

/*

* Copyright (C) 2000-2010 ZyXEL Communications, Corp.

* All Rights Reserved.

*

* ZyXEL Confidential;

* Protected as an unpublished work, treated as confidential,

* and hold in trust and in strict confidence by receiving party.

* Only the employees who need to know such ZyXEL confidential information

* to carry out the purpose granted under NDA are allowed to access.

*

* The computer program listings, specifications and documentation

* herein are the property of ZyXEL Communications, Corp. and shall

* not be reproduced, copied, disclosed, or used in whole or in part

* for any reason without the prior express written permission of

* ZyXEL Communications, Corp.

*/

/****************************************************************************/ 

#ifndef MIB_TRAP_TYPE_H
#define MIB_TRAP_TYPE_H



/* when you add a new trap type, please insert to the tail of the structure */
enum trap_type  {
	wlanStaAssociation,
	wlanStaDisassociation,
	wlanStaAuthFail,
	wtpOnLine,
	wtpOffLine,
	/* backward compatible for proWireless trap */
	wtpProOnLine,
	wtpProOffLine
};

#define OPT_OIDTYPE				"oid"
#define OPT_MAC					"mac"
#define OPT_SSID				"ssid"
#define OPT_REASON				"reason"

#define PROWIRELESS_TRAP_PATH	"/usr/local/bin/proWireless_snmptrap"


#endif


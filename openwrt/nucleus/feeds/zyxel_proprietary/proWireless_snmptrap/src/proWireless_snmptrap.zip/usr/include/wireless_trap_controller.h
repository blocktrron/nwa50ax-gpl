/****************************************************************************/
/*
* Copyright (C) 2000-2010 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/ 
 

#ifndef MIB_WIRELESS_TRAP_CONTROLLER_H
#define MIB_WIRELESS_TRAP_CONTROLLER_H


#define SNMP_SCOPE		"system/service/snmp"
#define SNMP_TYPE 		"service_snmp_t"

#define SNMPD_PATH "/usr/local/sbin/snmpd"
#define SNMP_XML_EXPORT	"/tmp/snmp.xml"


#define	ENABLE		1
#define	DISABLE		2

/*oid*/
#define	TRAP_WIRELESS_STATUS		1

#endif


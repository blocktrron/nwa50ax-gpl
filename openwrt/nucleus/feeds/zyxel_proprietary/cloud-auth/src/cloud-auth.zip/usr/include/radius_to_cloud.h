#include "zld-spec.h"

#define AUTH_MODULE_LOCAL		1
#define AUTH_MODULE_RADIUS		2
#define AUTH_MODULE_LDAP		3
#define AUTH_MODULE_AD			4

#define	RET_SUCCESS			0
#define	ERR_GENERAL_FAIL		-1
#define	ERR_SOCK_CONNECT_FAIL		-2
#define	ERR_SOCK_READ_FAIL		-3

/* socket timeout between radiustocloud and cloudauthd */
/* (QUERY_CLOUD_INFO_TIMEOUT + 5)                      */
#define ERR_SOCK_TIMEOUT			20

/* CC */
#define CC_QUERY_SUCCESS			1
#define CC_QUERY_FAIL				2


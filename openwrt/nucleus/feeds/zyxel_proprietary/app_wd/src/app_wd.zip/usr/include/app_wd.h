/******************************************************************************
 *
 *	Copyright (C) 2002-2005 ZyXEL Communications, Corp.
 *	All Rights Reserved.
 *
 * ZyXEL Confidential; Need to Know only.
 * Protected as an unpublished work.
 *
 * The computer program listings, specifications and documentation
 * herein are the property of ZyXEL Communications, Corp. and shall
 * not be reproduced, copied, disclosed, or used in whole or in part
 * for any reason without the prior express written permission of
 * ZyXEL Communications, Corp.
 *
 *****************************************************************************/
 /* $Id: app_wd.h,v 1.7 2006/07/04 04:14:29 bato.wang Exp $ */

/*
 * $Log: app_wd.h,v $
 * Revision 1.7  2006/07/04 04:14:29  bato.wang
 * Add mount points count
 *
 * Revision 1.6  2006/03/20 05:24:51  peterwang
 * add definitions for supporting memory usage monitoring
 *
 * Revision 1.5  2005/12/05 13:03:36  peterwang
 * *** empty log message ***
 *
 * Revision 1.4  2005/12/05 09:13:40  peterwang
 * integrate with zysh configuration
 *
 * Revision 1.3  2005/11/23 08:55:10  peterwang
 * 1. modify app_data_s structure
 * 2. modify query interval to 5 secs
 *
 * Revision 1.2  2005/11/21 08:56:29  peterwang
 * add cvs log
 *
 */

#ifndef _APP_WD_H_
#define _APP_WD_H_

#define DEFAULT_RETYY_COUNT		3
/* #define QURRY_INTERVAL		300 Obsolete, Max@2011.2.21 */
#define INITIAL_SLEEP_INTERVAL		240
#define DEFAULT_APPWD_CHECK_TIMER	60 /* seconds */

#define BUF_LEN_256			256
#define BUF_LEN_32			32
#define MAX_LOG_FILE_SIZE		64*1024 /* 64 KB */

#define APP_WD_OK	0
#define	APP_WD_FAIL	-1
#define APP_WD_YES	APP_WD_OK
#define APP_WD_NO	APP_WD_FAIL

#define APP_WD_GLOBAL_SETTING_PATH	("/tmp/__appwd__")
#define APP_WD_CHECKING			("/tmp/app_wd_checking")
#define APP_WD_CHECKING_SH		("/etc/app_wd/checking.sh")
#define APP_WD_REBOOT_LOG_PATH		("/etc/zyxel/ftp/tmp/app_wd_reboot.log")
#define APP_WD_RECOVER_LOG_PATH		("/etc/zyxel/ftp/tmp/app_wd_recover.log")
#define APP_WD_FLAG_PATH		("/tmp/app_wd_activate")
#define APP_WD_PATH			("/usr/sbin/app_wd")
#define APP_WD_WLAN_APPLY_LOCK		("/var/zyxel/wlan/wlan_apply_all.lock")
#define APP_WD_HOSTAPD_LOG_PATH		("/tmp/app_wd_hostapd.log")
#define APP_WD_CRONTAB_PATH		("/var/zyxel/crontab")
#define APP_WD_SIRQ_RUN_SHELL   ("/etc/app_wd/sirq_packet.sh")
#define APP_WD_SIRQ_CHECK_FLAG   ("/tmp/packet_on_sirq_flag")

/* porting from zysh-1.0.0 */
#define MAX_CMD_BUFFER 4096
#define EXEC_NOWAIT(file, args...) { \
        char __cmd__[MAX_CMD_BUFFER]; \
        sprintf(__cmd__, file, ##args); \
        __exec_nowait(__cmd__); \
}

enum {
	ONCE = 1,
	ALWAYS
};

/* recover status */
enum {
	SUSPEND = 1, /* Recover fail_count reach maximun value */
	SLEEP, /* watch dog sleep */
	RUNNING /* wake up */
};

/* application status */
enum {
	APP_DEAD = 1,
	APP_ZOMBIE,
	APP_ALIVE
};

typedef struct _monitor_list_s app_data_s;
typedef struct _monitor_list_s {
	char 		app_name[BUF_LEN_32];
	int 		app_pcount_min;
	int 		app_pcount_max;
	int 		app_pcount_current;
	unsigned int 	app_dead_count;
	unsigned int 	app_pnmatch_count;
	unsigned int 	app_zombie_count;
	int 		app_dead;
	int 		app_pnmatch;
	int 		app_zombie;
	int		need_to_check;
	int		already_in_check;
	int		console_printed;
	int		alert_logged;
	/**** Internal Configuration, Not read from config file ****/
#define CHECKING_OFF 0 /* Checking if not define */
#define CHECKING_ON 1 
/* #define CHECKING_RESOURCE 1<<1 */
	int checking_flag; /* Some apps. may not need to check temporarily or be terminated in normal case */
#ifdef ZLDCONFIG_APP_AUTO_RECOVER
	/**** Configuration ****/
	int auto_recover_activate; /* 0: Recover will not perform, 1: enable recover */
	int auto_recover_reboot; /* 0: Recover will not perform, 1: enable recover */
	int auto_recover_always; /* 0: Continue trying recover even if fail. 1: check fail_count and try_count */
	unsigned int auto_recover_max_fail_count; /* apply it when unlimited is 0 */
	unsigned int auto_recover_max_try_count; /* apply it when unlimited is 0 */
	/**** Deamon status *****/
	int auto_recover_status;
	unsigned int auto_recover_try_count; /* total recover count. Keep it as 0 when recover_always is 1. Useless now */
	unsigned int auto_recover_fail_count; /* Will count when recover_status = FAIL */
#endif
} *moniter_list_t;

/* Configurable by ZySH Command */
typedef struct _appwd_global_config_s appwd_config_s;
typedef struct _appwd_global_config_s {
	int		appwd_activate;
	int		appwd_alert;
	int		appwd_console_print;
#ifdef ZLDCONFIG_APP_AUTO_RECOVER
	int		appwd_auto_recover_activate; /* 0: Stop auto recover. 1: Activate auto recover */
	int		appwd_sys_reboot_activate; /* 0: Stop system reboot. 1: Activate system reboot */
#endif
	unsigned	retry_count;
	unsigned	interval;
	unsigned	mem_usage_threshold_min;
	unsigned	mem_usage_threshold_max;
	/*wuxi,Jeffrey, 2010-04-23 << appwatchdog enhancement*/
	unsigned cpu_usage_threshold_min;
	unsigned cpu_usage_threshold_max;
	/*wuxi,Jeffrey, 2010-04-23 >> appwatchdog enhancement*/
	unsigned	disk_usage_threshold_min;
	unsigned	disk_usage_threshold_max;
	unsigned	cpu_sirq_usage_threshold_min;
	unsigned	cpu_sirq_usage_threshold_max;
} *appwd_global_config_t;

#endif


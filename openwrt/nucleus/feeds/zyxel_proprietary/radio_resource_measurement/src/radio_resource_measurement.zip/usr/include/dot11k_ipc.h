/****************************************************************************/
/*
* Copyright (C) 2000-2018 Zyxel Communications, Corp.
* All Rights Reserved.
*
* Zyxel Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such Zyxel confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of Zyxel Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* Zyxel Communications, Corp.
*/
/****************************************************************************/
#ifndef _DOT11K_IPC_H
#define _DOT11K_IPC_H

#include "dot11k_shlib_common.h"

#ifndef EADDR_LEN
#define EADDR_LEN   6
#endif
#define MAX_DEBUG_FLAG_STRLEN   16
#define DOT11K_EVENT_MSG_SIZE   6000
#define DOT11K_EVENT_PATH       "/tmp/dot11ksocketevent"

typedef struct dot11kSocketEventMsg_s{
    pid_t pid;
    int code;
    char msg[DOT11K_EVENT_MSG_SIZE];
}dot11kSocketEventMsg_t;

typedef struct dot11k_ipc_bcn_measurement_s{
	int mode;
	int interval;
}dot11k_ipc_bcn_measurement_t;

typedef struct dot11k_ipc_nr_record_s
{	
	unsigned char nrMac[EADDR_LEN];
	int channel;
}dot11k_ipc_nr_record_t;

typedef struct dot11k_ipc_nr_s{
	unsigned char macAddr[EADDR_LEN];
	int nr24gCnt;
	int nr5gCnt;
}dot11k_ipc_nr_t;

enum dot11k_event_code {
	EVENT_DOT11K_GET_NR=0,
	EVENT_DOT11K_SET_BCN_MEASUREMENT_INTERVAL,
	EVENT_DOT11K_SET_BCN_MEASUREMENT_MODE,
	EVENT_DOT11K_GET_BCN_MEASUREMENT_INFO,
	EVENT_DOT11K_SET_ROAMING_GROUP,
	EVENT_DOT11K_SET_DBG_FLAG,
	EVENT_DOT11K_GET_DBG_FLAG,
	EVENT_DOT11K_SET_SAVE_TO_FILE,
};

int send_dot11k_event_no_wait(int eventCode, char *msg, int len);
int send_dot11k_event_wait(int eventCode, char *msg, int len);
int receive_dot11k_event(void *arg, int arg_len, int connectFd);

#endif /* _DOT11K_IPC_H */
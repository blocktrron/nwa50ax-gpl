/****************************************************************************/
/*
* Copyright (C) 2000-2018 Zyxel Communications, Corp.
* All Rights Reserved.
*
* Zyxel Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such Zyxel confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of Zyxel Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* Zyxel Communications, Corp.
*/
/****************************************************************************/
#ifndef _DOT11K_SHLIB_COMMON_H
#define _DOT11K_SHLIB_COMMON_H

#define DOT11K_DEBUG_ERROR     0x00000001
#define DOT11K_DEBUG_INFO      0x00000002
#define DOT11K_DEBUG_ALL       0xffffffff

#endif /* _DOT11K_SHLIB_COMMON_H */
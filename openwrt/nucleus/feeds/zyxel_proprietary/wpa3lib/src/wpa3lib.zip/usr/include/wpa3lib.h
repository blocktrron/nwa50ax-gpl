#ifndef _WPA3LIB_H_
#define _WPA3LIB_H_

#include "zld-spec.h"
#include <stdint.h>
#include <unistd.h>

#define WPA3_SSID_NAME_LEN 33
#define WPA3_DOT11_VAR_WLAN	"/var/zyxel/wlan"
#define WPA3_MAX_STR_LEN		256

typedef struct oweconf{
	int owetmvap_idx;
	char ssidname[WPA3_SSID_NAME_LEN];
	char mac[20];
	int openssid_idx;
     }oweconf_t;

int wpa3_get_owetm_info(int radio_idx, int interface_idx , oweconf_t *owetm_conf );
int wpa3_get_oweindex(int radio_idx, int interface_idx);
void wpa3_get_new_ssidname(int radio_idx, int interface_idx , char *original_ssidname);
void wpa3_owetm_trans_ssidname(int radio_idx, int interface_idx ,int open_interface_idx,char *newssidname ,int ssidlength);
char * GetDbgStr(void);

#define wpa3lib_printf(format, args...) \
	do { \
		if(wpa3lib_dbg > 0)\
		{\
			char *__dbg_buf; \
			__dbg_buf = (char *)GetDbgStr(); \
			snprintf(__dbg_buf,(size_t)WPA3LIB_DBG_STR_LEN,(const char*)("%s:%d:"format"\n\r"),__FILE__,__LINE__,## args); \
			write(console_fd, __dbg_buf, strlen(__dbg_buf)); \
		}\
	} while ( 0 )

#endif

#ifndef __LINUX_NETLINK_EXTERN_H
#define __LINUX_NETLINK_EXTERN_H

#include <linux/netlink.h>

#ifndef ZLD_CUSTOM_NETLINK
#define ZLD_CUSTOM_NETLINK 1

/*
 * The maximum number of protocols is MAX_LINKS = 32.
 * (Defined in linux/netlink.h)
 * The current kernel (4.4.60) has already defined 20 protocols. Thus we can
 * only define up to "12" protocols.
 * SPF10 FC defined netlink is below:
 * SPECTRAL_NETLINK 		17	qca-wifi: spectral netlink
 * NETLINK_ATH_EVENT		19	qca-wifi: adhoc netlink
 * NETLINK_WNM_EVENT		20	qca-wifi: WNM
 * NETLINK_BAND_STEERING_EVENT	21	qca-wifi: band select netlink
 * NETLINK_LOWI_IF_EVENT	22	qca-wifi: lowi if netlink
 * NETLINK_ACFG			24	qca-wifi: acfg
 * NETLINK_ATH_SSID_EVENT	29	qca-wifi: SSID steering
 * NETLINK_ALD			31	qca-wifi: ald netlink
 * NETLINK_SDK			30	qca-nss-macsec: nss macsec netlink
 * NETLINK_QCA_MC		23	qca-mcs: MC netlink
 */
enum zy_netfilter_types {
	NETLINK_ZYKLOG				= 8, /* Open-iSCSI */
	NETLINK_PROWLAN				= 18, /* SCSI Transports */
	NETLINK_PROC_TO_APP			= 25, /* qca-hify-bridge: Hify netlink */
	NETLINK_FORWARDTO_ACLOG		= 26,
	NETLINK_ETHER_INFO_NOTIFY	= 27, /* qca-hify-bridge: MC netlink */
	NETLINK_LINK_UPDOWN			= 28,
};

#endif /* Define ZLD_CUSTOM_NETLINK */
#endif /* __LINUX_NETLINK_EXTERN_H */

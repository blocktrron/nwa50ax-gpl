#ifndef __LINUX_PROWLAN_IPC_H
#define __LINUX_PROWLAN_IPC_H
/***************************** INCLUDES *****************************/

/* This header is used in user-space, therefore need to be sanitised
 * for that purpose. Those includes are usually not compatible with glibc.
 * To know which includes to use in user-space, check iwlib.h. */
#ifdef __KERNEL__
#include <linux/types.h>		/* for "caddr_t" et al		*/
#include <linux/socket.h>		/* for "struct sockaddr" et al	*/
#include <linux/if.h>			/* for IFNAMSIZ and co... */
#endif	/* __KERNEL__ */


enum {
	REASON_UNSPECIFIED		= 1,
	REASON_AUTH_EXPIRE		= 2,
	REASON_AUTH_LEAVE     = 3,
	REASON_ASSOC_EXPIRE		= 4,
	REASON_ASSOC_TOOMANY		= 5,
	REASON_NOT_AUTHED		= 6,
	REASON_NOT_ASSOCED		= 7,
	REASON_ASSOC_LEAVE		= 8,
	REASON_ASSOC_NOT_AUTHED	= 9,

	REASON_RSN_REQUIRED		= 11,
	REASON_RSN_INCONSISTENT	= 12,
	REASON_IE_INVALID		= 13,
	REASON_MIC_FAILURE		= 14,
};

/* ----------------------- PROWLAN EVENT TYPE ----------------------- */
#define PROWE_MSG   0x8000  /* Control Message */
#define PROWE_MSG_ASSOC   0x0001 /* Association/Reassociation */
#define PROWE_MSG_DIASSOC 0x0002 /* Disassociation */
#define PROWE_MSG_DEAUTH  0x0003 /* DeAuth */
#define PROWE_MSG_UPLINK_CONNECTED	0x0004 /* For ZyMesh, When VAP(station mode) connected to up link send notify ZyMesh app */
#define PROWE_MSG_UPLINK_DISCONNECTED	0x0005 /* For ZyMesh, When VAP(station mode) disconnected to up link send notify ZyMesh app */
#define PROWE_MSG_AUTHORIZED		0x0006 /* STA Authorized */
#define PROWE_MSG_DHCP_SNIFFER		0x0007 /* For DHCP sniffer */
#define PROWE_MSG_PRE_DISASSOC		0x0008 /* For Update Tx/Rx bytes */

#define PROWE_INFO  0x8100  /* Configure Infomation */
#define PROWE_INFO_STAIP   0x0001 /* mac + extra ip */
#define PROWE_INFO_CHANNEL 0x0002 /* Channel */
#define PROWE_INFO_SSID 0x0003 /* SSID */
#define PROWE_INFO_SECURITY 0x0004 /* security mode */
#define PROWE_INFO_ROLE 0x0005 /* wlan mode */
#define PROWE_INFO_DEL 0x0006 /* VAP delete */
#define PROWE_INFO_VAP 0x0007

#define PROWE_UTIL  0x8200  /* UTIL */
#define PROWE_UTIL_RESET   0x0001 /* Reset DUT's Config to default*/
#define PROWE_UTIL_REBOOT   0x0002 /* Reboot DUT */
#define PROWE_UTIL_BB_PANIC  0x0004 /* BB panic */
#define PROWE_UTIL_SETUP_RADIO  0x0005 /* Set up wifiX VAPs.
                                          For target assert, wifi1 VAPs should be re-established
                                          after successful target assert recovery */
#define PROWE_UTIL_DFS_ENHANCE 0x0006 /* DFS channel switch enhancement */
#define PROWE_UTIL_SETUP_RADIO_STOP_VAP_FAIL 0x0007 /* Set up wifiX VAPs for can't stop VAP*/
#define PROWE_UTIL_DENY_NSS_ACCEL    0x0008 /* Deny NSS acceleration */

#define PROWE_OFFLOAD_EVENT  0x8300  /* Offload engine event */
#define PROWE_OFFLOAD_EVENT_BMISS_TIMEOUT   0x0001 /* Beacon miss timeout event */
#define PROWE_OFFLOAD_EVENT_BMISS_DETECT   	0x0002 /* Beacon miss detect event */
#define PROWE_OFFLOAD_EVENT_PN_CHECK_FAILED     0x0003 /* PN check failed */
#define PROWE_OFFLOAD_EVENT_DFS_CHECK     0x0004 /* DFS check */

#define PROWE_MEASUREMENT  0x8400   /* MEASUREMENT */
#define PROWE_MEASUREMENT_BCNRPT  0x001 /* beacon report */
#define PROWE_MEASUREMENT_NEIGHBOR_REQ  0x002 /* neighbor request */
#define PROWE_MEASUREMENT_STA_ACTIVITY_CHANGE_IND 0x003  /* sta activity change event*/

#define PROWE_MONITOR 0x8500 /* MONITOR */
#define PROWE_MONITOR_PROBE  0x001 /*listen to Probe */

#define PROWE_BSTM 0x8600 /* 11v BSS Transition Management */
#define PROWE_BSTM_RESP 0x01 /* BSS Transition Management response */

#define PROWE_EVENT_DFS 0x8700 /* DFS related event */
#define PROWE_EVENT_DFS_CAC_EXPIRED 0x0001  /* CAC expired */
#define PROWE_EVENT_DFS_RADAR_DETECT 0x0002  /* Radar detected */
#define PROWE_EVENT_DFS_NOL_EXPIRED 0x003    /* NOL expired */

#define PROWE_SMESH 0x8800 /* Smart-mesh event */
#define PROWE_SMESH_INFO 0x01 /* common info */
#define PROWE_SMESH_WBS_FOUND 0x02 /* Root AP found */

/*****************************************************************
 *		Link layer specific messages.
 ****/
/* struct prowlan_ifinfomsg
 * passes link level specific information, not dependent
 * on network protocol.
 */

struct prowlan_ifinfomsg
{
	char	ifi_name[IFNAMSIZ];
	unsigned short	ifi_type;		/* ARPHRD_* */
	int		ifi_index;		/* Link index	*/
};

/* ---------------------------------------------- */
enum {
	NORMAL,     /* normal change */
	DFSDETECT,  /* DFS detected */
};

struct prowlan_chann_info {
	__u32 freq; /* Setting in MHz */
	__u8 ieee; /* IEEE Channel number */
	__u8 reason; /* freq set reason */
	__s8 cw_extoffset; /* channel width extern channel offset */
	__u8 vht_ch_freq; /* 11ac 80MHz channel center frequency*/
	__u8 vht_ch_freq2; /* 11ax 160MHz channel center frequency*/
	__u32 cac_timeout; /* DFS cac */
};

struct prowlan_ssid_info {
	__u32 len;				/* length in bytes */
	__u8 name[32];	/* ssid contents, max length is 32 that include "/0" */
};

struct prowlan_sec_mode {
	__u32 len;				/* length in bytes */
	__u8 name[32];	/* sec name, max length is 32 that include "/0" */
	__u32 is_zy1x;
};

struct prowlan_sta_info {
	__u16 vid;
	__u8 macaddr[6];
	/* Set to 1 if this client supports BSS Transition Management */
	__u8 isBTMSupported : 1;
	/* Set to 1 if this client implements Radio Resource Manangement */
	__u8 isRRMSupported : 1;
	__u8 rssi;
	__u8 authorized;
	__u8 is_reassoc;
	__u8 auth_alg;
	__u8 ssid[32];
	__u16 event_code;		/* disassoc/deauth event code */
	__u16 reason_code;		/* disassoc/deauth reason code */
	char event_type[64];	/* disassoc/deauth event type */
	__u8 reassoc_ap[6];
	char security[32];	/*Client security mode*/
	__u64 tx_bytes;
	__u64 rx_bytes;
	__u8 channel;
};

struct prowlan_security_info {
	__u32 len;				/* length in bytes */
	__u8 name[32];	/* security contents, max length is 32 that include "/0" */
};

struct prowlan_op_mode {
	__u16 opmode;	/* wlan role */
	__u16 flags;
};

struct prowlan_uplink_status {
	__u16 status;
	__u8 macaddr[6];
	char	ifi_name[IFNAMSIZ];
};

struct prowlan_vap_info{
	__u8 macaddr[6];
};

struct prowlan_reboot_info {
	__u8 reason[64];    /* reboot reason */
};

struct prowlan_setup_radio {
	__u8 radio_num;     /* radio number. 0: wifi0, 1: wifi1. */
};

struct prowlan_client_info {
	__u16 cap;
	__u8 macaddr[6];
	__u8 rssi;    /*  The RSSI of the received probe request.*/
};

struct prowlan_dfs_enhance_info {
	__u8 dfs_action; /* DFS channel switch enhancement */
};
/**
 * Metadata about a client activity status change.
 */
struct prowlan_sta_activity_change_ind {
	/* The MAC address of the client that activity status changes */
	__u8 macaddr[6];
	/* Activity status*/
	__u8 activity;
};
/**
 * Metadata and report contents about a Radio Resource Measurement report
 */
struct prowlan_rrm_report_ind {
	/* The type of the rrm event: One of BSTEERING_RRM_TYPE.*/
	__u32 rrm_type;
	/* The token corresponding to the measurement request.*/
	__u8 dialog_token;
	/* MAC address of the reporter station.*/
	__u8 macaddr[6];
	/* The result bitmap, as defined in IEEE80211_RRM_MEASRPT_MODE.*/
	__u8 measrpt_mode;
};


struct prowlan_neighbor_req_ind {
	/* MAC address of the reporter station.*/
	__u8 macaddr[6];
	__u8 dialogtoken;
	__u8 ssid[32];
	__u8 ssid_len;
};


struct prowlan_dfs_event_info {
	__u32 nchan;
	__u8 channel[16];
};
/**
 * Metadata and report contents about a Wireless Network
 * Management event
 */
struct prowlan_wnm_event_ind {
	/* The type of the wnm event: One of BSTEERING_WNM_TYPE.*/
	__u32 wnm_type;
	/* The token corresponding to the message.*/
	__u8 dialog_token;
	/* status of the response to the request frame */
	__u8 status;
	/* BSTM Reject Reason Code Received from STA */
	__u8 reject_code;
	/* number of minutes that the STA requests the BSS to delay termination */
	__u8 termination_delay;
	/* BSSID of the BSS that the STA transitions to */
	__u8 target_bssid[6];
	/* MAC address of the sending station.*/
	__u8 macaddr[6];
};

struct prowlan_smesh_event_ind {
	__u8 rt_type;
	__u8 bssid[6];
	__u8 channel;
};


struct prowlan_nss_accel_ind {
	__u32 vlan_id;
};

/* ----------------------- WIRELESS EVENTS ----------------------- */
/*
 * Wireless events are carried through the rtnetlink socket to user
 * space. They are encapsulated in the IFLA_WIRELESS field of
 * a RTM_NEWLINK message.
 */

struct prowlan_req_hdr {
	__u16 len;	/* u data length */
	__u16 ext_len;	/* extra data length */
};

struct	prowlan_req_data
{
	struct prowlan_req_hdr hdr;		/* 4 bytes */
	union{
		struct prowlan_sta_info	sta;
		struct prowlan_chann_info chann;
		struct prowlan_ssid_info ssid;
		struct prowlan_sec_mode sec_mode;
		struct prowlan_op_mode wlan_mode;
		struct prowlan_uplink_status uplink_status;
		struct prowlan_vap_info vap_info;
		struct prowlan_reboot_info reboot_info;
		struct prowlan_setup_radio radio_info;
		struct prowlan_client_info client;
		struct prowlan_dfs_enhance_info dfs_enhance;
		struct prowlan_sta_activity_change_ind sta_activity_change;
		struct prowlan_rrm_report_ind rrm_report;
		struct prowlan_wnm_event_ind wnm_event;
		struct prowlan_neighbor_req_ind neighbor_req;
		struct prowlan_dfs_event_info dfs_event;
		struct prowlan_smesh_event_ind smesh_event;
		struct prowlan_nss_accel_ind nss_accel_info;
	}u;
};

struct prowlan_event_hdr {
	__u16   len;			/* Real length of this stuff */
	__u16   cmd;			/* IOCTL */
};
/*
 * A Wireless Event. Contains basically the same data as the ioctl...
 */
struct prowlan_event {
	struct prowlan_event_hdr hdr;
	struct prowlan_req_data	data;		/* IOCTL fixed payload */
};

struct net_device;
extern void prowlan_send_event(struct net_device *dev, unsigned int group, unsigned int cmd, struct prowlan_req_data *caprqu, char *extra);

#endif	/*  */

#ifndef __LINUX_PROWLAN_IPC_VAR_H
#define __LINUX_PROWLAN_IPC_VAR_H

#ifndef __KERNEL__
#include <stdint.h>
#endif

/****
 *		messages.
 ****/

/* Types of messages */
#if 0
//org:
enum {
	PROWLANM_BASE	= 1,
#define PROWLANM_BASE	PROWLANM_BASE

	PROWLANM_WIRELESS_EVENT	= 1,
#define PROWLANM_WIRELESS_EVENT	PROWLANM_WIRELESS_EVENT

	__PROWLANM_MAX,
#define PROWLANM_MAX		__PROWLANM_MAX
};

#else


#ifdef __KERNEL__
typedef int (*prowlan_doit_func)(struct sk_buff *, struct nlmsghdr *, void *);
typedef int (*prowlan_dumpit_func)(struct sk_buff *, struct netlink_callback *);

int __prowlan_register(int protocol, int msgtype, prowlan_doit_func doit);
int __prowlan_unregister(int protocol, int msgtype);

struct prowlan_link
{
	prowlan_doit_func		doit;
	prowlan_dumpit_func	dumpit;
};
#endif

struct prowlan_tlv_hdr {
    uint16_t type;
    uint16_t length; /* Max length is 0x1FFF */
}__attribute__ ((packed));

enum {
	PROWLANM_BASE	= 1,
#define PROWLANM_BASE	PROWLANM_BASE

	PROWLANM_WIRELESS_EVENT	= 1,
#define PROWLANM_WIRELESS_EVENT	PROWLANM_WIRELESS_EVENT

	__PROWLANM_MAX,
#define PROWLANM_MAX		__PROWLANM_MAX
};

/* Types of messages */
enum {
	PROWLAN_NK_BASE                     = 0,
#define PROWLAN_NK_BASE                 PROWLAN_NK_BASE
	PROWLANM_NK_WIRELESS_EVENT          = 10,
#define PROWLANM_NK_WIRELESS_EVENT      PROWLANM_NK_WIRELESS_EVENT
    PROWLANM_NK_WIRELESS_XXX            = 11,
#define PROWLANM_NK_WIRELESS_XXX        PROWLANM_NK_WIRELESS_XXX
    PROWLANM_NK_WIRELESS_GET            = 12,
#define PROWLANM_NK_WIRELESS_GET        PROWLANM_NK_WIRELESS_GET
    PROWLANM_NK_WIRELESS_SET            = 13,
#define PROWLANM_NK_WIRELESS_SET        PROWLANM_NK_WIRELESS_SET

   	PROWLANM_NK_SYSTEM_EVENT            = 14,
#define PROWLANM_NK_SYSTEM_EVENT        PROWLANM_NK_SYSTEM_EVENT
    PROWLANM_NK_SYSTEM_XXX              = 15,
#define PROWLANM_NK_SYSTEM_XXX          PROWLANM_NK_SYSTEM_XXX
    PROWLANM_NK_SYSTEM_GET              = 16,
#define PROWLANM_NK_SYSTEM_GET          PROWLANM_NK_SYSTEM_GET
    PROWLANM_NK_SYSTEM_SET              = 17,
#define PROWLANM_NK_SYSTEM_SET          PROWLANM_NK_SYSTEM_SET
	__PROWLANM_NK_MAX,
#define PROWLANM_NK_MAX                 __PROWLANM_NK_MAX
};

#define PROWLAN_NR_MSGTYPES	(PROWLANM_NK_MAX + 1 - PROWLAN_NK_BASE)

#endif 

/* Types of attr messages */
#define PROWLANM_ATTR_MASK  0xF000
#define PROWLANM_ATTR_WIRELESS 0x8000
#define PROWLANM_ATTR(cmd)	((cmd) & PROWLANM_ATTR_MASK)


#define PROWLANM_NR_MSGTYPES	(PROWLANM_MAX + 1 - PROWLANM_BASE)
#define PROWLANM_NR_FAMILIES	(PROWLANM_NR_MSGTYPES >> 2)
#define PROWLANM_FAM(cmd)	(((cmd) - PROWLANM_BASE) >> 2)

/* prowlan netlink multicast groups - backwards compatibility for userspace */
#define PROWLANMGRP_WIRELESS		0x1
#define PROWLANMGRP_EKAHAU			0x2
#define PROWLANMGRP_MEASUREMENT		0x4
#define PROWLANMGRP_MONITOR			0x8
#define PROWLANMGRP_BSTM			0x10
#define PROWLANMGRP_DFS                        0x20
#define PROWLANMGRP_MAX				0x1000

#define PROWLAN_USER_MGRP(kernel_mgrp)  (1 << (kernel_mgrp -1))

/* prowlan netlink multicast groups */
enum prowlan_netlink_groups {
	PROWLANNLGRP_NONE,
#define PROWLANNLGRP_NONE		PROWLANNLGRP_NONE
	PROWLANNLGRP_WIRELESS,
#define PROWLANNLGRP_WIRELESS	PROWLANNLGRP_WIRELESS
	PROWLANNLGRP_EKAHAU,
#define PROWLANNLGRP_EKAHAU		PROWLANNLGRP_EKAHAU
	PROWLANNLGRP_MEASUREMENT,
#define PROWLANNLGRP_MEASUREMENT	PROWLANNLGRP_MEASUREMENT
	PROWLANNLGRP_MONITOR,
#define PROWLANNLGRP_MONITOR	PROWLANNLGRP_MONITOR
	PROWLANNLGRP_BSTM,
#define PROWLANNLGRP_BSTM		PROWLANNLGRP_BSTM   
	PROWLANNLGRP_DFS,
#define PROWLANNLGRP_DFS		PROWLANNLGRP_DFS
	__PROWLANNLGRP_MAX
};
#define PROWLANNLGRP_MAX	(__PROWLANNLGRP_MAX - 1)

#ifndef NLA_OK
#define NLA_OK(nla,len) \
((len) > 0 && (nla)->nla_len >= sizeof(struct nlattr) && \
(nla)->nla_len <= (len))
#endif

#ifndef NLA_NEXT
#define NLA_NEXT(nla,attrlen) \
((attrlen) -= NLA_ALIGN((nla)->nla_len), \
(struct nlattr *) (((char *)(nla)) + NLA_ALIGN((nla)->nla_len)))
#endif

#ifndef EXTRA_DATA
#define EXTRA_DATA(data,len) (((char*)data)+len)
#endif

/* End of information exported to user level */
#endif	/* __LINUX_PROWLAN_VAR_H */

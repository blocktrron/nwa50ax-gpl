#ifndef ZYXEL_EVENT_TYPE_HEADER_H
#define ZYXEL_EVENT_TYPE_HEADER_H
/*
 * ZyXEL Event codes
 *
 */
enum {
    ZYXEL_EVENT_UNKNOWN                       = 0,
    ZYXEL_EVENT_STA_LEAVING                   = 1,
    ZYXEL_EVENT_STA_INACTIVITY                = 2,
    ZYXEL_EVENT_VAP_DOWN                      = 3,  /* config changed */
    ZYXEL_EVENT_CLEAN_STA_WAR                 = 4,
    ZYXEL_EVENT_ASSOC_THRESHOLD               = 5,
    ZYXEL_EVENT_L2UPFRAME                     = 6,
    ZYXEL_EVENT_X_RETRY                       = 7,
    ZYXEL_EVENT_STA_DUP_AUTH                  = 8,  /* receive duplicated auth packet */
    ZYXEL_EVENT_STA_TIMEOUT                   = 9,  /* auth timeout */
    ZYXEL_EVENT_STA_KICKBYLB                  = 10, /* Load-balancing */
    ZYXEL_EVENT_STA_KICKBYAPP                 = 11, /* ioctl */
    ZYXEL_EVENT_STA_KICKBYHOSTAPD             = 12, /* Assinged by hostapd, when auth failed */
    ZYXEL_EVENT_STA_KICKBYIWPRIV              = 13, /* iwpriv wlan-x-x kickmac xx:xx:xx:xx:xx:xx */
    ZYXEL_EVENT_STA_KICKBYCAPWAP              = 14, /* ioctl: IEEE80211_IOCTL_KICKMAC */
    ZYXEL_EVENT_STA_KICKBYTXSTUCK_WAR         = 15, /* AP Tx Stuck kick all STA for QCA series */
    ZYXEL_EVENT_STA_ILLEGAL                   = 16, /* 802.11i illegal data transger */
    ZYXEL_EVENT_STA_OUT_OF_MEMORY             = 17, /* Out of memory, kickout the oldest STA */
    ZYXEL_EVENT_STA_KICKBYANNOUNCE            = 18, /* receive Lucent station announce packet or Cisco station announce packet */
    ZYXEL_EVENT_STA_KICKBYWNM                 = 19, /* wnm timer state is bss terminate, disassoc all STAs */
    ZYXEL_EVENT_STA_KICKBY_CLOUDEXPIRED       = 20, /* cloud auth expired,ioctl: IEEE80211_IOCTL_KICKMAC */
    ZYXEL_EVENT_STA_KICKBYRRM                 = 21, /* rrm kick STA workaround */
    ZYXEL_EVENT_STA_KICKBYPN_WAR              = 22, /* PN check fail kick STA workaround */
    ZYXEL_EVENT_STA_KICKBYBS                  = 23, /* Band select app */
    ZYXEL_EVENT_STA_KICKBYSMESH               = 24, /* Smart mesh app */
    ZYXEL_EVENT_STA_KICKBYWH                  = 25, /* Wireless Health app */
    ZYXEL_EVENT_STA_KICKBYINTRAROAM           = 26, /* Intra Roaming kick old STA */
    ZYXEL_EVENT_STA_KICKBYMACFILTER           = 27, /* MAC Filter */
    ZYXEL_EVENT_STA_KICKBYWLANMODULE          = 28, /* Wlan Module app */
    ZYXEL_EVENT_STA_KICKBYCDR                 = 29, /* Collaborative detection and response */
    ZYXEL_EVENT_STA_KICKBYGA                  = 30, /* Google Authenticator app */
    ZYXEL_EVENT_STA_KICKBYSTASTUCK_WAR        = 31, /* STA traffic stuck workaround */
    ZYXEL_EVENT_MAX,
    ZYXEL_EVENT_BLOCK_UNKNOWN                 = 100,
    ZYXEL_EVENT_BLOCK_MAC_FILTER              = 101,
    ZYXEL_EVENT_BLOCK_BAND_SELECT             = 102,
    ZYXEL_EVENT_BLOCK_ASSOC_THRESHOLD         = 103,
    ZYXEL_EVENT_BLOCK_ASSOC_THRESHOLD_NORETRY = 104,
    ZYXEL_EVENT_BLOCK_LB                      = 105,
    ZYXEL_EVENT_BLOCK_HOSTAPD                 = 106, /* Assinged by hostapd, when auth failed */
    ZYXEL_EVENT_BLOCK_LEGACY_STA              = 107, /* Reject legacy stations */
    ZYXEL_EVENT_BLOCK_MAX
};

static inline char *
event2string(int event, int reason)
{
    static char *ev[]={
        "by Unknown!",                          /* ZYXEL_EVENT_UNKNOWN                       = 0, */
        "by STA Logout",                        /* ZYXEL_EVENT_STA_LEAVING                   = 1, */
        "by STA timeout",                       /* ZYXEL_EVENT_STA_INACTIVITY                = 2, */
        "by Configuration Changed",             /* ZYXEL_EVENT_VAP_DOWN                      = 3, */
        "by Configuration Changed(WAR)",        /* ZYXEL_EVENT_CLEAN_STA_WAR                 = 4, */
        "by Lower STA Signal",                  /* ZYXEL_EVENT_ASSOC_THRESHOLD               = 5, */
        "by STA Leave(L2UPFrame)",              /* ZYXEL_EVENT_L2UPFRAME                     = 6, */
        "by X Retries",                         /* ZYXEL_EVENT_X_RETRY                       = 7, */
        "by STA reconnect",                     /* ZYXEL_EVENT_STA_DUP_AUTH                  = 8, */
        "by Auth Timeout",                      /* ZYXEL_EVENT_STA_TIMEOUT                   = 9, */
        "by Load-balancing",                    /* ZYXEL_EVENT_STA_KICKBYLB                  = 10, */
        "by Apps(ioctl)",                       /* ZYXEL_EVENT_STA_KICKBYAPP                 = 11, */
        "by Hostapd",                           /* ZYXEL_EVENT_STA_KICKBYHOSTAPD             = 12, */
        "by iwpriv(kickmac)",                   /* ZYXEL_EVENT_STA_KICKBYIWPRIV              = 13, */
        "by Disconnect feature",                /* ZYXEL_EVENT_STA_KICKBYCAPWAP              = 14, */
        "by Tx Stuck(WAR)",                     /* ZYXEL_EVENT_STA_KICKBYTXSTUCK_WAR         = 15, */
        "by 802.11i illegal data",              /* ZYXEL_EVENT_STA_ILLEGAL                   = 16, */
        "by Out of memory",                     /* ZYXEL_EVENT_STA_OUT_OF_MEMORY             = 17, */
        "by announce packet",                   /* ZYXEL_EVENT_STA_KICKBYANNOUNCE            = 18, */
        "by wnm",                               /* ZYXEL_EVENT_STA_KICKBYWNM                 = 19, */
        "by cloud-auth expired",                /* ZYXEL_EVENT_STA_KICKBY_CLOUDEXPIRED       = 20, */
        "by rrm",                               /* ZYXEL_EVENT_STA_KICKBYRRM                 = 21, */
        "by PN Check Fail(WAR)",                /* ZYXEL_EVENT_STA_KICKBYPN_WAR              = 22, */
        "by Band Select",                       /* ZYXEL_EVENT_STA_KICKBYBS                  = 23, */
        "by Smart Mesh State Machine Transfer", /* ZYXEL_EVENT_STA_KICKBYSMESH               = 24, */
        "by Wireless Health",                   /* ZYXEL_EVENT_STA_KICKBYWH                  = 25, */
        "by Intra Roaming",                     /* ZYXEL_EVENT_STA_KICKBYINTRA               = 26, */
        "by MAC Filter",                        /* ZYXEL_EVENT_STA_KICKBYMACFILTER           = 27, */
        "by Wlan Module",                       /* ZYXEL_EVENT_STA_KICKBYWLANMODULE          = 28, */
        "by Collaborative Detection Response",  /* ZYXEL_EVENT_STA_KICKBYCDR                 = 29, */
        "by Google Authenticator",              /* ZYXEL_EVENT_STA_KICKBYGA                  = 30, */
        "by STA Traffic Stuck(WAR)",            /* ZYXEL_EVENT_STA_KICKBYSTASTUCK_WAR        = 31, */
                                                /* note: new event string must be added before MAX */
        "Ignore It",                            /* ZYXEL_EVENT_MAX                                 */
    };

    static char *bl[]={
        "by Block Unknown!!",                   /* ZYXEL_EVENT_BLOCK_UNKNOWN                 = 100, */
        "by MAC Filter",                        /* ZYXEL_EVENT_BLOCK_MAC_FILTER              = 101, */
        "by Band Select",                       /* ZYXEL_EVENT_BLOCK_BAND_SELECT             = 102, */
        "by Lower STA Signal",                  /* ZYXEL_EVENT_BLOCK_ASSOC_THRESHOLD         = 103, */
        "by Lower STA Signal(Retry Disabled)",  /* ZYXEL_EVENT_BLOCK_ASSOC_THRESHOLD_NORETRY = 104, */
        "by Load-balancing",                    /* ZYXEL_EVENT_BLOCK_LB                      = 105, */
        "by Hostapd",                           /* ZYXEL_EVENT_BLOCK_HOSTAPD                 = 106, */
        "by Legacy STA Rejection",              /* ZYXEL_EVENT_BLOCK_LEGACY_STA              = 107, */
    };

    static char foo[64]="\0";

    if(event<ZYXEL_EVENT_MAX){
        return(ev[event]);
    }
    else if((event>=ZYXEL_EVENT_BLOCK_UNKNOWN) && (event<ZYXEL_EVENT_BLOCK_MAX)){
        event-=ZYXEL_EVENT_BLOCK_UNKNOWN;
        return(bl[event]);
    }

    snprintf(foo, 63, "by Unknown!!, event %d", event);
    return &foo[0];
}

#if defined(ZLDCONFIG_BSP_BRCM_ESDK_MODIFY) || !defined(WLAN_STATUS_SUCCESS)
/* Status codes (IEEE 802.11-2007, 7.3.1.9, Table 7-23) */
#define WLAN_STATUS_SUCCESS 0
#define WLAN_STATUS_UNSPECIFIED_FAILURE 1
#define WLAN_STATUS_TDLS_WAKEUP_ALTERNATE 2
#define WLAN_STATUS_TDLS_WAKEUP_REJECT 3
#define WLAN_STATUS_SECURITY_DISABLED 5
#define WLAN_STATUS_UNACCEPTABLE_LIFETIME 6
#define WLAN_STATUS_NOT_IN_SAME_BSS 7
#define WLAN_STATUS_CAPS_UNSUPPORTED 10
#define WLAN_STATUS_REASSOC_NO_ASSOC 11
#define WLAN_STATUS_ASSOC_DENIED_UNSPEC 12
#define WLAN_STATUS_NOT_SUPPORTED_AUTH_ALG 13
#define WLAN_STATUS_UNKNOWN_AUTH_TRANSACTION 14
#define WLAN_STATUS_CHALLENGE_FAIL 15
#define WLAN_STATUS_AUTH_TIMEOUT 16
#define WLAN_STATUS_AP_UNABLE_TO_HANDLE_NEW_STA 17
#define WLAN_STATUS_ASSOC_DENIED_RATES 18
/* IEEE 802.11b */
#define WLAN_STATUS_ASSOC_DENIED_NOSHORT 19
#define WLAN_STATUS_ASSOC_DENIED_NOPBCC 20
#define WLAN_STATUS_ASSOC_DENIED_NOAGILITY 21
/* IEEE 802.11h */
#define WLAN_STATUS_SPEC_MGMT_REQUIRED 22
#define WLAN_STATUS_PWR_CAPABILITY_NOT_VALID 23
#define WLAN_STATUS_SUPPORTED_CHANNEL_NOT_VALID 24
/* IEEE 802.11g */
#define WLAN_STATUS_ASSOC_DENIED_NO_SHORT_SLOT_TIME 25
#define WLAN_STATUS_ASSOC_DENIED_NO_DSSS_OFDM 26
#define WLAN_STATUS_ASSOC_DENIED_NO_HT 27
#define WLAN_STATUS_R0KH_UNREACHABLE 28
#define WLAN_STATUS_ASSOC_DENIED_NO_PCO 29
/* IEEE 802.11w */
#define WLAN_STATUS_ASSOC_REJECTED_TEMPORARILY 30
#define WLAN_STATUS_ROBUST_MGMT_FRAME_POLICY_VIOLATION 31
#define WLAN_STATUS_UNSPECIFIED_QOS_FAILURE 32
#define WLAN_STATUS_REQUEST_DECLINED 37
#define WLAN_STATUS_INVALID_PARAMETERS 38
/* IEEE 802.11i */
#define WLAN_STATUS_INVALID_IE 40
#define WLAN_STATUS_GROUP_CIPHER_NOT_VALID 41
#define WLAN_STATUS_PAIRWISE_CIPHER_NOT_VALID 42
#define WLAN_STATUS_AKMP_NOT_VALID 43
#define WLAN_STATUS_UNSUPPORTED_RSN_IE_VERSION 44
#define WLAN_STATUS_INVALID_RSN_IE_CAPAB 45
#define WLAN_STATUS_CIPHER_REJECTED_PER_POLICY 46
#define WLAN_STATUS_TS_NOT_CREATED 47
#define WLAN_STATUS_DIRECT_LINK_NOT_ALLOWED 48
#define WLAN_STATUS_DEST_STA_NOT_PRESENT 49
#define WLAN_STATUS_DEST_STA_NOT_QOS_STA 50
#define WLAN_STATUS_ASSOC_DENIED_LISTEN_INT_TOO_LARGE 51
/* IEEE 802.11r */
#define WLAN_STATUS_INVALID_FT_ACTION_FRAME_COUNT 52
#define WLAN_STATUS_INVALID_PMKID 53
#define WLAN_STATUS_INVALID_MDIE 54
#define WLAN_STATUS_INVALID_FTIE 55
#define WLAN_STATUS_GAS_ADV_PROTO_NOT_SUPPORTED 59
#define WLAN_STATUS_NO_OUTSTANDING_GAS_REQ 60
#define WLAN_STATUS_GAS_RESP_NOT_RECEIVED 61
#define WLAN_STATUS_STA_TIMED_OUT_WAITING_FOR_GAS_RESP 62
#define WLAN_STATUS_GAS_RESP_LARGER_THAN_LIMIT 63
#define WLAN_STATUS_REQ_REFUSED_HOME 64
#define WLAN_STATUS_ADV_SRV_UNREACHABLE 65
#define WLAN_STATUS_REQ_REFUSED_SSPN 67
#define WLAN_STATUS_REQ_REFUSED_UNAUTH_ACCESS 68
#define WLAN_STATUS_INVALID_RSNIE 72
#define WLAN_STATUS_TRANSMISSION_FAILURE 79

/* Reason codes (IEEE 802.11-2007, 7.3.1.7, Table 7-22) */
#define WLAN_REASON_UNSPECIFIED 1
#define WLAN_REASON_PREV_AUTH_NOT_VALID 2
#define WLAN_REASON_DEAUTH_LEAVING 3
#define WLAN_REASON_DISASSOC_DUE_TO_INACTIVITY 4
#define WLAN_REASON_DISASSOC_AP_BUSY 5
#define WLAN_REASON_CLASS2_FRAME_FROM_NONAUTH_STA 6
#define WLAN_REASON_CLASS3_FRAME_FROM_NONASSOC_STA 7
#define WLAN_REASON_DISASSOC_STA_HAS_LEFT 8
#define WLAN_REASON_STA_REQ_ASSOC_WITHOUT_AUTH 9
/* IEEE 802.11h */
#define WLAN_REASON_PWR_CAPABILITY_NOT_VALID 10
#define WLAN_REASON_SUPPORTED_CHANNEL_NOT_VALID 11
/* IEEE 802.11i */
#define WLAN_REASON_INVALID_IE 13
#define WLAN_REASON_MICHAEL_MIC_FAILURE 14
#define WLAN_REASON_4WAY_HANDSHAKE_TIMEOUT 15
#define WLAN_REASON_GROUP_KEY_UPDATE_TIMEOUT 16
#define WLAN_REASON_IE_IN_4WAY_DIFFERS 17
#define WLAN_REASON_GROUP_CIPHER_NOT_VALID 18
#define WLAN_REASON_PAIRWISE_CIPHER_NOT_VALID 19
#define WLAN_REASON_AKMP_NOT_VALID 20
#define WLAN_REASON_UNSUPPORTED_RSN_IE_VERSION 21
#define WLAN_REASON_INVALID_RSN_IE_CAPAB 22
#define WLAN_REASON_IEEE_802_1X_AUTH_FAILED 23
#define WLAN_REASON_CIPHER_SUITE_REJECTED 24
#define WLAN_REASON_TDLS_TEARDOWN_UNREACHABLE 25
#define WLAN_REASON_TDLS_TEARDOWN_UNSPECIFIED 26
/* IEEE 802.11e */
#define WLAN_REASON_DISASSOC_LOW_ACK 34
#if defined(ZLDCONFIG_WLAN_4MAC_WDS_SUPPORT)
#define WLAN_REASON_WDS_SPECIAL_LEAVE 102
#endif
#endif

#define WLAN_REASON_GROUP_REKEY_FAIL 103
#define WLAN_REASON_SM_RECURSIVE_CALL 104
#define WLAN_REASON_IGNORE_ZYLOG 105

static inline char *
zyxel_event2string(int event, int reason)
{
/* auth failed from hostapd */
	static char foo[64]="\0";

	if (event == ZYXEL_EVENT_BLOCK_HOSTAPD || event == ZYXEL_EVENT_STA_KICKBYHOSTAPD) {
		switch (reason) {
		case WLAN_REASON_IEEE_802_1X_AUTH_FAILED:
			snprintf(foo, 63, "by 802.1X auth failed");
			break;
		case WLAN_REASON_PREV_AUTH_NOT_VALID:
		case WLAN_REASON_4WAY_HANDSHAKE_TIMEOUT:
			snprintf(foo, 63, "by key handshake fail");
			break;
		case WLAN_REASON_GROUP_REKEY_FAIL:
		case WLAN_REASON_GROUP_KEY_UPDATE_TIMEOUT:
			snprintf(foo, 63, "by group rekey handshake fail");
			break;
		case WLAN_REASON_DISASSOC_DUE_TO_INACTIVITY:
			snprintf(foo, 63, "by STA timeout");
			break;
		case WLAN_REASON_SM_RECURSIVE_CALL:
			snprintf(foo, 63, "by WPA state machine recursive call");
			break;
		case WLAN_REASON_CLASS2_FRAME_FROM_NONAUTH_STA:
			snprintf(foo, 63, "by station tried to associate before authentication");
			break;
		default:
			snprintf(foo, 63, "by Hostapd");
			break;
		}
		return &foo[0];
	}

	return event2string(event, reason);
}



#endif

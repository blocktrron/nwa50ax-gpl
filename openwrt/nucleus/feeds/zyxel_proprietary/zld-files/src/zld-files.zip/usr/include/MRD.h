#ifndef __MRD_H__
#define __MRD_H__

#ifndef __KERNEL__
#include <stdint.h>
#endif

/* Manufacturer Related Data */
typedef struct mrd {
	uint8_t BspHeapBlkSize[16];
	uint8_t BspHeapBlkCnt[16];
	uint8_t HardwareVersion[32];
	uint8_t SerialNumber[32];
	uint8_t Reserved0[32];
	uint8_t VendorName[32];
	uint8_t ProductName[32];
	uint32_t Reserved4;
	uint16_t Reserved1;
	uint8_t SystemType;
	uint8_t Reserved2;
	uint8_t FeatureBits[30]; /* Other Feature Bits */
	uint8_t FeatureBit;      /* Main Feature Bits */
	uint8_t Reserved3;
	uint8_t EtherAddr[6];
	uint8_t CountryCode;
	uint8_t AreaCode;
} MRD;

/* Read MRD via /proc/MRD that stored a copy from Flash */
#define PROC_MRD_PATH "/proc/MRD"

/*
 * Other Feature Bits Usage:
 * FeatureBits[16]: MAC Qty.
 * FeatureBits[17~22]: 1st Extra MAC.
 */

/* Special country-code */
#define EU_ONLY_COUNTRY 1	/* Special Country-code: allow EU country selection only. The corresponding country = DE. */
#define DE_ALL_COUNTRY 2	/* Special Country-code: allow all country selection. The corresponding country = DE. */

#endif

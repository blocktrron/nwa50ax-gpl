/******************************************************************************
 *
 *  Copyright (C) 2011-2012 ZyXEL Communications, Corp.  
 *  All rights reserved.
 *
 *****************************************************************************/

#ifndef __ZLD_STORAGE_NAME_H__
#define __ZLD_STORAGE_NAME_H__ 

/* we should only export this part for firmware/bm/mrd update */

#define BM_NAME "bootm"
#define RECOVERY_NAME "recovery"
#define KERNEL_NAME "kernel"
#define FS_NAME "zldfs"
#define CONF_NAME "conf"
#define MYZYXEL_NAME "myZyXEL"
#define MRD_NAME "mrd"
#define DISKLOG_NAME "disklog"
#define ART_NAME "ART"
#define NVRAM_NAME "nvram"
#define COREDUMP_NAME "coredump"

#endif /* __ZLD_STORAGE_NAME_H__ */

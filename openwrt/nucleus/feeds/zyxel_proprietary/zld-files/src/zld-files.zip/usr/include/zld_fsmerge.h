/******************************************************************************
 *
 *  Copyright (C) 2011-2011 ZyXEL Communications, Corp.  
 *  All rights reserved.
 *
 *****************************************************************************/

#ifndef __ZLD_FSMERGE2_H__
#define __ZLD_FSMERGE2_H__ 

/***************************************
 * endianess
 */

#if __BYTE_ORDER == TARGET_BYTE_ORDER
#define HTONS(x) (x)
#define HTONL(x) (x)
#define NTOHS(x) (x)
#define NTOHL(x) (x)
#else
#define HTONS(x) htons(x)
#define HTONL(x) htonl(x)
#define NTOHS(x) ntohs(x)
#define NTOHL(x) ntohl(x)
#endif


#define FILE_TYPE_BM 		0x01
#define FILE_TYPE_KERNEL 	0x02
#define FILE_TYPE_CODE 		0x03
#define FILE_TYPE_DB 		0x04
#define FILE_TYPE_CONF 		0x05
#define FILE_TYPE_WTP 		0x06

#define FILE_HEADER_SIG 	0xdeadbeaf

#define FILE_HEADER_VERSION 0x100

#define MAX_FILE_NAME_LEN 	64
#define MAX_PATH_NAME_LEN 	128
#define MAX_VERSION_LEN 	32
#define MAX_BUILD_DATE_LEN 	32
#define MAX_CAPWAP_VER_LEN 	32
#define MAX_MODEL_ID_LEN	32  

/* package file alignment */
#define FILE_ALIGNMENT 	4

/* NOTE: the data struct is designed for 8 byte alignment */
struct file_info_s {
	uint16_t type;  /* (BM/kernel/ro_image/conf/db..) */
	uint16_t flags; /* (reserved) */
	uint32_t file_len; 
	uint32_t chk_sum;
	uint32_t flash_offset;
	char file_name[ MAX_FILE_NAME_LEN ];
	char dst_path[ MAX_PATH_NAME_LEN ]; 
	char version[ MAX_VERSION_LEN ];
	char build_date[MAX_BUILD_DATE_LEN];
};

struct file_header_s {
	uint32_t chk_sum;
	uint32_t signature; /*0xdeadbeaf using for endian check, too. */
	uint16_t version; 
	uint16_t file_num;
	uint16_t max_model;
	uint16_t model[5];
	uint32_t total_len;  /* (include header) */
	uint16_t file_offset; /*header_len + file_num*info_len */
	uint16_t header_len;
	uint16_t info_len;
	uint16_t reserve[3];

/* Note don't add item before this line */
	
	char capwap_ver[MAX_CAPWAP_VER_LEN];
	char model_id[MAX_MODEL_ID_LEN];

	struct file_info_s *file_info_p;
};


#define VERSION_RESERVED_SIZE 512

struct version_header_s {
	char bm_version[64];
	char kernel_version[64];
	char zld_version[64];
	char capwap_ver[MAX_CAPWAP_VER_LEN];
	char model_id[MAX_MODEL_ID_LEN];
	uint32_t bm_cksum;
	uint32_t kernel_cksum;
	uint32_t zld_cksum;
	uint32_t core_cksum;
	uint16_t max_model;
	uint16_t model[5];
	/* note while add new file must recalculate the reserved field */
	char reserved[512-4-64*4-4*4-2*6];
	uint32_t baudrate;
};

struct file_type_conv_s {
	char *str;
	int type;
};


extern int FILE_TYPE_CNT;
extern struct file_type_conv_s file_type_conv[];
extern int get_file_type_by_str ( char *type );
extern char * get_file_type_by_id ( int type );
extern void free_file_header ( struct file_header_s *file_header_p );
extern struct file_header_s *alloc_file_header ( int file_no );
extern void disp_file_header ( struct file_header_s *header_p );
extern int gen_ramdom_str( char *salt, int start, int end );
extern off_t get_file_len ( char *filename );
extern int get_file_chk_sum ( char * filename, uint32_t *chk_sum,uint32_t total_len, int skip );
extern struct file_header_s* translate_header ( struct file_header_s * src_header_p, int file_num );
extern void fill_version_string ( struct version_header_s *version, struct file_info_s *info_p );
extern void version_translate ( struct version_header_s *version );
extern void gen_version_info ( struct version_header_s *version, struct file_header_s *header_p);
extern off_t seek_version_location ( struct file_header_s *header_p );
extern int put_buf_to_file ( char *filename, char *buf, unsigned long size, unsigned long skip );
extern int read_buf_from_file ( char *filename, char *buf, unsigned long size, unsigned long skip );
extern void disp_version_header ( struct version_header_s *version );
#endif

/* $Id: */

/*
 * $Log:
 */

#ifndef _K_IFACENAME_CHANGE_H_
#define _K_IFACENAME_CHANGE_H_

#include "zld-spec.h"

#ifdef __KERNEL__
#include <linux/if.h>
#else 
/* include stdint.h for user space uint32_t definition. */
#include <stdint.h>
#endif /* __KERNEL__ */

/* ZLD 2.20 interface enhancement support maximum configurable interface name is 15, 
   so MAX_IFACE_NAME_LEN is defined to 16 (include '\0')
   Since MAX_IFACE_NAME_LEN length will relate to zyshd show interface format and CLI, 
   so modify MAX_IFACE_NAME_LEN length also need to update the following :
   1. USER_DEFINE_INTERFACE_NAME, CONFIG_INTERFACE, CONFIG_VIR_INTERFACE at zysh-1.0.0/cli/interface-predefine.cli    
   2. IFACE_NAME_COLUMN_FORMAT and IFACE_NAME_CONTENT_FORMAT at zysh-1.0.0/cmd/include/interface.h         */
#define MAX_IFACE_NAME_LEN 16  /* maximum length for user-define interface name */

#ifndef MAX_ETH
#define MAX_ETH ZLDSYSPARM_ETH_IFACE_MAX_NUM
#endif

#define MAX_PPP ZLDSYSPARM_PPP_IFACE_MAX_NUM
#define MAX_BR ZLDSYSPARM_BRIDGE_IFACE_MAX_NUM
#define MAX_VLAN ZLDSYSPARM_VLAN_IFACE_MAX_NUM
#define MAX_AUX 1

#define MAX_INTERFACE_NUM (MAX_ETH + MAX_PPP + MAX_AUX)/* interface name change table max number */

#define INTERNAL_ETH_IFACENAME "eth"
#define INTERNAL_PPP_IFACENAME "ppp"
#define INTERNAL_VLAN_IFACENAME "vlan"
#define INTERNAL_BRD_IFACENAME "br"
#define INTERNAL_VIR_IFACENAME ":"
#define EXTERNAL_ETH_IFACENAME_HIDDEN "hidden"

#define INTERNAL_AP_IFACENAME "wlan-"
#define EXTERNAL_ETH_IFACENAME "ge"

/* Used by ZySH ZyIO and Traffic Flow IPTables Match */
#define IFACE_PROPERTY_INTERNAL_STRING 		"internal"
#define IFACE_PROPERTY_EXTERNAL_STRING		"external"
#define IFACE_PROPERTY_GENERAL_STRING		"general"
#define SAFE_STRNCPY(dest, src, max_dest_size)                    \
	do {                                        \
		strncpy(dest, src, (size_t)(max_dest_size-1));    \
		dest[max_dest_size-1] = '\0';           \
	} while(0)


#define 	IFACE_SHIFT_BIT		8

#define 	IFACE_PROPERTY_MASK	((0x1<<IFACE_SHIFT_BIT)-1)
#define 	IFACE_TYPE_MASK		(~(IFACE_PROPERTY_MASK))

#define 	IFACE_TYPE_ETH		(0x00000001<<IFACE_SHIFT_BIT)
#define 	IFACE_TYPE_PPP		(0x00000002<<IFACE_SHIFT_BIT)
#define 	IFACE_TYPE_VLAN  	(0x00000004<<IFACE_SHIFT_BIT)
#define 	IFACE_TYPE_BRIDGE   (0x00000008<<IFACE_SHIFT_BIT)
#define 	IFACE_TYPE_WLAN	    (0x00000010<<IFACE_SHIFT_BIT) 
#define 	IFACE_TYPE_TUNNEL	(0x00000080<<IFACE_SHIFT_BIT) 
#define		IFACE_TYPE_ALL 		(IFACE_TYPE_ETH|IFACE_TYPE_PPP|IFACE_TYPE_VLAN|IFACE_TYPE_BRIDGE|IFACE_TYPE_WLAN|IFACE_TYPE_TUNNEL)

#define 	IFACE_TYPE_VIRTUAL_IFACE  (IFACE_TYPE_ETH|IFACE_TYPE_VLAN|IFACE_TYPE_BRIDGE)	

#define 	IFACE_PROPERTY_INTERNAL	0x00000001
#define 	IFACE_PROPERTY_EXTERNAL	0x00000002 
#define 	IFACE_PROPERTY_GENERAL	(IFACE_PROPERTY_INTERNAL|IFACE_PROPERTY_EXTERNAL)
#define 	IFACE_PROPERTY_UNUSED	IFACE_PROPERTY_GENERAL

enum { 
	IFACE_NAME_OK = 0, 
	IFACE_NAME_NULL_PTR,
	IFACE_NAME_NOT_FOUND 
};

enum { 
	IFACE_NO_SYSTEM_PPP = 0, 
	IFACE_SYSTEM_PPP
};

enum iface_name_configured_flag { 
	IFACE_NAME_UNCONFIGURED, 
	IFACE_NAME_CONFIGURED  
};

enum iface_name_duplicate_flag { 
	IFACE_NAME_CONFIG_SAME_NAME, 
	IFACE_NAME_DUPLICATED, 
	IFACE_NAME_NOT_DUPLICATED
};

struct _interface_info {
	uint32_t iface_type;
	uint32_t system_ppp;
	uint32_t virtual_iface_flag;
};

struct _if_property_info {
	uint32_t property_fixed_flag;
	uint32_t if_property;
};

#endif /* !(_K_IFACENAME_CHANGE_H_) */

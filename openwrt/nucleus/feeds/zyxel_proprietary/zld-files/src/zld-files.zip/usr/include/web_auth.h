#ifndef __WEB_AUTH_H__
#define __WEB_AUTH_H__

#define SHMKEY_WACD_PATH 			"/usr/sbin/wacd"
#define ZYXEL_WEB_AUTH_TYPE_LEN 		16
#define ZYXEL_WEB_AUTH_URL_MAX_LEN 		512
#define MAX_VPNIP_LEN				33
#define DEFAULT_VPNIP_STR			"Default"
#define CAPTIVE_PORTAL_CONFIG_FILE	"/tmp/portal_config"
#define CAPTIVE_PORTAL_SIMULATE_FLAG    "/tmp/cp_simulate"

#ifdef AAA_WEB_PORTAL
#define ZYXEL_URL_MAX_LEN 						256
#define WLAN_IF_LEN								16
#define WLAN_SSID_STR_LEN						64
#define WLAN_CAPTIVE_PORTAL_AUTH_TYPE_LEN	32
#define WLAN_CAPTIVE_PORTAL_METHOD_LEN		32
#define WLAN_CAPTVIE_PARAMETER_LEN			32
#define MAC_ADDRESS_LENGTH					6
#endif

#define WEBAUTH_STRNCPY(d_str, s_str, l_str)	\
do {				\
	strncpy(d_str, s_str, l_str-1);	\
	d_str[l_str - 1] = '\0';		\
} while(0)

enum {
	WEB_AUTH_LOGIN_URL,
	WEB_AUTH_LOGOUT_URL,
	WEB_AUTH_WELCOME_URL,
	WEB_AUTH_SESSION_URL,
	WEB_AUTH_ERROR_URL,
#if defined(ZLDCONFIG_USER_LOGOUT_PAGE) || defined(AAA_WEB_PORTAL)
	WEB_AUTH_USERLOGOUT_URL,	
#endif
	WEB_AUTH_MAX_URL
};

/*
 * '0': 'Authenticated successfully',
 * '-1': 'Validate user has failed',
 * '-2': 'Login attempt on a lockout address',
 * '-3': 'Simultaneous admin or access logons or users have reached the maximum number'
 * */
#define WEB_AUTH_SUCCESS			0
#define WEB_AUTH_VALID_FAIL			-1
#define WEB_AUTH_LOCKOUT_ADDRESS		-2
#define WEB_AUTH_MAX_NUM			-3
#define WEB_AUTH_NO_LOGIN_PAGE			-4
#define	WEB_AUTH_ERR_NO_RESPONSE		-5

/*
 * '0': 'Authenticated successfully',
 * '1': 'Username or Password incorrect',
 * '2': 'Username is required',
 * */
/* web auth error number for nebula */
#define WEB_AUTH_SUCCESS						0
#define WEB_AUTH_USR_PWD_INCORRECT			1
#define WEB_AUTH_USER_REQUIRED				2
#define WEB_AUTH_USR_EXPIRED					403
#define WEB_AUTH_NCAS_DISCONNECT				410

#define WEB_AUTH_INTERNAL			0
#define WEB_AUTH_EXTERNAL			1

#define WEB_AUTH_ACTIVATE			0
#define WEB_AUTH_DEACTIVATE			1

#define WEB_AUTH_INTERNAL_PORTAL			0
#define WEB_AUTH_EXTERNAL_PORTAL			1

/* Facebook Wifi Login Parameter */
#define ORIGINAL_URL_MAX_LENGTH				1800
#define FB_WIFI_TOKEN_SIZE				128

#ifdef AAA_WEB_PORTAL
/* define mulitiple captive portal simultaneous behavior */
#define SIMULTANEOUS_LOGIN_ALLOW					1
#define SIMULTANEOUS_LOGIN_LIMIT					2

/* define mulitiple captive portal NCC behavior */
#define CLOUD_DISCONNECT_BEHAVIOR_UNDEFINE 		0
#define CLOUD_DISCONNECT_BEHAVIOR_OPEN 			1
#define CLOUD_DISCONNECT_BEHAVIOR_RESTRICTED	2

/* define captive portal type */
#define CAPTIVE_LOGIN_PAGE_TYPE_INTERNAL			1
#define CAPTIVE_LOGIN_PAGE_TYPE_EXTERNAL			2

/* define after the captive portal page where the user should go */
#define CAPTIVE_SUCCESS_PAGE_TYPE_INTERNAL		1
#define CAPTIVE_SUCCESS_PAGE_TYPE_EXTERNAL		2

/* NCC connnection status */
#define CLOUD_CONNECTION_STATUS_UNDEFINE 		0
#define CLOUD_CONNECTED 							1
#define CLOUD_DISCONNECTED						2

#endif

#define NIPQUAD(addr) \
        ((unsigned char *)&addr)[0], \
        ((unsigned char *)&addr)[1], \
        ((unsigned char *)&addr)[2], \
        ((unsigned char *)&addr)[3]

#define WEBAUTH_DEBUG 0

#define DEBUG_WEBAUTH(format, args...) \
        do { \
		if(WEBAUTH_DEBUG) {	\
	                FILE *fp = fopen("/tmp/webauth_mlogin.log","a+"); \
        	        if ( fp ) fprintf(fp, format,## args); fflush(fp); \
                	fclose(fp); \
		}	\
        } while ( 0 )

struct web_auth_s {   
	int activate;
	int type;
	char url[WEB_AUTH_MAX_URL][ZYXEL_WEB_AUTH_URL_MAX_LEN];
};

#if defined(ZLDCONFIG_WEB_PORTAL_REDIRECT_FROM_AP)
enum {
	REDIRECT_ON_CONTROLLER = 0,
	REDIRECT_ON_AP
};
#endif

#ifdef AAA_WEB_PORTAL
/* multiple captive portal info */
struct multiple_portal_info
{
	//char vap[WLAN_IF_LEN];
	char ssid_name[WLAN_SSID_STR_LEN];
	char ssid_profile_name[WLAN_SSID_STR_LEN];
	char portal_profile_name[WLAN_SSID_STR_LEN];
	//char method[WLAN_CAPTIVE_PORTAL_METHOD_LEN]; /*open, click-to-continue or sign-on */
	char auth_type[WLAN_CAPTIVE_PORTAL_AUTH_TYPE_LEN]; /*ZyXEL cloud authentication, My-Radiuse*/
	int login_portal_type; /* internal or external */
	char login_url[ZYXEL_URL_MAX_LEN];
	int success_portal_type; /* internal or external*/
	char success_url[ZYXEL_URL_MAX_LEN];
	int simultaneous;
	int keep_previous_user;
	int max_login_count;
	int ncc_dis_behavior;
	int lease_time;
#ifdef ZLDCONFIG_AAA_FREE_ACCESS_SUPPORT	
	int free_time;
#endif
	/* URL Parameter Naming */
	char gw_addr_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char apmac_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char usermac_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char apip_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char userip_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char ssid_name_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char auth_path_param[WLAN_CAPTVIE_PARAMETER_LEN];
	char apurl_param[WLAN_CAPTVIE_PARAMETER_LEN];
};

/* multiple captive portal info database in shared memory structure */
struct multiple_portal_shm_db{
	struct multiple_portal_info portal_db_info[ZLDSYSPARM_WLAN_MAX_AP];
};

int init_ssid_portal_shmem(char *portal_profile, struct multiple_portal_info *ssid_portal_info);

#endif
/*
int get_web_auth_url(int i, char *data, int data_size);
int get_web_auth_type(void);
int get_web_auth_activate(void);
int check_external_web_portal(void);
int check_server_address(char *remote_ip);
*/

#define HTTP_STR	"http"
#define HTTPS_STR	"https"
#endif

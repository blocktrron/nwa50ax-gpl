#ifndef _K_IFACENAME_LIST_H_
#define _K_IFACENAME_LIST_H_


struct interface_map {
#ifdef __KERNEL__
	struct list_head list;
#endif
	char internal_iface[MAX_IFACE_NAME_LEN];
	char config_iface[MAX_IFACE_NAME_LEN];
	struct _interface_info iface_info;
};

struct interface_property_map {
#ifdef __KERNEL__
	struct list_head list;
#endif
	char internal_iface[MAX_IFACE_NAME_LEN];
	struct _if_property_info info;

};


#endif

#ifndef _PLATFORM_COMMON_H_
#define _PLATFORM_COMMON_H_

#define	INACTIVE		0
#define	ACTIVE			1

/* *************** LED define *************** */

/* LED SYMBOL FOR CLI OF SHOW LED STATUS */
#define LED_OFF             0
#define LED_GREEN_ON        1
#define LED_GREEN_BLINK     2 /*blinking rate 50ms*/
#define LED_BLINK_50MS      2 /*blinking rate 50ms, same as LED_GREEN_BLINK*/
#define LED_RED_ON          3
#define LED_RED_BLINK       4
#define LED_ORANGE_ON       5
#define LED_ORANGE_BLINK    6
#define LED_BLINK_SLOW          7 /* interval: 1000ms */
#define LED_ON_2S_OFF_3S        8
#define LED_ON_3S_OFF_3S        9
#define LED_BLINK_300MS    10 /*blinking rate 300ms*/

#if defined(ZLDCONFIG_PLATFORM_MIPS_ATHEROS_QCA955X)
#define SERIAL_LED_ACTION_OFF           0x0
#define SERIAL_LED_ACTION_ON            0x1
#define SERIAL_LED_BLINK_50MS           0x2
#define SERIAL_LED_BLINK_500MS          0x3
#define SERIAL_LED_BLINK_1S             0x4
#define SERIAL_LED_BLINK_2S3S           0x5
#define SERIAL_LED_BLINK_3S3S           0x6
#endif

/* *************** enum define *************** */

enum {
	SIGNAL_LEVEL_LOW = 0,
	SIGNAL_LEVEL_HIGH,
	SIGNAL_LEVEL_MAX,
};

enum {
	POWER_SOURCE_UNKNOWN = -1,
	POWER_SOURCE_NON_SUPPORT = 0,
	POWER_SOURCE_DC,
	POWER_SOURCE_POE_AF,
	POWER_SOURCE_POE_AT,
	POWER_SOURCE_POE_BT,
	POWER_SOURCE_MAX,
};

enum {
	POWER_STATUS_UNKNOWN = -1,
	POWER_STATUS_FULL = 0,
	POWER_STATUS_LIMITED_1,
	POWER_STATUS_LIMITED_2,
	POWER_STATUS_END,
};

enum {
        LED_UNLOCKED    = 0,
        LED_LOCKED,
};

enum {
	ETH_UPLINK_DOWN = 0,
	ETH_UPLINK_UP
};

enum {
	DFS_DISABLE = 0,
	DFS_ENABLE
};

#ifdef ZLDCONFIG_LAST_BOOT_REASON_SUPPORT
enum {
	ZY_LAST_BOOT_REASON_UNKNOWN = -1,
	ZY_LAST_BOOT_REASON_COLD_START = 0,
	ZY_LAST_BOOT_REASON_WARM_RESET,
	ZY_LAST_BOOT_REASON_PANIC,
	ZY_LAST_BOOT_REASON_I_SWDT,
	ZY_LAST_BOOT_REASON_I_HWDT,
	ZY_LAST_BOOT_REASON_E_HWDT,
	ZY_LAST_BOOT_REASON_END,
};
#endif

enum {
	ALL_LED_TURN_OFF = 0,
	ALL_LED_TURN_ON,
	ALL_LED_RUNNING,
	LED_OPERATION_MAX
};

/* *************** proc name define for platform support *************** */
#define PROC_PLATFORM_SUPPORT_POWER_STATUS	"/proc/support/power_status"
#define PROC_PLATFORM_SUPPORT_POWER_SOURCE	"/proc/support/power_source"
#define TMP_LLDP_PD_CURRENT_POWER "/tmp/lldp_pd_current_power"
#ifdef ZLDCONFIG_CRASH_DUMP_SUPPORT
#define PROC_PLATFORM_SUPPORT_CRASHDUMP_CTRL	"/proc/support/crashdump_ctrl"
#endif
#ifdef ZLDCONFIG_GREENPAK_HW_WDT_SUPPORT
#define PROC_PLATFORM_SUPPORT_WD_EN		"/proc/support/wd_en"
#define PROC_PLATFORM_SUPPORT_WDI		"/proc/support/wdi"
#endif
#ifdef ZLDCONFIG_LAST_BOOT_REASON_SUPPORT
#define PROC_PLATFORM_SUPPORT_LAST_BOOT_REASON	"/proc/support/last_boot_reason"
#endif
#define PROC_PLATFORM_SUPPORT_BOARD_INFO	"/proc/support/board_info"
/* ********************************************************************* */

#endif

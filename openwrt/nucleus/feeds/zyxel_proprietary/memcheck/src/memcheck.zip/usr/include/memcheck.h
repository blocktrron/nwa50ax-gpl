#ifndef _MEMCHECK_H_
#define _MEMCHECK_H_

#include <stdint.h>
#include <inttypes.h>
#include "zylog.h"
#include "zld-spec.h"

/****************************************************************
*
*   Symbol Definition
*
****************************************************************/
#define MCK_BUF_32					32
#define MCK_BUF_64					64
#define MCK_BUF_128					128
#define MCK_FLASH_USAGE_THRESHOLD	90
#define MCK_TMP_USAGE_THRESHOLD		90
#define MCK_MEM_MIN_THRESHOLD		3
#define MCK_MEM_MAX_THRESHOLD		7
#define MCK_MEM_STATUS_THRESHOLD	75                          /* Memory Status Threshold Value: 75% */
#define MCK_BIN_PATH				"/usr/sbin/memcheck"		/* Memcheck binary path */
#define MCK_INFO_PATH				"/tmp/memcheck_info"		/* Memcheck variables save in this file. */
#define MCK_TEMP_RECORD_FOLDER		"/tmp/"
#define MCK_TEMP_RECORD_NAME		"memcheck_record"
#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
#define MCK_RECORD_FOLDER			"/etc/zyxel/ftp/memcheck/"
#else
#define MCK_RECORD_FOLDER			"/etc/zyxel/ftp/diaglog/memcheck/"
#endif
#define MCK_MEM_RECORD_FMT			"mck_mem"
#define MCK_MEM_RECORD_MAX_NUM		5
#define MCK_BOOTUP_RECORD_FMT		"mck_bootup"
#define MCK_BOOTUP_RECORD_MAX_NUM	1
#define MCK_TMP_RECORD_FMT			"mck_tmp"
#define MCK_DAILY_TO_TMP_RECORD		1
#define MCK_VAR_RECORD_FMT			"mck_var"
#define MCK_DAILY_TO_VAR_RECORD		1
#define MCK_LEAK_RECORD_FMT			"mck_leak"
#define MCK_DAILY_TO_LEAK_RECORD	3

typedef struct mck_info{
	uint64_t mck_cur_mem;			/* Memcheck current memory value */
	uint64_t mck_prev_mem;		/* Memcheck previous memory value */
	int mck_mem_increase_count;				/* Memcheck memory increase count */
	int mck_mem_leak_threshold;				/* Memcheck memory leak threshold */
	int mck_tmp_first_detect;				/* Memcheck reach tmp threshold first detected */
	int mck_var_first_detect;				/* Memcheck reach var threshold first detected */
	int mck_debug;							/* Memcheck debug mode */
}MCK_INFO;

/****************************************************************
*
*   Data Declaration
*
****************************************************************/
enum MCK_EVENT_TYPE
{
	MCK_BEGIN = 0,				/* Memcheck begin and initialize. */
	MCK_SHOW_MEMORY,			/* Show memcheck status. */
	MCK_MODIFY_THRESHOLD,		/* Modify memcheck threshold. */
	MCK_DETECT_MEMORY,			/* Detect memory leak or not. */
	MCK_COLLECT_MEMORY_RECORD,	/* Collect memcheck record periodically. */
	MCK_COLLECT_TMP_RECORD,		/* Collect record for reach tmp folder threshold. */
	MCK_COLLECT_VAR_RECORD,		/* Collect record for reach var folder threshold. */
	MCK_FLUSH_RECORD,			/* Flush memcheck file. */
	MCK_SHOW_HELP,				/* Show help message. */
	MCK_DEBUG_MODE,				/* Memcheck debug mode. 0:disable 1:enable */
	MCK_END						/* Memcheck end. */
};

enum MCK_MEM_RECORD_TYPE
{
	MCK_DAILY_MEMORY_RECORD=0,	/* Collect for daily memcheck record. */
	MCK_BOOTUP_MEMORY_RECORD,	/* Collect for bootup memcheck record. */
};

enum MCK_DEBUG_TYPE
{
	MCK_DEBUG_DISABLE=0,		/* Disable memcheck debug mode. */
	MCK_DEBUG_ENABLE,			/* Enable memcheck debug mode. */
};

/****************************************************************
*
*   Macro Definition
*
****************************************************************/
#define MEMCHECK_PRINT(fmt, arg...)		printf(fmt, ##arg)
#define MEMCHECK_ERROR(fmt, arg...)		fprintf(stderr, fmt, ##arg)
#define MEMCHECK_DEBUG(fmt, arg...)		do	\
{											\
	if(mck_debug_level)						\
		fprintf(stderr, fmt, ##arg);		\
											\
}while(0)

#define MEMCHECK_ZYALERT(fmt, arg...)		\
	zylog(  ZYLOG_SRC_SYSTEM,				\
		ZYLOG_PRI_ALERT,					\
		ZYLOG_FAC_SYSTEM,					\
		0, 0, 0, 0,							\
		"Memcheck", fmt, ##arg)
/****************************************************************
*
*	Function Declaration
*
****************************************************************/
int mck_begin(int value);
int mck_show_memory(int value);
int mck_modify_threshold(int value);
int mck_detect_memory(int value);
int mck_collect_memory_record(int value);
int mck_collect_tmp_record(int value);
int mck_collect_var_record(int value);
int mck_flush_record(int value);
int mck_show_help(int value);
int mck_debug(int value);

#endif /* _MEMCHECK_H_ */

#ifndef _ZWD_H
#define _ZWD_H

#include <netinet/in.h>
#include <stdint.h>
#include "zylog.h"
/********************************************************
*   ZLD Wrapper Daemon Common Definitions
********************************************************/
#ifndef __cplusplus
#if defined (true) || defined (false) 
#else
typedef uint32_t bool;
#define true    1
#define false   0
#endif
#endif

/********************************************************
*   ZLD WRAPPER Daemon Message Q Related Parameter
********************************************************/
#define ZWD_PATH		"/usr/sbin/zwd"
#define ZWD_PROJECT_ID	('z' + 'w' + 'd')

/********************************************************
*   ZYLOG Related Parameter
********************************************************/
#define __ZYLOG_MAX_MESSAGE_LEN       ZYLOG_MAX_MESSAGE_LEN
#define __ZYLOG_MAX_NOTE_LEN          ZYLOG_MAX_NOTE_LEN
typedef struct zwd_zylog_s {
	int32_t src;
	int32_t fac;
	int32_t pri;
	struct in_addr saddr;
	uint16_t sport;
	struct in_addr daddr;
	uint16_t dport;
	char note[__ZYLOG_MAX_NOTE_LEN];
	char msg[__ZYLOG_MAX_MESSAGE_LEN];
} zwd_zylog_t;

/********************************************************
*   ZYENCRYT Related Parameter
********************************************************/
#define ZENCRYT_PATH			"/usr/sbin/zencrypt"
#define PASSWORD_SALT_LEN		8
#define IN_USER_PASSWORD_LEN		1024
typedef struct zwd_zyencry_s {
	char en_password[IN_USER_PASSWORD_LEN];
	char clear_password[IN_USER_PASSWORD_LEN];
	char salt[PASSWORD_SALT_LEN+1];
	char salt2[PASSWORD_SALT_LEN+1];
} zwd_zyencry_t;

/********************************************************
*   Main Data Structure
********************************************************/
/* ZLD WRAPPER Daemon Message Types */
enum {
	ZWD_MSG_ZYLOG = 1
};

typedef struct zwd_msg_s {
	long mtype;
	union {
		zwd_zylog_t zylog_msg;
	} msg;
} zwd_msg_t;

#endif

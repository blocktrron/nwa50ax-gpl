#ifndef __SCAN_IOCTL_H__
#define __SCAN_IOCTL_H__

#include <string.h>
#include <stdint.h>

int scan_start_scan(const char *vap_ifname, int scan_type, int channel_num, int *channel_list, 
						int active_time, int passive_time,  int home_time);
int scan_get_scanresult(const char *vap_ifname, void **buf);
int scan_flush_scandb(const char *vap_ifname);

#endif


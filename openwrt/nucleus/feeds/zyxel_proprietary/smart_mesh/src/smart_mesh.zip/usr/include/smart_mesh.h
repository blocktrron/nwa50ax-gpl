/****************************************************************************/
/*
* Copyright (C) 2000-2012 ZyXEL Communications, Corp.
* All Rights Reserved.
*
* ZyXEL Confidential;
* Protected as an unpublished work, treated as confidential,
* and hold in trust and in strict confidence by receiving party.
* Only the employees who need to know such ZyXEL confidential information
* to carry out the purpose granted under NDA are allowed to access.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and shall
* not be reproduced, copied, disclosed, or used in whole or in part
* for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/
/****************************************************************************/
#ifndef __SMART_MESH_H__
#define __SMART_MESH_H__

#include "zld-spec.h"

#define	SMESH_OK	0
#define	SMESH_FAIL	1
#define	SMESH_ON	1
#define	SMESH_OFF	0
#define	SMESH_YES	1
#define	SMESH_NO	0
#define	CLOCK_STOP	0
#define	CLOCK_START	1
#define	SMESH_DOWN	1
#define	SMESH_UP	0
#define	REGISTED	1
#define	NOT_REG		0
#define	DIFFERENT	1
#define	SAME		0

#define	SMESH_STR_LEN_8		8
#define	SMESH_STR_LEN_16	16
#define	SMESH_STR_LEN_32	32
#define	SMESH_STR_LEN_64	64
#define	SMESH_STR_LEN_128	128
#define	SMESH_STR_LEN_256	256
#define	SMESH_STR_LEN_512	512
#define	SMESH_MAC_LEN		18

#define	WIFI_CONF			"/var/zyxel/wlan/wlan-"
#define	CAT				"/bin/cat"
#define	ZYSH_BIN			"/bin/zysh"
#define	SMART_MESH_PID			"/var/run/smart_mesh.pid"
#define	SMART_MESH_DETAIL_CONFIG	"/etc/zyxel/ftp/smart_mesh/.smart_mesh_defail.conf"


#ifdef ZLDCONFIG_LEGACY_RW_FILE_PATH
#define	NEBULA_STATUS	"/etc_writable/zyxel/conf/nebula-status"
#define	RESET_FILE	"/etc_writable/zyxel/conf/nebula-reset-status"
#else
#define	NEBULA_STATUS	"/etc/zyxel/ftp/nebula/nebula-status"
#define	RESET_FILE	"/etc/zyxel/ftp/nebula/nebula-reset-status"
#endif
#define	NO_SMESH			"/etc/zyxel/ftp/smart_mesh/no_smesh"
#define	LAN_PORT_SCRIPT			"/usr/sbin/lan_port_op.sh"
#define	S_GEN_WDS_SCRIPT		"/usr/sbin/site_gen_zysh_cmd.sh"
#define	SMESH_WDS_SCRIPT		"/usr/sbin/smesh_sta_gen_zysh_cmd.sh"
#define	CHECK_ETH_SCRIPT		"/usr/sbin/check_ethernet.sh"
#define	ARPING_ETH_CHECK		"/usr/sbin/arping_ethernet_check.sh"
#define	NAP_ROLE_SCRIPT			"/usr/sbin/nap_zysh_cmd.sh"
#define ARPING_GW_CHK_WAR		"/usr/sbin/arping_gw_chk_war.sh"
#define	SMESH_PAP_ACL_SCRIPT		"/usr/sbin/smesh_pap_acl.sh"
#define	SMESH_HELP_VAP_SCRIPT		"/usr/sbin/help_vap.sh"
#define	PATH_CORNTAB			"/var/zyxel/crontab"
#define	MESH_AP_ROLE_FILE		"/etc/zyxel/ftp/smart_mesh/role"
#define	RM_ETH_SCRIPT			"/usr/sbin/remove_eth0_out_br.sh"
#define	ADD_ETH_SCRIPT			"/usr/sbin/add_eth0_to_br.sh"
#define	GET_PING_THROUGHPUT		"/usr/sbin/get_throughput.sh"

#if defined(ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER)
#define	WDS_PREFIX		"wlds-%d-%d"
#define	WDS_AP_PREFIX		"wlds-%d-9"
#define	WDS_STA_PREFIX		"wlds-%d-10"
#define	PAP_PREFIX		"wlpap-%d-11"
#define	PSTA_PREFIX		"wlpsta-%d-12"
#else	/* QCA or MTK */
#define	WDS_PREFIX		"wds-%d-%d"
#define	WDS_AP_PREFIX		"wds-%d-9"
#define	WDS_STA_PREFIX		"wds-%d-10"
#define	PAP_PREFIX		"pap-%d-11"
#if defined(ZLDCONFIG_WLAN_BUILD_MTK_DRIVER)
#define	PSTA_PREFIX		"wds-%d-10"
#else
#define	PSTA_PREFIX		"psta-%d-12"
#endif
#define	IFCONFIG		"/sbin/ifconfig"
#endif

#define	MD5SUM			"/usr/bin/md5sum"
#define	MKDIR			"/bin/mkdir"
#define	SMART_MESH_FOLDER	"/etc/zyxel/ftp/smart_mesh"
#define	SMART_MESH_SITE_ID	"/etc/zyxel/ftp/smart_mesh/site_id"
#define ZON_NO_ZDP_FILE     	"/tmp/.nozdp"
#define	ZON_ZDP_ZYSM_CMD	"configure terminal zon zdp server"
#define	SMESH_TIMER		200
#define	NAP_REGISTERED		"registered"
#define	SLOT1_STRING		"SLOT1"
#define	SLOT2_STRING		"SLOT2"
#define	PROC_VLAN_CONFIG	"/proc/net/vlan/config"
#define	BRCTL			"brctl show"
#define PROC_SYS_CLASS_NET	"/sys/class/net/"

#define SMART_MESK_PSK          	"/etc/zyxel/ftp/smart_mesh/smart-mesh-pap-psk"
#define SMESH_MANUAL_UPLINK		"/etc/zyxel/ftp/smart_mesh/smesh_manual_uplink"
#define SMESH_MANUAL_UPLINK_MAX_RETRY	"/etc/zyxel/ftp/smart_mesh/smesh_manual_uplink_max_retry"
#define SMESH_DOWNLINK			"/etc/zyxel/ftp/smart_mesh/smesh_downlink"
#define SMESH_UPLINK_FALLBACK 		"etc/zyxel/ftp/smart_mesh/fallback"
#define	ACL_PERIOD		10	//minutes
#define	CHECK_PERIOD		3	//minutes
#define	CHECK_TIME		10	//sec

/* Threshold default value */
#if defined(ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER)
#define DEF_CHUTIL_TH_2G	7
#define DEF_CHUTIL_TH_5G	11
#define DEF_CHUTIL_TH_6G	11
#else
#define DEF_CHUTIL_TH_2G	50
#define DEF_CHUTIL_TH_5G	80
#define DEF_CHUTIL_TH_6G	80
#endif
#define DEF_RSSI_TH_2G		(-80)
#define DEF_RSSI_TH_5G		(-75)
#define DEF_RSSI_TH_6G		(-85)
#define DEF_RADIO_BAND_SIG_DIFF	(-15)
#define DEF_PREFER_BAND		"auto"
#if defined(ZLDCONFIG_WLAN_BUILD_MTK_DRIVER)
#define DEF_CHUTIL_TH_WAIT		75
#define MAX_PREP_STATE_RETRY_COUNT	5
#else
#define DEF_CHUTIL_TH_WAIT		40
#define MAX_PREP_STATE_RETRY_COUNT	9
#endif

#define RADIO_PROFILE_2G	"2.4G"
#define RADIO_PROFILE_5G	"5G"
#define RADIO_PROFILE_6G	"6G"
#define RADIO_PROFILE_2g	"2g"
#define RADIO_PROFILE_5g	"5g"
#define RADIO_PROFILE_6g	"6g"

#if defined(ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER)
/* Todo */
#define	WL_CLI			"/usr/sbin/wl"
#define	WHAL_IOCTL		"/usr/local/sbin/whal_ioctl"
#elif defined(ZYUMAC_SUPPORT)
#define	WPA_CLI			"/usr/bin/wpa_cli"
#define	WPA_SUPPLICANT		"/usr/bin/wpa_supplicant"
#define	IWPRIV			"iwpriv"
#define	PROC_NET_WIRELESS	"/proc/net/wireless"
#define	WLANCONFIG		"/sbin/wlanconfig"
#else
#define	WPA_CLI			"/usr/local/bin/wpa_cli"
#define	WPA_SUPPLICANT		"/usr/local/bin/wpa_supplicant"
#define	IWPRIV			"iwpriv"
#define	PROC_NET_WIRELESS	"/proc/net/wireless"
#define	WLANCONFIG		"/sbin/wlanconfig"
#endif /* ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER */

#ifdef ZLDCONFIG_WLAN_DCS_WTP_SUPPORT
#define DOT11_DCS_UP  	"/usr/sbin/dcs_up.sh"
#define DOT11_DCS_DOWN	"/usr/sbin/dcs_down.sh"
#define DCS_CONF_PATH	"/var/zyxel/dcs/dcs-"
#define DCS_PID		"/var/run/dcs"
#endif


#define SLOT1_NUM		1
#define SLOT2_NUM		2
#define CALL_SH_FAIL		127
#define CALL_CMD_FAIL		-1
#define	SEND_EVENT_LEN		256
#define SH_RETURN_1		256
#define SH_RETURN_0		0
#define MAX_VAP_NUM		8
#define MAX_SLOT_NUM	ZLDSYSPARM_WLAN_MAX_SLOT
#define PSK_LEN			64
#define TIMER_TYPE_1		1 // for state time out, or wds station timeout
#define TIMER_TYPE_2		2 // for monitor ethernet.

#define TIMER_RESELECT_RADIO		3	/* for runtime re-select Smart-Mesh used radio */
//#define RESELECT_TIME			1800	/* 30 mins, let 2.4GHz Smart-Mesh link can re-connect to 5GHz */
#define RESELECT_TIME                 30    /* 30 mins, let 2.4GHz Smart-Mesh link can re-connect to 5GHz */

#define TIMER_PERIOD_CHECK_ETH		4	/* for runtime checking eth link status */
//#define ETH_PERIOD_CHECK_TIME		30

#define TIMER_PERIOD_CHECK_ETH_2	5	/* for runtime checking eth link status */
#define ETH_PERIOD_CHECK_TIME_2		30
#define TIMER_TYPE_MAX			6

#define CONFIG_PARAM_NUM		11
#define ZYSH_APPLYING_LOCK		"/var/run/zysh-configuring"
#define ZYSH_CONF_APPLYING_LOCK		"/tmp/zysh-applying.lock"
#define SMESH_WIRELESS_BRIDGE		"/etc/zyxel/ftp/smart_mesh/smesh_wireless_bridge"
#define NO_SMESH_AUTO_DETECT		"/etc/zyxel/ftp/smart_mesh/no_smesh_auto_detect"
#define SERVICE_VAP_DOWN_FLAG		"/etc/zyxel/ftp/smart_mesh/service_vap_down_flag"
#define IP_TYPE         		"/var/zyxel/zysh/IP.type"
#define SM_DBG_FILE_NAME		"/tmp/smart_mesh_dbg_log"
#define DEFAULT_SM_DBG_FILE_SIZE (10 * 1024)    /*10KB*/
#define name_pipe	"/tmp/smart_pipe"

enum{
	NA = -2,
	UNKNOWN,
	WBS_UNSUPPORT,
	WBS_SUPPORT
};

enum{
	AUTO_MODE,
	MANUAL_MODE,
	BACK_AUTO_MODE
};

enum{
	DISABLED = -1,
	UNLIMITED
};

enum{
	WSTA,
	PSTA
};

/* Smart Mesh debug level */
enum SM_DBG_LVL {
	MSG_STATE=1,
	MSG_ERROR,
	MSG_FUNC,
	MSG_EVT,
	MSG_TIMER,
	MSG_ALL
};

typedef struct sm_event_msg_s{
	pid_t pid;
	int32_t code;
	char msg[SEND_EVENT_LEN];
} sm_event_msg_t;

typedef struct sm_wb_info_s{
	int running_status;
	int rt_type;
} sm_wb_info_t;

typedef struct sm_mesh_info_s{
	char site_gen_ssid[SMESH_STR_LEN_32];
	char site_gen_psk[PSK_LEN];
	int eth_ping_pkt_count;
	int wds_link_timeout;
	int eth_link_period_check_time;
	int smesh_link_timeout;
	int chutil_th[ZLDSYSPARM_WLAN_MAX_SLOT];
	int rssi_th[ZLDSYSPARM_WLAN_MAX_SLOT];
	char band_name[ZLDSYSPARM_WLAN_MAX_SLOT][SMESH_STR_LEN_8];
	char prefer_band[6];
	int smart_mesh_switch;
	int radio_band_sig_diff;
	int uplink_mode;
	int fallback_retry_count;
	int current_retry_count;
	int reselect_time;
	int eth_period_check_time;
	int def_chutil_th_wait;
} sm_mesh_info_t;

#define ZYMESH_LOCK_INIT(_LOCK)	(pthread_mutex_init(& _LOCK,NULL))
#define ZYMESH_LOCK_GET(_LOCK)	(pthread_mutex_lock(& _LOCK))
#define ZYMESH_LOCK_PUT(_LOCK)	(pthread_mutex_unlock(& _LOCK))

/* Thread to handle netlink events */
#define NLA_OK(nla,len) \
	((len) > 0 && (nla)->nla_len >= sizeof(struct nlattr) && \
	(nla)->nla_len <= (len))
#define NLA_NEXT(nla,attrlen) \
		((attrlen) -= NLA_ALIGN((nla)->nla_len), \
		(struct nlattr *) (((char *)(nla)) + NLA_ALIGN((nla)->nla_len)))

#define GET_TYPE(date)  (0xFF00&date)
#define GET_SUBTYPE(date)   (0x00FF&date)

struct S_MESH_State {
	int state;
};

typedef struct S_MESHEventMsg_s{
	pid_t pid;
	int32_t code;
	char msg[256];
} S_MESHEventMsg_t;

typedef pthread_mutex_t S_MESHLock_t;
#define S_MESH_EVENT_HOOK_MAX 50
#define S_MESHLIST_CNT(head)			(head.count)
#define S_MESHLOCK_GET(_LOCK)	(pthread_mutex_lock(& _LOCK))
#define S_MESHLOCK_PUT(_LOCK)	(pthread_mutex_unlock(& _LOCK))

#define S_MESHQLIST_FOREACH(head, entry, field)	\
	for (entry = head.listHead;					\
		entry != NULL;						\
		entry = entry->field.next)
		
#define S_MESHQLIST_INSERT(head, entry, field) do {\
		if (((entry->field.next) = head.listHead) != NULL)		\
			(head.listHead)->field.prev = &(entry->field.next); 	\
		head.listHead = entry;						\
		entry->field.prev = &(head.listHead);				\
		head.count++;							\
	} while (0)


#define S_MESHLIST_INSERT(head,entry,field)	do{				\
			entry->field.next = NULL;				\
			if (head.listHead == NULL) head.listHead = entry;	\
			else	 head.listTail->field.next = entry; 		\
			head.listTail = entry; head.count++;			\
}while(0)

#define S_MESHLIST_REMOVE(head,entry,field)	do{				\
				entry = head.listHead;				\
				if (entry) {					\
					head.listHead = entry->field.next;	\
					entry->field.next = NULL;		\
					head.count--;				\
				}						\
}while(0)

#define S_MESHQLIST_HEAD(entryType)			\
	struct {					\
		struct entryType *listHead; 		\
		int32_t count,wm;			\
		void *priv; 				\
	}
#define S_MESHQLIST_REMOVE(head,entry, field) do {			\
	if ((entry->field.next) != NULL)				\
		(entry->field.next)->field.prev = entry->field.prev;	\
	*(entry->field.prev) = (entry->field.next);			\
	head.count--;							\
	if(!head.count)							\
		head.listHead = NULL;					\
} while (0)

#define S_MESHQLIST_INIT(head,watermark)	do{\
		head.listHead = NULL;			\
		head.count = 0; 			\
		head.wm = watermark;			\
		head.priv = NULL;			\
	}while(0)


#define S_MESHQLIST_CNT(head)			(head.count)

typedef void (*mesh_timer_cb_func)(void);

typedef void (*S_MESH_timer_cb_func)(void);

#define S_MESHLIST_INIT(head,watermark)	do{	\
	head.listHead = head.listTail = NULL;	\
	head.count = 0;				\
	head.wm = watermark;			\
	head.priv = NULL;			\
}while(0)

#define S_MESHLIST_ENTRY(entryType)		\
struct {					\
	struct entryType *next;			\
}


#define S_MESHQLIST_ENTRY(entryType)		\
struct {					\
	struct entryType *next;			\
	struct entryType **prev;		\
}

#define S_MESHLIST_HEAD(entryType)		\
struct {					\
	struct entryType *listHead,*listTail;	\
	int32_t count,wm;			\
	void *priv;				\
}


typedef struct S_MESH_Register_Timer_s
{
	S_MESHQLIST_HEAD(S_MESH_Register_Timer_Entry_s) S_MESHRegisterTimerList;
} S_MESH_Register_Timer_t;


typedef struct S_MESH_Register_Timer_Entry_s
{
	S_MESHQLIST_ENTRY(S_MESH_Register_Timer_Entry_s) next;
	mesh_timer_cb_func pFunc;
	int32_t iTimerType;
	int32_t iTime;
	int32_t iTimeCounter;
} S_MESH_Register_Timer_Entry_t;

typedef struct S_MESH_Timers_Exec_Func_Entry_s
{
	S_MESHLIST_ENTRY(S_MESH_Timers_Exec_Func_Entry_s) next;
	mesh_timer_cb_func pFunc;
} S_MESH_Timers_Exec_Func_Entry_t;


typedef struct S_MESH_Timers_Exec_Func_s
{
	S_MESHLIST_HEAD(S_MESH_Timers_Exec_Func_Entry_s) S_MESHTimersExecFuncList;
} S_MESH_Timers_Exec_Func_t;


#define S_MESH_MALLOC_CHECK(name, size, errProc, errRet){name = malloc(size); \
	if(!(name)) { \
		{errProc;} \
		{errRet;} \
	} \
}

#define S_MESH_MEM_FREE(name){ if(name){\
		free(name);\
		name=NULL;\
	}\
}

int32_t S_MESHRegisterTimerAct(S_MESH_timer_cb_func S_MESHFuncPtr, int32_t iTimerType, int32_t iTime);
int32_t S_MESHUnRegisterTimer(int32_t iTimerType);

#define ATTACH_S_MESH_TIMER(callbackfunc, description, time)\
									S_MESHRegisterTimerAct(callbackfunc, description, time);

#define DEATTACH_S_MESH_TIMER(type)\
									S_MESHUnRegisterTimer(type);
#define	EVT_REQUEST_ROLE			1
#define	EVT_SHOW_MACHINE_STATUS			2
#define	EVT_ETH_PING_PKT_COUNT			3
#define	EVT_WDS_TIMEOUT_VALUE			4
#define	EVT_SMART_MESH_DEBUG_LEVEL		5
#define	EVT_ETH_CHECK_PERIOD			6
#define	EVT_SMESH_TIMEOUT_VALUE			7
#define	EVT_SHOW_SMART_MESH_DETAIL_INFO		8
#define	EVT_SMART_MESH_SWITCH			9
#define	EVT_QUERY_WDS_WORKING_SLOT		10
#define	EVT_RELOAD_DCS				11
#define	EVT_UPDATE_SMART_MESH_CONFIG		12
#define	EVT_CONFIG_MESH_ID			13
#define	EVT_FQC_TEST_MODE			14
#define	EVT_MANAGED_VLAN_CHG			15
#define	EVT_PAP_PSK_SECURITY			16
#define	EVT_SMART_MESH_WIRELESS_BIDGE_SWITCH	17
#define	EVT_SMART_MESH_AUTO_DETECT_SWITCH	18
#define EVT_SHOW_WIRELESS_BRIDGE		19
#define	EVT_SMART_MESH_MANUAL_UPLINK_SWITCH	20
#define	EVT_SMART_MESH_DOWNLINK_DISABLE_SWITCH	21
#define EVT_SMART_MESH_RECONNECT_SWITCH		22
#define EVT_SMART_MESH_LOG_SIZE			23
#define EVT_SMART_MESH_DUMP			24
#define EVT_SMART_MESH_MANUAL_UPLINK_RETRY	25
#define EVT_LAN_PORT_SETTING_CHANGE		26

#define	CC_DOWN_COUNT	4
#define PARSER_BAND	0x20220121

/* Function Prototype */
int operate_vap(int slot, const char *vap,int operate);
int operate_service_vap(int slot,int operate);
int operate_mesh_vap(int slot, int operate);
int operate_mesh_sta_vap(int slot, int operate);
void trigger_wpa_supplicant(char *vap_name);
int32_t operate_wds_supplicant(char *vap_name,int operate);
int check_sta_vap_exist(void);
void service_vap_down_flag_create(int create);
int is_smesh_wireless_bridge_enable(void);
int is_smesh_auto_detect_enable(void);
int check_vap_status_is_up(const char *vap_name);
void terminate_wpa_supplicant(char *vap_name);
void reselect_radio_notify(void);

/* State Machine callback function */
int boot_state(void);
int nap_state(void);
int root_state(void);
int repeater_prep_state(void);
int repeater_stable_state(void);
int smesh_repeater_state(void);
int fqc_test_state(void);

struct smart_mesh_ops {
	/* Driver Name & Driver Version */
	const char *chip_vendor;
	const char *driver_vresion;
	const char *driver_name;

	/* API */
	int (*check_sta_vap_exist)(void);
	void (*reselect_radio_notify)(void);
	int (*operate_wds_supplicant)(char *vap_name, int operate);	
	void (*trigger_wpa_supplicant)(char *vap_name);
	void (*terminate_wpa_supplicant)(char *vap_name);
	int (*check_vap_status_is_up)(const char *vap_name);
};

/*========== Global var start ==========*/
enum state_codes {
	BOOTUP=0,
	NAP_STATE,
	ROOT_STATE,
	REPEATER_PREP_STATE,
	REPEATER_STABLE_STATE,
	SMESH_REPEATER_STATE,
	FQC_TEST_STATE,
	UNKNOWN_STATE
};

enum ROLE_STATE {
	AP_MODE=0,
	ROOT_MODE,
	REPEATER_MODE
};

enum event_code {
	INIT_FINISH=0,		/* Init Event Code */
	ETH_ON,			/* Get DHCP IP */
	ETH_OFF,		/* Release DHCP IP */
	S_MESH_STA_UP,		/* pSTA Connection Up */
	S_MESH_STA_DOWN,	/* pSTA Connection Down */
	S_GEN_STA_UP,		/* WDS STA Connection Up */	/* 5 */
	S_GEN_STA_DOWN,		/* WDS STA Connection Down */	
	TIME_OUT,		/* Timeout Event */
	FQC_TEST_MODE,	    	/* For FQC Test or RD internal debug mode */
	NO_MESH_ID_CONF,	/* No mesh-id */
	SMART_MESH_ROOT,	/* Role as Root */				/* 10 */
	SMART_MESH_REPEATER,	/* Role as Repeater */
	SMART_MESH_NORMAL,	/* Role as Root */
	ZYSH_WIFI_APPLYIED,	/* Not Used */
	NCC_CONNECTED,		/* Not Used */
	NCC_NOT_CONNECT,	/* Not Used */	/* 15 */
	DECIDE_BAND,		/* Decided to used which Radio Band for Smart Mesh Link */
	SMART_MESH_ON,		/* Smart Mesh Function Turn-On */
	SMART_MESH_OFF,		/* Smart Mesh Function Turn-Off */
	RESELECT_RADIO,		/* Reselect Smart-Mesh used Radio */
	GET_MESH_ID,		/* Get mesh-id event */
	PAP_PSK_SECURITY,	/* pAP pSTA WPA2-PSK Security */
	SMART_MESH_WIRELESS_BRIDGE_SWITCH_CHANGE,	/* Smart Mesh Wireless Bridge On/Off */
	SMART_MESH_AUTO_DETECT_SWITCH_CHANGE,		/* Smart Mesh Auto Detect On/Off */
	SMART_MESH_MANUAL_UPLINK_CONFIG_CHANGE,		/* Smart Mesh Manual Uplink On/Off */
	SMART_MESH_DOWNLINK_CONFIG_CHANGE,		/* Smart Mesh Downlink On/Off */
	SMART_MESH_RECONNECT_CONFIG_CHANGE,		/* Smart Mesh Manual Uplink Reconnect On/Off */
	SMART_MESH_MANUAL_UPLINK_MAX_RETRY,
	EVENT_MAX	/* 28 */
};

enum band_name{
	BAND_2G=1,
	BAND_5G,
	BAND_6G
};

extern const int ETH_ON_D;
extern const int ETH_OFF_D;
extern const int S_MESH_STA_UP_D;
extern const int S_MESH_STA_DOWN_D;
extern const int S_GEN_STA_UP_D;
extern const int S_GEN_STA_DOWN_D;
extern const int TIME_OUT_D;
extern const int FQC_TEST_MODE_D;
extern const int NO_MESH_ID_CONF_D;
extern const int SMART_MESH_ROOT_D;
extern const int SMART_MESH_REPEATER_D;
extern const int SMART_MESH_NORMAL_D;
extern const int ZYSH_WIFI_APPLYIED_D;
extern const int NCC_CONNECTED_D;
extern const int NCC_NOT_CONNECT_D;
extern const int DECIDE_BAND_D;
extern const int SMART_MESH_ON_D;
extern const int SMART_MESH_OFF_D;
extern const int RESELECT_RADIO_D;
extern const int GET_MESH_ID_D;
extern const int PAP_PSK_SECURITY_D;
extern const int SMART_MESH_WIRELESS_BRIDGE_SWITCH_CHANGE_D;
extern const int SMART_MESH_AUTO_DETECT_SWITCH_CHANGE_D;
extern const int SMART_MESH_MANUAL_UPLINK_CONFIG_CHANGE_D;
extern const int SMART_MESH_DOWNLINK_CONFIG_CHANGE_D;
extern const int SMART_MESH_RECONNECT_CONFIG_CHANGE_D;
extern const int SMART_MESH_MANUAL_UPLINK_MAX_RETRY_D;

extern const char *event_s[EVENT_MAX] ;

/*Create pipe fd*/
extern int event_queue[2];
extern int n_pipe;
extern int working_slot;
extern int psta_working_slot;
/*record what role we decide*/
extern int NAP_ROLE;

/* ===== Smart Mesh Core State Machine ===== */
extern const char *state_s[UNKNOWN_STATE];
extern int repeater_prep_state_retry_count;
extern int Current_Mesh_State;
extern int state_trans_ok;
extern int need_reapply_config;

typedef struct EVENT_RECORD {
	char role[SMESH_STR_LEN_32];
	char slot[SMESH_STR_LEN_32];
	int reg_state;
	int Link_State;
	char machine_status[SMESH_STR_LEN_32];
	char pre_machine_status[SMESH_STR_LEN_32];
	int eth_ping_pkt_count;
	int wds_link_timeout;
	int smesh_link_timeout;
	int eth_link_period_check_time;
	char site_mesh_ssid[SMESH_STR_LEN_32];
	char site_mesh_psk[PSK_LEN];
	int chutil_th[ZLDSYSPARM_WLAN_MAX_SLOT];
	int rssi_th[ZLDSYSPARM_WLAN_MAX_SLOT];
	char band_name[ZLDSYSPARM_WLAN_MAX_SLOT][SMESH_STR_LEN_8];
	char prefer_band[6];
	int smart_mesh_switch;
	int smart_mesh_wireless_bridge_switch;
	int smart_mesh_auto_detect_switch;
	int rt_type;
	int radio_band_sig_diff;
	int smart_mesh_manual_uplink_switch;
	char **uplink_bssid_table;
	int smart_mesh_downlink;
	int reselect_time;
	int eth_period_check_time;
	int def_chutil_th_wait;
} mesh_event_record_t;

mesh_event_record_t mesh_event_record;

S_MESH_Register_Timer_t gRegisterTimerTable;
S_MESHLock_t gTimerListLock;
int32_t gTimerMax;

/* ZyLog */
#define SMESH_APP_ZYLOGGING(pri, arg...) \
	zylog(  ZYLOG_SRC_WLAN_SMART_MESH,    \
			pri,                   \
			ZYLOG_FAC_WLAN_SMART_MESH,    \
			0, 0, 0, 0,            \
			NULL, ##arg)

#define SMESH_APP_ALERT_LOG(arg...)      SMESH_APP_ZYLOGGING(ZYLOG_PRI_ALERT, ##arg)
#define SMESH_APP_ERROR_LOG(arg...)      SMESH_APP_ZYLOGGING(ZYLOG_PRI_ERR, ##arg)
#define SMESH_APP_WARNING_LOG(arg...)    SMESH_APP_ZYLOGGING(ZYLOG_PRI_WARNING, ##arg)
#define SMESH_APP_NOTICE_LOG(arg...)     SMESH_APP_ZYLOGGING(ZYLOG_PRI_NOTICE, ##arg)
#define SMESH_APP_INFO_LOG(arg...)       SMESH_APP_ZYLOGGING(ZYLOG_PRI_INFO, ##arg)
#define SMESH_APP_DEBUG_LOG(arg...)      SMESH_APP_ZYLOGGING(ZYLOG_PRI_DEBUG, ##arg)

#define SMESH_JSON_ZYLOGGING(pri, msg, arg...) \
	zylog_json(ZYLOG_SRC_WLAN_SMART_MESH,    \
	pri,                   \
	ZYLOG_FAC_WLAN_SMART_MESH,    \
	0, 0, 0, 0,            \
	NULL, msg, ##arg)

#define SMESH_JSON_ALERT_LOG(msg, arg...)      SMESH_JSON_ZYLOGGING(ZYLOG_PRI_ALERT, msg, ##arg)
#define SMESH_JSON_ERROR_LOG(msg, arg...)      SMESH_JSON_ZYLOGGING(ZYLOG_PRI_ERR, msg, ##arg)
#define SMESH_JSON_WARNING_LOG(msg, arg...)    SMESH_JSON_ZYLOGGING(ZYLOG_PRI_WARNING, msg, ##arg)
#define SMESH_JSON_NOTICE_LOG(msg, arg...)     SMESH_JSON_ZYLOGGING(ZYLOG_PRI_NOTICE, msg, ##arg)
#define SMESH_JSON_INFO_LOG(msg, arg...)       SMESH_JSON_ZYLOGGING(ZYLOG_PRI_INFO, msg, ##arg)
#define SMESH_JSON_DEBUG_LOG(msg, arg...)      SMESH_JSON_ZYLOGGING(ZYLOG_PRI_DEBUG, msg, ##arg)

extern char wds_up_interface[SMESH_STR_LEN_16];
extern int wireless_bridge_switch_change;
extern int manual_uplink_config_change;
extern int manual_uplink_mode;
extern int downlink_config_change;
extern int reconnect_switch_change;

extern int max_fallback_retry_count;
extern int wireless_bridge_switch_support;

extern char band_name[ZLDSYSPARM_WLAN_MAX_SLOT][SMESH_STR_LEN_8];
extern char *band_name_lower[ZLDSYSPARM_WLAN_MAX_SLOT];
extern int chutil_th_array[ZLDSYSPARM_WLAN_MAX_SLOT];
extern int rssi_th_array[ZLDSYSPARM_WLAN_MAX_SLOT];


extern int user_define;
extern int sm_dbg_log_to_file;
extern int sm_log_file_size;

#define SM_DBG(level, fmt, args...) \
	if (level <= user_define) { \
		if (sm_dbg_log_to_file) { \
			sm_debug_log_to_file("%s:%d : " fmt, __FUNCTION__, __LINE__, ##args); \
		} else { \
			sm_debug_log_to_console("%s:%d : " fmt, __FUNCTION__, __LINE__, ##args); \
		} \
	} \
/*state function*/
extern int (* state[])(void);

/*======main=======*/
void init_config_radio_band(void);
int get_channel_throughput(char *vap_name,int* throughputArry);
int activate_smesh_vap(void);
int read_uplink_bssid_conf(void);
void setup_smart_mesh_default_conf(void);
void read_smart_mesh_conf(void);
int boot_state(void);
int nap_state(void);
int root_state(void);
int discovery_best_mesh_band(int slot, int* last_rssi, int* last_chutil);
int repeater_prep_state(void);
int repeater_stable_state(void);
int smesh_repeater_state(void);
int fqc_test_state(void);
int state_transform(int cur_state, int event);
/*======main=======*/

/*=====common=====*/
void sm_debug_log_to_file(char *fmt, ...);
void sm_debug_log_to_console(char *fmt, ...);
int create_thread(void* (*func_cb)(void*) , void *context);
int32_t create_ipc_socket(const char *path);
int ip_type_is_dhcp(void);
/*
	check /var/zyxel/wlan-x.conf,
	if this conf content wifi vap, return YES
*/
void renew_if_dhcp(const char *interface_name); /* renew dhcp */
int config_lan_port(int op); /* down or up lan port when NAP is connect/disconnect from NCC */
int check_eth_port_status(char *iface);
int is_smesh_disable(void);
#ifdef ZLDCONFIG_WIRELESS_BRIDGE_SUPPORT
void set_wireless_bridge_ie(char *vap_name, int operate);
void set_wireless_bridge_check(int operate);
#endif /* ZLDCONFIG_WIRELESS_BRIDGE_SUPPORT */
int is_nap_registed(void);
void reload_zdp(void);
#ifdef ZLDCONFIG_WLAN_DCS_WTP_SUPPORT
int smart_mesh_exist_dcs(int slot_num);
int smart_mesh_dcs_activate(int slot_num);
int smart_mesh_kill_dcs(int slot_num);
void smart_mesh_dcs_apply(int slot_num);
#endif
int check_role_ssid_psk(int role,const char *ssid, const char *psk);
/*
	input of this function is site id ,
	we will echo site id to a file
	ex:/tmp/smart_mesh/site_id
*/
int create_site_id_file(const char *input);
int check_site_id_file(void);
/*
	binary of md5cum only support file
	Usage: md5sum [-c[sw]] [FILE]...
	so input is site_id, output value
	is site_id calculate by md5cum
*/
int gen_md5sum(const char *input,char *output);
void set_ap_role(int role);
int create_s_gen_vap(int oper);
int check_ethernet(void);
int get_eth_vlan_id(char* eth_name);
void uplink_select_mode(int sta_type, int mode, int wpa_cmd);
int is_feature_change(void);
int repeater_stable_state_sync_eth(void);
int get_radio_band_idx(int slot_num);
void convert2lowerstr(char *string);
/*=====common=====*/

/*=====event=====*/
void init_hyfwd_evt_loop(void);
int32_t net_interface_moniter(void* param);
#if defined(ZLDCONFIG_UBUS_SUPPORT) && defined(ZYUMAC_SUPPORT)
void ubus_event_recv(int ubus_event_type, struct prowlan_req_data *prowlan_req, char *ifi_name);
int ubus_event_register(void);
int UbusEvtLoop(void);
void init_ubus_evt_loop(void);
#endif /* ZLDCONFIG_UBUS_SUPPORT && ZYUMAC_SUPPORT */
#ifdef ZLDCONFIG_WIRELESS_BRIDGE_SUPPORT
void wlan_driver_netlink_event_recv(char *e, char *ifi_name);
int init_wlan_driver_netlink_socket (void);
int wbs_evt_loop(void* param);
#endif /* ZLDCONFIG_WIRELESS_BRIDGE_SUPPORT */
void *monitor_ncc_status(void *priv);
int32_t zysh_evt_loop(void* param);
int32_t S_MESHSupplicantEvtLoop(void* param);
#ifdef ZLDCONFIG_WLAN_HY_FWD
int32_t hy_fwd_evt_loop(void* param);
#endif /* ZLDCONFIG_WLAN_HY_FWD */
void init_zysh_evt_loop(void);
void init_supplicant_evt_loop(void);
void init_net_interface_moniter(void);
void init_ncc_status_moniter(void);
#ifdef ZLDCONFIG_WIRELESS_BRIDGE_SUPPORT
void init_wbs_evt_loop(void);
#endif /* ZLDCONFIG_WIRELESS_BRIDGE_SUPPORT */
int integrate_event(int cur_state, int *event_p);
void get_radio_band_event(void);
/*=====event=====*/

/*=====timer=====*/
void timeout_notify(void);
void arping_check_ethernet(void);
void arping_check_ethernet_2(void);
int S_MESH_Timer(void);
void init_S_MESH_timer(void);
/*=====timer=====*/

/*=====qsdk=====*/
#if defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER)
#if(ZLDSYSPARM_ATHEROS_DRIVER_VERSION == 110)
int check_sta_vap_exist_qsdk(void);
void trigger_wpa_supplicant_qsdk(char *vap_name);
void terminate_wpa_supplicant_qsdk(char *vap_name);
int operate_wds_supplicant_qsdk(char *vap_name,int operate);
void reselect_radio_notify_qsdk(void);
int check_vap_status_is_up_qsdk(const char *vap_name);
#else
int check_sta_vap_exist_lsdk(void);
void trigger_wpa_supplicant_lsdk(char *vap_name);
void terminate_wpa_supplicant_lsdk(char *vap_name);
int operate_wds_supplicant_lsdk(char *vap_name,int operate);
void reselect_radio_notify_lsdk(void);
int check_vap_status_is_up_lsdk(const char *vap_name);
#endif
extern struct smart_mesh_ops *smart_mesh_ops_p;
#endif
/*=====qsdk=====*/

/*=====mtk=====*/
#if defined(ZLDCONFIG_WLAN_BUILD_MTK_DRIVER)
int check_sta_vap_exist_mtk(void);				/* Check if STA VAP exist or not */
void trigger_wpa_supplicant_mtk(char *vap_name);		/* Bring up wpa_supplicant */
void terminate_wpa_supplicant_mtk(char *vap_name);		/* Terminate wpa_supplicant */
int operate_wds_supplicant_mtk(char *vap_name,int operate);	/* operate wpa_supplicant: UP->reconnect, DOWN->disconnect */
void reselect_radio_notify_mtk(void);  				/* Trigger 2.4GHz to do reselect band */
int check_vap_status_is_up_mtk(const char *vap_name); 	
extern struct smart_mesh_ops *smart_mesh_ops_p;
#endif
/*=====mtk=====*/

/*=====brcm=====*/
#if defined(ZLDCONFIG_WLAN_BUILD_BROADCOM_DRIVER)
int check_sta_vap_exist_brcm(void);				/* Check if STA VAP exist or not */
void trigger_wpa_supplicant_brcm(char *vap_name); 		/* Bring up wpa_supplicant */
void terminate_wpa_supplicant_brcm(char *vap_name);		/* Terminate wpa_supplicant */
int operate_wds_supplicant_brcm(char *vap_name,int operate);	/* operate wpa_supplicant: UP->reconnect, DOWN->disconnect */
void reselect_radio_notify_brcm(void);				/* Trigger 2.4GHz to do reselect band */
int check_vap_status_is_up_brcm(const char *vap_name); 
extern struct smart_mesh_ops *smart_mesh_ops_p;
#endif 
/*=====brcm=====*/

/*=====platform=====*/
#if defined(ZLDCONFIG_WLAN_BUILD_ATHEROS_DRIVER) || defined(ZLDCONFIG_WLAN_BUILD_MTK_DRIVER)
int is_wpa_supplicant_exist(char *vap_name);				/* check if wpa_supplicant exist or not */
int check_sta_vap_exist_common(void);					/* Check if STA VAP exist or not */
void trigger_wpa_supplicant_comm(char *vap_name, const char *drv_name);		/* Bring up wpa_supplicant */
void terminate_wpa_supplicant_comm(char *vap_name, const char *drv_name);	/* Terminate wpa_supplicant */
int32_t operate_wds_supplicant_comm(char *vap_name,int operate, const char *drv_name);	/* operate wpa_supplicant: UP->reconnect, DOWN->disconnect */
void reselect_radio_notify_comm(char *vap_name);		/* Trigger 2.4GHz to do reselect band */
int check_vap_status_is_up_comm(const char *vap_name);		/* Check if vap exist and status is up */
#endif

/*=====platform=====*/

#endif /* #ifndef __SMART_MESH_H__ */
